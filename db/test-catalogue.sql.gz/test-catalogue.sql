--
-- PostgreSQL database dump
--


-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: seed; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA seed;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: brand_aliases; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.brand_aliases (
    alias text,
    brand text
);


--
-- Name: families; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.families (
    id smallint,
    name text,
    harshness real
);


--
-- Name: fragrance_accords; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.fragrance_accords (
    fragrance_id integer,
    accord text,
    strength real
);


--
-- Name: fragrance_notes; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.fragrance_notes (
    fragrance_id integer,
    note_id integer,
    layer text
);


--
-- Name: fragrances; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.fragrances (
    id integer,
    slug text,
    name text,
    brand text,
    gender text,
    release_year smallint,
    image_url text,
    community_rating real,
    rating_votes integer,
    profile real[],
    facets jsonb,
    harshness real,
    strength smallint,
    seasons jsonb,
    daynight jsonb,
    search_vector tsvector
);


--
-- Name: name_aliases; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.name_aliases (
    alias text,
    name_word text
);


--
-- Name: notes; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.notes (
    id integer,
    name text,
    mapped boolean,
    profile real[],
    facets jsonb,
    harshness real
);


--
-- Name: pair_scores; Type: TABLE; Schema: seed; Owner: -
--

CREATE TABLE seed.pair_scores (
    base_id integer,
    partner_id integer,
    goal text,
    score real,
    rank integer
);


--
-- Data for Name: brand_aliases; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.brand_aliases (alias, brand) FROM stdin;
YSL	Yves Saint Laurent
JPG	Jean Paul Gaultier
D&G	Dolce&Gabbana
DG	Dolce&Gabbana
CDG	Comme des Garcons
MFK	Maison Francis Kurkdjian
PDM	Parfums de Marly
TF	Tom Ford
MMM	Maison Martin Margiela
Margiela	Maison Martin Margiela
CK	Calvin Klein
DKNY	Donna Karan
LV	Louis Vuitton
ADP	Acqua di Parma
V&R	Viktor&Rolf
Bulgari	Bvlgari
Christian Dior	Dior
Paco Rabanne	Rabanne
Thierry Mugler	Mugler
Mont Blanc	Montblanc
\.


--
-- Data for Name: families; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.families (id, name, harshness) FROM stdin;
0	Soft Amber	0.15
1	Amber	0.25
2	Woody Amber	0.6
3	Woods	0.4
4	Mossy Woods	0.5
5	Dry Woods	0.8
6	Aromatic Fougère	0.5
7	Citrus	0.6
8	Water	0.4
9	Green	0.7
10	Fruity	0.3
11	Floral	0.3
12	Soft Floral	0.15
13	Floral Amber	0.3
\.


--
-- Data for Name: fragrance_accords; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.fragrance_accords (fragrance_id, accord, strength) FROM stdin;
1	citrus	100
1	woody	64
1	fresh	47
1	fruity	41
1	aromatic	34
1	musky	28
1	powdery	24
1	green	20
2	white floral	100
2	amber	61
2	floral	20
2	animalic	17
2	powdery	13
2	fresh	10
2	woody	6
2	soft spicy	6
3	sweet	100
3	vanilla	74
3	fruity	51
3	patchouli	40
3	woody	39
3	white floral	35
3	powdery	33
3	iris	27
4	sweet	100
4	patchouli	47
4	fruity	45
4	warm spicy	44
4	caramel	42
4	vanilla	38
4	woody	36
4	honey	29
5	vanilla	100
5	coffee	82
5	sweet	76
5	white floral	67
5	warm spicy	64
5	soft spicy	51
5	woody	49
5	fruity	46
6	fresh spicy	100
6	amber	58
6	citrus	56
6	aromatic	48
6	musky	39
6	woody	35
6	lavender	24
6	herbal	22
7	citrus	100
7	woody	47
7	patchouli	46
7	sweet	45
7	white floral	42
7	rose	33
7	earthy	27
7	vanilla	26
8	warm spicy	100
8	earthy	78
8	woody	77
8	sweet	65
8	amber	52
8	patchouli	49
8	floral	46
8	chocolate	45
9	vanilla	100
9	sweet	92
9	tobacco	79
9	warm spicy	60
9	fruity	44
9	woody	35
9	cacao	33
9	powdery	28
10	vanilla	100
10	aromatic	91
10	green	85
10	fresh spicy	52
10	amber	46
10	citrus	37
10	fruity	37
10	woody	33
11	vanilla	100
11	sweet	80
11	almond	79
11	fruity	63
11	nutty	56
11	powdery	55
11	woody	46
11	coconut	43
12	sweet	100
12	warm spicy	75
12	vanilla	72
12	amber	66
12	cinnamon	55
12	woody	27
12	fresh spicy	26
12	fruity	20
13	white floral	100
13	floral	82
13	fruity	74
13	sweet	49
13	fresh	48
13	citrus	36
13	aquatic	36
13	powdery	31
14	woody	100
14	amber	98
14	warm spicy	58
14	metallic	24
14	fresh spicy	23
14	aromatic	22
14	white floral	22
14	animalic	22
15	citrus	100
15	fruity	58
15	leather	45
15	smoky	36
15	woody	36
15	aromatic	34
15	sweet	31
15	fresh	30
16	citrus	100
16	woody	88
16	fresh spicy	70
16	aromatic	66
16	earthy	43
16	warm spicy	35
16	patchouli	19
16	sweet	19
17	aromatic	100
17	fresh spicy	98
17	woody	73
17	fruity	59
17	fresh	52
17	amber	52
17	citrus	46
17	herbal	39
18	warm spicy	100
18	vanilla	72
18	lavender	52
18	aromatic	51
18	powdery	50
18	iris	48
18	woody	41
18	amber	36
19	fruity	100
19	sweet	55
19	woody	54
19	leather	48
19	citrus	42
19	smoky	38
19	musky	36
19	fresh	32
20	woody	100
20	vanilla	69
20	balsamic	67
20	warm spicy	59
20	amber	48
20	powdery	41
20	nutty	32
20	musky	23
21	vanilla	100
21	sweet	88
21	amber	60
21	cinnamon	57
21	warm spicy	53
21	powdery	41
21	aromatic	37
21	soft spicy	35
22	vanilla	100
22	sweet	73
22	honey	58
22	aromatic	43
22	amber	42
22	lavender	35
22	tobacco	29
22	green	26
23	sweet	100
23	white floral	99
23	warm spicy	89
23	vanilla	89
23	amber	56
23	cacao	53
23	woody	52
23	tuberose	47
24	amber	100
24	citrus	88
24	fresh spicy	64
24	musky	59
24	aquatic	57
24	warm spicy	49
24	woody	35
24	fresh	32
25	citrus	100
25	aromatic	51
25	marine	40
25	fresh spicy	29
25	floral	24
25	woody	22
25	fresh	21
25	white floral	17
26	woody	100
26	aromatic	71
26	earthy	34
26	musky	29
26	fresh spicy	18
26	green	16
26	amber	10
26	powdery	8
27	aromatic	100
27	vanilla	94
27	fresh spicy	66
27	lavender	64
27	warm spicy	58
27	green	53
27	powdery	38
27	sweet	35
28	fresh spicy	100
28	warm spicy	91
28	white floral	87
28	coconut	76
28	lactonic	52
28	woody	47
28	powdery	46
28	fresh	41
29	aromatic	100
29	warm spicy	79
29	lavender	55
29	woody	52
29	fresh spicy	47
29	citrus	27
29	earthy	14
29	herbal	12
30	iris	100
30	woody	75
30	powdery	68
30	earthy	55
30	aromatic	51
30	violet	50
30	floral	48
30	lavender	47
31	floral	100
31	fresh	43
31	citrus	43
31	woody	30
31	rose	23
31	fresh spicy	22
31	aquatic	21
31	musky	16
32	warm spicy	100
32	cinnamon	73
32	citrus	62
32	amber	47
32	woody	45
32	leather	39
32	rose	32
32	animalic	29
33	floral	100
33	rose	81
33	fresh	56
33	fruity	21
33	white floral	21
33	tropical	18
33	woody	14
33	amber	12
34	woody	100
34	floral	73
34	sweet	45
34	powdery	42
34	amber	38
34	fruity	35
34	violet	27
34	fresh spicy	24
35	warm spicy	100
35	woody	100
35	sweet	86
35	vanilla	73
35	cinnamon	69
35	amber	30
35	powdery	26
35	nutty	19
36	citrus	100
36	green	61
36	powdery	37
36	woody	37
36	white floral	34
36	fresh	33
36	aromatic	32
36	fresh spicy	26
37	leather	100
37	woody	87
37	ozonic	73
37	fresh spicy	68
37	aromatic	64
37	animalic	63
37	aquatic	54
37	floral	52
38	citrus	100
38	amber	85
38	woody	64
38	fresh spicy	58
38	aromatic	45
38	warm spicy	31
38	fresh	29
38	smoky	29
39	white floral	100
39	citrus	73
39	lavender	65
39	vanilla	49
39	aromatic	39
39	sweet	37
39	powdery	33
39	animalic	32
40	citrus	100
40	aromatic	57
40	fresh spicy	45
40	floral	28
40	rose	24
40	green	20
40	fresh	19
40	musky	18
41	tobacco	100
41	sweet	84
41	vanilla	76
41	rum	74
41	woody	59
41	aromatic	53
41	soft spicy	49
41	amber	30
42	citrus	100
42	woody	75
42	fresh spicy	72
42	aromatic	57
42	amber	53
42	smoky	32
42	balsamic	29
42	warm spicy	29
43	floral	100
43	patchouli	64
43	white floral	57
43	woody	41
43	powdery	40
43	citrus	39
43	sweet	35
43	musky	33
44	sweet	100
44	honey	83
44	vanilla	80
44	tobacco	59
44	lavender	59
44	citrus	57
44	aromatic	53
44	floral	39
45	musky	100
45	powdery	63
45	white floral	56
45	citrus	52
45	floral	51
45	fruity	42
45	woody	37
45	amber	33
46	aromatic	100
46	green	61
46	marine	54
46	fresh spicy	49
46	lavender	35
46	woody	33
46	salty	22
46	fresh	18
47	green	100
47	fruity	48
47	floral	37
47	fresh	30
47	powdery	29
47	musky	25
47	aquatic	25
47	woody	23
48	citrus	100
48	aromatic	50
48	fresh spicy	39
48	woody	34
48	floral	31
48	green	27
48	fresh	19
48	sweet	18
49	floral	100
49	fruity	76
49	citrus	72
49	sweet	62
49	fresh spicy	58
49	powdery	57
49	white floral	49
49	musky	48
50	woody	100
50	vanilla	89
50	aromatic	73
50	soft spicy	71
50	fruity	63
50	green	62
50	floral	58
50	rose	56
51	fruity	100
51	ozonic	84
51	aquatic	79
51	green	32
51	sweet	30
51	fresh	29
51	tropical	28
51	aromatic	24
52	citrus	100
52	fresh spicy	59
52	vanilla	58
52	aromatic	57
52	woody	47
52	warm spicy	33
52	sweet	23
52	powdery	23
53	warm spicy	100
53	fresh spicy	74
53	woody	70
53	aromatic	69
53	lavender	66
53	soft spicy	55
53	cinnamon	44
53	amber	35
54	warm spicy	100
54	fresh spicy	85
54	woody	83
54	vanilla	81
54	aromatic	74
54	fruity	62
54	powdery	57
54	lavender	48
55	sweet	100
55	woody	96
55	coconut	88
55	amber	68
55	vanilla	60
55	tropical	55
55	fruity	54
55	powdery	40
56	woody	100
56	aromatic	92
56	earthy	68
56	violet	58
56	floral	52
56	powdery	48
56	fresh	32
56	green	25
57	leather	100
57	animalic	59
57	warm spicy	41
57	white floral	38
57	amber	34
57	smoky	30
57	earthy	25
57	mossy	24
58	citrus	100
58	amber	98
58	woody	81
58	vanilla	74
58	powdery	71
58	balsamic	71
58	smoky	63
58	leather	52
59	vanilla	100
59	amber	47
59	warm spicy	43
59	fruity	39
59	cinnamon	36
59	sweet	36
59	lavender	34
59	fresh	30
60	cherry	100
60	sweet	88
60	almond	78
60	nutty	65
60	fruity	60
60	vanilla	48
60	warm spicy	40
60	amber	35
61	floral	100
61	fresh	57
61	green	32
61	musky	17
61	fruity	15
61	rose	13
61	soft spicy	11
61	powdery	11
62	woody	100
62	citrus	96
62	aromatic	81
62	amber	69
62	musky	55
62	fresh spicy	48
62	soft spicy	46
62	oud	46
63	white floral	100
63	citrus	51
63	woody	30
63	powdery	18
63	animalic	18
63	sweet	15
63	amber	13
63	lactonic	12
64	sweet	100
64	lactonic	49
64	vanilla	43
64	coconut	34
64	musky	24
64	lavender	19
64	nutty	17
64	powdery	16
65	woody	100
65	warm spicy	69
65	oud	69
65	aromatic	50
65	vanilla	44
65	balsamic	41
65	fresh spicy	39
65	amber	34
66	vanilla	100
66	fruity	72
66	aromatic	72
66	sweet	70
66	cinnamon	58
66	warm spicy	56
66	fresh spicy	48
66	lavender	47
67	green	100
67	fruity	95
67	aquatic	91
67	ozonic	89
67	fresh	79
67	citrus	51
67	white floral	40
67	floral	36
68	citrus	100
68	aromatic	100
68	green	94
68	white floral	56
68	fresh spicy	47
68	woody	42
68	fresh	26
68	sweet	20
69	vanilla	100
69	tobacco	89
69	warm spicy	67
69	sweet	62
69	cinnamon	45
69	powdery	30
69	fresh spicy	21
69	whiskey	17
70	fruity	100
70	white floral	80
70	vanilla	70
70	powdery	53
70	sweet	51
70	amber	36
70	citrus	32
70	fresh	28
71	citrus	100
71	aromatic	63
71	woody	55
71	fruity	35
71	fresh spicy	32
71	tropical	28
71	warm spicy	25
71	fresh	21
72	sweet	100
72	fruity	64
72	tropical	35
72	fresh	27
72	chocolate	20
72	floral	18
72	powdery	15
72	musky	14
73	powdery	100
73	iris	82
73	violet	77
73	woody	68
73	fresh spicy	49
73	warm spicy	44
73	aromatic	40
73	earthy	38
74	caramel	100
74	powdery	73
74	amber	51
74	sweet	50
74	vanilla	49
74	musky	39
74	warm spicy	26
74	balsamic	25
75	citrus	100
75	green	89
75	aromatic	61
75	fresh spicy	47
75	fresh	38
75	ozonic	15
75	white floral	15
75	floral	12
76	aromatic	100
76	marine	59
76	fresh spicy	55
76	amber	46
76	woody	42
76	smoky	41
76	warm spicy	40
76	citrus	39
77	amber	100
77	tobacco	90
77	fresh spicy	79
77	citrus	77
77	aromatic	77
77	warm spicy	58
77	sweet	55
77	woody	40
78	vanilla	100
78	lavender	60
78	woody	58
78	aromatic	54
78	powdery	50
78	balsamic	42
78	sweet	42
78	warm spicy	35
79	soft spicy	100
79	sweet	83
79	powdery	78
79	anis	66
79	violet	51
79	vanilla	49
79	floral	38
79	iris	33
80	powdery	100
80	floral	84
80	violet	80
80	rose	62
80	amber	57
80	musky	55
80	vanilla	54
80	sweet	45
81	woody	100
81	fresh spicy	56
81	aromatic	45
81	oud	36
81	green	27
81	amber	25
81	earthy	25
81	warm spicy	24
82	fruity	100
82	sweet	95
82	amber	92
82	white floral	83
82	woody	79
82	warm spicy	71
82	balsamic	58
82	tuberose	58
83	fruity	100
83	sweet	69
83	woody	30
83	powdery	29
83	musky	29
83	vanilla	16
83	amber	14
83	cherry	13
84	aromatic	100
84	salty	72
84	marine	70
84	citrus	62
84	musky	58
84	herbal	55
84	soft spicy	39
84	floral	32
85	warm spicy	100
85	sweet	82
85	vanilla	74
85	cinnamon	49
85	coffee	44
85	amber	31
85	powdery	21
85	aromatic	19
86	citrus	100
86	aromatic	55
86	vanilla	53
86	aldehydic	52
86	marine	46
86	sweet	40
86	fresh spicy	34
86	fresh	31
87	citrus	100
87	marine	83
87	aromatic	78
87	fresh spicy	57
87	woody	43
87	salty	36
87	amber	35
87	white floral	28
88	citrus	100
88	aromatic	78
88	floral	68
88	fresh spicy	63
88	green	56
88	fruity	49
88	tropical	48
88	powdery	45
89	woody	100
89	citrus	95
89	aromatic	46
89	floral	36
89	musky	33
89	powdery	33
89	earthy	29
89	white floral	25
90	vanilla	100
90	floral	85
90	white floral	71
90	fruity	51
90	sweet	50
90	powdery	30
90	tropical	26
90	woody	25
91	sweet	100
91	caramel	60
91	vanilla	35
91	fruity	30
91	soft spicy	25
91	powdery	24
91	balsamic	14
91	citrus	10
92	citrus	100
92	sweet	94
92	fresh	92
92	fruity	81
92	woody	61
92	green	48
92	floral	40
92	lactonic	33
93	vanilla	100
93	white floral	74
93	sweet	49
93	fruity	26
93	amber	24
93	aromatic	23
93	citrus	23
93	powdery	20
94	citrus	100
94	fruity	84
94	vanilla	65
94	soft spicy	39
94	aromatic	39
94	sweet	38
94	white floral	37
94	powdery	37
95	amber	100
95	woody	70
95	musky	60
95	balsamic	50
95	warm spicy	30
96	amber	100
96	vanilla	75
96	powdery	28
96	sweet	26
96	aromatic	16
96	balsamic	15
96	lavender	14
96	animalic	13
97	fresh spicy	100
97	citrus	75
97	amber	61
97	lavender	39
97	musky	36
97	aromatic	31
97	herbal	30
97	anis	27
98	floral	100
98	fresh spicy	78
98	citrus	56
98	fruity	54
98	fresh	45
98	tropical	35
98	white floral	25
98	musky	25
99	white floral	100
99	tuberose	51
99	sweet	30
99	citrus	28
99	woody	27
99	patchouli	25
99	vanilla	24
99	fruity	24
100	amber	100
100	fresh spicy	90
100	tobacco	89
100	aromatic	83
100	citrus	80
100	sweet	58
100	warm spicy	52
100	woody	41
108	citrus	100
108	white floral	76
108	patchouli	33
108	fresh spicy	31
108	woody	26
108	sweet	23
108	soapy	19
108	aromatic	19
126	fruity	100
126	powdery	97
126	floral	72
126	sweet	57
126	rose	45
126	vanilla	44
126	woody	36
126	amber	25
155	marine	100
155	aromatic	98
155	citrus	72
155	fresh spicy	53
155	fresh	49
155	woody	44
155	mineral	42
155	salty	24
171	amber	100
171	almond	93
171	woody	78
171	warm spicy	78
171	musky	69
171	animalic	59
171	nutty	56
171	fruity	46
176	fruity	100
176	citrus	95
176	aquatic	80
176	fresh	71
176	warm spicy	49
176	sweet	40
176	amber	39
176	musky	36
182	fruity	100
182	rose	67
182	sweet	61
182	soft spicy	47
182	aromatic	37
182	floral	31
182	woody	31
182	fresh	30
184	vanilla	100
184	sweet	44
184	balsamic	37
184	nutty	34
184	aromatic	32
184	lavender	27
184	powdery	27
184	herbal	24
185	woody	100
185	citrus	59
185	aromatic	48
185	amber	40
185	fresh spicy	37
185	powdery	27
185	warm spicy	26
185	green	24
187	woody	100
187	citrus	90
187	fruity	78
187	mossy	76
187	earthy	67
187	floral	64
187	sweet	51
187	powdery	40
219	vanilla	100
219	woody	89
219	balsamic	76
219	rum	71
219	aromatic	64
219	warm spicy	55
219	nutty	42
219	powdery	41
222	fresh	100
222	floral	97
222	fruity	94
222	aquatic	83
222	ozonic	72
222	sweet	68
222	white floral	47
222	citrus	39
230	floral	100
230	white floral	93
230	fresh	73
230	green	62
230	rose	42
230	soft spicy	26
230	powdery	21
230	woody	21
285	fruity	100
285	citrus	89
285	sweet	39
285	fresh	34
285	aromatic	32
285	musky	29
285	powdery	27
285	fresh spicy	27
335	amber	100
335	vanilla	96
335	sweet	71
335	aromatic	50
335	warm spicy	43
335	balsamic	40
335	lavender	36
335	almond	30
358	aromatic	100
358	fresh spicy	67
358	marine	45
358	woody	38
358	citrus	31
358	amber	24
358	patchouli	23
358	warm spicy	22
455	citrus	100
455	woody	74
455	amber	63
455	aromatic	63
455	vanilla	58
455	fresh spicy	53
455	warm spicy	45
455	powdery	44
488	warm spicy	100
488	amber	80
488	balsamic	47
488	woody	36
488	powdery	29
488	earthy	26
488	smoky	22
488	cinnamon	22
593	white floral	100
593	vanilla	75
593	woody	63
593	citrus	50
593	amber	46
593	sweet	45
593	fresh spicy	43
593	warm spicy	33
640	floral	100
640	fresh	86
640	white floral	84
640	green	52
640	rose	38
640	fruity	34
640	sweet	32
640	vodka	32
647	aromatic	100
647	woody	71
647	amber	63
647	fresh spicy	57
647	aldehydic	53
647	fresh	41
647	floral	40
647	citrus	32
785	aromatic	100
785	woody	96
785	citrus	68
785	fresh spicy	59
785	amber	59
785	marine	56
785	fruity	37
785	warm spicy	31
868	amber	100
868	citrus	92
868	coconut	73
868	sweet	39
868	lactonic	26
868	vanilla	22
868	tropical	22
868	animalic	20
882	aromatic	100
882	marine	57
882	mineral	46
882	citrus	42
882	fresh spicy	27
882	lavender	24
882	salty	23
882	woody	23
901	woody	100
901	citrus	74
901	mossy	58
901	earthy	51
901	fresh spicy	31
901	fruity	30
901	patchouli	28
901	sweet	27
921	woody	100
921	fresh spicy	43
921	aromatic	35
921	warm spicy	24
921	powdery	24
921	amber	14
921	smoky	13
921	balsamic	12
\.


--
-- Data for Name: fragrance_notes; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.fragrance_notes (fragrance_id, note_id, layer) FROM stdin;
1	2	base
1	4	heart
1	5	base
1	8	base
1	8	top
1	15	top
1	53	top
1	165	heart
1	168	top
1	384	heart
2	5	base
2	64	top
2	68	heart
3	3	base
3	4	heart
3	7	base
3	10	base
3	14	heart
3	16	heart
3	29	top
3	33	top
3	65	base
4	1	top
4	2	base
4	3	base
4	4	heart
4	4	top
4	5	base
4	6	base
4	7	base
4	9	heart
4	10	base
4	12	top
4	18	heart
4	23	heart
4	44	heart
4	46	heart
4	48	base
4	51	heart
4	52	top
4	63	heart
4	69	top
4	88	heart
4	92	top
4	96	heart
4	100	heart
4	112	heart
4	126	top
4	209	base
4	216	top
5	3	base
5	4	heart
5	7	base
5	8	base
5	14	top
5	20	top
5	29	top
5	68	base
5	73	heart
5	79	heart
5	123	heart
6	1	top
6	7	heart
6	8	base
6	11	heart
6	13	heart
6	20	heart
6	31	heart
6	36	base
6	54	top
6	57	base
6	134	heart
6	340	heart
7	1	top
7	3	base
7	4	heart
7	7	base
7	9	heart
7	10	base
7	11	base
7	12	top
7	14	top
7	24	base
7	30	heart
7	45	top
7	76	heart
7	84	base
8	1	top
8	3	base
8	4	heart
8	4	top
8	5	base
8	6	base
8	7	base
8	11	base
8	12	top
8	15	top
8	21	base
8	24	base
8	30	heart
8	30	top
8	33	top
8	51	heart
8	62	heart
8	62	top
8	74	heart
8	97	heart
8	242	heart
8	286	base
8	362	top
9	3	heart
9	10	heart
9	56	base
9	98	top
9	102	heart
9	133	top
9	228	base
9	358	heart
10	3	base
10	8	base
10	10	heart
10	11	base
10	15	top
10	19	base
10	31	heart
10	36	heart
10	38	top
10	145	top
11	2	base
11	3	base
11	4	heart
11	6	base
11	9	heart
11	18	heart
11	32	heart
11	46	top
11	67	heart
11	69	top
11	77	base
11	88	heart
11	100	top
12	1	top
12	3	base
12	10	base
12	17	top
12	25	base
12	32	heart
12	44	top
12	65	heart
12	66	base
12	110	base
12	150	base
12	224	heart
12	276	heart
13	1	top
13	2	base
13	3	base
13	4	heart
13	8	base
13	9	heart
13	12	top
13	18	heart
13	23	top
13	27	heart
13	29	top
13	32	heart
13	41	heart
13	46	heart
13	51	heart
13	58	top
13	92	top
13	112	base
14	4	top
14	8	base
14	19	base
14	36	base
14	40	top
14	47	heart
14	66	heart
14	108	base
14	128	heart
14	236	base
15	1	top
15	2	base
15	3	base
15	4	heart
15	7	base
15	9	heart
15	15	top
15	33	top
15	47	base
15	52	top
15	53	top
15	148	heart
16	7	base
16	8	base
16	11	base
16	25	base
16	26	top
16	45	top
16	54	heart
16	238	heart
16	310	heart
17	1	top
17	8	base
17	10	base
17	11	base
17	31	heart
17	34	top
17	53	top
17	59	heart
17	66	base
17	83	heart
17	117	base
18	3	base
18	13	heart
18	16	heart
18	22	top
18	56	base
18	300	base
19	1	top
19	2	base
19	4	heart
19	7	heart
19	8	base
19	15	top
19	19	base
19	20	top
19	33	top
19	36	base
19	52	heart
19	53	top
19	148	base
20	3	base
20	14	top
20	20	top
20	49	heart
20	68	base
20	78	top
20	83	heart
20	113	heart
20	313	base
21	3	base
21	5	base
21	10	base
21	13	heart
21	17	heart
21	20	top
21	27	top
21	59	heart
21	83	top
21	120	base
21	140	heart
22	3	heart
22	10	base
22	13	top
22	25	heart
22	38	top
22	60	base
22	63	base
23	1	top
23	2	base
23	3	base
23	5	base
23	6	base
23	7	base
23	8	base
23	9	heart
23	10	base
23	14	heart
23	15	top
23	16	heart
23	17	base
23	32	heart
23	64	heart
23	65	base
23	68	base
23	73	top
23	77	top
23	102	base
24	1	top
24	2	base
24	7	heart
24	10	base
24	21	base
24	26	top
24	36	heart
24	40	base
24	99	heart
24	115	top
24	124	heart
24	136	top
24	305	heart
25	1	top
25	4	heart
25	4	top
25	5	base
25	7	base
25	8	base
25	9	heart
25	12	top
25	15	top
25	19	base
25	23	heart
25	24	base
25	27	heart
25	35	top
25	37	heart
25	41	heart
25	44	heart
25	45	top
25	55	heart
25	87	heart
25	104	heart
25	118	heart
25	130	top
25	135	heart
25	287	heart
26	2	base
26	11	heart
26	68	base
26	91	top
27	1	top
27	3	base
27	5	base
27	6	base
27	8	base
27	10	base
27	13	top
27	14	heart
27	17	heart
27	22	top
27	38	top
27	88	heart
27	122	top
28	2	base
28	5	base
28	6	base
28	14	heart
28	22	top
28	34	top
28	39	heart
28	54	top
28	62	heart
28	69	heart
29	1	heart
29	8	heart
29	11	base
29	13	heart
29	22	top
29	88	base
30	8	base
30	11	base
30	13	top
30	16	heart
30	29	heart
30	86	heart
31	2	base
31	5	base
31	39	heart
31	58	heart
31	74	heart
31	131	base
31	262	top
31	322	top
31	393	top
32	5	base
32	7	base
32	9	heart
32	17	heart
32	26	top
32	28	base
32	38	top
32	56	base
32	133	heart
32	177	top
33	5	base
33	8	base
33	9	heart
33	18	heart
33	39	top
33	41	top
33	58	heart
33	106	top
34	5	base
34	74	heart
34	131	base
34	142	base
34	170	heart
34	174	base
34	201	heart
34	247	top
34	312	top
34	322	top
35	3	base
35	6	base
35	10	heart
35	17	heart
35	65	base
35	128	heart
35	189	base
35	215	top
35	295	heart
36	1	top
36	2	base
36	4	heart
36	5	base
36	6	base
36	8	base
36	9	heart
36	12	top
36	15	top
36	16	heart
36	18	heart
36	19	base
36	22	top
36	27	heart
36	41	heart
36	42	top
36	44	heart
36	52	top
36	127	base
36	247	base
36	303	top
37	1	top
37	2	base
37	4	heart
37	5	base
37	6	heart
37	7	base
37	8	heart
37	8	top
37	10	base
37	11	base
37	12	top
37	13	top
37	15	top
37	18	heart
37	28	base
37	44	heart
37	61	heart
37	82	heart
37	99	heart
37	200	top
37	255	top
37	294	top
38	1	top
38	4	heart
38	5	base
38	6	base
38	7	base
38	8	base
38	15	top
38	20	top
38	21	base
38	26	top
38	34	heart
38	37	top
38	38	top
38	44	heart
38	57	base
38	66	base
38	81	top
38	92	heart
39	2	base
39	3	base
39	4	heart
39	8	base
39	12	top
39	13	heart
39	13	top
39	14	heart
39	33	top
39	47	base
39	95	top
40	1	top
40	2	base
40	5	base
40	8	heart
40	9	top
40	10	base
40	15	top
40	31	heart
40	35	top
40	72	heart
40	135	heart
41	3	base
41	11	heart
41	15	top
41	20	top
41	35	top
41	72	heart
41	85	heart
41	98	base
41	346	base
42	4	heart
42	6	base
42	7	base
42	8	base
42	11	base
42	15	top
42	20	top
42	21	base
42	24	base
42	26	top
42	34	heart
42	38	top
42	44	heart
42	57	base
42	105	heart
43	1	top
43	2	base
43	3	base
43	4	heart
43	7	base
43	9	heart
43	14	heart
43	41	heart
43	51	heart
43	94	top
43	351	top
44	1	top
44	3	base
44	10	base
44	13	top
44	15	top
44	17	heart
44	63	heart
44	64	heart
44	68	heart
44	98	base
45	1	top
45	2	heart
45	3	base
45	5	heart
45	7	base
45	11	base
45	14	top
45	94	top
46	2	base
46	4	heart
46	6	heart
46	8	base
46	13	top
46	19	base
46	31	heart
46	35	heart
46	37	top
46	38	top
46	42	top
46	47	base
46	55	top
46	60	base
46	87	top
46	339	top
47	2	base
47	5	base
47	8	base
47	19	base
47	53	top
47	74	heart
47	76	heart
47	249	top
48	1	top
48	2	base
48	5	base
48	6	base
48	8	base
48	11	base
48	12	top
48	15	top
48	17	heart
48	18	heart
48	31	heart
48	37	top
48	40	heart
48	44	heart
48	59	top
48	60	base
48	87	top
48	91	top
48	180	heart
48	271	top
48	287	heart
48	350	top
48	393	top
49	2	base
49	4	heart
49	5	base
49	8	base
49	16	base
49	26	top
49	135	heart
49	147	top
50	3	base
50	7	base
50	9	heart
50	36	base
50	41	heart
50	56	base
50	126	top
51	2	base
51	4	heart
51	6	base
51	20	top
51	104	heart
51	139	top
51	268	top
51	270	base
51	372	heart
52	3	base
52	6	base
52	7	base
52	8	base
52	9	heart
52	10	base
52	12	top
52	15	top
52	19	base
52	31	heart
52	55	top
52	208	top
52	275	top
52	311	heart
53	5	base
53	6	base
53	7	base
53	11	base
53	13	heart
53	17	top
53	22	top
53	26	top
53	44	top
53	79	base
54	1	top
54	3	base
54	4	heart
54	6	base
54	7	base
54	12	top
54	13	top
54	22	base
54	27	heart
54	31	heart
54	49	base
54	53	top
54	54	base
54	90	base
54	155	base
55	5	base
55	6	base
55	10	base
55	16	top
55	34	top
55	47	base
55	52	top
55	56	heart
55	69	heart
55	91	top
56	1	top
56	8	base
56	11	base
56	27	heart
56	104	heart
56	152	top
56	183	top
57	5	base
57	7	base
57	22	top
57	28	heart
57	64	heart
57	93	base
58	1	top
58	2	base
58	3	base
58	4	heart
58	6	base
58	7	heart
58	8	top
58	9	heart
58	10	base
58	11	heart
58	12	top
58	15	top
58	16	heart
58	21	base
58	28	base
58	84	base
58	89	top
58	103	base
59	1	top
59	3	base
59	5	base
59	7	base
59	10	base
59	14	heart
59	17	top
59	18	heart
59	53	top
59	389	top
60	3	base
60	6	base
60	7	base
60	8	base
60	9	heart
60	10	base
60	11	base
60	17	base
60	25	base
60	46	heart
60	64	heart
60	78	base
60	123	top
60	132	heart
60	169	top
60	204	top
60	313	base
61	2	flat
61	5	flat
61	8	flat
61	39	flat
61	94	flat
61	95	flat
61	250	flat
61	309	flat
61	352	flat
61	390	flat
62	1	top
62	7	base
62	11	heart
62	20	top
62	28	heart
62	36	base
62	72	top
62	110	base
62	185	base
63	1	top
63	4	top
63	6	base
63	8	base
63	12	top
63	14	heart
63	24	base
63	45	top
63	62	heart
63	375	base
64	1	top
64	2	base
64	13	top
64	29	top
64	56	base
64	65	heart
64	69	heart
64	142	heart
64	365	heart
65	3	flat
65	5	flat
65	6	flat
65	10	flat
65	11	flat
65	22	flat
65	67	flat
65	71	flat
65	340	flat
66	1	top
66	5	base
66	7	base
66	8	base
66	13	top
66	15	top
66	17	heart
66	29	top
66	38	top
66	72	heart
66	88	heart
66	173	base
67	5	base
67	6	base
67	9	heart
67	18	heart
67	26	top
67	27	heart
67	32	heart
67	56	base
67	58	top
67	145	heart
67	219	top
68	8	base
68	15	top
68	38	top
68	57	base
68	182	base
68	370	heart
69	3	flat
69	17	flat
69	40	flat
69	60	flat
69	181	flat
69	220	flat
70	1	top
70	2	base
70	3	base
70	4	heart
70	5	base
70	11	base
70	12	top
70	18	heart
70	23	top
70	46	heart
70	50	heart
70	106	top
71	1	top
71	2	base
71	5	base
71	8	heart
71	15	top
71	22	top
71	40	base
71	54	heart
71	56	base
71	59	heart
71	67	top
71	193	top
71	347	base
71	350	heart
72	2	base
72	4	heart
72	16	base
72	51	heart
72	56	base
72	147	top
72	221	heart
72	268	top
72	327	top
72	377	heart
73	5	base
73	6	base
73	7	base
73	8	base
73	16	heart
73	22	top
73	27	heart
73	31	heart
73	35	top
73	124	top
73	195	top
73	284	heart
74	2	heart
74	3	base
74	25	base
74	48	top
74	323	heart
75	1	top
75	2	base
75	2	heart
75	4	base
75	4	heart
75	5	base
75	15	top
75	19	base
75	19	heart
75	38	top
75	45	top
75	61	heart
75	78	base
75	88	base
75	127	base
75	139	top
75	198	base
75	232	heart
75	375	heart
76	1	top
76	7	base
76	21	base
76	31	heart
76	55	heart
76	59	heart
76	118	top
77	5	base
77	8	base
77	14	heart
77	22	heart
77	26	top
77	34	heart
77	37	top
77	60	base
77	75	top
78	1	top
78	3	base
78	6	base
78	7	base
78	9	heart
78	13	top
78	16	heart
78	25	base
78	64	heart
78	79	base
78	90	base
79	3	base
79	10	base
79	11	base
79	16	heart
79	24	base
79	27	top
79	65	base
79	79	heart
79	119	top
79	154	heart
79	202	heart
79	265	top
80	3	base
80	4	heart
80	9	heart
80	9	top
80	12	top
80	21	base
80	24	base
80	33	top
80	84	heart
80	255	top
80	306	heart
81	7	flat
81	11	flat
81	36	flat
81	56	flat
81	75	flat
81	110	flat
81	357	flat
82	2	base
82	3	base
82	4	heart
82	5	base
82	6	base
82	8	base
82	9	heart
82	11	base
82	14	heart
82	17	heart
82	21	heart
82	32	heart
82	37	top
82	43	base
82	46	top
82	61	heart
82	67	top
82	84	heart
82	111	top
82	137	heart
82	388	top
83	2	base
83	3	base
83	4	heart
83	5	base
83	7	base
83	12	top
83	15	top
83	19	base
83	27	heart
83	33	top
83	56	base
83	68	base
83	70	top
83	107	top
83	112	top
83	132	top
84	26	flat
84	59	flat
84	86	flat
84	143	flat
84	149	flat
85	2	base
85	3	base
85	10	base
85	17	top
85	22	top
85	25	base
85	34	top
85	65	heart
85	73	base
85	190	heart
85	378	heart
86	3	base
86	5	base
86	8	heart
86	10	base
86	11	base
86	24	base
86	35	heart
86	45	top
86	54	heart
86	81	top
86	118	top
86	134	base
86	177	top
87	4	heart
87	7	base
87	12	top
87	19	base
87	26	top
87	47	base
87	49	base
87	118	top
87	166	heart
88	2	base
88	16	base
88	17	base
88	21	base
88	26	top
88	39	heart
88	45	heart
88	57	base
88	74	heart
88	135	heart
88	184	heart
88	194	top
88	252	top
88	360	top
89	4	heart
89	5	base
89	7	base
89	8	top
89	11	base
89	15	top
89	16	base
89	20	heart
89	24	base
89	210	top
89	354	base
89	369	heart
90	3	base
90	4	heart
90	11	base
90	62	heart
90	307	top
91	1	top
91	2	base
91	3	base
91	6	base
91	10	base
91	18	heart
91	45	top
91	48	base
91	70	top
91	79	heart
91	96	heart
91	107	heart
91	115	top
91	216	heart
92	2	base
92	8	base
92	15	top
92	39	heart
92	65	heart
92	130	top
92	145	heart
92	161	base
92	225	heart
93	3	base
93	4	heart
93	6	base
93	9	heart
93	10	base
93	14	heart
93	112	top
93	277	top
93	293	heart
93	341	top
94	1	top
94	2	base
94	3	base
94	4	heart
94	5	base
94	8	base
94	9	heart
94	10	base
94	12	top
94	18	heart
94	26	top
94	33	top
94	45	top
94	50	heart
94	100	heart
94	125	top
95	199	flat
96	2	base
96	3	base
96	5	base
96	8	base
96	10	base
96	13	heart
96	25	heart
96	45	top
96	57	top
97	1	top
97	3	base
97	13	heart
97	36	base
97	44	heart
97	119	heart
97	340	heart
98	2	base
98	4	base
98	4	heart
98	5	base
98	12	heart
98	34	heart
98	41	top
98	54	heart
98	58	heart
98	106	top
99	1	top
99	3	base
99	7	base
99	11	base
99	14	heart
99	29	top
99	32	heart
99	36	base
99	64	heart
100	5	base
100	8	base
100	14	heart
100	22	heart
100	26	top
100	34	heart
100	37	top
100	60	base
100	75	top
108	1	top
108	7	base
108	14	heart
108	157	base
126	1	top
126	2	base
126	3	base
126	4	heart
126	5	base
126	6	base
126	9	heart
126	9	top
126	16	heart
126	18	top
126	23	base
126	23	top
126	43	heart
126	52	top
126	100	base
126	129	top
126	163	top
155	1	top
155	2	base
155	5	base
155	7	base
155	13	heart
155	55	heart
155	91	heart
155	118	top
155	164	top
155	251	top
155	283	heart
155	289	base
171	2	base
171	4	heart
171	8	heart
171	36	base
171	40	top
171	47	base
171	56	base
171	68	base
171	123	top
176	1	top
176	2	base
176	7	base
176	14	heart
176	15	top
176	17	top
176	22	heart
176	46	heart
176	47	base
176	53	top
176	136	heart
176	229	base
182	2	base
182	3	base
182	4	heart
182	8	base
182	9	top
182	20	heart
182	39	heart
182	70	top
182	126	heart
184	3	base
184	13	heart
184	59	heart
184	108	top
184	113	top
184	343	base
185	1	top
185	6	base
185	8	base
185	10	base
185	13	heart
185	15	top
185	31	heart
185	38	top
185	42	heart
185	52	heart
185	66	base
185	105	base
185	122	top
187	1	top
187	4	heart
187	6	base
187	7	base
187	9	heart
187	15	top
187	19	base
187	23	heart
187	24	base
187	41	heart
187	45	top
187	66	base
187	290	top
219	1	top
219	3	base
219	7	base
219	8	base
219	13	heart
219	85	top
219	113	base
219	134	top
219	226	heart
222	2	base
222	3	base
222	4	heart
222	6	base
222	9	heart
222	11	base
222	15	top
222	18	heart
222	23	base
222	33	top
222	50	top
222	52	top
222	63	heart
222	70	base
222	74	heart
222	74	top
222	87	top
222	92	top
222	112	base
222	141	heart
222	147	top
222	255	heart
222	367	base
230	2	base
230	4	heart
230	6	base
230	7	base
230	8	base
230	9	heart
230	18	heart
230	20	top
230	27	top
230	31	heart
230	32	top
230	39	heart
230	41	top
230	42	top
230	50	heart
230	96	top
230	99	top
230	129	heart
230	267	heart
285	1	top
285	2	base
285	5	base
285	14	heart
285	15	top
285	22	heart
285	46	heart
285	53	top
285	93	base
285	119	top
285	229	base
335	3	base
335	10	base
335	13	top
335	77	base
335	150	heart
358	1	top
358	7	base
358	31	heart
358	55	heart
358	72	heart
358	117	base
358	3171	top
455	1	top
455	3	base
455	6	heart
455	10	base
455	12	top
455	117	base
455	134	top
488	1	top
488	2	base
488	3	base
488	4	heart
488	5	base
488	7	base
488	9	heart
488	11	base
488	13	top
488	17	heart
488	18	heart
488	19	base
488	21	base
488	23	top
488	30	heart
488	45	top
488	51	heart
488	78	heart
488	80	top
488	81	top
488	97	top
488	125	heart
488	133	heart
488	313	base
488	359	base
488	3037	top
593	3	base
593	5	base
593	7	base
593	14	heart
593	56	base
593	124	top
640	2	base
640	4	heart
640	5	base
640	6	base
640	8	base
640	9	heart
640	15	top
640	18	heart
640	23	top
640	27	top
640	30	heart
640	39	top
640	41	heart
640	50	heart
640	52	top
640	87	heart
640	135	heart
640	346	base
640	2952	top
640	3192	top
647	5	base
647	7	base
647	8	base
647	11	base
647	12	top
647	17	heart
647	21	base
647	37	heart
647	44	heart
647	57	base
647	58	heart
647	81	top
647	88	heart
647	159	top
647	284	top
647	351	top
647	373	heart
647	3133	heart
785	1	top
785	7	base
785	10	base
785	13	heart
785	15	top
785	26	top
785	29	top
785	31	heart
785	53	top
785	55	heart
785	56	base
785	57	base
785	66	base
785	118	top
868	5	base
868	251	top
868	3040	heart
882	7	base
882	11	base
882	13	heart
882	31	heart
882	72	heart
882	118	top
882	251	top
882	289	base
901	1	top
901	4	heart
901	5	base
901	7	heart
901	8	heart
901	19	base
901	26	top
901	52	top
901	56	base
921	1	flat
921	6	flat
921	7	flat
921	8	flat
921	11	flat
921	21	flat
921	44	flat
921	49	flat
921	68	flat
921	71	flat
921	88	flat
921	91	flat
921	275	flat
\.


--
-- Data for Name: fragrances; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.fragrances (id, slug, name, brand, gender, release_year, image_url, community_rating, rating_votes, profile, facets, harshness, strength, seasons, daynight, search_vector) FROM stdin;
1	dolce-gabbana-light-blue-2001	Light Blue	Dolce&Gabbana	female	2001	https://fimgs.net/mdimg/perfume/375x500.485.jpg	3.8634	36883	{0.05139665,0,0.03575419,0.12290503,0,0.03575419,0.12653631,0.3187151,0.05251397,0.06368715,0.11452514,0.013407821,0.06480447,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.145251}	0.45332402	1	{"autumn": 0.06860255296397781, "spring": 0.3072244870681013, "summer": 0.5627213794025262, "winter": 0.06145158056539464}	{"day": 0.8905199462124608, "night": 0.10948005378753922}	'blue':2 'd':5 'dg':7 'dolce':3 'g':6 'gabbana':4 'light':1
2	mugler-alien-2005	Alien	Mugler	female	2005	https://fimgs.net/mdimg/perfume/375x500.707.jpg	3.9876	36095	{0.081974246,0.17896996,0.094420604,0.015450643,0,0.027038626,0.012875536,0.012875536,0.017167382,0,0,0.33733904,0.13090129,0.09098712}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.025751, "sweet": 0.0, "creamy": 0.0, "powdery": 0.055794}	0.3061588	4	{"autumn": 0.3287680274578397, "spring": 0.17233754661562325, "summer": 0.09989769314544074, "winter": 0.3989967327810963}	{"day": 0.3251581864770172, "night": 0.6748418135229828}	'alien':1 'mugler':2,4 'thierry':3
6	dior-sauvage-2015	Sauvage	Dior	male	2015	https://fimgs.net/mdimg/perfume/375x500.31861.jpg	3.8496	34238	{0.071204185,0.09109948,0.048691098,0.07539267,0,0.070680626,0.33455497,0.22513089,0,0.042408377,0,0,0.040837698,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.26178, "sweet": 0.0, "creamy": 0.0, "powdery": 0.102094}	0.51149213	3	{"autumn": 0.26174822562570044, "spring": 0.2831341053418005, "summer": 0.2636906985431453, "winter": 0.19142697048935375}	{"day": 0.5229242819843342, "night": 0.4770757180156658}	'christian':3 'dior':2,4 'sauvage':1 'savage':5
7	chanel-coco-mademoiselle-2001	Coco Mademoiselle	Chanel	female	2001	https://fimgs.net/mdimg/perfume/375x500.611.jpg	4.1034	33428	{0.10409836,0.044945356,0.063387975,0.07704918,0.107103825,0.07295082,0,0.27322406,0,0.007377049,0.030737706,0.13196722,0.05,0.03715847}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.193989, "creamy": 0.0, "powdery": 0.0}	0.4053757	4	{"autumn": 0.28354397646830654, "spring": 0.30200084041762293, "summer": 0.17083104373404015, "winter": 0.24362413938003039}	{"day": 0.5961432809581365, "night": 0.40385671904186354}	'chanel':3 'coco':1 'mademoiselle':2
8	tom-ford-black-orchid-2006	Black Orchid	Tom Ford	female	2006	https://fimgs.net/mdimg/perfume/375x500.1018.jpg	3.8828	32626	{0.21464844,0.11025391,0.21386719,0.09023438,0.13925782,0.09492187,0,0,0,0.015234375,0.03173828,0.071875,0.01796875,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.195312, "sweet": 0.214844, "creamy": 0.0, "powdery": 0.0}	0.4005127	4	{"autumn": 0.37425374468237227, "spring": 0.11246559182068423, "summer": 0.06413327136881994, "winter": 0.44914739212812355}	{"day": 0.2249120252396554, "night": 0.7750879747603446}	'black':1 'ford':4 'orchid':2 'tf':5 'tom':3
9	tom-ford-tobacco-vanille-2007	Tobacco Vanille	Tom Ford	unisex	2007	https://fimgs.net/mdimg/perfume/375x500.1825.jpg	4.1681	31666	{0.32887474,0.15562633,0.19617835,0.044585988,0,0.048407644,0,0,0,0,0.14225054,0.0118895965,0.02972399,0.042462844}	{"sharp": 0.0, "smoky": 0.167728, "spicy": 0.127389, "sweet": 0.477707, "creamy": 0.0, "powdery": 0.059448}	0.28252655	4	{"autumn": 0.38934194843485354, "spring": 0.08296217301298538, "summer": 0.05147104949501286, "winter": 0.47622482905714825}	{"day": 0.28829665228551143, "night": 0.7117033477144885}	'ford':4 'tf':5 'tobacco':1 'tom':3 'tv':7 'vanilla':6 'vanille':2
10	versace-eros-2012	Eros	Versace	male	2012	https://fimgs.net/mdimg/perfume/375x500.16657.jpg	4.0542	30827	{0.14386694,0.0989605,0.03284823,0.04116424,0,0.035343036,0.24074844,0.10935551,0,0.17920998,0.07692308,0,0,0.04158004}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.108108, "sweet": 0.2079, "creamy": 0.0, "powdery": 0.0}	0.43239084	3	{"autumn": 0.25650163166429757, "spring": 0.27462011251476504, "summer": 0.22166609942140983, "winter": 0.2472121563995275}	{"day": 0.4468229697587496, "night": 0.5531770302412504}	'eros':1 'versace':2
11	dior-hypnotic-poison-1998	Hypnotic Poison	Dior	female	1998	https://fimgs.net/mdimg/perfume/375x500.219.jpg	4.0842	30582	{0.40881225,0.07662835,0.03908046,0.13180077,0,0.017624522,0,0,0,0,0.21398467,0.021072797,0.052681994,0.038314175}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.578544, "creamy": 0.340996, "powdery": 0.105364}	0.060948275	3	{"autumn": 0.3534977759805904, "spring": 0.09874646178730287, "summer": 0.0627982207844723, "winter": 0.4849575414476345}	{"day": 0.2760228827260291, "night": 0.7239771172739708}	'christian':4 'dior':3,5 'hypnotic':1 'poison':2
12	lattafa-perfumes-khamrah-2022	Khamrah	Lattafa Perfumes	unisex	2022	https://fimgs.net/mdimg/perfume/375x500.75805.jpg	4.2133	30398	{0.33424038,0.21655329,0.20657596,0.036734693,0,0.02403628,0.029478459,0.017687075,0,0,0.10204082,0,0,0.03265306}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.353741, "sweet": 0.390023, "creamy": 0.0, "powdery": 0.0}	0.30295917	4	{"autumn": 0.37978466271149197, "spring": 0.0880685563612393, "summer": 0.054581410678971654, "winter": 0.4775653702482971}	{"day": 0.30519559653897715, "night": 0.6948044034610229}	'kamrah':4 'khamrah':1 'lattafa':2 'perfumes':3
13	dior-j-adore-1999	J'adore	Dior	female	1999	https://fimgs.net/mdimg/perfume/375x500.210.jpg	3.795	29804	{0.07412281,0.026864035,0,0,0,0,0.031578947,0.110526316,0.12105263,0,0.18914473,0.28903508,0.11381579,0.04385965}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.107456, "creamy": 0.0, "powdery": 0.067982}	0.29035637	2	{"autumn": 0.2529251415391067, "spring": 0.3540364856364018, "summer": 0.21287481652338017, "winter": 0.18016355630111133}	{"day": 0.6161911894873017, "night": 0.38380881051269833}	'adore':2 'christian':4 'dior':3,5 'j':1 'jadore':6
14	maison-francis-kurkdjian-baccarat-rouge-540-2015	Baccarat Rouge 540	Maison Francis Kurkdjian	unisex	2015	https://fimgs.net/mdimg/perfume/375x500.33519.jpg	3.7481	29764	{0.11598916,0.17723577,0.22547425,0.16260162,0,0.10406504,0.07886179,0.018699188,0.032520324,0.024932249,0,0.035772357,0.01192412,0.01192412}	{"sharp": 0.065041, "smoky": 0.0, "spicy": 0.219512, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.48842818	4	{"autumn": 0.32884672203801585, "spring": 0.20751124388562425, "summer": 0.13367913069170415, "winter": 0.3299629033846558}	{"day": 0.43161021984551395, "night": 0.568389780154486}	'540':3 'baccarat':1 'br540':8 'francis':5 'kurkdjian':6 'maison':4 'mfk':7 'rouge':2
15	armaf-club-de-nuit-intense-man-2015	Club de Nuit Intense Man	Armaf	male	2015	https://fimgs.net/mdimg/perfume/375x500.34696.jpg	4.0684	29183	{0.04189189,0.020945946,0.107027024,0.05837838,0,0.15081081,0.097837836,0.2945946,0.032432433,0.018378379,0.17770271,0,0,0}	{"sharp": 0.0, "smoky": 0.218919, "spicy": 0.0, "sweet": 0.083784, "creamy": 0.0, "powdery": 0.0}	0.5625338	4	{"autumn": 0.2537243696874944, "spring": 0.29192948406922203, "summer": 0.2839146764425755, "winter": 0.17043146980070803}	{"day": 0.5322297632842244, "night": 0.46777023671577556}	'armaf':6 'cdnim':7 'club':1 'de':2 'intense':4 'man':5 'nuit':3
16	hermes-terre-d-hermes-2006	Terre d'Hermès	Hermès	male	2006	https://fimgs.net/mdimg/perfume/375x500.17.jpg	4.2782	29017	{0.053409092,0.0107954545,0.10068182,0.12,0.08022727,0.10977273,0.19954546,0.275,0,0.039772727,0.0107954545,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.238636, "sweet": 0.043182, "creamy": 0.0, "powdery": 0.0}	0.5700625	2	{"autumn": 0.2970620774431469, "spring": 0.3023478795328826, "summer": 0.23948371235402582, "winter": 0.16110633066994468}	{"day": 0.6488153998025666, "night": 0.35118460019743336}	'd':2 'hermes':3,4 'terre':1
17	yves-saint-laurent-y-eau-de-parfum-2018	Y Eau de Parfum	Yves Saint Laurent	male	2018	https://fimgs.net/mdimg/perfume/375x500.50757.jpg	4.4149	28789	{0.020038536,0.060115606,0.048169557,0.08439306,0,0.06589595,0.33121386,0.17533718,0.04007707,0.061079,0.113680154,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.188825, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52543354	3	{"autumn": 0.24687985605626891, "spring": 0.29915760202829805, "summer": 0.2955262942667866, "winter": 0.15843624764864644}	{"day": 0.5567725332663821, "night": 0.4432274667336179}	'de':3 'eau':2 'edp':9 'laurent':7 'parfum':4 'saint':6 'y':1 'ysl':8 'yves':5
18	jean-paul-gaultier-le-male-le-parfum-2020	Le Male Le Parfum	Jean Paul Gaultier	male	2020	https://fimgs.net/mdimg/perfume/375x500.61856.jpg	4.5871	28689	{0.23422222,0.08,0.16755556,0.05466667,0,0.018222222,0.20622222,0,0,0.022666667,0,0.054222222,0.13022222,0.032}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.222222, "sweet": 0.16, "creamy": 0.0, "powdery": 0.217778}	0.32515556	3	{"autumn": 0.3546778376221823, "spring": 0.16918013165769, "summer": 0.05976461200877718, "winter": 0.4163774187113505}	{"day": 0.2959121877365632, "night": 0.7040878122634368}	'gaultier':7 'jean':5 'jpg':8 'le':1,3 'lmw':9 'male':2 'parfum':4 'paul':6
19	creed-aventus-2010	Aventus	Creed	male	2010	https://fimgs.net/mdimg/perfume/375x500.9828.jpg	4.3158	28444	{0.10345679,0.033950616,0.11160494,0.09777778,0,0.15407407,0.023703704,0.1274074,0.03160494,0,0.2808642,0,0.035555556,0}	{"sharp": 0.0, "smoky": 0.212346, "spicy": 0.0, "sweet": 0.135802, "creamy": 0.0, "powdery": 0.088889}	0.45646295	2	{"autumn": 0.2339781210385464, "spring": 0.30860603784215224, "summer": 0.3179961500539931, "winter": 0.13941969106530824}	{"day": 0.5935460961427493, "night": 0.40645390385725066}	'aventus':1 'creed':2
20	maison-martin-margiela-by-the-fireplace-2015	By the Fireplace	Maison Martin Margiela	unisex	2015	https://fimgs.net/mdimg/perfume/375x500.31623.jpg	4.2031	27061	{0.285877,0.17334852,0.20842825,0.1690205,0,0.045558088,0,0,0,0,0,0.018678816,0.06765376,0.03143508}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.134396, "sweet": 0.157175, "creamy": 0.072893, "powdery": 0.145786}	0.29279044	2	{"autumn": 0.4411195379684575, "spring": 0.04563196141275029, "summer": 0.02833751150318916, "winter": 0.4849109891156031}	{"day": 0.30338047602621593, "night": 0.696619523973784}	'by':1 'fireplace':3 'maison':4 'margiela':6,8 'martin':5 'mmm':7 'the':2
21	giorgio-armani-emporio-armani-stronger-with-you-intensely-2019	Emporio Armani Stronger With You Intensely	Giorgio Armani	male	2019	https://fimgs.net/mdimg/perfume/375x500.52802.jpg	4.5759	26525	{0.37876856,0.20191082,0.17579618,0,0,0,0.062845014,0,0,0.015711254,0.046709128,0.017409766,0.043524414,0.05732484}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.307856, "sweet": 0.399151, "creamy": 0.0, "powdery": 0.087049}	0.25144374	4	{"autumn": 0.3874133806811176, "spring": 0.07477004266232645, "summer": 0.038396093807797585, "winter": 0.49942048284875834}	{"day": 0.30042252306631023, "night": 0.6995774769336898}	'armani':2,8 'emporio':1 'giorgio':7 'intensely':6 'stronger':3 'swy':9 'with':4 'you':5
22	jean-paul-gaultier-le-male-elixir-2023	Le Male Elixir	Jean Paul Gaultier	male	2023	https://fimgs.net/mdimg/perfume/375x500.81642.jpg	4.5028	26052	{0.32980296,0.2205665,0.056403942,0,0,0.014285714,0.18374385,0,0,0.072413795,0.04495074,0,0,0.07783251}	{"sharp": 0.0, "smoky": 0.071429, "spicy": 0.0, "sweet": 0.568966, "creamy": 0.0, "powdery": 0.0}	0.2333436	4	{"autumn": 0.3566501071268806, "spring": 0.12155957902667577, "summer": 0.0577778824194194, "winter": 0.46401243142702425}	{"day": 0.29850746268656714, "night": 0.7014925373134329}	'elixir':3 'gaultier':6 'jean':4 'jpg':7 'le':1 'lmw':8 'male':2 'paul':5
23	carolina-herrera-good-girl-2016	Good Girl	Carolina Herrera	female	2016	https://fimgs.net/mdimg/perfume/375x500.39681.jpg	3.9508	25832	{0.30205128,0.14871795,0.15538462,0.053333335,0,0.017777778,0,0,0,0,0.042735044,0.14974359,0.033846155,0.09641026}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.152137, "sweet": 0.413675, "creamy": 0.0, "powdery": 0.0}	0.24310257	3	{"autumn": 0.3595417321531971, "spring": 0.15447927868310035, "summer": 0.09186036893043263, "winter": 0.39411862023326993}	{"day": 0.28316378090682476, "night": 0.7168362190931752}	'carolina':3 'girl':2 'good':1 'herrera':4
24	versace-versace-pour-homme-dylan-blue-2016	Versace Pour Homme Dylan Blue	Versace	male	2016	https://fimgs.net/mdimg/perfume/375x500.40031.jpg	4.1906	25758	{0.13057852,0.12396694,0.11652893,0.067768596,0,0.04090909,0.08595041,0.24132231,0.14421488,0,0,0,0.048760332,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.233471, "sweet": 0.0, "creamy": 0.0, "powdery": 0.121901}	0.4498347	2	{"autumn": 0.24686117062816637, "spring": 0.30575301868279303, "summer": 0.31174032319429706, "winter": 0.1356454874947436}	{"day": 0.562731109700071, "night": 0.43726889029992905}	'blue':5 'dylan':4 'homme':3 'pour':2 'versace':1,6
25	giorgio-armani-acqua-di-gio-1996	Acqua di Gio	Giorgio Armani	male	1996	https://fimgs.net/mdimg/perfume/375x500.410.jpg	4.1253	25724	{0,0,0.014473684,0.043421052,0,0.03355263,0.20263158,0.37828946,0.15921053,0.03355263,0,0.096710525,0.026973683,0.011184211}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.095395, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.51907897	1	{"autumn": 0.09405549166187464, "spring": 0.3500215641173088, "summer": 0.5057863714778609, "winter": 0.05013657274295572}	{"day": 0.8227680262659427, "night": 0.17723197373405733}	'acqua':1 'adg':7 'aqua':6 'armani':5 'di':2 'gio':3 'giorgio':4
26	lalique-encre-noire-2006	Encre Noire	Lalique	male	2006	https://fimgs.net/mdimg/perfume/375x500.1834.jpg	4.1381	25605	{0.055944055,0.02097902,0.07692308,0.23006994,0.07132867,0.11818182,0.24125874,0.01888112,0,0.10629371,0,0.005594406,0.054545455,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.062937, "sweet": 0.0, "creamy": 0.0, "powdery": 0.129371}	0.4882867	2	{"autumn": 0.3903061224489796, "spring": 0.19048656047784968, "summer": 0.08035714285714286, "winter": 0.33885017421602787}	{"day": 0.43463681107685653, "night": 0.5653631889231435}	'encre':1 'lalique':3 'noire':2
27	jean-paul-gaultier-le-male-1995	Le Male	Jean Paul Gaultier	male	1995	https://fimgs.net/mdimg/perfume/375x500.430.jpg	3.997	25575	{0.21358268,0.054232284,0.06850394,0,0,0.025984252,0.36929134,0.03897638,0,0.122834645,0.017224409,0.01496063,0.037401576,0.037007876}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.244094, "sweet": 0.253937, "creamy": 0.0, "powdery": 0.074803}	0.4024754	3	{"autumn": 0.2830687830687831, "spring": 0.25849121010411336, "summer": 0.17087671388746659, "winter": 0.287563292939637}	{"day": 0.49218232747644514, "night": 0.5078176725235549}	'gaultier':5 'jean':3 'jpg':6 'le':1 'lmw':7 'male':2 'paul':4
28	versace-crystal-noir-2004	Crystal Noir	Versace	female	2004	https://fimgs.net/mdimg/perfume/375x500.631.jpg	3.9409	25212	{0.21148148,0,0.11851852,0.09962963,0,0.054444443,0.11537037,0.07833333,0.03037037,0,0.04222222,0.113703705,0.1037037,0.032222223}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.353704, "sweet": 0.140741, "creamy": 0.237037, "powdery": 0.085185}	0.3397963	3	{"autumn": 0.3517733660495204, "spring": 0.13611420923488735, "summer": 0.11755520856569261, "winter": 0.39455721614989964}	{"day": 0.28066054523453626, "night": 0.7193394547654637}	'crystal':1 'noir':2 'versace':3
29	yves-saint-laurent-la-nuit-de-l-homme-2009	La Nuit de l'Homme	Yves Saint Laurent	male	2009	https://fimgs.net/mdimg/perfume/375x500.5521.jpg	4.4482	24999	{0.08186529,0,0.14974093,0.08082902,0.021761658,0.062176164,0.43238342,0.10647669,0,0.06476684,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.326425, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.569456	1	{"autumn": 0.34939904208211586, "spring": 0.2126999427659126, "summer": 0.09479772268578486, "winter": 0.3431032924661867}	{"day": 0.2791680950748486, "night": 0.7208319049251514}	'de':3 'homme':5 'l':4 'la':1 'laurent':8 'nuit':2 'saint':7 'ysl':9 'yves':6
30	dior-dior-homme-intense-2011-2011	Dior Homme Intense 2011	Dior	male	2011	https://fimgs.net/mdimg/perfume/375x500.13016.jpg	4.4911	24842	{0.041295547,0,0.030364372,0.091093116,0.06680162,0.06376518,0.1777328,0,0,0.05202429,0,0.18623482,0.29068825,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.441296}	0.3038259	3	{"autumn": 0.3626625638643753, "spring": 0.1578901532745007, "summer": 0.06348699489084998, "winter": 0.415960287970274}	{"day": 0.29786549393971895, "night": 0.702134506060281}	'2011':4 'christian':6 'dior':1,5,7 'homme':2 'intense':3
31	versace-bright-crystal-2006	Bright Crystal	Versace	female	2006	https://fimgs.net/mdimg/perfume/375x500.632.jpg	3.7415	24512	{0.02147651,0,0.020134227,0.07114094,0,0.034899328,0.08020134,0.20973155,0.12818792,0,0,0.3224832,0.11174497,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.073826, "sweet": 0.0, "creamy": 0.0, "powdery": 0.053691}	0.40541947	1	{"autumn": 0.08616926282369283, "spring": 0.44399245956940175, "summer": 0.3965671197539438, "winter": 0.07327115785296161}	{"day": 0.8663655685441021, "night": 0.13363443145589798}	'bright':1 'crystal':2 'versace':3
32	rabanne-1-million-2008	1 Million	Rabanne	male	2008	https://fimgs.net/mdimg/perfume/375x500.3747.jpg	3.7321	24418	{0.1498829,0.13770492,0.3327869,0.06323185,0,0.096252926,0,0.14519906,0,0,0,0.052459016,0.022482436,0}	{"sharp": 0.0, "smoky": 0.091335, "spicy": 0.405152, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.54871196	4	{"autumn": 0.35323798172427495, "spring": 0.14664282876440207, "summer": 0.08379022646007152, "winter": 0.4163289630512515}	{"day": 0.28685499563846206, "night": 0.7131450043615379}	'1':1 'million':2 'paco':4 'rabanne':3,5
33	chloe-chloe-eau-de-parfum-2008	Chloé Eau de Parfum	Chloé	female	2008	https://fimgs.net/mdimg/perfume/375x500.1733.jpg	3.9569	24038	{0.0074303406,0.022291021,0.016099071,0.026006192,0,0.008668731,0.052012384,0.052012384,0.06934985,0,0.10959753,0.4733746,0.1501548,0.013003096}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.31995356	2	{"autumn": 0.21139317723241519, "spring": 0.3958049833419361, "summer": 0.24658627000140773, "winter": 0.146215569424241}	{"day": 0.7649918962722853, "night": 0.23500810372771475}	'chloe':1,5 'de':3 'eau':2 'edp':6 'parfum':4
34	calvin-klein-euphoria-2005	Euphoria	Calvin Klein	female	2005	https://fimgs.net/mdimg/perfume/375x500.253.jpg	3.8288	23807	{0.11119792,0.08867188,0.071875,0.15625,0,0.06458333,0.03125,0.01875,0,0.0140625,0.12044271,0.18802084,0.13489583,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0625, "sweet": 0.117188, "creamy": 0.0, "powdery": 0.179688}	0.30461589	3	{"autumn": 0.3541933418693982, "spring": 0.16271873666239864, "summer": 0.0949637217242851, "winter": 0.38812419974391804}	{"day": 0.3509044773676025, "night": 0.6490955226323974}	'calvin':2 'ck':4 'euphoria':1 'klein':3
35	by-kilian-angels-share-2020	Angels' Share	By Kilian	unisex	2020	https://fimgs.net/mdimg/perfume/375x500.62615.jpg	4.3515	23723	{0.32584494,0.14870775,0.2471173,0.1306163,0,0.03976143,0,0,0,0,0.042743538,0.010337972,0.02584493,0.029025845}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.335984, "sweet": 0.316103, "creamy": 0.037773, "powdery": 0.05169}	0.31875744	3	{"autumn": 0.40539778732999787, "spring": 0.08748502572052709, "summer": 0.04943273905996758, "winter": 0.45768444788950746}	{"day": 0.29088364654138343, "night": 0.7091163534586166}	'angels':1 'by':3 'kilian':4 'share':2
36	calvin-klein-ck-one-1994	CK One	Calvin Klein	unisex	1994	https://fimgs.net/mdimg/perfume/375x500.276.jpg	3.8188	23162	{0.030833334,0,0.020555556,0.061666667,0,0.035,0.16861111,0.32694444,0.036666665,0.15333334,0,0.07722222,0.07027778,0.018888889}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.072222, "sweet": 0.0, "creamy": 0.0, "powdery": 0.102778}	0.50688887	1	{"autumn": 0.09929600523903077, "spring": 0.3575638506876228, "summer": 0.4823182711198428, "winter": 0.0608218729535036}	{"day": 0.8704468367497419, "night": 0.12955316325025806}	'calvin':3 'ck':1,5 'klein':4 'one':2
37	dior-fahrenheit-1988	Fahrenheit	Dior	male	1988	https://fimgs.net/mdimg/perfume/375x500.228.jpg	3.9833	23061	{0,0.033689838,0.14723708,0.093048126,0,0.19590017,0.17789662,0.036363635,0.20035651,0.0228164,0,0.0741533,0.018538324,0}	{"sharp": 0.0, "smoky": 0.178253, "spicy": 0.121212, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58535653	3	{"autumn": 0.35124281366249577, "spring": 0.19428474805546161, "summer": 0.09815691579303348, "winter": 0.3563155224890091}	{"day": 0.4090746695248303, "night": 0.5909253304751697}	'christian':3 'dior':2,4 'fahrenheit':1
38	chanel-bleu-de-chanel-eau-de-parfum-2014	Bleu de Chanel Eau de Parfum	Chanel	male	2014	https://fimgs.net/mdimg/perfume/375x500.25967.jpg	4.4198	23037	{0.06666667,0.11564626,0.13605443,0.08707483,0,0.09478458,0.16712019,0.28594103,0.026303856,0.020408163,0,0,0,0}	{"sharp": 0.0, "smoky": 0.06576, "spicy": 0.201814, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.55784583	2	{"autumn": 0.25413090247743253, "spring": 0.27234014239137666, "summer": 0.2642890411870384, "winter": 0.20923991394415242}	{"day": 0.5183945052586392, "night": 0.48160549474136083}	'bdc':10 'bleu':1 'blue':8 'chanel':3,7 'de':2,5 'eau':4 'edp':9 'parfum':6
39	yves-saint-laurent-libre-2019	Libre	Yves Saint Laurent	female	2019	https://fimgs.net/mdimg/perfume/375x500.56077.jpg	3.9209	22548	{0.13504674,0.06693925,0.029906543,0,0,0.022429906,0.22476636,0.17056075,0,0.018224299,0.021612149,0.15560748,0.08528037,0.06962617}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.200935, "creamy": 0.0, "powdery": 0.077103}	0.33544976	3	{"autumn": 0.32820139814927063, "spring": 0.25166686871135896, "summer": 0.15092738513759243, "winter": 0.269204348001778}	{"day": 0.5206757616455786, "night": 0.47932423835442145}	'laurent':4 'libre':1 'saint':3 'ysl':5 'yves':2
40	versace-versace-pour-homme-2008	Versace Pour Homme	Versace	male	2008	https://fimgs.net/mdimg/perfume/375x500.2318.jpg	4.2651	22433	{0.023151126,0,0,0.011575563,0,0.028938906,0.25016078,0.38327974,0.024437299,0.08810289,0,0.12604502,0.06430868,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.144695, "sweet": 0.0, "creamy": 0.0, "powdery": 0.057878}	0.5182315	1	{"autumn": 0.10873812571582564, "spring": 0.3720945900424443, "summer": 0.4730512699589032, "winter": 0.04611601428282692}	{"day": 0.8157465495608532, "night": 0.1842534504391468}	'homme':3 'pour':2 'versace':1,4
41	maison-martin-margiela-jazz-club-2013	Jazz Club	Maison Martin Margiela	male	2013	https://fimgs.net/mdimg/perfume/375x500.20541.jpg	4.1935	21710	{0.28133333,0.2167619,0.18533333,0.067428574,0,0.06057143,0.0807619,0,0,0.020190476,0.04,0,0,0.04761905}	{"sharp": 0.0, "smoky": 0.190476, "spicy": 0.093333, "sweet": 0.445714, "creamy": 0.0, "powdery": 0.0}	0.33629525	2	{"autumn": 0.43465402843601897, "spring": 0.09065402843601895, "summer": 0.04519431279620853, "winter": 0.42949763033175353}	{"day": 0.23459398549193605, "night": 0.765406014508064}	'club':2 'jazz':1 'maison':3 'margiela':5,7 'martin':4 'mmm':6
42	chanel-bleu-de-chanel-2010	Bleu de Chanel	Chanel	male	2010	https://fimgs.net/mdimg/perfume/375x500.9099.jpg	4.1841	21277	{0.06263982,0.10357942,0.1442953,0.10067114,0,0.10872483,0.18255034,0.2720358,0,0.025503356,0,0,0,0}	{"sharp": 0.0, "smoky": 0.071588, "spicy": 0.225951, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.57325506	2	{"autumn": 0.2539460072746688, "spring": 0.29736042980612004, "summer": 0.2750692428337838, "winter": 0.1736243200854273}	{"day": 0.5355136317937194, "night": 0.4644863682062807}	'bdc':6 'bleu':1 'blue':5 'chanel':3,4 'de':2
43	viktor-rolf-flowerbomb-2005	Flowerbomb	Viktor&Rolf	female	2005	https://fimgs.net/mdimg/perfume/375x500.1460.jpg	3.9224	21177	{0.10440098,0.021393644,0.06699266,0.07628362,0.07823961,0.051344745,0,0.09535452,0,0,0.021393644,0.29877752,0.15794621,0.02787286}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.085575, "creamy": 0.0, "powdery": 0.178484}	0.31334352	2	{"autumn": 0.2738218303435695, "spring": 0.2760717543326239, "summer": 0.1587108543630283, "winter": 0.29139556096077834}	{"day": 0.5248838109992254, "night": 0.47511618900077457}	'flowerbomb':1 'r':5 'rolf':3 'v':4 'viktor':2
44	xerjoff-xj-1861-naxos-2015	XJ 1861 Naxos	Xerjoff	unisex	2015	https://fimgs.net/mdimg/perfume/375x500.30529.jpg	4.4925	20946	{0.26320755,0.15773585,0.05566038,0,0,0.02226415,0.19132076,0.10754717,0,0.02,0.047169812,0.058867924,0.014716981,0.061509434}	{"sharp": 0.0, "smoky": 0.111321, "spicy": 0.0, "sweet": 0.496226, "creamy": 0.0, "powdery": 0.0}	0.28536794	4	{"autumn": 0.3160417642359294, "spring": 0.2384914184963773, "summer": 0.11576076475935976, "winter": 0.32970605250833357}	{"day": 0.4553198079603531, "night": 0.5446801920396469}	'1861':2 'naxos':3 'xerjoff':4 'xj':1
45	narciso-rodriguez-narciso-rodriguez-for-her-2003	Narciso Rodriguez For Her	Narciso Rodriguez	female	2003	https://fimgs.net/mdimg/perfume/375x500.209.jpg	4.0022	20768	{0.15092166,0.04562212,0.032258064,0.097235024,0,0.017050691,0,0.11981567,0,0,0.09677419,0.20046084,0.2140553,0.025806451}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.375576}	0.2505069	2	{"autumn": 0.31913443516783097, "spring": 0.24921906060089738, "summer": 0.13227693530981996, "winter": 0.2993695689214517}	{"day": 0.4899193548387097, "night": 0.5100806451612904}	'for':3 'her':4 'narciso':1,5 'rodriguez':2,6
46	davidoff-cool-water-1988	Cool Water	Davidoff	male	1988	https://fimgs.net/mdimg/perfume/375x500.507.jpg	3.889	20658	{0,0,0.017741935,0.053225808,0,0.055913977,0.42231184,0.05403226,0.21182796,0.18494624,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.13172, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.55419356	1	{"autumn": 0.108467971096858, "spring": 0.34533571486563286, "summer": 0.49330194040756675, "winter": 0.05289437362994236}	{"day": 0.8172441345245878, "night": 0.18275586547541223}	'cool':1 'davidoff':3 'water':2
47	nautica-nautica-voyage-2006	Nautica Voyage	Nautica	male	2006	https://fimgs.net/mdimg/perfume/375x500.913.jpg	3.8962	20326	{0.058990538,0,0.014511041,0.059305992,0,0.014511041,0.09148265,0.028391168,0.116719246,0.25236592,0.15141957,0.111671925,0.10063092,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.170347}	0.40747634	1	{"autumn": 0.06854694751874331, "spring": 0.37583006069260977, "summer": 0.5240271331667262, "winter": 0.03159585862192074}	{"day": 0.8916018245237456, "night": 0.10839817547625435}	'nautica':1,3 'voyage':2
48	issey-miyake-l-eau-d-issey-pour-homme-1994	L'Eau d'Issey Pour Homme	Issey Miyake	male	1994	https://fimgs.net/mdimg/perfume/375x500.721.jpg	4.1724	20294	{0.028301887,0.014150944,0.021383647,0.064150944,0,0.04591195,0.22201258,0.36918238,0.02389937,0.09937107,0.014150944,0.077987425,0.019496856,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.122642, "sweet": 0.056604, "creamy": 0.0, "powdery": 0.0}	0.53227985	2	{"autumn": 0.11435863658817717, "spring": 0.3775728634941545, "summer": 0.4581755310390252, "winter": 0.049892968878643175}	{"day": 0.8088811821471653, "night": 0.19111881785283474}	'd':3 'eau':2 'homme':6 'issey':4,7 'l':1 'miyake':8 'pour':5
49	chanel-chance-eau-tendre-2010	Chance Eau Tendre	Chanel	female	2010	https://fimgs.net/mdimg/perfume/375x500.8069.jpg	4.1242	20154	{0.1289272,0.029693486,0,0.018390805,0,0.022222223,0.055555556,0.17126437,0,0,0.17528735,0.23141763,0.14846744,0.018773947}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.111111, "sweet": 0.118774, "creamy": 0.0, "powdery": 0.201149}	0.2950862	1	{"autumn": 0.11391958617446508, "spring": 0.4438631554197037, "summer": 0.3644486245003527, "winter": 0.07776863390547849}	{"day": 0.8459623295085517, "night": 0.15403767049144837}	'chance':1 'chanel':4 'eau':2 'tendre':3
50	giorgio-armani-si-2013	Si	Giorgio Armani	female	2013	https://fimgs.net/mdimg/perfume/375x500.18453.jpg	3.8364	19957	{0.15541957,0.031118881,0.072202794,0.10489511,0,0.034965035,0.12377623,0,0,0.11223776,0.11013986,0.14965035,0.04965035,0.055944055}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.124126, "sweet": 0.155594, "creamy": 0.0, "powdery": 0.0}	0.37446678	3	{"autumn": 0.3645783706526918, "spring": 0.20843258694616484, "summer": 0.11279180562172463, "winter": 0.3141972367794188}	{"day": 0.5399102263856362, "night": 0.46008977361436376}	'armani':3 'giorgio':2 'si':1
51	dolce-gabbana-d-g-anthology-l-imperatrice-3-2009	D&G Anthology L'Imperatrice 3	Dolce&Gabbana	female	2009	https://fimgs.net/mdimg/perfume/375x500.6086.jpg	3.8083	19460	{0.036945812,0.018472906,0,0,0,0,0.12586206,0.021428572,0.38866994,0.074876845,0.31995073,0.013793103,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.073892, "creamy": 0.0, "powdery": 0.0}	0.3791749	1	{"autumn": 0.09673695084158716, "spring": 0.3677462477972899, "summer": 0.4654554293006016, "winter": 0.07006137206052136}	{"day": 0.8690877460041317, "night": 0.13091225399586823}	'3':6 'anthology':3 'd':1,9 'dg':11 'dolce':7 'g':2,10 'gabbana':8 'imperatrice':5 'l':4
52	versace-eros-flame-2018	Eros Flame	Versace	male	2018	https://fimgs.net/mdimg/perfume/375x500.52180.jpg	4.3199	19458	{0.166,0.043375,0.073,0.0705,0,0.053,0.18775,0.29425,0,0.0285,0.014375,0.0115,0.02875,0.029}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.23, "sweet": 0.2025, "creamy": 0.0, "powdery": 0.0575}	0.44666874	3	{"autumn": 0.3019875485165021, "spring": 0.24869103128500353, "summer": 0.15577378936674569, "winter": 0.2935476308317487}	{"day": 0.4611764705882353, "night": 0.5388235294117647}	'eros':1 'flame':2 'versace':3
53	dior-sauvage-elixir-2021	Sauvage Elixir	Dior	male	2021	https://fimgs.net/mdimg/perfume/375x500.68415.jpg	4.2977	19236	{0.16237816,0.06666667,0.23294348,0.081871346,0,0.056140352,0.30838206,0.043274853,0,0.026900584,0,0,0,0.021442495}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.532164, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.54369396	4	{"autumn": 0.33882669335167925, "spring": 0.1931015072862593, "summer": 0.07986740884357996, "winter": 0.38820439051848143}	{"day": 0.33674730708105244, "night": 0.6632526929189475}	'christian':4 'dior':3,5 'elixir':2 'sauvage':1 'savage':6
54	parfums-de-marly-layton-2016	Layton	Parfums de Marly	unisex	2016	https://fimgs.net/mdimg/perfume/375x500.39314.jpg	4.4435	19086	{0.17915255,0.027457627,0.12983051,0.08440678,0,0.056949154,0.2537288,0.043220337,0,0.025084745,0.10508475,0.019322034,0.048305083,0.027457627}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.313559, "sweet": 0.137288, "creamy": 0.0, "powdery": 0.09661}	0.4192034	3	{"autumn": 0.3134907891279596, "spring": 0.2626339298747555, "summer": 0.1076402066972236, "winter": 0.3162350743000613}	{"day": 0.4614342974758964, "night": 0.5385657025241035}	'de':3 'layton':1 'marly':4 'parfums':2 'pdm':5
55	jean-paul-gaultier-le-beau-le-parfum-2022	Le Beau Le Parfum	Jean Paul Gaultier	male	2022	https://fimgs.net/mdimg/perfume/375x500.72158.jpg	4.5107	18980	{0.27736184,0.13868092,0.058467023,0.13404635,0,0.0342246,0,0,0,0,0.26631016,0.033868093,0.035650622,0.021390375}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.442068, "creamy": 0.156863, "powdery": 0.071301}	0.16368984	3	{"autumn": 0.19741687570048566, "spring": 0.304958104285638, "summer": 0.3815445375460319, "winter": 0.11608048246784437}	{"day": 0.5190667816422344, "night": 0.48093321835776565}	'beau':2 'gaultier':7 'jean':5 'jpg':8 'le':1,3 'parfum':4 'paul':6
56	byredo-bal-d-afrique-2009	Bal d'Afrique	Byredo	unisex	2009	https://fimgs.net/mdimg/perfume/375x500.6458.jpg	4.1394	18810	{0.03031579,0,0.042105265,0.12631579,0.08589473,0.08505263,0.1856842,0.020210527,0.026947368,0.11957895,0,0.13221052,0.14568421,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.223158}	0.41882107	1	{"autumn": 0.20963583628746374, "spring": 0.3505210011816522, "summer": 0.33768396175743903, "winter": 0.10215920077344505}	{"day": 0.7629663330300273, "night": 0.2370336669699727}	'afrique':3 'bal':1 'byredo':4 'd':2
57	tom-ford-ombre-leather-2018-2018	Ombré Leather (2018)	Tom Ford	unisex	2018	https://fimgs.net/mdimg/perfume/375x500.50239.jpg	4.319	18678	{0.066096865,0.10854701,0.3048433,0,0.11111111,0.2940171,0,0,0,0.0071225073,0,0.06495727,0.021652421,0.021652421}	{"sharp": 0.0, "smoky": 0.37037, "spicy": 0.116809, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.65505695	3	{"autumn": 0.3795996643893084, "spring": 0.1534619840984458, "summer": 0.05813256622318111, "winter": 0.4088057852890647}	{"day": 0.32785936482673805, "night": 0.672140635173262}	'2018':3 'ford':5 'leather':2 'ombre':1 'tf':6 'tom':4
58	guerlain-shalimar-eau-de-parfum-1990	Shalimar Eau de Parfum	Guerlain	female	1990	https://fimgs.net/mdimg/perfume/375x500.53.jpg	3.9731	18656	{0.16311476,0.17885245,0.16901639,0.07967213,0,0.13967213,0,0.16393442,0,0,0,0.023278689,0.05819672,0.024262294}	{"sharp": 0.0, "smoky": 0.188525, "spicy": 0.0, "sweet": 0.121311, "creamy": 0.0, "powdery": 0.116393}	0.440959	4	{"autumn": 0.3689644700880656, "spring": 0.12458244761615549, "summer": 0.10340115396295171, "winter": 0.4030519283328272}	{"day": 0.33866603928949535, "night": 0.6613339607105047}	'de':3 'eau':2 'edp':6 'guerlain':5 'parfum':4 'shalimar':1
59	afnan-9pm-2020	9pm	Afnan	male	2020	https://fimgs.net/mdimg/perfume/375x500.65414.jpg	4.3321	18363	{0.30630136,0.18630137,0.14575343,0,0,0,0.11780822,0.024657534,0.03287671,0,0.13150685,0,0,0.05479452}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.216438, "sweet": 0.372603, "creamy": 0.0, "powdery": 0.0}	0.28065753	4	{"autumn": 0.3242929322260294, "spring": 0.20236366804111738, "summer": 0.08856495731459435, "winter": 0.3847784424182589}	{"day": 0.3136900389852534, "night": 0.6863099610147466}	'9':3 '9pm':1 'afnan':2 'pm':4
60	tom-ford-lost-cherry-2018	Lost Cherry	Tom Ford	unisex	2018	https://fimgs.net/mdimg/perfume/375x500.51411.jpg	4.0547	18271	{0.37957197,0.10233463,0.08560311,0.06828794,0,0,0,0,0,0,0.3455253,0,0,0.018677043}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.077821, "sweet": 0.610895, "creamy": 0.27821, "powdery": 0.0}	0.104309335	2	{"autumn": 0.35290116674514727, "spring": 0.18578977659184848, "summer": 0.11751164129126772, "winter": 0.3437974153717365}	{"day": 0.4023979018358936, "night": 0.5976020981641064}	'cherry':2 'ford':4 'lost':1 'tf':5 'tom':3
61	lanvin-eclat-darpege-2002	Eclat d’Arpège	Lanvin	female	2002	https://fimgs.net/mdimg/perfume/375x500.988.jpg	3.8649	17884	{0.0609375,0,0.012890625,0.01328125,0,0,0.091796875,0.06679688,0.0890625,0.1,0.05859375,0.35664064,0.14140625,0.00859375}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.042969, "sweet": 0.0, "creamy": 0.0, "powdery": 0.109375}	0.3521875	1	{"autumn": 0.11170281021429487, "spring": 0.4640703195175157, "summer": 0.3450532529192865, "winter": 0.07917361734890287}	{"day": 0.8704101096804959, "night": 0.12958989031950405}	'arpege':3 'd':2 'eclat':1 'lanvin':4
62	montblanc-explorer-2019	Explorer	Montblanc	male	2019	https://fimgs.net/mdimg/perfume/375x500.52002.jpg	4.2329	17745	{0.10868762,0.0935305,0.13049908,0.13123845,0,0.08022181,0.16414048,0.20406654,0,0.029944547,0,0,0.040665433,0.017005546}	{"sharp": 0.0, "smoky": 0.085028, "spicy": 0.173752, "sweet": 0.0, "creamy": 0.0, "powdery": 0.101664}	0.5034011	1	{"autumn": 0.2605517078079678, "spring": 0.3031137157402474, "summer": 0.2942638962884035, "winter": 0.14207068016338129}	{"day": 0.6157818880614941, "night": 0.3842181119385059}	'blanc':4 'explorer':1 'mont':3 'montblanc':2
63	dior-pure-poison-2004	Pure Poison	Dior	female	2004	https://fimgs.net/mdimg/perfume/375x500.214.jpg	4.0415	17728	{0.083657585,0.06595331,0.0614786,0.079377435,0,0.044357978,0,0.19844358,0,0,0.01459144,0.24747081,0.12684825,0.07782101}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.058366, "creamy": 0.046693, "powdery": 0.070039}	0.34170234	3	{"autumn": 0.25628482130724284, "spring": 0.2950808533768175, "summer": 0.1602799293382253, "winter": 0.28835439597771434}	{"day": 0.5254537405931828, "night": 0.47454625940681716}	'christian':4 'dior':3,5 'poison':2 'pure':1
64	ariana-grande-cloud-2018	Cloud	Ariana Grande	female	2018	https://fimgs.net/mdimg/perfume/375x500.50384.jpg	3.9523	17705	{0.4642384,0.111258276,0.011258278,0.08774834,0,0,0.06291391,0,0,0,0.116556294,0.010596027,0.10695364,0.028476821}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.586093, "creamy": 0.331126, "powdery": 0.13245}	0.03018212	1	{"autumn": 0.2621984717574789, "spring": 0.25955151575687957, "summer": 0.1892323827598262, "winter": 0.2890176297258153}	{"day": 0.652311412891824, "night": 0.34768858710817596}	'ariana':2 'cloud':1 'grande':3
65	tom-ford-oud-wood-2007	Oud Wood	Tom Ford	unisex	2007	https://fimgs.net/mdimg/perfume/375x500.1826.jpg	4.2836	17665	{0.15470852,0.14237668,0.25784755,0.13452914,0,0.1087444,0.13340807,0.026233183,0,0.022421524,0,0,0,0.019730942}	{"sharp": 0.0, "smoky": 0.154709, "spicy": 0.242152, "sweet": 0.098655, "creamy": 0.0, "powdery": 0.0}	0.5136435	2	{"autumn": 0.36699439492786917, "spring": 0.19415602315537994, "summer": 0.08177892125333089, "winter": 0.35707066066342}	{"day": 0.41109205260148657, "night": 0.5889079473985135}	'ford':4 'oud':1 'tf':5 'tom':3 'wood':2
66	jean-paul-gaultier-ultra-male-2015	Ultra Male	Jean Paul Gaultier	male	2015	https://fimgs.net/mdimg/perfume/375x500.30947.jpg	4.4435	17594	{0.24665391,0.10497132,0.11969407,0,0,0.01835564,0.2458891,0.02753346,0,0.02753346,0.17112811,0,0,0.038240917}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.309751, "sweet": 0.325048, "creamy": 0.0, "powdery": 0.0}	0.35274377	4	{"autumn": 0.32893745290128107, "spring": 0.19928752483386997, "summer": 0.09649242995135987, "winter": 0.3752825923134891}	{"day": 0.2779586683500565, "night": 0.7220413316499436}	'gaultier':5 'jean':3 'jpg':6 'male':2 'paul':4 'ultra':1
67	donna-karan-dkny-be-delicious-2004	DKNY Be Delicious	Donna Karan	female	2004	https://fimgs.net/mdimg/perfume/375x500.498.jpg	3.6479	17530	{0,0,0,0,0,0,0.10585198,0.12857144,0.33356282,0.13769363,0.16351119,0.090877794,0.02616179,0.013769363}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4442513	1	{"autumn": 0.0868402533427164, "spring": 0.4107670654468684, "summer": 0.4569317382125264, "winter": 0.04546094299788881}	{"day": 0.9117647058823529, "night": 0.08823529411764706}	'be':2 'delicious':3 'dkny':1,6 'donna':4 'karan':5
68	giorgio-armani-acqua-di-gioia-2010	Acqua di Gioia	Giorgio Armani	female	2010	https://fimgs.net/mdimg/perfume/375x500.8442.jpg	3.9346	17378	{0.020618556,0.010309278,0.017319588,0.051958762,0,0.03670103,0.26824743,0.2513402,0.021443298,0.19628866,0.010309278,0.06927835,0.023092784,0.023092784}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.096907, "sweet": 0.041237, "creamy": 0.0, "powdery": 0.0}	0.5376701	1	{"autumn": 0.07602892478205042, "spring": 0.348651753733865, "summer": 0.5175373386497263, "winter": 0.057781982834358314}	{"day": 0.8602473702462143, "night": 0.1397526297537857}	'acqua':1 'aqua':6 'armani':5 'di':2 'gioia':3 'giorgio':4
69	viktor-rolf-spicebomb-extreme-2015	Spicebomb Extreme	Viktor&Rolf	male	2015	https://fimgs.net/mdimg/perfume/375x500.30499.jpg	4.4871	17375	{0.3150812,0.187471,0.26844546,0,0,0.058932714,0.02436195,0.014617169,0,0,0.035962876,0.013921114,0.034802783,0.046403714}	{"sharp": 0.0, "smoky": 0.206497, "spicy": 0.308585, "sweet": 0.415313, "creamy": 0.0, "powdery": 0.069606}	0.36180973	4	{"autumn": 0.3867623290101313, "spring": 0.08065597035518587, "summer": 0.03784444356841566, "winter": 0.4947372570662672}	{"day": 0.30221497486071475, "night": 0.6977850251392852}	'extreme':2 'r':6 'rolf':4 'spicebomb':1 'v':5 'viktor':3
70	dolce-gabbana-the-one-2006	The One	Dolce&Gabbana	female	2006	https://fimgs.net/mdimg/perfume/375x500.698.jpg	3.8473	17338	{0.20133333,0.10744444,0.016,0,0,0,0.018666666,0.089777775,0.024888888,0,0.25055555,0.13022222,0.094444446,0.06666667}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.268889, "creamy": 0.0, "powdery": 0.117778}	0.21677223	2	{"autumn": 0.3608293224731581, "spring": 0.18548685671973345, "summer": 0.11225472047389856, "winter": 0.34142910033320995}	{"day": 0.48693799753335576, "night": 0.5130620024666442}	'd':5 'dg':7 'dolce':3 'g':6 'gabbana':4 'one':2 'the':1
71	versace-versace-man-eau-fraiche-2006	Versace Man Eau Fraiche	Versace	male	2006	https://fimgs.net/mdimg/perfume/375x500.644.jpg	4.1385	17161	{0.027855154,0,0.0724234,0.09192201,0,0.048467968,0.20250696,0.32284123,0.023398329,0.035097495,0.15988858,0.015598886,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.158774, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5285237	1	{"autumn": 0.06814129708045465, "spring": 0.3374749275685313, "summer": 0.5602295520392244, "winter": 0.03415422331178961}	{"day": 0.868214080184155, "night": 0.131785919815845}	'eau':3 'fraiche':4 'man':2 'versace':1,5
72	britney-spears-fantasy-2005	Fantasy	Britney Spears	female	2005	https://fimgs.net/mdimg/perfume/375x500.600.jpg	3.9417	16869	{0.24607508,0.09897611,0.013651877,0.009556314,0,0,0.027645051,0.027645051,0.036860067,0,0.3993174,0.08327645,0.056996588,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.409556, "creamy": 0.0, "powdery": 0.098976}	0.1753925	2	{"autumn": 0.2356157077138476, "spring": 0.25181678778585237, "summer": 0.21908127208480566, "winter": 0.2934862324154944}	{"day": 0.6335338187190039, "night": 0.3664661812809961}	'britney':2 'fantasy':1 'spears':3
73	prada-prada-l-homme-2016	Prada L'Homme	Prada	male	2016	https://fimgs.net/mdimg/perfume/375x500.39029.jpg	4.4575	16858	{0.09558233,0,0.08032128,0.08192771,0.045783132,0.06987952,0.11345381,0.029518072,0,0.054618474,0,0.12048193,0.30843374,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.186747, "sweet": 0.0, "creamy": 0.0, "powdery": 0.52008}	0.3191767	2	{"autumn": 0.26670744269894414, "spring": 0.3192763327324234, "summer": 0.2782964202935874, "winter": 0.13571980427504507}	{"day": 0.6752302472127969, "night": 0.3247697527872031}	'homme':3 'l':2 'prada':1,4
74	prada-prada-candy-2011	Prada Candy	Prada	female	2011	https://fimgs.net/mdimg/perfume/375x500.12426.jpg	3.7551	16763	{0.45399517,0.23099273,0.08062954,0.0188862,0,0,0,0,0,0,0.030266345,0.03535109,0.12615012,0.023728814}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.062954, "sweet": 0.48184, "creamy": 0.0, "powdery": 0.271186}	0.09990315	1	{"autumn": 0.3625905411163187, "spring": 0.17486152535151256, "summer": 0.12509586706433745, "winter": 0.33745206646783127}	{"day": 0.6170589035505374, "night": 0.38294109644946267}	'candy':2 'prada':1,3
75	elizabeth-arden-green-tea-1999	Green Tea	Elizabeth Arden	female	1999	https://fimgs.net/mdimg/perfume/375x500.83.jpg	3.8605	16713	{0,0,0,0,0,0.024933686,0.27718833,0.33289126,0.07214854,0.22122017,0,0.04933687,0.014323607,0.00795756}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.124668, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5800265	1	{"autumn": 0.06097871798139416, "spring": 0.392889002166433, "summer": 0.510768446540079, "winter": 0.03536383331209379}	{"day": 0.936577300106295, "night": 0.06342269989370497}	'arden':4 'elizabeth':3 'green':1 'tea':2
76	giorgio-armani-acqua-di-gio-profumo-2015	Acqua di Giò Profumo	Giorgio Armani	male	2015	https://fimgs.net/mdimg/perfume/375x500.29727.jpg	4.4264	16550	{0.05971564,0.06540284,0.13744076,0.05971564,0,0.1042654,0.25473934,0.13151659,0.13981043,0.047393367,0,0,0,0}	{"sharp": 0.0, "smoky": 0.097156, "spicy": 0.225118, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.56850713	3	{"autumn": 0.2381264443141448, "spring": 0.3123512572000138, "summer": 0.32842410236953745, "winter": 0.12109819611630393}	{"day": 0.5336111614422903, "night": 0.46638883855770974}	'acqua':1 'adg':8 'aqua':7 'armani':6 'di':2 'gio':3 'giorgio':5 'profumo':4
77	dolce-gabbana-the-one-for-men-eau-de-parfum-2015	The One for Men Eau de Parfum	Dolce&Gabbana	male	2015	https://fimgs.net/mdimg/perfume/375x500.31909.jpg	4.4891	16538	{0.122743055,0.1749132,0.18715277,0.041666668,0,0.072569445,0.17552084,0.17482638,0,0.02673611,0.023871528,0,0,0}	{"sharp": 0.0, "smoky": 0.15625, "spicy": 0.237847, "sweet": 0.095486, "creamy": 0.0, "powdery": 0.0}	0.523329	1	{"autumn": 0.3650597286117447, "spring": 0.19522944291955, "summer": 0.0708624888854525, "winter": 0.3688483395832528}	{"day": 0.31762818175187807, "night": 0.682371818248122}	'd':10 'de':6 'dg':12 'dolce':8 'eau':5 'edp':13 'for':3 'g':11 'gabbana':9 'men':4 'one':2 'parfum':7 'the':1
78	guerlain-mon-guerlain-2017	Mon Guerlain	Guerlain	female	2017	https://fimgs.net/mdimg/perfume/375x500.43297.jpg	4.0799	16489	{0.26848072,0.11678004,0.10249433,0.078911565,0,0.026303856,0.2340136,0,0,0.024489796,0.023809524,0.022675738,0.05668934,0.045351475}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.079365, "sweet": 0.321995, "creamy": 0.0, "powdery": 0.113379}	0.28427437	2	{"autumn": 0.3112310761647694, "spring": 0.2842976176505105, "summer": 0.13132261471658255, "winter": 0.27314869146813753}	{"day": 0.6165454946023353, "night": 0.3834545053976647}	'guerlain':2,3 'mon':1
79	lolita-lempicka-lolita-lempicka-1997	Lolita Lempicka	Lolita Lempicka	female	1997	https://fimgs.net/mdimg/perfume/375x500.456.jpg	3.974	16391	{0.31626505,0.06134538,0.08674699,0,0,0,0.07951807,0,0,0.020481927,0.041666668,0.13273093,0.20140563,0.059839357}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.333333, "sweet": 0.26506, "creamy": 0.0, "powdery": 0.325301}	0.21759538	3	{"autumn": 0.33208479438954414, "spring": 0.19676442460949953, "summer": 0.10535543512910424, "winter": 0.3657953458718521}	{"day": 0.5044924720738222, "night": 0.49550752792617775}	'lempicka':2,4 'lolita':1,3
80	kenzo-flower-by-kenzo-2000	Flower by Kenzo	Kenzo	female	2000	https://fimgs.net/mdimg/perfume/375x500.72.jpg	3.6441	16371	{0.22029795,0.10474861,0.021229051,0.020484172,0,0,0,0,0,0.029795159,0.020949721,0.27299812,0.28938547,0.020111732}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.184358, "creamy": 0.0, "powdery": 0.437616}	0.13613129	2	{"autumn": 0.24207775236850704, "spring": 0.3583796145050637, "summer": 0.17649460960470434, "winter": 0.22304802352172493}	{"day": 0.7295393717424989, "night": 0.27046062825750106}	'by':2 'flower':1 'kenzo':3,4
81	essential-parfums-bois-imperial-2020	Bois Impérial	Essential Parfums	unisex	2020	https://fimgs.net/mdimg/perfume/375x500.64338.jpg	4.1653	16350	{0.043195266,0.065680474,0.16982248,0.17751479,0.044378698,0.1464497,0.20532544,0.049704142,0,0.09792899,0,0,0,0}	{"sharp": 0.0, "smoky": 0.106509, "spicy": 0.236686, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5983136	4	{"autumn": 0.27582003943359024, "spring": 0.3024197884925614, "summer": 0.25552966481448286, "winter": 0.16623050725936547}	{"day": 0.6346352716569883, "night": 0.3653647283430117}	'bois':1 'essential':3 'imperial':2 'parfums':4
82	dior-poison-1985	Poison	Dior	female	1985	https://fimgs.net/mdimg/perfume/375x500.218.jpg	3.924	16302	{0.16650943,0.1697327,0.1481132,0.0745283,0,0.024842767,0,0,0,0,0.19457547,0.13301887,0.026100628,0.06257862}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.111635, "sweet": 0.149371, "creamy": 0.0, "powdery": 0.0}	0.3138011	4	{"autumn": 0.3524041937816341, "spring": 0.11135213304410702, "summer": 0.07013738250180766, "winter": 0.4661062906724512}	{"day": 0.223986856516977, "night": 0.776013143483023}	'christian':3 'dior':2,4 'poison':1
83	burberry-burberry-her-2018	Burberry Her	Burberry	female	2018	https://fimgs.net/mdimg/perfume/375x500.51694.jpg	3.8911	16233	{0.23266667,0.09616667,0.029333333,0.079333335,0,0.02,0,0,0,0,0.4255,0.019333333,0.087,0.010666667}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.326667, "creamy": 0.0, "powdery": 0.193333}	0.17964166	2	{"autumn": 0.18368967623701893, "spring": 0.3821014050091631, "summer": 0.29108124618204034, "winter": 0.14312767257177764}	{"day": 0.7749363713489275, "night": 0.2250636286510726}	'burberry':1,3 'her':2
84	jo-malone-london-wood-sage-sea-salt-2014	Wood Sage & Sea Salt	Jo Malone London	unisex	2014	https://fimgs.net/mdimg/perfume/375x500.25529.jpg	4.2144	16108	{0.0875,0,0.02397541,0.023770493,0,0.029508196,0.24282786,0.12704918,0.2614754,0.07479508,0,0.052459016,0.06065574,0.015983606}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.079918, "sweet": 0.0, "creamy": 0.0, "powdery": 0.118852}	0.43900615	1	{"autumn": 0.156888720666162, "spring": 0.3205273782488014, "summer": 0.44436033308099926, "winter": 0.07822356800403735}	{"day": 0.8472881138607514, "night": 0.15271188613924863}	'jo':5 'london':7 'malone':6 'sage':2 'salt':4 'sea':3 'wood':1
85	lattafa-perfumes-khamrah-qahwa-2023	Khamrah Qahwa	Lattafa Perfumes	unisex	2023	https://fimgs.net/mdimg/perfume/375x500.88175.jpg	4.3374	16072	{0.38309523,0.16333333,0.26833335,0,0,0.020952381,0.036190476,0,0,0.009047619,0.048809525,0.01,0.025,0.035238095}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.354762, "sweet": 0.371429, "creamy": 0.0, "powdery": 0.05}	0.30388096	4	{"autumn": 0.39287955486758985, "spring": 0.08011546667782286, "summer": 0.03158599338995105, "winter": 0.4954189850646362}	{"day": 0.2821843702025002, "night": 0.7178156297974998}	'kamrah':5 'khamrah':1 'lattafa':3 'perfumes':4 'qahwa':2
86	chanel-allure-homme-sport-2004	Allure Homme Sport	Chanel	male	2004	https://fimgs.net/mdimg/perfume/375x500.607.jpg	4.258	15870	{0.12603407,0.050121654,0,0,0,0.016545013,0.17104623,0.3160584,0.14209245,0.02676399,0.024330901,0.025304137,0.07591241,0.025790755}	{"sharp": 0.126521, "smoky": 0.0, "spicy": 0.082725, "sweet": 0.226277, "creamy": 0.0, "powdery": 0.126521}	0.4028954	2	{"autumn": 0.16600536193029491, "spring": 0.35420911528150134, "summer": 0.40353887399463806, "winter": 0.07624664879356569}	{"day": 0.7458270864567716, "night": 0.2541729135432284}	'allure':1 'chanel':4 'homme':2 'sport':3
87	rabanne-invictus-2013	Invictus	Rabanne	male	2013	https://fimgs.net/mdimg/perfume/375x500.18471.jpg	3.803	15589	{0.015217391,0.045652173,0.033913042,0.056086957,0,0.059130434,0.1976087,0.2545652,0.24304348,0.033913042,0,0.03652174,0.012173913,0.012173913}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.123913, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5113043	2	{"autumn": 0.16182896379525594, "spring": 0.3548689138576779, "summer": 0.3964835622138993, "winter": 0.08681856013316687}	{"day": 0.6984924623115578, "night": 0.3015075376884422}	'invictus':1 'paco':3 'rabanne':2,4
88	hermes-un-jardin-sur-le-nil-2005	Un Jardin Sur Le Nil	Hermès	unisex	2005	https://fimgs.net/mdimg/perfume/375x500.18.jpg	4.1018	15554	{0.026627218,0,0,0,0,0.024852071,0.20729783,0.23451677,0,0.119132146,0.17238659,0.14398421,0.07120316,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.12426, "sweet": 0.0, "creamy": 0.0, "powdery": 0.088757}	0.46254438	1	{"autumn": 0.07278282670009402, "spring": 0.3704951425885302, "summer": 0.5242870573487934, "winter": 0.03243497336258226}	{"day": 0.9025596276905178, "night": 0.09744037230948226}	'hermes':6 'jardin':2 'le':4 'nil':5 'sur':3 'un':1
89	chanel-chance-eau-fraiche-2007	Chance Eau Fraiche	Chanel	female	2007	https://fimgs.net/mdimg/perfume/375x500.1483.jpg	4.0836	15527	{0.058186397,0,0.050377835,0.16775818,0.043828715,0.072292194,0.092695214,0.23929471,0,0.03047859,0,0.12695214,0.105541565,0.012594459}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.166247}	0.42982367	2	{"autumn": 0.1068921265192119, "spring": 0.3913338869177927, "summer": 0.4214539140937571, "winter": 0.08032007246923832}	{"day": 0.8522790439132851, "night": 0.14772095608671484}	'chance':1 'chanel':4 'eau':2 'fraiche':3
90	lancome-hypnose-2005	Hypnôse	Lancôme	female	2005	https://fimgs.net/mdimg/perfume/375x500.170.jpg	3.8758	15421	{0.21461187,0.07420091,0.011415525,0.034246575,0,0.011415525,0,0,0,0,0.19246575,0.2780822,0.10547945,0.07808219}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.342466, "creamy": 0.0, "powdery": 0.068493}	0.18206622	3	{"autumn": 0.29665156763478107, "spring": 0.18554045652366996, "summer": 0.1035615951683098, "winter": 0.4142463806732392}	{"day": 0.4131712530056105, "night": 0.5868287469943895}	'hypnose':1 'lancome':2
91	aquolina-pink-sugar-2004	Pink Sugar	Aquolina	female	2004	https://fimgs.net/mdimg/perfume/375x500.975.jpg	3.7244	15380	{0.454698,0.19127516,0.039261743,0,0,0,0,0.033557046,0,0,0.18456376,0.016107382,0.040268455,0.040268455}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.083893, "sweet": 0.654362, "creamy": 0.0, "powdery": 0.080537}	0.10766779	3	{"autumn": 0.2701860995062666, "spring": 0.21048233953665021, "summer": 0.16946448917584506, "winter": 0.3498670717812381}	{"day": 0.6798583891768871, "night": 0.32014161082311293}	'aquolina':3 'pink':1 'sugar':2
92	nina-ricci-nina-2006	Nina	Nina Ricci	female	2006	https://fimgs.net/mdimg/perfume/375x500.147.jpg	3.8542	15379	{0.11566485,0.0428051,0.022222223,0.078688525,0,0.022222223,0.067759566,0.23242259,0.06703097,0.06994536,0.19034608,0.058287796,0.032604735,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.17122, "creamy": 0.060109, "powdery": 0.0}	0.37295994	1	{"autumn": 0.19563318777292577, "spring": 0.37840412862246925, "summer": 0.24684398570861452, "winter": 0.17911869789599047}	{"day": 0.7971134020618557, "night": 0.20288659793814434}	'nina':1,2 'ricci':3
93	dior-dior-addict-2002	Dior Addict	Dior	female	2002	https://fimgs.net/mdimg/perfume/375x500.215.jpg	4.1011	15342	{0.28112096,0.13761061,0.014159292,0,0,0,0.054277286,0.06784661,0,0.0135693215,0.11283186,0.14277287,0.07315634,0.10265487}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.439528, "creamy": 0.0, "powdery": 0.058997}	0.18410768	4	{"autumn": 0.31700981335385797, "spring": 0.104579565133731, "summer": 0.06619203386569175, "winter": 0.5122185876467192}	{"day": 0.2399944024629163, "night": 0.7600055975370836}	'addict':2 'christian':4 'dior':1,3,5
94	cacharel-amor-amor-2003	Amor Amor	Cacharel	female	2003	https://fimgs.net/mdimg/perfume/375x500.238.jpg	3.7662	15122	{0.20182233,0.051252846,0.026651481,0,0,0,0.07107061,0.22779043,0,0.017767653,0.21298406,0.067425966,0.05899772,0.0642369}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.088838, "sweet": 0.234624, "creamy": 0.0, "powdery": 0.084282}	0.30972666	1	{"autumn": 0.26611368997793167, "spring": 0.27866981203865765, "summer": 0.19922380336351875, "winter": 0.25599269461989194}	{"day": 0.61907190209077, "night": 0.38092809790923}	'amor':1,2 'cacharel':3
95	juliette-has-a-gun-not-a-perfume-2010	Not A Perfume	Juliette Has A Gun	female	2010	https://fimgs.net/mdimg/perfume/375x500.10296.jpg	3.7525	15100	{0.21290323,0.27419356,0.21612903,0.17419355,0,0.045161292,0,0,0,0,0,0,0.077419356,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.096774, "sweet": 0.0, "creamy": 0.0, "powdery": 0.193548}	0.33306453	1	{"autumn": 0.23656420259635433, "spring": 0.2932669671083608, "summer": 0.2753077285262662, "winter": 0.19486110176901864}	{"day": 0.6985994397759103, "night": 0.3014005602240896}	'a':2,6 'gun':7 'has':5 'juliette':4 'not':1 'perfume':3
96	maison-francis-kurkdjian-grand-soir-2016	Grand Soir	Maison Francis Kurkdjian	unisex	2016	https://fimgs.net/mdimg/perfume/375x500.40816.jpg	4.301	14941	{0.31149825,0.3236934,0.10348432,0,0,0.01358885,0.09337979,0,0,0.0111498255,0.022648083,0.019512195,0.048780486,0.05226481}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.351916, "creamy": 0.0, "powdery": 0.097561}	0.2057317	4	{"autumn": 0.3965373267271614, "spring": 0.11846573512219563, "summer": 0.056059678227467574, "winter": 0.42893725992317544}	{"day": 0.30098949919224555, "night": 0.6990105008077544}	'francis':4 'grand':1 'kurkdjian':5 'maison':3 'mfk':6 'soir':2
97	dior-sauvage-eau-de-parfum-2018	Sauvage Eau de Parfum	Dior	male	2018	https://fimgs.net/mdimg/perfume/375x500.48100.jpg	4.2104	14906	{0.0802005,0.09172932,0.044110276,0.018045112,0,0.050125312,0.3784461,0.2631579,0,0.03809524,0,0,0.036090225,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.318296, "sweet": 0.0, "creamy": 0.0, "powdery": 0.090226}	0.5221554	3	{"autumn": 0.26778801228140436, "spring": 0.26495127486316916, "summer": 0.2212988920037378, "winter": 0.2459618208516887}	{"day": 0.48962306846835196, "night": 0.510376931531648}	'christian':6 'de':3 'dior':5,7 'eau':2 'edp':9 'parfum':4 'sauvage':1 'savage':8
98	lancome-miracle-2000	Miracle	Lancôme	female	2000	https://fimgs.net/mdimg/perfume/375x500.184.jpg	3.9508	14867	{0.023923445,0,0,0.011961723,0,0.037320573,0.12559809,0.22224881,0.043062203,0,0.19617225,0.24401914,0.08373206,0.011961723}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.186603, "sweet": 0.0, "creamy": 0.0, "powdery": 0.059809}	0.41882774	2	{"autumn": 0.16527615551476724, "spring": 0.4254964124812281, "summer": 0.2902552978474887, "winter": 0.11897213415651593}	{"day": 0.8105912441703024, "night": 0.1894087558296976}	'lancome':2 'miracle':1
99	givenchy-l-interdit-eau-de-parfum-2018	L'Interdit Eau de Parfum	Givenchy	female	2018	https://fimgs.net/mdimg/perfume/375x500.51488.jpg	3.9721	14816	{0.09514563,0.039805826,0.041747574,0.052427184,0.040453073,0.03365696,0,0.090614885,0,0,0.10194175,0.2932039,0.06472492,0.14627832}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.174757, "creamy": 0.0, "powdery": 0.0}	0.30894822	3	{"autumn": 0.3429555945647227, "spring": 0.22729341395227878, "summer": 0.10773031662440674, "winter": 0.32202067485859176}	{"day": 0.46405154872258647, "night": 0.5359484512774135}	'de':4 'eau':3 'edp':7 'givenchy':6 'interdit':2 'l':1 'parfum':5
100	dolce-gabbana-the-one-for-men-2008	The One for Men	Dolce&Gabbana	male	2008	https://fimgs.net/mdimg/perfume/375x500.2056.jpg	4.2505	14755	{0.117706574,0.17065768,0.17521079,0.04148398,0,0.07419899,0.18785834,0.18043844,0,0.027993254,0.02445194,0,0,0}	{"sharp": 0.0, "smoky": 0.150084, "spicy": 0.23946, "sweet": 0.097808, "creamy": 0.0, "powdery": 0.0}	0.52440137	1	{"autumn": 0.3728969279356876, "spring": 0.1987941429801895, "summer": 0.09107091587711742, "winter": 0.33723801320700547}	{"day": 0.3695372113764741, "night": 0.6304627886235259}	'd':7 'dg':9 'dolce':5 'for':3 'g':8 'gabbana':6 'men':4 'one':2 'the':1
108	yves-saint-laurent-myslf-eau-de-parfum-2023	MYSLF Eau de Parfum	Yves Saint Laurent	male	2023	https://fimgs.net/mdimg/perfume/375x500.84094.jpg	4.3298	14319	{0.035168197,0.017584099,0.04617737,0.04770642,0.050458714,0.055045873,0.10550459,0.33425078,0.017431192,0.011620795,0.017584099,0.13944954,0.07553517,0.04648318}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.094801, "sweet": 0.070336, "creamy": 0.0, "powdery": 0.058104}	0.45795873	2	{"autumn": 0.2487052341597796, "spring": 0.31280073461891644, "summer": 0.30707070707070705, "winter": 0.13142332415059688}	{"day": 0.5849588209796273, "night": 0.4150411790203728}	'de':3 'eau':2 'edp':10 'laurent':7 'myself':9 'myslf':1 'parfum':4 'saint':6 'ysl':8 'yves':5
126	lancome-tresor-1990	Trésor	Lancôme	female	1990	https://fimgs.net/mdimg/perfume/375x500.172.jpg	3.6504	13262	{0.1869748,0.079936974,0.025630252,0.045378152,0,0.01512605,0,0,0,0,0.240021,0.22794117,0.1605042,0.018487396}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.212185, "creamy": 0.0, "powdery": 0.203782}	0.19066702	3	{"autumn": 0.37278234530506277, "spring": 0.1964517524881004, "summer": 0.11239723063608828, "winter": 0.3183686715707486}	{"day": 0.5007643961270596, "night": 0.49923560387294036}	'lancome':2 'tresor':1
155	giorgio-armani-acqua-di-gio-profondo-2020	Acqua di Giò Profondo	Giorgio Armani	male	2020	https://fimgs.net/mdimg/perfume/375x500.59532.jpg	4.3291	12045	{0,0,0.018257262,0.054771785,0,0.08506224,0.24813278,0.21286307,0.34024897,0.0406639,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.109959, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5337552	2	{"autumn": 0.11239723063608828, "spring": 0.37381003894418, "summer": 0.4705755084379057, "winter": 0.04321722198182605}	{"day": 0.7534356505166014, "night": 0.24656434948339853}	'acqua':1 'adg':8 'aqua':7 'armani':6 'di':2 'gio':3 'giorgio':5 'profondo':4
171	maison-francis-kurkdjian-baccarat-rouge-540-extrait-de-parfum-2017	Baccarat Rouge 540 Extrait de Parfum	Maison Francis Kurkdjian	unisex	2017	https://fimgs.net/mdimg/perfume/375x500.46066.jpg	4.2035	11503	{0.280829,0.13419689,0.20241795,0.1658031,0,0.057512954,0,0,0,0,0.11157168,0,0.047668394,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.134715, "sweet": 0.160622, "creamy": 0.25734, "powdery": 0.119171}	0.26881692	4	{"autumn": 0.32813398504887864, "spring": 0.21628809660724554, "summer": 0.11400230017251294, "winter": 0.34157561817136284}	{"day": 0.413354117952715, "night": 0.586645882047285}	'540':3 'baccarat':1 'br540':11 'de':5 'extrait':4 'francis':8 'kurkdjian':9 'maison':7 'mfk':10 'parfum':6 'rouge':2
176	rasasi-hawas-for-him-2015	Hawas for Him	Rasasi	male	2015	https://fimgs.net/mdimg/perfume/375x500.46890.jpg	4.2919	11389	{0.121176474,0.06549019,0.07294118,0.014117647,0,0,0.041764706,0.22803922,0.21254902,0,0.21568628,0,0.028235294,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.096078, "sweet": 0.078431, "creamy": 0.0, "powdery": 0.070588}	0.3837647	4	{"autumn": 0.15286718827374468, "spring": 0.3554521144894523, "summer": 0.41854016044369613, "winter": 0.07314053679310686}	{"day": 0.6852935796597769, "night": 0.31470642034022317}	'for':2 'hawas':1 'him':3 'rasasi':4
182	lancome-tresor-midnight-rose-2011	Trésor Midnight Rose	Lancôme	female	2011	https://fimgs.net/mdimg/perfume/375x500.11721.jpg	3.9631	11134	{0.13366337,0.037747525,0.050247524,0.046039604,0,0.015346535,0.095544554,0.022277229,0.02970297,0.018316831,0.28527227,0.17747524,0.06509901,0.023267327}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.116337, "sweet": 0.15099, "creamy": 0.0, "powdery": 0.0}	0.31899133	3	{"autumn": 0.3368373965555804, "spring": 0.18989040483113398, "summer": 0.10232610154327891, "winter": 0.3709460970700067}	{"day": 0.3695764019893672, "night": 0.6304235980106329}	'lancome':4 'midnight':2 'rose':3 'tresor':1
184	giorgio-armani-emporio-armani-stronger-with-you-2017	Emporio Armani Stronger With You	Giorgio Armani	male	2017	https://fimgs.net/mdimg/perfume/375x500.45258.jpg	4.2937	11106	{0.3523077,0.15230769,0.055076923,0.031384617,0,0,0.21353847,0,0,0.041846152,0.033846155,0.016615385,0.041538462,0.06153846}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.443077, "creamy": 0.104615, "powdery": 0.083077}	0.19041538	3	{"autumn": 0.3891963275059741, "spring": 0.1366494780530751, "summer": 0.048798893220978495, "winter": 0.42535530121997234}	{"day": 0.364173651407694, "night": 0.635826348592306}	'armani':2,7 'emporio':1 'giorgio':6 'stronger':3 'swy':8 'with':4 'you':5
185	chanel-bleu-de-chanel-parfum-2018	Bleu de Chanel Parfum	Chanel	male	2018	https://fimgs.net/mdimg/perfume/375x500.49912.jpg	4.45	11095	{0.0734072,0.06648199,0.120775625,0.16620499,0,0.07590028,0.17091413,0.19418283,0,0.079778396,0,0.014958449,0.03739612,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.174515, "sweet": 0.0, "creamy": 0.0, "powdery": 0.074792}	0.5101662	2	{"autumn": 0.26450603486812696, "spring": 0.265042467590523, "summer": 0.23080017881090747, "winter": 0.23965131873044257}	{"day": 0.49223022831843044, "night": 0.5077697716815696}	'bdc':7 'bleu':1 'blue':6 'chanel':3,5 'de':2 'parfum':4
187	chloe-nomade-2018	Nomade	Chloé	female	2018	https://fimgs.net/mdimg/perfume/375x500.48434.jpg	3.9697	10987	{0.066254415,0.022526503,0.03533569,0.10600707,0.20530035,0.070848055,0,0.1590106,0,0.011837455,0.16033569,0.10459364,0.05795053,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.090106, "creamy": 0.0, "powdery": 0.070671}	0.4017447	2	{"autumn": 0.3151847723570265, "spring": 0.3229014833233302, "summer": 0.20732230129469262, "winter": 0.1545914430249507}	{"day": 0.7011732229123534, "night": 0.29882677708764666}	'chloe':2 'nomade':1
219	giorgio-armani-emporio-armani-stronger-with-you-absolutely-2021	Emporio Armani Stronger With You Absolutely	Giorgio Armani	male	2021	https://fimgs.net/mdimg/perfume/375x500.64501.jpg	4.5164	10270	{0.29535317,0.16059479,0.1788104,0.12267658,0,0.033085503,0.09516729,0,0,0.023791822,0,0.015241636,0.03810409,0.03717472}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.10223, "sweet": 0.317844, "creamy": 0.078067, "powdery": 0.076208}	0.27767658	4	{"autumn": 0.39723013202174473, "spring": 0.09002070929329536, "summer": 0.036047113642246956, "winter": 0.4767020450427129}	{"day": 0.27789984965884124, "night": 0.7221001503411588}	'absolutely':6 'armani':2,8 'emporio':1 'giorgio':7 'stronger':3 'swy':9 'with':4 'you':5
222	davidoff-cool-water-1996	Cool Water	Davidoff	female	1996	https://fimgs.net/mdimg/perfume/375x500.508.jpg	3.6095	10044	{0.05666667,0.028333334,0,0,0,0,0.074,0.115,0.301,0,0.185,0.17633334,0.048,0.015666667}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.113333, "creamy": 0.0, "powdery": 0.0}	0.33961666	1	{"autumn": 0.0644709180098108, "spring": 0.27582340574632097, "summer": 0.6014015416958655, "winter": 0.0583041345480028}	{"day": 0.8962304108428631, "night": 0.10376958915713681}	'cool':1 'davidoff':3 'water':2
230	estee-lauder-pleasures-1995	Pleasures	Estée Lauder	female	1995	https://fimgs.net/mdimg/perfume/375x500.536.jpg	3.8314	9855	{0.044063926,0,0.02739726,0.028767124,0,0.009589041,0.078310505,0.05,0.06666667,0.11324201,0,0.386758,0.14086758,0.0543379}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.059361, "sweet": 0.0, "creamy": 0.0, "powdery": 0.047945}	0.3724886	2	{"autumn": 0.127960794990471, "spring": 0.4780833106452491, "summer": 0.3034304383337871, "winter": 0.09052545603049278}	{"day": 0.842508377213978, "night": 0.15749162278602202}	'estee':2 'lauder':3 'pleasures':1
285	rasasi-hawas-ice-2023	Hawas Ice	Rasasi	male	2023	https://fimgs.net/mdimg/perfume/375x500.89050.jpg	4.3975	8416	{0.10397878,0.02586207,0,0.015384615,0,0.014323607,0.13076924,0.2846154,0.03607427,0.016976127,0.29111406,0.014323607,0.06657825,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.071618, "sweet": 0.103448, "creamy": 0.0, "powdery": 0.148541}	0.37153184	4	{"autumn": 0.17115911552921684, "spring": 0.34250939909513795, "summer": 0.40495762441853056, "winter": 0.08137386095711464}	{"day": 0.7088703563305534, "night": 0.29112964366944655}	'hawas':1 'ice':2 'rasasi':3
335	jo-malone-london-myrrh-tonka-2016	Myrrh & Tonka	Jo Malone London	unisex	2016	https://fimgs.net/mdimg/perfume/375x500.42027.jpg	4.2035	7532	{0.33540773,0.25096565,0.12403434,0.012875536,0,0,0.16309012,0,0,0.021459227,0.050965667,0,0,0.04120172}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.092275, "sweet": 0.422747, "creamy": 0.064378, "powdery": 0.0}	0.23325644	2	{"autumn": 0.4047680412371134, "spring": 0.12268041237113401, "summer": 0.0547680412371134, "winter": 0.4177835051546392}	{"day": 0.36453526697429134, "night": 0.6354647330257086}	'jo':3 'london':5 'malone':4 'myrrh':1 'tonka':2
358	giorgio-armani-acqua-di-gio-parfum-2023	Acqua di Giò Parfum	Giorgio Armani	male	2023	https://fimgs.net/mdimg/perfume/375x500.81508.jpg	4.4397	7264	{0.038857143,0.04114286,0.092857145,0.065142855,0.032857142,0.07314286,0.32428572,0.146,0.12857144,0.057142857,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.254286, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.55214286	2	{"autumn": 0.21275816610517065, "spring": 0.3339680679654314, "summer": 0.3643620916947415, "winter": 0.08891167423465651}	{"day": 0.5998667554963357, "night": 0.4001332445036642}	'acqua':1 'adg':8 'aqua':7 'armani':6 'di':2 'gio':3 'giorgio':5 'parfum':4
455	dior-sauvage-parfum-2019	Sauvage Parfum	Dior	male	2019	https://fimgs.net/mdimg/perfume/375x500.56324.jpg	4.1094	6272	{0.1572,0.0988,0.1088,0.0888,0,0.0508,0.1538,0.2318,0,0.0252,0,0.0176,0.044,0.0232}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.196, "sweet": 0.116, "creamy": 0.0, "powdery": 0.088}	0.43518	3	{"autumn": 0.29537241075363596, "spring": 0.2606434552666373, "summer": 0.1628911414720141, "winter": 0.28109299250771264}	{"day": 0.45701507371210864, "night": 0.5429849262878913}	'christian':4 'dior':3,5 'parfum':2 'sauvage':1 'savage':6
488	estee-lauder-youth-dew-1953	Youth-Dew	Estée Lauder	female	1953	https://fimgs.net/mdimg/perfume/375x500.555.jpg	3.7376	6059	{0.21685083,0.21574585,0.32348067,0.059668507,0.043093923,0.07790055,0,0,0,0.0071823206,0,0.0160221,0.04005525,0}	{"sharp": 0.0, "smoky": 0.060773, "spicy": 0.337017, "sweet": 0.0, "creamy": 0.0, "powdery": 0.08011}	0.45785913	4	{"autumn": 0.38475750577367207, "spring": 0.10762124711316397, "summer": 0.07413394919168591, "winter": 0.43348729792147805}	{"day": 0.3531760435571688, "night": 0.6468239564428312}	'dew':3 'estee':4 'lauder':5 'youth':2 'youth-dew':1
593	yves-saint-laurent-myslf-le-parfum-2024	MYSLF Le Parfum	Yves Saint Laurent	male	2024	https://fimgs.net/mdimg/perfume/375x500.94983.jpg	4.315	5254	{0.19758242,0.118351646,0.09142857,0.083076924,0,0.046593405,0.04725275,0.13824175,0,0,0.024725275,0.13186814,0.043956045,0.07692308}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.167033, "sweet": 0.263736, "creamy": 0.0, "powdery": 0.0}	0.3401154	2	{"autumn": 0.28259125551544323, "spring": 0.2703569995988769, "summer": 0.18130766145206578, "winter": 0.2657440834336141}	{"day": 0.4778743961352657, "night": 0.5221256038647343}	'laurent':6 'le':2 'myself':8 'myslf':1 'parfum':3 'saint':5 'ysl':7 'yves':4
640	giorgio-armani-acqua-di-gio-1995	Acqua di Gio	Giorgio Armani	female	1995	https://fimgs.net/mdimg/perfume/375x500.411.jpg	3.9776	4950	{0.0349345,0.01746725,0,0,0,0,0.0930131,0.070305675,0.11703057,0.09082969,0.09170306,0.34279475,0.10524017,0.036681224}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.069869, "creamy": 0.0, "powdery": 0.0}	0.3518559	2	{"autumn": 0.08482871125611746, "spring": 0.3578031538879826, "summer": 0.5043501903208265, "winter": 0.05301794453507341}	{"day": 0.8658318425760286, "night": 0.13416815742397137}	'acqua':1 'adg':7 'aqua':6 'armani':5 'di':2 'gio':3 'giorgio':4
647	comme-des-garcons-comme-des-garcons-2-1999	Comme des Garcons 2	Comme des Garcons	unisex	1999	https://fimgs.net/mdimg/perfume/375x500.390.jpg	4.1658	4911	{0.027571116,0.08271335,0.058643326,0.09321663,0,0.056017507,0.2643326,0.15754923,0.035886213,0.043763675,0,0.09321663,0.08708972,0}	{"sharp": 0.115974, "smoky": 0.0, "spicy": 0.124726, "sweet": 0.0, "creamy": 0.0, "powdery": 0.115974}	0.47932166	3	{"autumn": 0.31381345926800475, "spring": 0.30318772136953953, "summer": 0.17473435655253838, "winter": 0.20826446280991737}	{"day": 0.6383265856950068, "night": 0.3616734143049933}	'2':4 'cdg':8 'comme':1,5 'des':2,6 'garcons':3,7
785	giorgio-armani-acqua-di-gio-absolu-2018	Acqua di Giò Absolu	Giorgio Armani	male	2018	https://fimgs.net/mdimg/perfume/375x500.48138.jpg	4.1125	4286	{0.047826085,0.069960475,0.09802371,0.11383399,0,0.06126482,0.21640316,0.16936758,0.11067194,0.03952569,0.07312253,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.177866, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5083992	2	{"autumn": 0.2680714076675446, "spring": 0.3124085455077553, "summer": 0.30143400643839624, "winter": 0.11808604038630377}	{"day": 0.5848849945235487, "night": 0.41511500547645125}	'absolu':4 'acqua':1 'adg':8 'aqua':7 'armani':6 'di':2 'gio':3 'giorgio':5
868	davidoff-cool-water-intense-2019	Cool Water Intense	Davidoff	male	2019	https://fimgs.net/mdimg/perfume/375x500.55266.jpg	4.0517	3987	{0.25939086,0.20342639,0.07106599,0.05025381,0,0.015228426,0,0.23350254,0,0,0.125,0.011167512,0.019796954,0.011167512}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.340102, "creamy": 0.251269, "powdery": 0.0}	0.23368655	3	{"autumn": 0.226751931787903, "spring": 0.3305355715427658, "summer": 0.33786304289901414, "winter": 0.10484945377031708}	{"day": 0.6112519006588951, "night": 0.38874809934110494}	'cool':1 'davidoff':4 'intense':3 'water':2
882	giorgio-armani-acqua-di-gio-eau-de-parfum-2022	Acqua di Giò Eau de Parfum	Giorgio Armani	male	2022	https://fimgs.net/mdimg/perfume/375x500.71606.jpg	4.0499	3931	{0,0,0.013450292,0.040350877,0,0.096491225,0.34356725,0.14649123,0.3011696,0.058479533,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.078947, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5343275	1	{"autumn": 0.15074702031223772, "spring": 0.37132784958871917, "summer": 0.42840355883834147, "winter": 0.0495215712607017}	{"day": 0.7531873161163779, "night": 0.2468126838836221}	'acqua':1 'adg':11 'aqua':9 'armani':8 'de':5 'di':2 'eau':4 'edp':10 'gio':3 'giorgio':7 'parfum':6
901	rasasi-hawas-black-2024	Hawas Black	Rasasi	male	2024	https://fimgs.net/mdimg/perfume/375x500.96817.jpg	4.2244	3864	{0.033834588,0.016917294,0.071177945,0.15037593,0.25714287,0.118045114,0.03884712,0.20877193,0,0.012781955,0.09210526,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.077694, "sweet": 0.067669, "creamy": 0.0, "powdery": 0.0}	0.51455516	4	{"autumn": 0.2601802212843618, "spring": 0.26782251625413483, "summer": 0.24386905440857762, "winter": 0.22812820805292575}	{"day": 0.5135195530726256, "night": 0.4864804469273743}	'black':2 'hawas':1 'rasasi':3
921	comme-des-garcons-wonderwood-2010	Wonderwood	Comme des Garcons	male	2010	https://fimgs.net/mdimg/perfume/375x500.8991.jpg	4.1874	3804	{0.08301887,0.05433962,0.17358491,0.2264151,0,0.13735849,0.18679245,0.048679244,0,0.026415095,0,0.018113207,0.04528302,0}	{"sharp": 0.0, "smoky": 0.049057, "spicy": 0.25283, "sweet": 0.0, "creamy": 0.0, "powdery": 0.090566}	0.52056605	1	{"autumn": 0.3971805087342936, "spring": 0.20410665032178976, "summer": 0.07876187557462458, "winter": 0.3199509653692921}	{"day": 0.5650342285413376, "night": 0.43496577145866244}	'cdg':5 'comme':2 'des':3 'garcons':4 'wonderwood':1
3	lancome-la-vie-est-belle-2012	La Vie Est Belle	Lancôme	female	2012	https://fimgs.net/mdimg/perfume/375x500.14982.jpg	3.6453	35714	{0.2614035,0.09974937,0.04962406,0.058646616,0.050125312,0.039598998,0,0,0,0,0.1904762,0.08947369,0.106265664,0.05463659}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.43609, "creamy": 0.0, "powdery": 0.150376}	0.18066417	4	{"autumn": 0.3157245700573257, "spring": 0.20460605252632982, "summer": 0.11398480202639648, "winter": 0.36568457538994803}	{"day": 0.4956485046679677, "night": 0.5043514953320323}	'belle':4 'est':3 'la':1 'lancome':5 'vie':2
4	mugler-angel-1992	Angel	Mugler	female	1992	https://fimgs.net/mdimg/perfume/375x500.704.jpg	3.5374	35335	{0.35249344,0.14146982,0.12519684,0.056692913,0.06167979,0.043569554,0,0,0,0,0.18372704,0,0,0.035170604}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.115486, "sweet": 0.548556, "creamy": 0.0, "powdery": 0.0}	0.22501312	4	{"autumn": 0.2923725277476425, "spring": 0.1285571225903363, "summer": 0.08804139197196027, "winter": 0.49102895769006094}	{"day": 0.32880949375078905, "night": 0.671190506249211}	'angel':1 'mugler':2,4 'thierry':3
5	yves-saint-laurent-black-opium-2014	Black Opium	Yves Saint Laurent	female	2014	https://fimgs.net/mdimg/perfume/375x500.25324.jpg	3.9413	34996	{0.3246729,0.072897196,0.1953271,0.05495327,0,0.048971962,0,0,0,0,0.12149533,0.075140186,0.025046729,0.08149533}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.214953, "sweet": 0.328972, "creamy": 0.0, "powdery": 0.0}	0.29892522	2	{"autumn": 0.382532030952683, "spring": 0.10522643663579856, "summer": 0.0678041354814157, "winter": 0.44443739693010276}	{"day": 0.27129643824416166, "night": 0.7287035617558383}	'black':1 'laurent':5 'opium':2 'saint':4 'ysl':6 'yves':3
\.


--
-- Data for Name: name_aliases; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.name_aliases (alias, name_word) FROM stdin;
myself	MYSLF
savage	Sauvage
blue	Bleu
aqua	Acqua
aqua	Aqva
vanilla	Vanille
jadore	J'adore
kamrah	Khamrah
br540	Baccarat Rouge 540
no5	No 5
edp	Eau de Parfum
edt	Eau de Toilette
torino 21	Torino21
9 pm	9pm
bdc	Bleu de Chanel
adg	Acqua di Giò
cdnim	Club de Nuit Intense Man
tv	Tobacco Vanille
lmw	Le Male
swy	Stronger With You
\.


--
-- Data for Name: notes; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.notes (id, name, mapped, profile, facets, harshness) FROM stdin;
35	Neroli	t	{0,0,0,0,0,0,0,0.5,0,0,0,0.5,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.45
36	Ambroxan	t	{0,0.3,0.4,0.3,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.435
37	Coriander	t	{0,0,0,0,0,0,0.5,0.3,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.72
38	Mint	t	{0,0,0,0,0,0,0.6,0,0,0.4,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58
39	Peony	t	{0,0,0,0,0,0,0,0,0,0,0.2,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
40	Saffron	t	{0,0.2,0.5,0,0,0.3,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.74
41	Freesia	t	{0,0,0,0,0,0,0,0,0,0.2,0,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.35
42	Green Notes	t	{0,0,0,0,0,0,0,0,0,1,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.7
43	Heliotrope	t	{0.5,0,0,0,0,0,0,0,0,0,0,0,0.5,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 1.0}	0
44	Nutmeg	t	{0,0.2,0.5,0,0,0,0.3,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.65
45	Orange	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
46	Plum	t	{0.3,0,0,0,0,0,0,0,0,0,0.7,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.255
47	Ambergris	t	{0,0.4,0.3,0,0,0,0,0,0.3,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4
48	Caramel	t	{0.7,0.3,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0
49	Guaiac Wood	t	{0,0,0.4,0,0,0.6,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.97
50	Lily	t	{0,0,0,0,0,0,0,0,0,0,0,0.7,0.3,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.255
51	Orchid	t	{0,0,0,0,0,0,0,0,0,0,0,0.5,0.3,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.255
52	Pineapple	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
53	Apple	t	{0,0,0,0,0,0,0,0,0,0.2,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.38
54	Pepper	t	{0,0,0.2,0,0,0.4,0.4,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.79
55	Rosemary	t	{0,0,0,0,0,0,0.8,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.54
56	Woody Notes	t	{0,0,0,0.7,0,0.3,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52
57	Labdanum	t	{0,0.6,0.4,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.39
58	Magnolia	t	{0,0,0,0,0,0,0,0.2,0,0,0,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.33
59	Sage	t	{0,0,0,0,0,0,0.7,0,0,0.3,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.56
60	Tobacco	t	{0,0.3,0.5,0,0,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.785
61	Carnation	t	{0,0,0,0,0,0,0,0,0,0,0,0.6,0,0.4}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.45
62	Gardenia	t	{0,0,0,0,0,0,0,0,0,0,0,0.6,0.2,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 1.0, "powdery": 0.0}	0.07
63	Honey	t	{0.5,0.3,0,0,0,0,0,0,0,0,0,0,0,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.01
64	Jasmine Sambac	t	{0,0,0,0,0,0,0,0,0,0,0,0.6,0.2,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
65	Praline	t	{0.8,0.2,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0
66	Amberwood	t	{0,0,0.6,0.4,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52
67	Brazilian Rosewood	t	{0,0,0,0.5,0,0,0.2,0,0,0,0,0.3,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.39
68	Cashmeran	t	{0.2,0,0.5,0.3,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.45
69	Coconut	t	{0.5,0,0,0.2,0,0,0,0,0,0,0.3,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 1.0, "powdery": 0.0}	0
70	Raspberry	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
71	Agarwood (Oud)	t	{0,0.2,0.5,0,0,0.3,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.84
72	Clary Sage	t	{0,0,0.2,0,0,0,0.6,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.56
73	Coffee	t	{0.3,0,0.5,0,0,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.505
74	Lotus	t	{0,0,0,0,0,0,0,0,0.4,0,0,0.4,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.31
75	Basil	t	{0,0,0,0,0,0,0.6,0,0,0.4,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58
76	Mimosa	t	{0,0,0,0,0,0,0,0,0,0,0,0.5,0.5,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.075
77	Almond	t	{0.6,0,0,0.2,0,0,0,0,0,0,0.2,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 1.0, "powdery": 0.0}	0
78	Cloves	t	{0,0.2,0.6,0,0,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.72
79	Licorice	t	{0.4,0,0.2,0,0,0,0.4,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.18
80	Narcissus	t	{0,0,0,0,0,0,0,0,0,0.3,0,0.5,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.39
81	Aldehydes	t	{0,0,0,0,0,0,0,0.2,0,0,0,0.2,0.6,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.32
82	Honeysuckle	t	{0,0,0,0,0,0,0,0,0,0,0.2,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
83	Juniper	t	{0,0,0,0,0,0.2,0.6,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
84	Opoponax	t	{0,0.6,0.4,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.19
85	Rum	t	{0.4,0.4,0.2,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.08
86	Ambrette (Musk Mallow)	t	{0.3,0,0,0,0,0,0,0,0,0,0.3,0,0.4,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.045
87	Calone	t	{0,0,0,0,0,0,0,0,1,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4
88	Caraway	t	{0,0,0.3,0,0,0.2,0.5,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.74
89	Citruses	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
90	Coumarin	t	{0.6,0.2,0,0,0,0,0.2,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.04
91	Cypress	t	{0,0,0,0,0,0.4,0.3,0,0,0.3,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.68
92	Melon	t	{0,0,0,0,0,0,0,0,0.4,0,0.6,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.34
93	Moss	t	{0,0,0,0,1,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5
94	Osmanthus	t	{0,0,0,0,0,0,0,0,0,0,0.3,0.5,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
95	Petitgrain	t	{0,0,0,0,0,0,0,0.6,0,0.4,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.64
96	Red Berries	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
97	Spices	t	{0,0.3,0.5,0,0,0,0.2,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.625
98	Tobacco Leaf	t	{0,0,0.4,0,0,0.4,0,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.95
99	Violet Leaf	t	{0,0,0,0,0,0,0,0,0,0.6,0,0,0.4,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.48
100	Apricot	t	{0.2,0,0,0,0,0,0,0,0,0,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
101	Bitter Orange	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.8
102	Cacao	t	{0.6,0,0.4,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.13
103	Civet	t	{0,0.3,0.5,0,0,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.535
104	Cyclamen	t	{0,0,0,0,0,0,0,0,0.2,0.2,0,0.6,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4
105	Iso E Super	t	{0,0,0.4,0.6,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.48
106	Litchi	t	{0,0,0,0,0,0,0,0,0,0,0.7,0.3,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
107	Strawberry	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
108	Sugar	t	{0.6,0,0,0,0,0,0,0,0,0,0.4,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.01
109	Tangerine	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
110	Akigalawood	t	{0,0,0.5,0,0,0.3,0.2,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.64
111	Anise	t	{0.3,0,0.2,0,0,0,0.5,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.565
112	Blackberry	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
113	Chestnut	t	{0.5,0,0,0.5,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 1.0, "powdery": 0.0}	0.075
114	Fig	t	{0,0,0,0.2,0,0,0,0,0,0.4,0.4,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.48
115	Fig Leaf	t	{0,0,0,0,0,0,0,0,0,0.7,0.3,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58
116	Galbanum	t	{0,0,0,0,0,0,0,0,0,1,0,0,0,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.9
117	Olibanum	t	{0,0.2,0.3,0,0,0.5,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.88
118	Sea Notes	t	{0,0,0,0,0,0,0,0,1,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4
119	Star Anise	t	{0.3,0,0.3,0,0,0,0.4,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.575
120	Suede	t	{0.2,0,0,0,0,0.4,0,0,0,0,0,0,0.4,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.26
121	Thyme	t	{0,0,0,0,0,0,0.8,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.54
122	Artemisia	t	{0,0,0,0,0,0,0.6,0,0,0.4,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58
123	Bitter Almond	t	{0.5,0,0,0,0,0,0,0,0,0,0.3,0.2,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.225
124	Black Pepper	t	{0,0,0.2,0,0,0.4,0.4,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.79
125	Cassia	t	{0.2,0.3,0.5,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.555
126	Cassis	t	{0,0,0,0,0,0,0,0,0,0.3,0.7,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.42
127	Green Tea	t	{0,0,0,0,0,0,0,0.2,0.4,0.4,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.56
128	Hedione	t	{0,0,0,0,0,0,0,0.3,0.3,0,0,0.4,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.42
129	Lilac	t	{0,0,0,0,0,0,0,0,0,0.2,0,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.35
130	Lime	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.8
131	Mahogany	t	{0,0,0,0.7,0,0.3,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52
132	Sour Cherry	t	{0.2,0,0,0,0,0,0,0,0,0,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.07
133	Spicy Notes	t	{0,0.3,0.5,0,0,0,0.2,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.625
134	Elemi	t	{0,0,0,0,0,0.3,0.3,0.4,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.63
135	Hyacinth	t	{0,0,0,0,0,0,0,0,0,0.5,0,0.5,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5
136	Water Notes	t	{0,0,0,0,0,0,0,0,1,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.4
137	White Honey	t	{0.5,0.3,0,0,0,0,0,0,0,0,0,0,0,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.01
138	Sugar Cane	t	{0.5,0,0,0,0,0,0,0,0,0.2,0.3,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.105
139	Rhubarb	t	{0,0,0,0,0,0,0,0.2,0,0.4,0.4,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52
140	Toffee	t	{0.8,0.2,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0
141	Water Lily	t	{0,0,0,0,0,0,0,0,0.5,0,0,0.5,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.35
142	Whipped Cream	t	{1,0,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 1.0, "powdery": 0.0}	0
143	Seaweed	t	{0,0,0,0,0.2,0,0,0,0.8,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.42
144	Clementine	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
145	Green Apple	t	{0,0,0,0,0,0,0,0,0,0.4,0.6,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.46
146	Red Apple	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
147	Quince	t	{0,0,0,0,0,0,0,0,0,0.3,0.7,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.42
148	Birch	t	{0,0,0.4,0,0,0.6,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.97
149	Salt	t	{0,0,0,0,0,0.2,0,0,0.8,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.48
150	Myrrh	t	{0,0.6,0.4,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.39
242	Fruity Notes	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
251	Green Mandarin	t	{0,0,0,0,0,0,0,0.8,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.62
159	Angelica	t	{0,0,0,0,0,0,0.5,0,0,0.3,0,0,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.49
200	Chamomile	t	{0.2,0,0,0,0,0,0.5,0,0,0,0.3,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.37
154	Amaryllis	f	\N	\N	\N
32	Tuberose	t	{0,0,0,0,0,0,0,0,0,0,0,0.6,0,0.4}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
33	Black Currant	t	{0,0,0,0,0,0,0,0,0,0.2,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.38
178	Blood Orange	t	{0,0,0,0,0,0,0,0.8,0,0,0.2,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.54
2926	Absinthe	f	\N	\N	\N
152	African Marigold	f	\N	\N	\N
2929	Allspice	f	\N	\N	\N
153	Almond Blossom	f	\N	\N	\N
2931	Almond Milk	f	\N	\N	\N
2932	Almond Tree	f	\N	\N	\N
2933	Amaretto	f	\N	\N	\N
155	Ambermax™	f	\N	\N	\N
156	Ambrettolide	f	\N	\N	\N
157	Ambrofix™	f	\N	\N	\N
158	Amyl Salicylate	f	\N	\N	\N
2939	Amyris	f	\N	\N	\N
160	Animal notes	f	\N	\N	\N
2941	Apple Blossom	f	\N	\N	\N
2942	Apple Leaf	f	\N	\N	\N
161	Apple Tree	f	\N	\N	\N
162	Apple Tree Blossom	f	\N	\N	\N
163	Apricot Blossom	f	\N	\N	\N
2946	Aqual	f	\N	\N	\N
164	Aquozone	f	\N	\N	\N
2948	Arum Lily	f	\N	\N	\N
2949	Balsam Fir	f	\N	\N	\N
165	Bamboo	f	\N	\N	\N
2951	Banana	f	\N	\N	\N
2952	Banana Leaf	f	\N	\N	\N
166	Bay Leaf	f	\N	\N	\N
167	Beeswax	f	\N	\N	\N
2955	Belambra tree	f	\N	\N	\N
2956	Belladonna	f	\N	\N	\N
168	Bellflower	f	\N	\N	\N
2958	Bergamot Leaf	f	\N	\N	\N
2959	Big Strawberry	f	\N	\N	\N
2960	Bitter Orange Blossom	f	\N	\N	\N
2961	Black Amber	f	\N	\N	\N
2962	Black Basil	f	\N	\N	\N
2963	Black Cardamom	f	\N	\N	\N
169	Black Cherry	f	\N	\N	\N
2965	Black Elder	f	\N	\N	\N
2966	Black Licorice	f	\N	\N	\N
2967	Black Musk	f	\N	\N	\N
170	Black Orchid	f	\N	\N	\N
171	Black Rose	f	\N	\N	\N
173	Black Vanilla Husk	f	\N	\N	\N
183	Buchu or Agathosma	f	\N	\N	\N
2992	Buddleia	f	\N	\N	\N
184	Bulrush	f	\N	\N	\N
2994	Burning Cherry	f	\N	\N	\N
2995	Cacao Butter	f	\N	\N	\N
185	Cacao Pod	f	\N	\N	\N
186	Cactus	f	\N	\N	\N
2998	Cactus Flower	f	\N	\N	\N
2999	Cade oil	f	\N	\N	\N
3000	Calamus	f	\N	\N	\N
3001	Calypsone	f	\N	\N	\N
3002	Cambodian Oud	f	\N	\N	\N
188	Camelia	f	\N	\N	\N
3004	Camellia	f	\N	\N	\N
189	Candied Almond	f	\N	\N	\N
190	Candied Fruits	f	\N	\N	\N
3007	Candied Ginger	f	\N	\N	\N
191	Candied Lemon	f	\N	\N	\N
192	Candy apple	f	\N	\N	\N
3010	Cappuccino	f	\N	\N	\N
193	Carambola (Star Fruit)	f	\N	\N	\N
194	Carrot	f	\N	\N	\N
195	Carrot Seeds	f	\N	\N	\N
3014	Casablanca Lily	f	\N	\N	\N
3015	Cashmirwood	f	\N	\N	\N
196	Castoreum	f	\N	\N	\N
197	Caviar	f	\N	\N	\N
198	Celery Seeds	f	\N	\N	\N
3019	Celosia	f	\N	\N	\N
199	Cetalox	f	\N	\N	\N
201	Champaca	f	\N	\N	\N
3022	Champagne	f	\N	\N	\N
3023	Champagne Rosé	f	\N	\N	\N
202	Cherry	f	\N	\N	\N
203	Cherry Blossom	f	\N	\N	\N
204	Cherry Liqueur	f	\N	\N	\N
205	Chinese Black Tea	f	\N	\N	\N
206	Chinese Cinnamon Wood	f	\N	\N	\N
208	Chinotto	f	\N	\N	\N
209	Chocolate	f	\N	\N	\N
3031	Cistus Incanus	f	\N	\N	\N
210	Citron	f	\N	\N	\N
3033	Civetta	f	\N	\N	\N
3034	Clearwood	f	\N	\N	\N
211	Clover	f	\N	\N	\N
212	Coal	f	\N	\N	\N
3037	Coca-Cola	f	\N	\N	\N
3038	Coconut Blossom	f	\N	\N	\N
213	Coconut Milk	f	\N	\N	\N
3040	Coconut Nectar	f	\N	\N	\N
3041	Coconut Powder	f	\N	\N	\N
214	Coconut Water	f	\N	\N	\N
215	Cognac	f	\N	\N	\N
216	Cotton Candy	f	\N	\N	\N
217	Cotton Flower	f	\N	\N	\N
221	Cupcake	f	\N	\N	\N
3051	Curry Tree	f	\N	\N	\N
3052	Cypress Leaf	f	\N	\N	\N
3053	Cypriol	f	\N	\N	\N
222	Cypriol Oil or Nagarmotha	f	\N	\N	\N
3055	Damask Plum	f	\N	\N	\N
223	Dark Chocolate	f	\N	\N	\N
224	Dates	f	\N	\N	\N
225	Datura	f	\N	\N	\N
226	Davana	f	\N	\N	\N
3060	Dew Drop	f	\N	\N	\N
227	Dragée	f	\N	\N	\N
228	Dried Fruits	f	\N	\N	\N
229	Driftwood	f	\N	\N	\N
230	Dry Wood	f	\N	\N	\N
3065	Dulce de leche	f	\N	\N	\N
3066	Earl Grey Tea	f	\N	\N	\N
3067	Earthy Notes	f	\N	\N	\N
3068	Ebony	f	\N	\N	\N
3069	Eucalyptus	f	\N	\N	\N
3070	Evernyl	f	\N	\N	\N
231	Exotic Woods	f	\N	\N	\N
3072	Exotic floral notes	f	\N	\N	\N
3073	False Jasmine	f	\N	\N	\N
232	Fennel	f	\N	\N	\N
3075	Fern	f	\N	\N	\N
233	Fig Nectar	f	\N	\N	\N
234	Fig Tree	f	\N	\N	\N
3078	Finger Lime	f	\N	\N	\N
235	Fir	f	\N	\N	\N
236	Fir Resin	f	\N	\N	\N
237	Flax	f	\N	\N	\N
238	Flint	f	\N	\N	\N
3085	Flowers	f	\N	\N	\N
3086	Forest Fruits	f	\N	\N	\N
3087	Forget me not	f	\N	\N	\N
240	Frangipani	f	\N	\N	\N
3089	Frankincense	f	\N	\N	\N
3090	French Narcissus	f	\N	\N	\N
3091	Fresh Almond	f	\N	\N	\N
241	Fruits	f	\N	\N	\N
19	Oakmoss	t	{0,0,0,0,1,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5
20	Pink Pepper	t	{0,0,0,0,0,0.3,0.4,0.3,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.77
21	Incense	t	{0,0.2,0.3,0,0,0.5,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.88
22	Cardamom	t	{0,0,0.3,0,0,0,0.5,0.2,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.7
23	Peach	t	{0,0,0,0,0,0,0,0,0,0,0.8,0,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
24	White Musk	t	{0.3,0,0,0,0,0,0,0,0.2,0,0,0,0.5,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.05
25	Benzoin	t	{0.4,0.6,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.01
26	Grapefruit	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.8
27	Violet	t	{0,0,0,0,0,0,0,0,0,0,0,0.3,0.7,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.045
28	Leather	t	{0,0,0.4,0,0,0.6,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.97
29	Pear	t	{0,0,0,0,0,0,0,0,0,0.2,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.38
30	Ylang-Ylang	t	{0,0,0,0,0,0,0,0,0,0,0,0.5,0,0.5}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
31	Geranium	t	{0,0,0,0,0,0,0.3,0,0,0.4,0,0.3,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.52
34	Ginger	t	{0,0,0.3,0,0,0,0.4,0.3,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.71
1	Bergamot	t	{0,0,0,0,0,0,0.2,0.8,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.58
2	Musk	t	{0.4,0,0,0.2,0,0,0,0,0,0,0,0,0.4,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.05
3	Vanilla	t	{0.7,0.3,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0
4	Jasmine	t	{0,0,0,0,0,0,0,0,0,0,0,0.7,0.3,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.255
5	Amber	t	{0.3,0.7,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.22
6	Sandalwood	t	{0.3,0,0,0.7,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 1.0, "powdery": 0.0}	0.125
7	Patchouli	t	{0,0,0.3,0,0.5,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.59
8	Cedar	t	{0,0,0,0.6,0,0.4,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.56
9	Rose	t	{0,0,0,0,0,0,0,0,0,0,0,0.7,0.3,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.255
10	Tonka Bean	t	{0.7,0.3,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0
239	Floral Notes	f	\N	\N	\N
3084	Flower Petals	f	\N	\N	\N
243	Fruity and Spicy Notes	f	\N	\N	\N
3094	Galanga	f	\N	\N	\N
3095	Galbanum Leaf	f	\N	\N	\N
3096	Georgywood	f	\N	\N	\N
3097	Geosmin	f	\N	\N	\N
3098	Gin	f	\N	\N	\N
244	Ginger flower	f	\N	\N	\N
3100	Gingerbread	f	\N	\N	\N
3101	Goji Berries	f	\N	\N	\N
3102	Gooseberry	f	\N	\N	\N
245	Gourmand Accord	f	\N	\N	\N
151	African Freesia Petals	f	\N	\N	\N
172	Black Tea	f	\N	\N	\N
176	Blood Grapefruit	f	\N	\N	\N
187	Californian Gardenia	f	\N	\N	\N
246	Granny Smith apple	f	\N	\N	\N
264	Indian Tuberose	f	\N	\N	\N
351	Tea	t	{0,0,0,0.3,0,0,0.4,0,0,0.3,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.53
346	Styrax	t	{0,0.5,0.3,0,0,0.2,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 1.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.715
378	White Flowers	t	{0,0,0,0,0,0,0,0,0,0,0,0.6,0.2,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.27
313	Peru Balsam	t	{0.4,0.6,0,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.01
322	Pomegranate	t	{0,0,0,0,0,0,0,0,0,0.2,0.8,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.38
365	Vanilla Orchid	t	{0.5,0,0,0,0,0,0,0,0,0,0,0.3,0,0.2}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 0.0, "powdery": 0.0}	0.025
174	Black Violet	f	\N	\N	\N
2972	Black and Pink Pepper	f	\N	\N	\N
207	Chinese Osmanthus	f	\N	\N	\N
318	Pink Grapefruit	f	\N	\N	\N
334	Rose Oil	f	\N	\N	\N
338	Sea Salt	f	\N	\N	\N
345	Spanish Labdanum	f	\N	\N	\N
2973	Black currant leaf	f	\N	\N	\N
175	Black locust	f	\N	\N	\N
2975	Black locust Honey	f	\N	\N	\N
2976	Blackwood	f	\N	\N	\N
177	Blood Mandarin	f	\N	\N	\N
179	Blue Hyacinth	f	\N	\N	\N
180	Blue Lotus	f	\N	\N	\N
2980	Bluebell	f	\N	\N	\N
2981	Blueberry	f	\N	\N	\N
2982	Boronia	f	\N	\N	\N
181	Bourbon Whiskey	f	\N	\N	\N
2984	Bran	f	\N	\N	\N
2985	Brandy	f	\N	\N	\N
2986	Brazilian Orange	f	\N	\N	\N
2987	Brazilian Redwood	f	\N	\N	\N
2988	Broom	f	\N	\N	\N
182	Brown sugar	f	\N	\N	\N
2990	Bubble Gum	f	\N	\N	\N
11	Vetiver	t	{0,0,0,0,0.2,0.6,0,0,0,0.2,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.72
12	Mandarin Orange	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.6
13	Lavender	t	{0,0,0,0,0,0,1,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.5
14	Orange Blossom	t	{0,0,0,0,0,0,0,0.2,0,0,0,0.6,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.33
15	Lemon	t	{0,0,0,0,0,0,0,1,0,0,0,0,0,0}	{"sharp": 1.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.8
16	Iris	t	{0,0,0,0,0,0,0,0,0,0,0,0.3,0.7,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 1.0}	0.045
17	Cinnamon	t	{0.2,0.3,0.5,0,0,0,0,0,0,0,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 1.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.555
18	Lily-of-the-Valley	t	{0,0,0,0,0,0,0,0,0,0.3,0,0.5,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.39
218	Cranberry	f	\N	\N	\N
3047	Creme Brulee	f	\N	\N	\N
219	Cucumber	f	\N	\N	\N
3104	Grapefruit blossom	f	\N	\N	\N
3105	Grass	f	\N	\N	\N
3106	Gray Musk	f	\N	\N	\N
247	Green Accord	f	\N	\N	\N
3108	Green Almond	f	\N	\N	\N
3109	Green Bell Pepper	f	\N	\N	\N
248	Green Grass	f	\N	\N	\N
249	Green Leaves	f	\N	\N	\N
250	Green Lilac	f	\N	\N	\N
3113	Green Lily	f	\N	\N	\N
252	Green Mango	f	\N	\N	\N
253	Green Pepper	f	\N	\N	\N
3116	Green Sap	f	\N	\N	\N
3117	Guava	f	\N	\N	\N
254	Gurjan balsam	f	\N	\N	\N
255	Hawthorn	f	\N	\N	\N
256	Hay	f	\N	\N	\N
257	Hazelnut	f	\N	\N	\N
258	Hazelnut Cocoa Spread	f	\N	\N	\N
259	Helvetolide	f	\N	\N	\N
3124	Herbal Notes	f	\N	\N	\N
3125	Hexyl acetate	f	\N	\N	\N
3126	Hibiscus Seed	f	\N	\N	\N
261	Himalayan Poppy	f	\N	\N	\N
3128	Holly	f	\N	\N	\N
262	Ice	f	\N	\N	\N
3130	Ice cream	f	\N	\N	\N
3131	Icing Pink	f	\N	\N	\N
263	Immortelle	f	\N	\N	\N
3133	Ink	f	\N	\N	\N
265	Ivy	f	\N	\N	\N
3135	Jasmine Leaf	f	\N	\N	\N
266	Jasmine Tea	f	\N	\N	\N
3137	Jellybean	f	\N	\N	\N
3141	Kumquat	f	\N	\N	\N
3142	Lactones	f	\N	\N	\N
3143	Lantana	f	\N	\N	\N
3144	Laotian Oud	f	\N	\N	\N
3145	Laurels	f	\N	\N	\N
3146	Lavender Extract	f	\N	\N	\N
3147	Leatherwood	f	\N	\N	\N
3148	Lemon Blossom	f	\N	\N	\N
270	Lemon Tree	f	\N	\N	\N
3151	Lemongrass	f	\N	\N	\N
3153	Lime (Linden) Blossom	f	\N	\N	\N
3154	Lime Blossom	f	\N	\N	\N
3155	Liquidambar	f	\N	\N	\N
3156	Liquor	f	\N	\N	\N
3157	Litsea Cubeba	f	\N	\N	\N
3158	Lorenox	f	\N	\N	\N
3159	Loukhoum	f	\N	\N	\N
3160	Lychee	f	\N	\N	\N
3161	Macadamia	f	\N	\N	\N
3162	Macarons	f	\N	\N	\N
3165	Mahonia	f	\N	\N	\N
3167	Malt	f	\N	\N	\N
3169	Maninka	f	\N	\N	\N
3171	Marine notes	f	\N	\N	\N
3172	Marjoram	f	\N	\N	\N
3173	Marron glace	f	\N	\N	\N
3177	Matcha Tea	f	\N	\N	\N
3179	Meringue	f	\N	\N	\N
3183	Milk Chocolate	f	\N	\N	\N
3186	Miracle berry	f	\N	\N	\N
3187	Mocha	f	\N	\N	\N
3188	Mock Orange	f	\N	\N	\N
3189	Moepel accord	f	\N	\N	\N
3190	Monoi Oil	f	\N	\N	\N
3191	Mugane	f	\N	\N	\N
3192	Musk Vodka	f	\N	\N	\N
3193	Myrhh	f	\N	\N	\N
3195	Mystikal	f	\N	\N	\N
3196	Nasturtium	f	\N	\N	\N
3198	Nectarine blossom	f	\N	\N	\N
3201	Nympheal™	f	\N	\N	\N
3204	Olive Leaf	f	\N	\N	\N
3206	Oolong tea	f	\N	\N	\N
3207	Orange Pepper	f	\N	\N	\N
3208	Orangewood	f	\N	\N	\N
3209	Orcanox™	f	\N	\N	\N
3211	Oriental Woodsy notes	f	\N	\N	\N
3213	Oud	f	\N	\N	\N
3214	Ozonic notes	f	\N	\N	\N
3216	Palm Tree	f	\N	\N	\N
3217	Palmarosa	f	\N	\N	\N
3218	Palo Santo	f	\N	\N	\N
3221	Papaya flower	f	\N	\N	\N
309	Peach Blossom	f	\N	\N	\N
3226	Pear Blossom	f	\N	\N	\N
3227	Peat	f	\N	\N	\N
310	Pelargonium	f	\N	\N	\N
3229	Pelargonium Leaf	f	\N	\N	\N
3230	Pepper Oil	f	\N	\N	\N
3231	Peppermint	f	\N	\N	\N
311	Pepperwood™	f	\N	\N	\N
314	Petalia	f	\N	\N	\N
315	Pimento	f	\N	\N	\N
316	Pimento Leaf	f	\N	\N	\N
3237	Pimento Seeds	f	\N	\N	\N
3238	Pine	f	\N	\N	\N
317	Pine Needles	f	\N	\N	\N
3240	Pine Tree	f	\N	\N	\N
3241	Pink Freesia	f	\N	\N	\N
3242	Pink Nerium Oleander	f	\N	\N	\N
319	Pink Peony	f	\N	\N	\N
3244	Pink Rose	f	\N	\N	\N
3245	Pink Violet	f	\N	\N	\N
3286	Sesame	f	\N	\N	\N
3287	Shiso	f	\N	\N	\N
3288	Siam Resin	f	\N	\N	\N
340	Sichuan Pepper	f	\N	\N	\N
341	Silk Tree blossom	f	\N	\N	\N
342	Silkwood Blossom	f	\N	\N	\N
3292	Skin	f	\N	\N	\N
343	Smoke	f	\N	\N	\N
3294	Soap	f	\N	\N	\N
344	Soil Tincture	f	\N	\N	\N
3296	Solar Notes	f	\N	\N	\N
3297	Spearmint	f	\N	\N	\N
3298	Speculoos	f	\N	\N	\N
3299	Stephanotis	f	\N	\N	\N
3300	Strelitzia	f	\N	\N	\N
3301	Sweet Notes	f	\N	\N	\N
3302	Sweet Pea	f	\N	\N	\N
347	Sycamore	f	\N	\N	\N
348	Sylkolide	f	\N	\N	\N
349	Tamarind	f	\N	\N	\N
350	Tarragon	f	\N	\N	\N
352	Tea Leaf	f	\N	\N	\N
353	Tea Rose	f	\N	\N	\N
354	Teak Wood	f	\N	\N	\N
355	Thanaka Wood	f	\N	\N	\N
356	Tiare Flower	f	\N	\N	\N
357	Timur	f	\N	\N	\N
358	Tobacco Blossom	f	\N	\N	\N
359	Tolu Balsam	f	\N	\N	\N
360	Tomato	f	\N	\N	\N
3316	Tropical Fruit	f	\N	\N	\N
361	Tropical Fruits	f	\N	\N	\N
362	Truffle	f	\N	\N	\N
3319	Tulip	f	\N	\N	\N
3320	Turkey Red Rose	f	\N	\N	\N
3321	Turkish Rose Oil	f	\N	\N	\N
3322	Turmeric	f	\N	\N	\N
363	Vanilla Caviar	f	\N	\N	\N
364	Vanilla Flower	f	\N	\N	\N
3325	Vanilla Sugar	f	\N	\N	\N
3326	Verbena	f	\N	\N	\N
366	Vervain	f	\N	\N	\N
3328	Vinyl	f	\N	\N	\N
3329	Vinyl Guaiacol	f	\N	\N	\N
3330	Violet Leaves	f	\N	\N	\N
367	Violet Root	f	\N	\N	\N
3332	Vodka	f	\N	\N	\N
368	Wallflower	f	\N	\N	\N
3334	Walnut	f	\N	\N	\N
369	Water Hyacinth	f	\N	\N	\N
370	Water Jasmine	f	\N	\N	\N
3337	Water Mint	f	\N	\N	\N
371	Water Peony	f	\N	\N	\N
372	Watermelon	f	\N	\N	\N
373	West Indian Bay	f	\N	\N	\N
374	Whiskey	f	\N	\N	\N
375	White Amber	f	\N	\N	\N
376	White Bergamot	f	\N	\N	\N
3344	White Camelia	f	\N	\N	\N
3345	White Cedar Extract	f	\N	\N	\N
377	White Chocolate	f	\N	\N	\N
3347	White Currant	f	\N	\N	\N
3348	White Ginger Lily	f	\N	\N	\N
3349	White Iris	f	\N	\N	\N
379	White Lily	f	\N	\N	\N
3351	White Lotus	f	\N	\N	\N
380	White Nerium Oleander	f	\N	\N	\N
3353	White Orchid	f	\N	\N	\N
381	White Peach	f	\N	\N	\N
382	White Pear	f	\N	\N	\N
383	White Pepper	f	\N	\N	\N
384	White Rose	f	\N	\N	\N
385	White Rum	f	\N	\N	\N
3359	White Sandalwood	f	\N	\N	\N
386	White Tea	f	\N	\N	\N
3361	White Tobacco	f	\N	\N	\N
3362	White Violet	f	\N	\N	\N
3363	White Wood	f	\N	\N	\N
387	White Woods	f	\N	\N	\N
388	Wild Berries	f	\N	\N	\N
389	Wild Lavender	f	\N	\N	\N
3367	Wild Rose	f	\N	\N	\N
390	Wisteria	f	\N	\N	\N
391	Wolfwood	f	\N	\N	\N
392	Wormwood	f	\N	\N	\N
3371	Yellow Freesia	f	\N	\N	\N
393	Yuzu	f	\N	\N	\N
3373	Zefir	f	\N	\N	\N
394	cannabis	f	\N	\N	\N
3375	gunpowder	f	\N	\N	\N
3376	mulberry	f	\N	\N	\N
3377	pink tulip	f	\N	\N	\N
260	Hibiscus	t	{0,0,0,0,0,0,0,0,0,0,0.4,0.6,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
220	Cumin	f	\N	\N	\N
320	Pistachio	f	\N	\N	\N
3247	Pitahaya	f	\N	\N	\N
321	Pitosporum	f	\N	\N	\N
3249	Plastic	f	\N	\N	\N
3250	Plum Liquor	f	\N	\N	\N
3251	Pomarose	f	\N	\N	\N
3252	Pomelo	f	\N	\N	\N
3253	Popcorn	f	\N	\N	\N
3254	Poppy	f	\N	\N	\N
323	Powdery Notes	f	\N	\N	\N
3256	Precious Woods	f	\N	\N	\N
3257	Pumpkin	f	\N	\N	\N
3258	Rain Notes	f	\N	\N	\N
324	Rangoon Creeper	f	\N	\N	\N
3260	Raspberry Bloom	f	\N	\N	\N
325	Red Currant	f	\N	\N	\N
326	Red Cyclamen	f	\N	\N	\N
3263	Red Fruits	f	\N	\N	\N
3264	Red Lily	f	\N	\N	\N
327	Red Litchi	f	\N	\N	\N
3266	Red Pepper	f	\N	\N	\N
3267	Red Thyme	f	\N	\N	\N
328	Red currant leaf	f	\N	\N	\N
329	Reed	f	\N	\N	\N
330	Resins	f	\N	\N	\N
331	Rhubarb Leaf	f	\N	\N	\N
332	Rice	f	\N	\N	\N
3273	Roasted Coffee Beans	f	\N	\N	\N
3274	Rock rose	f	\N	\N	\N
3275	Rose Geranium	f	\N	\N	\N
333	Rose Hip	f	\N	\N	\N
335	Rose Water	f	\N	\N	\N
3278	Rubber	f	\N	\N	\N
336	Sand	f	\N	\N	\N
3280	Sandal	f	\N	\N	\N
337	Sapodilla	f	\N	\N	\N
3282	Sclarene	f	\N	\N	\N
339	Sea water	f	\N	\N	\N
3284	Sequoia	f	\N	\N	\N
3285	Serenolide	f	\N	\N	\N
272	Lemon Zest	f	\N	\N	\N
298	Orange Peel	f	\N	\N	\N
305	Papyrus	t	{0,0,0,0.2,0,0.5,0,0,0,0.3,0,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.69
278	Mango	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
280	Marshmallow	t	{0.8,0,0,0,0,0,0,0,0,0,0,0,0.2,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 1.0, "creamy": 1.0, "powdery": 0.0}	0
308	Passionfruit	t	{0,0,0,0,0,0,0,0,0,0,1,0,0,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 0.0, "powdery": 0.0}	0.3
288	Milk	t	{0.5,0,0,0.2,0,0,0,0,0,0,0,0,0.3,0}	{"sharp": 0.0, "smoky": 0.0, "spicy": 0.0, "sweet": 0.0, "creamy": 1.0, "powdery": 0.0}	0
267	Karo Karounde	f	\N	\N	\N
268	Kiwi	f	\N	\N	\N
269	Kulfi	f	\N	\N	\N
271	Lemon Verbena	f	\N	\N	\N
273	Lime (Linden Blossom)	f	\N	\N	\N
274	Mace	f	\N	\N	\N
275	Madagascar Pepper	f	\N	\N	\N
276	Mahonial	f	\N	\N	\N
277	Mandarin Leaf	f	\N	\N	\N
279	Marigold	f	\N	\N	\N
281	Martini	f	\N	\N	\N
282	Massoia Wood	f	\N	\N	\N
283	Mastic or Lentisque	f	\N	\N	\N
284	Mate	f	\N	\N	\N
285	Metallic notes	f	\N	\N	\N
286	Mexican chocolate	f	\N	\N	\N
287	Mignonette	f	\N	\N	\N
289	Mineral notes	f	\N	\N	\N
290	Mirabelle	f	\N	\N	\N
291	Myrtle	f	\N	\N	\N
292	Nectarine	f	\N	\N	\N
293	Night blooming Cereus	f	\N	\N	\N
294	Nutmeg Flower	f	\N	\N	\N
295	Oak	f	\N	\N	\N
296	Olive Blossom	f	\N	\N	\N
297	Olive Tree	f	\N	\N	\N
299	Oregano	f	\N	\N	\N
300	Oriental notes	f	\N	\N	\N
301	Palisander Rosewood	f	\N	\N	\N
302	Panacotta	f	\N	\N	\N
303	Papaya	f	\N	\N	\N
304	Paprika	f	\N	\N	\N
306	Parma Violet	f	\N	\N	\N
307	Passion Flower	f	\N	\N	\N
312	Persimmon	f	\N	\N	\N
\.


--
-- Data for Name: pair_scores; Type: TABLE DATA; Schema: seed; Owner: -
--

COPY seed.pair_scores (base_id, partner_id, goal, score, rank) FROM stdin;
1	36	enhance	100	1
1	84	enhance	95.53692	2
1	108	enhance	95.221695	3
1	71	enhance	94.8875	4
1	48	enhance	94.68425	5
1	68	enhance	94.53992	6
1	285	enhance	94.36272	7
1	89	enhance	94.33264	8
1	25	enhance	94.080666	9
1	40	enhance	93.914505	10
1	87	enhance	92.944	11
1	75	enhance	91.44747	12
1	647	enhance	91.35727	13
1	88	enhance	91.27964	14
1	176	enhance	90.71025	15
1	785	enhance	89.51613	16
1	17	enhance	89.39339	17
1	155	enhance	89.391594	18
1	15	enhance	89.117165	19
1	92	enhance	88.65621	20
1	86	enhance	88.638405	21
1	882	enhance	88.58689	22
1	46	enhance	86.67422	23
1	185	enhance	86.528206	24
1	31	enhance	85.15356	25
1	6	enhance	84.79517	26
1	56	enhance	84.73472	27
1	358	enhance	83.6866	28
1	24	enhance	83.6136	29
1	67	enhance	83.60043	30
1	16	enhance	82.76558	31
1	38	enhance	82.673355	32
1	76	enhance	82.503914	33
1	62	enhance	82.094055	34
1	97	enhance	81.86587	35
1	52	enhance	81.59972	36
1	98	enhance	81.47735	37
1	7	enhance	81.44215	38
1	47	enhance	80.92171	39
1	187	enhance	80.81803	40
1	10	enhance	80.80685	41
1	222	enhance	80.59589	42
1	37	enhance	80.51803	43
1	455	enhance	80.49383	44
1	42	enhance	80.30178	45
1	39	enhance	80.11515	46
1	26	enhance	79.46789	47
1	19	enhance	77.66912	48
1	51	enhance	77.601204	49
1	901	enhance	75.93147	50
1	94	enhance	75.691635	51
1	29	enhance	73.902336	52
1	63	enhance	72.442635	53
1	49	enhance	72.20232	54
1	27	enhance	70.04574	55
1	54	enhance	69.11722	56
1	100	enhance	69.00606	57
1	61	enhance	68.97855	58
1	81	enhance	67.40298	59
1	13	enhance	67.27889	60
1	77	enhance	67.2342	61
1	640	enhance	67.206505	62
1	30	enhance	66.68882	63
1	921	enhance	66.20839	64
1	50	enhance	64.52218	65
1	45	enhance	63.7484	66
1	43	enhance	63.429234	67
1	230	enhance	62.56016	68
1	58	enhance	62.133423	69
1	73	enhance	62.106907	70
1	34	enhance	61.75678	71
1	182	enhance	61.349064	72
1	18	enhance	57.98327	73
1	28	enhance	56.74433	74
1	70	enhance	56.58205	75
1	593	enhance	56.11815	76
1	78	enhance	55.201748	77
1	66	enhance	53.837616	78
1	99	enhance	53.764626	79
1	868	enhance	53.36523	80
1	33	enhance	52.057545	81
1	53	enhance	51.47277	82
1	14	enhance	50.65135	83
1	44	enhance	49.709763	84
1	83	enhance	49.0085	85
1	65	enhance	48.692863	86
1	72	enhance	48.29556	87
1	126	enhance	47.527004	88
1	32	enhance	45.487103	89
1	184	enhance	44.129116	90
1	2	enhance	43.83701	91
1	82	enhance	42.96664	92
1	80	enhance	42.676033	93
1	79	enhance	42.223892	94
1	93	enhance	42.18466	95
1	57	enhance	41.631557	96
1	3	enhance	41.381775	97
1	59	enhance	41.07944	98
1	8	enhance	40.7128	99
1	219	enhance	40.36235	100
1	171	enhance	39.91231	101
1	55	enhance	39.036705	102
1	90	enhance	38.335346	103
1	95	enhance	38.202362	104
1	20	enhance	36.897396	105
1	22	enhance	36.335182	106
1	335	enhance	35.994125	107
1	96	enhance	34.602745	108
1	5	enhance	33.6387	109
1	488	enhance	33.27764	110
1	41	enhance	33.09381	111
1	9	enhance	31.10711	112
1	11	enhance	30.652102	113
1	4	enhance	30.458784	114
1	64	enhance	30.284756	115
1	21	enhance	30.160826	116
1	35	enhance	29.524122	117
1	69	enhance	29.353548	118
1	74	enhance	29.104496	119
1	60	enhance	29.088564	120
1	12	enhance	29.085949	121
1	23	enhance	28.505161	122
1	85	enhance	27.969755	123
1	91	enhance	27.806906	124
1	64	soften	100	1
1	11	soften	98.27274	2
1	74	soften	97.327	3
1	80	soften	96.04349	4
1	60	soften	94.54654	5
1	91	soften	94.463234	6
1	90	soften	91.43122	7
1	55	soften	91.0419	8
1	3	soften	90.585205	9
1	126	soften	90.54018	10
1	83	soften	89.21593	11
1	93	soften	88.54861	12
1	96	soften	88.29279	13
1	72	soften	88.05066	14
1	79	soften	87.955635	15
1	23	soften	87.44301	16
1	4	soften	86.77228	17
1	184	soften	86.50745	18
1	70	soften	85.44091	19
1	21	soften	85.27061	20
1	335	soften	84.688934	21
1	171	soften	84.452515	22
1	45	soften	84.41325	23
1	20	soften	83.656654	24
1	2	soften	83.5515	25
1	22	soften	83.53196	26
1	9	soften	83.32628	27
1	219	soften	82.88339	28
1	5	soften	82.37954	29
1	85	soften	81.864845	30
1	82	soften	81.731346	31
1	868	soften	81.64837	32
1	34	soften	81.61768	33
1	12	soften	81.40961	34
1	35	soften	81.40938	35
1	95	soften	81.029854	36
1	99	soften	80.917946	37
1	59	soften	80.87616	38
1	43	soften	80.82625	39
1	30	soften	80.36895	40
1	78	soften	80.08045	41
1	33	soften	79.966545	42
1	73	soften	79.4131	43
1	13	soften	79.09356	44
1	49	soften	78.66421	45
1	41	soften	78.565605	46
1	18	soften	78.35689	47
1	182	soften	78.21156	48
1	44	soften	78.210396	49
1	69	soften	77.70944	50
1	63	soften	76.75204	51
1	593	soften	76.666885	52
1	28	soften	76.21268	53
1	94	soften	75.25171	54
1	61	soften	75.24977	55
1	8	soften	75.1113	56
1	230	soften	75.04104	57
1	640	soften	74.644485	58
1	50	soften	74.546906	59
1	66	soften	73.771454	60
1	39	soften	73.7682	61
1	222	soften	71.71816	62
1	187	soften	71.44348	63
1	56	soften	70.117096	64
1	7	soften	69.74467	65
1	92	soften	69.4214	66
1	58	soften	69.26907	67
1	31	soften	69.26094	68
1	54	soften	69.16935	69
1	47	soften	69.03453	70
1	27	soften	68.23092	71
1	285	soften	68.02894	72
1	176	soften	67.71274	73
1	89	soften	67.60985	74
1	98	soften	67.49131	75
1	51	soften	67.04869	76
1	455	soften	66.41281	77
1	10	soften	65.81608	78
1	86	soften	64.51332	79
1	24	soften	64.50846	80
1	52	soften	63.680542	81
1	84	soften	62.913063	82
1	67	soften	62.427795	83
2	63	enhance	100	1
2	99	enhance	98.66354	2
2	43	enhance	98.580154	3
2	34	enhance	96.42681	4
2	126	enhance	94.81091	5
2	82	enhance	94.1554	6
2	230	enhance	93.24144	7
2	90	enhance	91.18337	8
2	45	enhance	90.94522	9
2	80	enhance	90.907135	10
2	33	enhance	90.727516	11
2	50	enhance	89.262665	12
2	49	enhance	88.61206	13
2	70	enhance	88.594154	14
2	61	enhance	88.099396	15
2	182	enhance	88.01379	16
2	13	enhance	87.41716	17
2	640	enhance	83.62968	18
2	79	enhance	81.75918	19
2	593	enhance	81.71811	20
2	93	enhance	79.729515	21
2	23	enhance	79.34531	22
2	18	enhance	79.00152	23
2	3	enhance	78.94847	24
2	5	enhance	78.15954	25
2	31	enhance	77.62251	26
2	83	enhance	77.385	27
2	94	enhance	76.696106	28
2	39	enhance	76.53549	29
2	20	enhance	75.24681	30
2	30	enhance	75.19818	31
2	72	enhance	73.53626	32
2	95	enhance	73.31374	33
2	73	enhance	72.85531	34
2	96	enhance	72.545456	35
2	74	enhance	71.258545	36
2	171	enhance	71.22317	37
2	28	enhance	71.19152	38
2	55	enhance	70.60397	39
2	7	enhance	70.57389	40
2	58	enhance	70.079636	41
2	187	enhance	69.94209	42
2	98	enhance	69.81419	43
2	56	enhance	69.71409	44
2	8	enhance	69.41897	45
2	78	enhance	69.32582	46
2	219	enhance	69.16505	47
2	21	enhance	68.47518	48
2	89	enhance	67.62098	49
2	59	enhance	67.45495	50
2	488	enhance	66.82556	51
2	47	enhance	66.79894	52
2	9	enhance	66.746925	53
2	85	enhance	65.461754	54
2	35	enhance	65.29614	55
2	14	enhance	65.28734	56
2	184	enhance	64.493805	57
2	335	enhance	63.556576	58
2	19	enhance	63.535816	59
2	54	enhance	63.47791	60
2	12	enhance	63.39526	61
2	69	enhance	63.174953	62
2	222	enhance	62.683247	63
2	868	enhance	62.587303	64
2	91	enhance	62.30688	65
2	92	enhance	61.870026	66
2	4	enhance	61.480324	67
2	108	enhance	61.23358	68
2	32	enhance	60.90446	69
2	66	enhance	60.848885	70
2	64	enhance	60.83686	71
2	11	enhance	60.561188	72
2	455	enhance	60.25509	73
2	41	enhance	60.157295	74
2	44	enhance	58.76303	75
2	647	enhance	58.675743	76
2	60	enhance	58.12958	77
2	65	enhance	57.583797	78
2	176	enhance	57.48272	79
2	285	enhance	56.97528	80
2	88	enhance	56.919643	81
2	22	enhance	56.507767	82
2	10	enhance	55.820595	83
2	62	enhance	55.397495	84
2	24	enhance	55.00539	85
2	27	enhance	54.020363	86
2	77	enhance	53.308735	87
2	57	enhance	53.142197	88
2	921	enhance	52.885677	89
2	185	enhance	52.222496	90
2	100	enhance	52.02773	91
2	52	enhance	47.738533	92
2	26	enhance	47.336887	93
2	1	enhance	46.598206	94
2	36	enhance	45.045937	95
2	84	enhance	44.443348	96
2	53	enhance	44.270493	97
2	86	enhance	44.20666	98
2	37	enhance	43.78898	99
2	785	enhance	42.779022	100
2	81	enhance	42.077545	101
2	38	enhance	41.23641	102
2	42	enhance	40.259808	103
2	67	enhance	40.162945	104
2	15	enhance	39.279	105
2	51	enhance	39.21373	106
2	6	enhance	38.230343	107
2	40	enhance	38.14776	108
2	68	enhance	38.005535	109
2	76	enhance	37.243168	110
2	901	enhance	36.59386	111
2	71	enhance	36.53434	112
2	17	enhance	35.290043	113
2	48	enhance	34.051197	114
2	97	enhance	33.749706	115
2	29	enhance	31.414434	116
2	16	enhance	30.828688	117
2	87	enhance	30.653368	118
2	25	enhance	29.980267	119
2	358	enhance	29.81937	120
2	75	enhance	24.058352	121
2	46	enhance	19.97676	122
2	155	enhance	16.72102	123
2	882	enhance	16.252298	124
2	11	soften	100	1
2	91	soften	95.03924	2
2	55	soften	93.30701	3
2	184	soften	93.1005	4
2	868	soften	91.94467	5
2	22	soften	89.82658	6
2	3	soften	89.51214	7
2	96	soften	89.38008	8
2	93	soften	89.012794	9
2	4	soften	88.7608	10
2	44	soften	87.106674	11
2	171	soften	86.454254	12
2	219	soften	86.110306	13
2	126	soften	86.0386	14
2	59	soften	85.75894	15
2	90	soften	85.62422	16
2	21	soften	85.08651	17
2	79	soften	84.50712	18
2	23	soften	83.644806	19
2	9	soften	83.33884	20
2	12	soften	82.702675	21
2	30	soften	82.32103	22
2	85	soften	81.66071	23
2	34	soften	81.573654	24
2	64	soften	71.21257	25
2	60	soften	68.24619	26
2	74	soften	65.623795	27
2	72	soften	64.202896	28
2	83	soften	63.783993	29
2	335	soften	62.727646	30
2	70	soften	61.203888	31
2	78	soften	60.88682	32
2	80	soften	60.87177	33
2	45	soften	58.86457	34
2	20	soften	58.347904	35
2	49	soften	57.748425	36
2	13	soften	57.693302	37
2	5	soften	56.745724	38
3	93	enhance	100	1
3	55	enhance	98.74323	2
3	83	enhance	97.31074	3
3	91	enhance	97.284035	4
3	90	enhance	96.781586	5
3	70	enhance	96.56645	6
3	72	enhance	96.47924	7
3	4	enhance	95.69935	8
3	74	enhance	95.19152	9
3	23	enhance	95.0919	10
3	9	enhance	93.779976	11
3	11	enhance	93.64483	12
3	184	enhance	92.84269	13
3	64	enhance	92.80055	14
3	60	enhance	92.70206	15
3	126	enhance	92.5211	16
3	5	enhance	91.98845	17
3	22	enhance	91.16751	18
3	78	enhance	90.51316	19
3	96	enhance	90.29718	20
3	44	enhance	89.5116	21
3	593	enhance	89.41594	22
3	82	enhance	88.558174	23
3	59	enhance	88.40822	24
3	335	enhance	88.17545	25
3	34	enhance	87.94315	26
3	219	enhance	87.6334	27
3	99	enhance	87.32196	28
3	94	enhance	87.0152	29
3	21	enhance	86.82754	30
3	41	enhance	86.33861	31
3	50	enhance	86.20181	32
3	79	enhance	85.95126	33
3	80	enhance	84.41484	34
3	868	enhance	83.65874	35
3	69	enhance	82.48838	36
3	12	enhance	81.96061	37
3	85	enhance	81.84137	38
3	182	enhance	81.67153	39
3	43	enhance	80.93049	40
3	18	enhance	80.908585	41
3	66	enhance	80.01012	42
3	35	enhance	79.588806	43
3	20	enhance	79.034645	44
3	39	enhance	78.85789	45
3	8	enhance	78.60519	46
3	49	enhance	77.86467	47
3	171	enhance	77.378	48
3	7	enhance	77.196144	49
3	63	enhance	77.07734	50
3	2	enhance	74.61077	51
3	58	enhance	72.86365	52
3	45	enhance	72.43607	53
3	19	enhance	72.37107	54
3	13	enhance	71.23093	55
3	10	enhance	70.59664	56
3	92	enhance	69.958595	57
3	187	enhance	69.70964	58
3	27	enhance	69.54299	59
3	28	enhance	67.886024	60
3	54	enhance	67.29099	61
3	95	enhance	64.4885	62
3	455	enhance	63.026283	63
3	640	enhance	60.694576	64
3	73	enhance	60.22643	65
3	285	enhance	60.165703	66
3	52	enhance	59.925407	67
3	30	enhance	59.738434	68
3	230	enhance	59.43463	69
3	61	enhance	58.63616	70
3	176	enhance	57.85653	71
3	86	enhance	57.82311	72
3	65	enhance	57.722786	73
3	56	enhance	56.785313	74
3	222	enhance	56.173916	75
3	488	enhance	55.849606	76
3	33	enhance	55.232765	77
3	47	enhance	54.45335	78
3	89	enhance	54.309708	79
3	14	enhance	53.359467	80
3	77	enhance	53.301388	81
3	100	enhance	52.476215	82
3	108	enhance	52.06332	83
3	31	enhance	49.242523	84
3	62	enhance	48.017902	85
3	32	enhance	47.374485	86
3	98	enhance	47.115856	87
3	24	enhance	46.917667	88
3	921	enhance	45.501877	89
3	647	enhance	45.156113	90
3	26	enhance	44.656364	91
3	185	enhance	44.622215	92
3	57	enhance	43.427055	93
3	15	enhance	43.213932	94
3	901	enhance	42.62303	95
3	88	enhance	41.81731	96
3	1	enhance	41.571457	97
3	51	enhance	40.059002	98
3	81	enhance	36.603523	99
3	84	enhance	36.55106	100
3	785	enhance	35.986027	101
3	53	enhance	35.53951	102
3	36	enhance	35.146385	103
3	38	enhance	34.156948	104
3	37	enhance	33.927402	105
3	42	enhance	33.401012	106
3	68	enhance	32.75944	107
3	6	enhance	32.49032	108
3	16	enhance	31.086143	109
3	76	enhance	30.890186	110
3	48	enhance	30.560324	111
3	67	enhance	30.041056	112
3	71	enhance	30.022856	113
3	17	enhance	29.434696	114
3	97	enhance	27.798355	115
3	40	enhance	26.252293	116
3	29	enhance	25.928576	117
3	358	enhance	24.699694	118
3	87	enhance	23.572142	119
3	25	enhance	20.36888	120
3	75	enhance	17.669264	121
3	46	enhance	17.04447	122
3	155	enhance	14.139257	123
3	882	enhance	13.9978485	124
3	11	soften	100	1
3	91	soften	94.80121	2
3	55	soften	92.400024	3
3	64	soften	71.729485	4
3	60	soften	67.647575	5
3	74	soften	65.852715	6
3	72	soften	64.545685	7
3	80	soften	64.150406	8
3	83	soften	63.625732	9
4	91	enhance	100	1
4	9	enhance	99.83761	2
4	23	enhance	99.20322	3
4	59	enhance	98.14913	4
4	335	enhance	97.97611	5
4	5	enhance	97.92617	6
4	22	enhance	97.56116	7
4	41	enhance	96.94854	8
4	55	enhance	96.92811	9
4	60	enhance	95.60304	10
4	21	enhance	95.576614	11
4	12	enhance	95.455894	12
4	3	enhance	95.301544	13
4	219	enhance	95.18401	14
4	184	enhance	94.889366	15
4	96	enhance	94.035515	16
4	93	enhance	93.90544	17
4	85	enhance	93.84449	18
4	74	enhance	93.37586	19
4	69	enhance	93.275894	20
4	44	enhance	93.18436	21
4	78	enhance	92.742134	22
4	11	enhance	92.52602	23
4	593	enhance	92.51341	24
4	35	enhance	91.93361	25
4	64	enhance	91.82507	26
4	66	enhance	89.03243	27
4	8	enhance	88.73303	28
4	868	enhance	88.053894	29
4	82	enhance	87.05564	30
4	72	enhance	85.9301	31
4	83	enhance	84.13287	32
4	20	enhance	83.94596	33
4	70	enhance	81.79819	34
4	171	enhance	81.64989	35
4	90	enhance	81.520164	36
4	50	enhance	80.25572	37
4	18	enhance	78.46192	38
4	94	enhance	78.33114	39
4	79	enhance	76.79836	40
4	58	enhance	74.178314	41
4	10	enhance	73.67625	42
4	27	enhance	73.535614	43
4	7	enhance	73.353806	44
4	65	enhance	71.84979	45
4	34	enhance	71.72818	46
4	99	enhance	71.11046	47
4	54	enhance	71.05508	48
4	126	enhance	70.96707	49
4	182	enhance	69.78502	50
4	28	enhance	68.51517	51
4	455	enhance	68.06353	52
4	39	enhance	68.05497	53
4	95	enhance	67.7697	54
4	488	enhance	67.47362	55
4	52	enhance	65.81776	56
4	77	enhance	65.79217	57
4	14	enhance	65.13685	58
4	19	enhance	65.10701	59
4	100	enhance	64.70813	60
4	92	enhance	63.359543	61
4	32	enhance	61.329197	62
4	63	enhance	59.46899	63
4	80	enhance	59.227333	64
4	187	enhance	58.634464	65
4	43	enhance	58.124367	66
4	2	enhance	57.860867	67
4	49	enhance	55.901463	68
4	176	enhance	53.36037	69
4	86	enhance	53.32231	70
4	62	enhance	52.254364	71
4	921	enhance	52.1858	72
4	24	enhance	51.132782	73
4	53	enhance	50.38127	74
4	57	enhance	49.830112	75
4	185	enhance	48.62087	76
4	13	enhance	48.30799	77
4	81	enhance	47.17684	78
4	285	enhance	46.903255	79
4	901	enhance	46.883717	80
4	45	enhance	45.136868	81
4	38	enhance	43.956547	82
4	108	enhance	43.94572	83
4	42	enhance	43.72074	84
4	26	enhance	42.428116	85
4	222	enhance	42.33771	86
4	15	enhance	41.906017	87
4	785	enhance	41.817028	88
4	89	enhance	39.66959	89
4	16	enhance	39.634056	90
4	76	enhance	39.401997	91
4	647	enhance	39.083523	92
4	640	enhance	39.05266	93
4	73	enhance	37.494446	94
4	56	enhance	36.85956	95
4	37	enhance	36.417183	96
4	230	enhance	36.14095	97
4	6	enhance	36.003586	98
4	29	enhance	35.46749	99
4	61	enhance	33.318615	100
4	47	enhance	32.897987	101
4	17	enhance	32.47573	102
4	358	enhance	32.199455	103
4	97	enhance	32.179485	104
4	30	enhance	31.08257	105
4	31	enhance	30.956186	106
4	98	enhance	30.851326	107
4	51	enhance	30.54718	108
4	1	enhance	30.471203	109
4	71	enhance	30.40912	110
4	33	enhance	30.326086	111
4	48	enhance	29.562216	112
4	68	enhance	29.379673	113
4	84	enhance	28.425953	114
4	88	enhance	26.799063	115
4	36	enhance	25.669147	116
4	87	enhance	24.667372	117
4	40	enhance	19.456045	118
4	67	enhance	18.490788	119
4	46	enhance	17.606531	120
4	25	enhance	17.139683	121
4	155	enhance	15.340317	122
4	75	enhance	14.9630165	123
4	882	enhance	14.365454	124
4	11	soften	100	1
4	90	soften	96.80006	2
4	126	soften	96.71795	3
4	3	soften	94.00604	4
4	93	soften	93.42972	5
4	55	soften	93.234406	6
4	91	soften	92.828964	7
4	184	soften	91.13197	8
4	79	soften	90.07073	9
4	96	soften	84.31412	10
4	64	soften	71.06633	11
4	80	soften	69.863625	12
4	72	soften	68.21338	13
4	60	soften	67.54739	14
4	83	soften	66.9233	15
4	70	soften	65.545685	16
4	74	soften	63.481518	17
5	23	enhance	100	1
5	21	enhance	98.26392	2
5	12	enhance	98.15921	3
5	85	enhance	98.076836	4
5	59	enhance	98.02875	5
5	35	enhance	96.95288	6
5	4	enhance	96.43816	7
5	9	enhance	96.39145	8
5	593	enhance	96.29116	9
5	69	enhance	95.23035	10
5	219	enhance	94.777885	11
5	82	enhance	94.50387	12
5	335	enhance	93.764145	13
5	8	enhance	92.55346	14
5	91	enhance	92.38048	15
5	41	enhance	92.32924	16
5	96	enhance	90.95581	17
5	66	enhance	90.88898	18
5	78	enhance	90.60418	19
5	74	enhance	90.5546	20
5	55	enhance	90.2767	21
5	3	enhance	90.214096	22
5	20	enhance	90.1972	23
5	93	enhance	89.616165	24
5	184	enhance	88.27553	25
5	22	enhance	87.72396	26
5	60	enhance	87.68024	27
5	18	enhance	87.18273	28
5	50	enhance	86.99723	29
5	171	enhance	86.72466	30
5	79	enhance	85.95086	31
5	11	enhance	84.73552	32
5	64	enhance	84.49602	33
5	44	enhance	84.12864	34
5	868	enhance	82.649574	35
5	90	enhance	81.99103	36
5	70	enhance	81.761765	37
5	488	enhance	81.15312	38
5	83	enhance	80.728806	39
5	28	enhance	80.30977	40
5	72	enhance	80.1837	41
5	54	enhance	79.8504	42
5	65	enhance	79.5659	43
5	94	enhance	79.348946	44
5	34	enhance	79.22921	45
5	95	enhance	76.97872	46
5	99	enhance	76.785034	47
5	14	enhance	76.61248	48
5	32	enhance	76.58081	49
5	58	enhance	76.319855	50
5	182	enhance	76.19479	51
5	27	enhance	75.23026	52
5	126	enhance	74.80103	53
5	455	enhance	74.036995	54
5	2	enhance	72.440414	55
5	77	enhance	72.1971	56
5	10	enhance	71.97912	57
5	7	enhance	71.72094	58
5	100	enhance	70.83866	59
5	63	enhance	69.40679	60
5	39	enhance	68.494705	61
5	52	enhance	68.159195	62
5	43	enhance	66.67379	63
5	80	enhance	65.50514	64
5	53	enhance	64.959015	65
5	19	enhance	64.25958	66
5	49	enhance	64.206604	67
5	921	enhance	62.859188	68
5	24	enhance	61.286163	69
5	62	enhance	61.178806	70
5	92	enhance	60.952564	71
5	187	enhance	59.27049	72
5	57	enhance	57.12813	73
5	185	enhance	57.101257	74
5	176	enhance	56.738003	75
5	45	enhance	55.704933	76
5	81	enhance	55.2916	77
5	13	enhance	54.474815	78
5	42	enhance	51.508602	79
5	38	enhance	51.259953	80
5	86	enhance	50.952404	81
5	230	enhance	49.676254	82
5	108	enhance	49.565716	83
5	73	enhance	49.49163	84
5	785	enhance	48.548138	85
5	285	enhance	48.491447	86
5	647	enhance	47.148014	87
5	76	enhance	46.7951	88
5	26	enhance	46.540455	89
5	640	enhance	46.357784	90
5	901	enhance	46.341557	91
5	89	enhance	46.032047	92
5	61	enhance	44.938965	93
5	16	enhance	44.66464	94
5	29	enhance	44.242126	95
5	222	enhance	43.854572	96
5	6	enhance	43.79353	97
5	56	enhance	42.938606	98
5	37	enhance	42.58304	99
5	98	enhance	42.46747	100
5	31	enhance	42.030495	101
5	33	enhance	41.947285	102
5	15	enhance	40.475437	103
5	97	enhance	40.344734	104
5	30	enhance	39.37135	105
5	358	enhance	38.850323	106
5	47	enhance	38.445755	107
5	17	enhance	37.91444	108
5	71	enhance	35.840607	109
5	88	enhance	34.332935	110
5	84	enhance	33.502666	111
5	1	enhance	33.14106	112
5	68	enhance	32.293934	113
5	48	enhance	32.19674	114
5	36	enhance	30.73007	115
5	51	enhance	29.447136	116
5	87	enhance	28.658453	117
5	40	enhance	25.421698	118
5	25	enhance	20.88098	119
5	67	enhance	20.738384	120
5	46	enhance	19.771734	121
5	75	enhance	17.907726	122
5	155	enhance	16.909893	123
5	882	enhance	15.074692	124
5	64	soften	100	1
5	11	soften	98.976715	2
5	72	soften	96.76823	3
5	80	soften	96.632355	4
5	60	soften	96.121544	5
5	83	soften	95.104454	6
5	126	soften	94.85799	7
5	90	soften	94.57944	8
5	55	soften	93.25512	9
5	3	soften	93.01601	10
5	70	soften	92.750305	11
5	13	soften	92.4921	12
5	93	soften	92.16873	13
5	91	soften	92.10865	14
5	45	soften	90.962715	15
5	184	soften	90.95739	16
5	49	soften	90.78998	17
5	74	soften	89.71215	18
5	79	soften	88.364174	19
5	868	soften	88.206474	20
5	22	soften	86.652374	21
5	44	soften	86.21575	22
5	4	soften	85.8348	23
5	78	soften	85.534805	24
5	96	soften	84.70807	25
5	335	soften	84.48019	26
5	23	soften	82.80548	27
5	59	soften	82.226746	28
5	171	soften	82.06591	29
5	219	soften	81.40375	30
5	21	soften	80.294655	31
5	9	soften	79.6908	32
5	20	soften	78.11891	33
6	97	enhance	100	1
6	358	enhance	97.34834	2
6	29	enhance	97.24346	3
6	17	enhance	96.08777	4
6	16	enhance	95.85462	5
6	42	enhance	95.48369	6
6	76	enhance	95.33434	7
6	38	enhance	95.2051	8
6	785	enhance	94.76625	9
6	185	enhance	94.5986	10
6	647	enhance	93.74984	11
6	62	enhance	93.078735	12
6	52	enhance	92.555725	13
6	455	enhance	91.97172	14
6	71	enhance	91.44751	15
6	24	enhance	91.10444	16
6	48	enhance	90.531075	17
6	40	enhance	88.91664	18
6	87	enhance	88.5446	19
6	68	enhance	87.8749	20
6	108	enhance	87.64582	21
6	54	enhance	87.419174	22
6	100	enhance	87.40302	23
6	36	enhance	86.62454	24
6	46	enhance	86.269516	25
6	27	enhance	86.13589	26
6	77	enhance	85.64043	27
6	81	enhance	85.499825	28
6	53	enhance	85.31472	29
6	25	enhance	85.26213	30
6	84	enhance	85.25374	31
6	921	enhance	84.9911	32
6	882	enhance	84.70626	33
6	37	enhance	83.85236	34
6	75	enhance	83.77808	35
6	155	enhance	83.53502	36
6	26	enhance	82.84372	37
6	1	enhance	82.817245	38
6	10	enhance	81.83804	39
6	86	enhance	80.73006	40
6	89	enhance	80.06117	41
6	88	enhance	76.46797	42
6	15	enhance	76.37573	43
6	901	enhance	75.65355	44
6	285	enhance	74.791466	45
6	39	enhance	73.21575	46
6	176	enhance	73.06917	47
6	18	enhance	71.85501	48
6	28	enhance	71.67739	49
6	66	enhance	71.3256	50
6	56	enhance	71.04761	51
6	65	enhance	70.537224	52
6	7	enhance	70.189156	53
6	32	enhance	69.32949	54
6	98	enhance	69.1711	55
6	14	enhance	68.96672	56
6	31	enhance	67.27379	57
6	92	enhance	66.31806	58
6	78	enhance	64.21287	59
6	94	enhance	63.732708	60
6	593	enhance	63.68293	61
6	187	enhance	63.200615	62
6	58	enhance	62.643604	63
6	50	enhance	60.62625	64
6	19	enhance	60.49945	65
6	73	enhance	58.01989	66
6	488	enhance	56.21835	67
6	63	enhance	55.881012	68
6	49	enhance	55.86839	69
6	8	enhance	55.37825	70
6	57	enhance	54.2162	71
6	67	enhance	54.133247	72
6	59	enhance	53.989895	73
6	30	enhance	52.392334	74
6	222	enhance	52.23814	75
6	44	enhance	51.557037	76
6	219	enhance	51.104733	77
6	79	enhance	50.785755	78
6	34	enhance	50.267433	79
6	47	enhance	49.581226	80
6	35	enhance	49.050507	81
6	12	enhance	48.760918	82
6	868	enhance	48.662945	83
6	51	enhance	48.272987	84
6	182	enhance	48.2494	85
6	85	enhance	48.18025	86
6	184	enhance	48.052757	87
6	21	enhance	47.64861	88
6	335	enhance	47.61613	89
6	20	enhance	47.420845	90
6	69	enhance	47.340443	91
6	95	enhance	47.14752	92
6	171	enhance	46.291485	93
6	43	enhance	46.098377	94
6	61	enhance	45.319187	95
6	41	enhance	43.64465	96
6	5	enhance	43.414257	97
6	45	enhance	43.197594	98
6	230	enhance	43.051292	99
6	82	enhance	41.2374	100
6	640	enhance	41.150192	101
6	22	enhance	40.985172	102
6	96	enhance	40.434494	103
6	13	enhance	39.33786	104
6	70	enhance	37.82931	105
6	99	enhance	37.044884	106
6	9	enhance	36.622936	107
6	23	enhance	35.868446	108
6	93	enhance	35.157368	109
6	4	enhance	35.149437	110
6	2	enhance	35.126076	111
6	74	enhance	31.909481	112
6	3	enhance	31.587667	113
6	55	enhance	30.342602	114
6	83	enhance	29.190777	115
6	72	enhance	29.08916	116
6	64	enhance	28.819786	117
6	91	enhance	28.707706	118
6	33	enhance	28.130049	119
6	80	enhance	27.59824	120
6	126	enhance	27.207994	121
6	11	enhance	25.039318	122
6	60	enhance	24.90499	123
6	90	enhance	22.622446	124
6	11	soften	100	1
6	80	soften	99.01636	2
6	60	soften	98.7759	3
6	126	soften	96.582596	4
6	90	soften	96.499405	5
6	83	soften	95.99517	6
6	72	soften	94.79813	7
6	91	soften	94.6678	8
6	55	soften	94.47278	9
6	3	soften	93.00797	10
6	70	soften	89.62912	11
6	93	soften	89.215256	12
6	79	soften	87.99731	13
6	45	soften	87.738434	14
6	23	soften	87.5552	15
6	4	soften	87.426544	16
6	33	soften	86.80282	17
6	2	soften	85.95548	18
6	13	soften	85.1726	19
6	82	soften	85.16512	20
6	34	soften	85.146255	21
6	96	soften	85.115814	22
6	171	soften	85.033485	23
6	99	soften	84.232445	24
6	9	soften	83.8015	25
6	182	soften	83.763176	26
6	43	soften	83.629135	27
6	21	soften	83.337875	28
6	5	soften	83.24813	29
6	184	soften	82.90875	30
6	20	soften	82.39326	31
6	868	soften	81.67745	32
6	335	soften	81.54592	33
6	30	soften	81.38142	34
6	12	soften	80.73366	35
6	35	soften	80.696976	36
6	219	soften	80.654366	37
6	85	soften	80.44797	38
6	22	soften	80.43775	39
6	640	soften	80.33191	40
6	73	soften	80.26875	41
6	59	soften	79.94553	42
6	230	soften	79.89334	43
6	63	soften	78.60236	44
6	50	soften	77.416954	45
6	78	soften	77.03744	46
6	41	soften	76.68698	47
6	593	soften	76.338745	48
6	18	soften	76.29687	49
6	69	soften	76.283066	50
6	28	soften	76.24682	51
6	44	soften	75.64926	52
6	8	soften	75.195305	53
6	187	soften	74.31894	54
6	66	soften	73.094604	55
6	39	soften	72.44363	56
6	98	soften	71.73403	57
6	285	soften	71.329025	58
6	176	soften	71.14045	59
6	488	soften	71.05171	60
6	7	soften	70.35725	61
6	19	soften	69.87561	62
6	64	soften	68.958405	63
6	54	soften	68.358734	64
6	89	soften	68.122444	65
6	58	soften	68.07441	66
6	14	soften	67.039894	67
6	74	soften	66.53009	68
6	10	soften	65.95326	69
6	27	soften	65.6574	70
6	455	soften	64.58659	71
6	108	soften	63.99482	72
6	24	soften	63.732883	73
6	26	soften	63.70021	74
6	86	soften	63.56393	75
6	647	soften	62.43583	76
6	52	soften	61.645893	77
6	185	soften	60.95781	78
6	785	soften	60.040684	79
6	49	soften	57.951305	80
6	87	soften	57.002098	81
6	61	soften	56.535675	82
6	95	soften	56.000412	83
6	94	soften	54.260014	84
6	222	soften	53.890835	85
6	47	soften	52.86115	86
6	51	soften	51.71391	87
6	92	soften	51.083794	88
6	31	soften	50.636032	89
6	56	soften	49.917248	90
6	67	soften	47.644485	91
6	88	soften	46.271755	92
6	1	soften	44.818226	93
6	84	soften	44.11482	94
6	62	soften	42.477417	95
6	36	soften	41.656357	96
7	187	enhance	100	1
7	39	enhance	99.648766	2
7	108	enhance	99.42373	3
7	92	enhance	98.13763	4
7	593	enhance	96.03077	5
7	89	enhance	95.25311	6
7	10	enhance	94.86055	7
7	94	enhance	94.84402	8
7	63	enhance	94.780975	9
7	52	enhance	94.22027	10
7	455	enhance	94.001816	11
7	50	enhance	92.43257	12
7	901	enhance	91.03895	13
7	19	enhance	90.42289	14
7	86	enhance	90.036995	15
7	15	enhance	89.50038	16
7	44	enhance	89.49319	17
7	78	enhance	89.43273	18
7	99	enhance	89.286995	19
7	185	enhance	88.08123	20
7	1	enhance	87.88467	21
7	58	enhance	87.80821	22
7	868	enhance	87.43726	23
7	647	enhance	87.14281	24
7	43	enhance	86.59581	25
7	285	enhance	86.5399	26
7	62	enhance	86.4322	27
7	176	enhance	86.19384	28
7	48	enhance	85.94212	29
7	27	enhance	85.89998	30
7	31	enhance	85.77442	31
7	34	enhance	85.35918	32
7	785	enhance	84.898895	33
7	16	enhance	84.72848	34
7	36	enhance	84.563995	35
7	54	enhance	84.23264	36
7	38	enhance	84.19566	37
7	93	enhance	84.16197	38
7	70	enhance	83.98804	39
7	100	enhance	83.95766	40
7	71	enhance	83.83072	41
7	68	enhance	83.66264	42
7	8	enhance	83.58094	43
7	56	enhance	83.36448	44
7	77	enhance	83.251434	45
7	66	enhance	82.98885	46
7	3	enhance	82.92269	47
7	184	enhance	82.85295	48
7	42	enhance	82.797295	49
7	182	enhance	82.68832	50
7	26	enhance	82.28109	51
7	24	enhance	82.252	52
7	49	enhance	81.86172	53
7	219	enhance	81.04963	54
7	37	enhance	80.80975	55
7	18	enhance	80.178085	56
7	55	enhance	80.17022	57
7	59	enhance	80.04062	58
7	222	enhance	79.984856	59
7	82	enhance	79.70588	60
7	22	enhance	79.67582	61
7	17	enhance	79.6413	62
7	4	enhance	79.12423	63
7	87	enhance	78.9261	64
7	40	enhance	78.89984	65
7	76	enhance	78.73558	66
7	25	enhance	78.58313	67
7	5	enhance	78.5566	68
7	335	enhance	78.421104	69
7	84	enhance	78.23477	70
7	23	enhance	78.1038	71
7	41	enhance	77.902756	72
7	28	enhance	77.897095	73
7	13	enhance	77.83415	74
7	6	enhance	77.55044	75
7	72	enhance	77.43588	76
7	88	enhance	77.363976	77
7	921	enhance	76.74601	78
7	98	enhance	76.71179	79
7	90	enhance	76.67713	80
7	81	enhance	76.20576	81
7	358	enhance	75.92384	82
7	9	enhance	75.893265	83
7	640	enhance	75.24436	84
7	65	enhance	75.10402	85
7	96	enhance	74.941154	86
7	83	enhance	74.54421	87
7	14	enhance	73.08159	88
7	126	enhance	72.50001	89
7	97	enhance	72.49363	90
7	91	enhance	72.43149	91
7	11	enhance	71.8625	92
7	230	enhance	71.65925	93
7	2	enhance	71.64399	94
7	29	enhance	71.25752	95
7	75	enhance	71.19194	96
7	64	enhance	71.186195	97
7	60	enhance	71.08583	98
7	20	enhance	71.02739	99
7	171	enhance	70.66721	100
7	61	enhance	70.54816	101
7	12	enhance	70.12923	102
7	69	enhance	70.11237	103
7	21	enhance	70.04092	104
7	155	enhance	69.83241	105
7	35	enhance	69.567604	106
7	882	enhance	69.100784	107
7	85	enhance	67.99178	108
7	74	enhance	67.98379	109
7	45	enhance	67.80802	110
7	47	enhance	67.47878	111
7	46	enhance	66.93523	112
7	79	enhance	66.50333	113
7	32	enhance	65.85751	114
7	57	enhance	65.55385	115
7	67	enhance	64.46137	116
7	30	enhance	64.378204	117
7	33	enhance	64.13823	118
7	51	enhance	63.06566	119
7	95	enhance	61.048256	120
7	53	enhance	60.92044	121
7	80	enhance	60.895084	122
7	73	enhance	59.39507	123
7	488	enhance	58.340904	124
7	11	soften	100	1
7	91	soften	96.14002	2
7	55	soften	93.24001	3
7	90	soften	91.9524	4
7	126	soften	91.61023	5
7	3	soften	91.40776	6
7	93	soften	90.47078	7
7	184	soften	89.2387	8
7	96	soften	89.00072	9
7	79	soften	87.996544	10
7	4	soften	87.72514	11
7	23	soften	86.65855	12
7	22	soften	86.46609	13
7	868	soften	85.96741	14
7	21	soften	85.5744	15
7	171	soften	84.88027	16
7	9	soften	83.7831	17
7	219	soften	83.51635	18
7	59	soften	83.48451	19
7	2	soften	82.61199	20
7	34	soften	82.53713	21
7	82	soften	82.460556	22
7	12	soften	82.06304	23
7	44	soften	81.86366	24
7	85	soften	81.7635	25
7	182	soften	81.75906	26
7	99	soften	81.67996	27
7	30	soften	81.57256	28
7	35	soften	80.90031	29
7	18	soften	79.71513	30
7	63	soften	78.427925	31
7	28	soften	78.365685	32
7	39	soften	77.955215	33
7	66	soften	77.763695	34
7	69	soften	77.46096	35
7	50	soften	77.13059	36
7	285	soften	75.85133	37
7	176	soften	75.675644	38
7	8	soften	74.39101	39
7	27	soften	73.25629	40
7	64	soften	70.92227	41
7	60	soften	68.36741	42
7	74	soften	67.575745	43
7	80	soften	66.45432	44
7	83	soften	64.958595	45
7	72	soften	64.92753	46
7	70	soften	62.205505	47
7	335	soften	60.661476	48
7	45	soften	60.05243	49
7	13	soften	58.475185	50
7	20	soften	57.966858	51
7	78	soften	57.70427	52
7	5	soften	57.69546	53
7	49	soften	57.49023	54
7	33	soften	57.209396	55
7	43	soften	56.569736	56
7	94	soften	56.359875	57
7	73	soften	56.265675	58
7	95	soften	56.182014	59
7	222	soften	55.825233	60
7	41	soften	55.535225	61
7	640	soften	55.34647	62
7	61	soften	55.2166	63
7	593	soften	54.848904	64
7	51	soften	54.504536	65
7	230	soften	54.190098	66
7	92	soften	53.35702	67
7	187	soften	51.624153	68
7	86	soften	50.65984	69
8	35	enhance	100	1
8	219	enhance	97.69657	2
8	20	enhance	97.09659	3
8	65	enhance	96.61627	4
8	5	enhance	96.61199	5
8	12	enhance	96.14418	6
8	14	enhance	95.95035	7
8	85	enhance	95.551544	8
8	488	enhance	94.60319	9
8	593	enhance	94.55612	10
8	69	enhance	93.87222	11
8	171	enhance	93.06305	12
8	59	enhance	92.59205	13
8	41	enhance	92.54018	14
8	21	enhance	92.463425	15
8	23	enhance	92.396454	16
8	82	enhance	91.95647	17
8	4	enhance	91.2166	18
8	9	enhance	91.129326	19
8	78	enhance	90.87184	20
8	32	enhance	90.80688	21
8	335	enhance	89.7287	22
8	18	enhance	89.66569	23
8	95	enhance	89.362526	24
8	66	enhance	88.257904	25
8	54	enhance	87.050224	26
8	58	enhance	86.871956	27
8	921	enhance	86.610374	28
8	96	enhance	86.12704	29
8	77	enhance	85.28905	30
8	50	enhance	85.12443	31
8	100	enhance	83.92907	32
8	455	enhance	83.61827	33
8	55	enhance	82.963135	34
8	28	enhance	82.52244	35
8	81	enhance	81.3508	36
8	184	enhance	81.12177	37
8	34	enhance	81.054855	38
8	3	enhance	80.469376	39
8	74	enhance	80.35121	40
8	7	enhance	79.65424	41
8	53	enhance	79.53544	42
8	22	enhance	79.48077	43
8	57	enhance	79.39299	44
8	62	enhance	78.53446	45
8	868	enhance	78.24748	46
8	91	enhance	78.189575	47
8	44	enhance	77.00715	48
8	185	enhance	76.568634	49
8	27	enhance	75.93129	50
8	60	enhance	75.90501	51
8	79	enhance	75.73291	52
8	901	enhance	75.02225	53
8	187	enhance	74.97444	54
8	11	enhance	74.4348	55
8	93	enhance	74.18485	56
8	52	enhance	74.04842	57
8	10	enhance	73.4233	58
8	64	enhance	73.20562	59
8	26	enhance	72.851524	60
8	24	enhance	71.77515	61
8	42	enhance	70.80647	62
8	19	enhance	70.63993	63
8	38	enhance	69.206505	64
8	83	enhance	68.74635	65
8	99	enhance	67.87094	66
8	94	enhance	67.691315	67
8	182	enhance	67.44484	68
8	2	enhance	67.16074	69
8	43	enhance	67.001686	70
8	63	enhance	66.96823	71
8	70	enhance	65.990776	72
8	16	enhance	65.96844	73
8	90	enhance	65.498726	74
8	785	enhance	64.740974	75
8	72	enhance	64.187225	76
8	39	enhance	63.799057	77
8	76	enhance	63.771187	78
8	37	enhance	62.91364	79
8	29	enhance	62.553116	80
8	126	enhance	61.481674	81
8	89	enhance	60.625797	82
8	647	enhance	60.255947	83
8	92	enhance	58.55254	84
8	6	enhance	58.311626	85
8	56	enhance	57.3837	86
8	108	enhance	56.54296	87
8	358	enhance	56.005253	88
8	176	enhance	54.4874	89
8	49	enhance	53.9275	90
8	80	enhance	53.283203	91
8	73	enhance	53.017723	92
8	17	enhance	52.28473	93
8	97	enhance	51.696	94
8	15	enhance	51.55817	95
8	45	enhance	50.85334	96
8	86	enhance	48.428543	97
8	71	enhance	47.40443	98
8	285	enhance	44.0778	99
8	30	enhance	43.816895	100
8	31	enhance	42.45917	101
8	1	enhance	41.86938	102
8	230	enhance	41.76644	103
8	13	enhance	40.93296	104
8	48	enhance	40.79332	105
8	68	enhance	39.526306	106
8	98	enhance	39.0244	107
8	87	enhance	38.870583	108
8	84	enhance	37.73473	109
8	36	enhance	36.90456	110
8	61	enhance	36.362568	111
8	640	enhance	35.595245	112
8	222	enhance	35.046127	113
8	47	enhance	34.517002	114
8	88	enhance	33.30312	115
8	33	enhance	32.98828	116
8	46	enhance	31.352898	117
8	40	enhance	30.444918	118
8	25	enhance	28.130053	119
8	155	enhance	27.695982	120
8	882	enhance	26.793411	121
8	51	enhance	23.761198	122
8	75	enhance	23.440903	123
8	67	enhance	17.17712	124
8	11	soften	100	1
8	90	soften	97.039505	2
8	91	soften	96.47104	3
8	126	soften	96.37971	4
8	93	soften	95.52491	5
8	3	soften	93.297424	6
8	55	soften	92.69202	7
8	184	soften	92.21208	8
8	79	soften	91.66337	9
8	30	soften	89.22024	10
8	868	soften	88.90158	11
8	22	soften	88.36068	12
8	182	soften	88.1252	13
8	39	soften	87.89635	14
8	285	soften	87.84992	15
8	99	soften	87.512215	16
8	44	soften	87.23398	17
8	96	soften	86.52567	18
8	4	soften	85.503876	19
8	2	soften	84.880455	20
8	34	soften	84.58998	21
8	63	soften	84.578995	22
8	23	soften	84.4439	23
8	176	soften	84.29185	24
8	59	soften	83.72252	25
8	21	soften	82.77898	26
8	28	soften	82.741325	27
8	66	soften	81.986046	28
8	18	soften	81.615166	29
8	50	soften	81.18494	30
8	82	soften	81.12459	31
8	9	soften	80.53534	32
8	219	soften	80.28189	33
8	171	soften	79.93909	34
8	12	soften	77.949844	35
8	85	soften	77.24861	36
8	35	soften	74.85928	37
8	69	soften	73.419945	38
8	64	soften	71.817986	39
8	80	soften	69.76628	40
8	72	soften	69.06237	41
8	60	soften	68.25999	42
8	83	soften	67.095604	43
8	70	soften	66.814026	44
8	13	soften	65.92448	45
8	74	soften	65.58619	46
8	49	soften	64.50844	47
8	45	soften	64.1997	48
8	222	soften	64.15587	49
8	33	soften	63.812313	50
8	640	soften	62.854107	51
8	94	soften	62.719925	52
8	51	soften	62.711834	53
8	61	soften	62.295998	54
8	230	soften	60.369316	55
8	73	soften	60.350376	56
8	43	soften	60.123726	57
8	335	soften	59.852184	58
8	92	soften	59.47556	59
8	78	soften	59.34836	60
8	593	soften	56.872215	61
8	5	soften	56.470398	62
8	20	soften	53.71517	63
8	41	soften	53.2518	64
8	95	soften	50.993263	65
9	41	enhance	100	1
9	4	enhance	98.99533	2
9	69	enhance	98.58603	3
9	23	enhance	97.96887	4
9	5	enhance	97.052986	5
9	59	enhance	96.57149	6
9	91	enhance	96.4935	7
9	335	enhance	96.16638	8
9	21	enhance	96.00559	9
9	219	enhance	95.400635	10
9	22	enhance	95.16938	11
9	12	enhance	95.01026	12
9	85	enhance	94.60734	13
9	96	enhance	94.516045	14
9	74	enhance	94.19241	15
9	55	enhance	93.3968	16
9	35	enhance	92.89604	17
9	3	enhance	92.60227	18
9	184	enhance	92.41401	19
9	44	enhance	91.86416	20
9	78	enhance	91.81702	21
9	593	enhance	91.35994	22
9	93	enhance	90.99685	23
9	60	enhance	90.663795	24
9	64	enhance	88.9103	25
9	11	enhance	88.82553	26
9	8	enhance	87.90026	27
9	82	enhance	87.836105	28
9	20	enhance	87.63036	29
9	66	enhance	86.45103	30
9	868	enhance	85.62385	31
9	171	enhance	83.95194	32
9	58	enhance	83.18843	33
9	18	enhance	82.07954	34
9	83	enhance	82.063896	35
9	72	enhance	81.86068	36
9	70	enhance	80.38574	37
9	79	enhance	79.928154	38
9	90	enhance	79.25111	39
9	65	enhance	78.54951	40
9	50	enhance	78.48796	41
9	94	enhance	76.29116	42
9	488	enhance	74.48283	43
9	95	enhance	74.154884	44
9	34	enhance	73.78709	45
9	77	enhance	72.07756	46
9	27	enhance	71.64762	47
9	126	enhance	71.53191	48
9	54	enhance	71.498825	49
9	19	enhance	71.03312	50
9	100	enhance	70.54755	51
9	10	enhance	70.10948	52
9	7	enhance	69.76489	53
9	28	enhance	69.689354	54
9	99	enhance	69.46146	55
9	455	enhance	69.27232	56
9	14	enhance	68.50194	57
9	32	enhance	68.24889	58
9	182	enhance	67.50721	59
9	39	enhance	66.71876	60
9	52	enhance	64.379814	61
9	80	enhance	63.659252	62
9	2	enhance	62.28746	63
9	57	enhance	62.213657	64
9	63	enhance	61.562656	65
9	43	enhance	60.16015	66
9	92	enhance	59.408108	67
9	62	enhance	58.152565	68
9	49	enhance	57.019924	69
9	921	enhance	56.30702	70
9	187	enhance	55.319218	71
9	24	enhance	54.662857	72
9	176	enhance	52.933407	73
9	53	enhance	52.81061	74
9	86	enhance	51.471745	75
9	81	enhance	51.05131	76
9	45	enhance	50.839363	77
9	185	enhance	50.418224	78
9	13	enhance	47.497852	79
9	38	enhance	47.251133	80
9	42	enhance	47.10358	81
9	15	enhance	46.7515	82
9	285	enhance	45.56978	83
9	73	enhance	43.842484	84
9	108	enhance	43.2246	85
9	76	enhance	42.99391	86
9	901	enhance	42.784912	87
9	26	enhance	42.78042	88
9	37	enhance	42.466812	89
9	785	enhance	41.62854	90
9	89	enhance	41.48639	91
9	647	enhance	40.877453	92
9	222	enhance	39.478333	93
9	56	enhance	38.51017	94
9	16	enhance	38.079967	95
9	640	enhance	37.7417	96
9	230	enhance	37.538643	97
9	6	enhance	37.196415	98
9	30	enhance	35.844788	99
9	29	enhance	35.462208	100
9	61	enhance	34.792595	101
9	47	enhance	33.432217	102
9	97	enhance	33.21076	103
9	31	enhance	31.7286	104
9	358	enhance	31.560009	105
9	17	enhance	31.13292	106
9	1	enhance	30.85725	107
9	33	enhance	30.762089	108
9	98	enhance	30.621693	109
9	71	enhance	28.9722	110
9	84	enhance	28.9097	111
9	48	enhance	27.461864	112
9	68	enhance	27.123137	113
9	51	enhance	26.963438	114
9	88	enhance	26.124498	115
9	36	enhance	25.80047	116
9	87	enhance	23.687712	117
9	40	enhance	18.93569	118
9	67	enhance	16.28472	119
9	25	enhance	15.818348	120
9	46	enhance	15.321982	121
9	155	enhance	13.428393	122
9	75	enhance	13.025697	123
9	882	enhance	12.133899	124
9	11	soften	100	1
9	126	soften	98.61121	2
9	90	soften	98.47024	3
9	3	soften	95.13613	4
9	93	soften	94.116875	5
9	55	soften	94.116875	6
9	91	soften	91.985054	7
9	184	soften	91.29968	8
9	79	soften	90.66224	9
9	868	soften	87.6603	10
9	22	soften	86.29962	11
9	4	soften	85.69672	12
9	96	soften	83.50991	13
9	23	soften	83.257286	14
9	59	soften	81.61869	15
9	171	soften	81.377625	16
9	219	soften	80.619835	17
9	21	soften	79.31821	18
9	64	soften	70.573906	19
9	80	soften	70.471985	20
9	72	soften	69.42128	21
9	83	soften	68.09008	22
9	60	soften	67.71372	23
9	70	soften	66.672646	24
9	45	soften	65.93185	25
9	74	soften	62.36572	26
9	335	soften	58.370876	27
10	27	enhance	100	1
10	52	enhance	97.34381	2
10	92	enhance	94.957985	3
10	66	enhance	94.53333	4
10	455	enhance	94.217606	5
10	39	enhance	93.28768	6
10	94	enhance	93.28107	7
10	86	enhance	92.375595	8
10	54	enhance	91.56183	9
10	68	enhance	91.22241	10
10	785	enhance	90.773254	11
10	7	enhance	90.46186	12
10	176	enhance	90.0594	13
10	50	enhance	89.99233	14
10	17	enhance	89.62293	15
10	100	enhance	89.077065	16
10	78	enhance	88.985306	17
10	593	enhance	88.804375	18
10	285	enhance	88.62685	19
10	48	enhance	88.603935	20
10	108	enhance	88.54898	21
10	44	enhance	88.18354	22
10	77	enhance	87.85807	23
10	185	enhance	87.43537	24
10	76	enhance	87.39619	25
10	71	enhance	87.066345	26
10	647	enhance	86.54208	27
10	358	enhance	86.27937	28
10	6	enhance	86.2282	29
10	38	enhance	85.979225	30
10	84	enhance	85.80346	31
10	36	enhance	85.43511	32
10	24	enhance	85.400536	33
10	59	enhance	85.3588	34
10	62	enhance	85.0606	35
10	42	enhance	84.64275	36
10	97	enhance	84.64099	37
10	16	enhance	84.53606	38
10	87	enhance	84.255035	39
10	15	enhance	84.19677	40
10	46	enhance	83.44173	41
10	184	enhance	83.253426	42
10	1	enhance	83.15568	43
10	29	enhance	82.795685	44
10	75	enhance	82.435295	45
10	868	enhance	82.15578	46
10	22	enhance	81.92886	47
10	40	enhance	81.92416	48
10	88	enhance	81.62492	49
10	19	enhance	81.55254	50
10	335	enhance	81.164406	51
10	18	enhance	80.46747	52
10	25	enhance	79.75424	53
10	182	enhance	79.60571	54
10	37	enhance	79.35776	55
10	882	enhance	79.032486	56
10	222	enhance	78.41427	57
10	155	enhance	78.06761	58
10	93	enhance	77.726326	59
10	28	enhance	77.6084	60
10	81	enhance	77.33072	61
10	187	enhance	77.32748	62
10	70	enhance	76.93912	63
10	219	enhance	76.79364	64
10	89	enhance	76.50164	65
10	26	enhance	76.17295	66
10	4	enhance	75.78691	67
10	41	enhance	75.6959	68
10	5	enhance	75.1836	69
10	72	enhance	75.168	70
10	58	enhance	75.083374	71
10	65	enhance	74.43525	72
10	12	enhance	74.38358	73
10	901	enhance	74.00962	74
10	21	enhance	73.99766	75
10	921	enhance	73.89491	76
10	98	enhance	73.87248	77
10	51	enhance	73.52469	78
10	8	enhance	73.47035	79
10	55	enhance	73.36708	80
10	53	enhance	73.28799	81
10	49	enhance	72.94369	82
10	96	enhance	72.75125	83
10	9	enhance	72.73157	84
10	63	enhance	72.53278	85
10	82	enhance	72.32655	86
10	3	enhance	72.31722	87
10	91	enhance	71.994	88
10	31	enhance	71.86451	89
10	23	enhance	71.68912	90
10	85	enhance	71.599075	91
10	67	enhance	71.36737	92
10	56	enhance	71.33432	93
10	69	enhance	71.07845	94
10	47	enhance	70.9256	95
10	60	enhance	70.26065	96
10	14	enhance	69.90584	97
10	83	enhance	69.889366	98
10	34	enhance	69.598114	99
10	99	enhance	69.3032	100
10	35	enhance	68.848015	101
10	64	enhance	67.009514	102
10	640	enhance	66.96575	103
10	13	enhance	66.8916	104
10	79	enhance	66.50567	105
10	11	enhance	66.12538	106
10	32	enhance	65.41111	107
10	171	enhance	64.39357	108
10	90	enhance	64.34009	109
10	74	enhance	64.068504	110
10	20	enhance	62.87815	111
10	61	enhance	61.811028	112
10	43	enhance	61.4186	113
10	230	enhance	60.283478	114
10	126	enhance	60.10434	115
10	488	enhance	57.10682	116
10	2	enhance	54.039333	117
10	57	enhance	53.260612	118
10	95	enhance	52.87512	119
10	45	enhance	51.323456	120
10	73	enhance	50.659668	121
10	30	enhance	49.477577	122
10	80	enhance	47.275677	123
10	33	enhance	46.970787	124
10	11	soften	100	1
10	80	soften	98.06434	2
10	60	soften	96.67633	3
10	90	soften	94.49504	4
10	126	soften	94.30517	5
10	91	soften	94.20784	6
10	55	soften	93.49138	7
10	83	soften	93.359924	8
10	3	soften	92.96055	9
10	72	soften	92.30468	10
10	93	soften	89.77336	11
10	79	soften	88.63147	12
10	70	soften	88.59039	13
10	45	soften	88.00603	14
10	4	soften	87.57676	15
10	23	soften	86.93211	16
10	96	soften	86.46906	17
10	184	soften	86.42715	18
10	33	soften	85.143456	19
10	171	soften	85.11501	20
10	34	soften	85.07115	21
10	2	soften	84.84708	22
10	30	soften	84.83085	23
10	43	soften	84.65997	24
10	99	soften	84.151405	25
10	13	soften	84.07961	26
10	21	soften	83.57848	27
10	335	soften	83.5291	28
10	868	soften	83.30141	29
10	9	soften	83.14398	30
10	82	soften	83.10497	31
10	20	soften	82.96444	32
10	73	soften	82.958015	33
10	22	soften	82.95785	34
10	5	soften	82.64305	35
10	182	soften	82.502594	36
10	219	soften	82.43512	37
10	78	soften	80.79586	38
10	59	soften	80.72137	39
10	35	soften	80.59668	40
10	12	soften	80.41594	41
10	85	soften	80.19342	42
10	63	soften	79.84833	43
10	640	soften	79.37093	44
10	44	soften	79.236084	45
10	18	soften	79.023186	46
10	230	soften	78.97554	47
10	28	soften	78.73124	48
10	593	soften	78.155754	49
10	41	soften	77.86308	50
10	50	soften	77.40118	51
10	187	soften	76.672485	52
10	39	soften	76.65753	53
10	8	soften	76.433044	54
10	69	soften	76.38098	55
10	66	soften	75.32587	56
10	7	soften	73.57867	57
10	285	soften	73.44198	58
10	98	soften	73.04192	59
10	89	soften	71.89703	60
10	176	soften	71.74211	61
10	54	soften	71.58763	62
10	64	soften	70.27886	63
10	27	soften	70.143814	64
10	86	soften	68.235344	65
10	74	soften	66.775795	66
10	49	soften	58.35342	67
10	95	soften	56.09906	68
10	61	soften	55.905785	69
10	94	soften	55.121964	70
10	222	soften	53.86128	71
10	56	soften	52.119743	72
10	31	soften	51.89693	73
10	92	soften	51.863106	74
10	47	soften	51.62005	75
10	51	soften	50.95326	76
11	64	enhance	100	1
11	60	enhance	98.66889	2
11	55	enhance	98.03446	3
11	184	enhance	92.038994	4
11	91	enhance	91.91137	5
11	868	enhance	91.80308	6
11	3	enhance	91.43895	7
11	4	enhance	90.72362	8
11	93	enhance	89.54121	9
11	9	enhance	87.83624	10
11	335	enhance	87.49802	11
11	23	enhance	87.433525	12
11	22	enhance	87.42759	13
11	74	enhance	87.39756	14
11	219	enhance	86.065056	15
11	5	enhance	84.366844	16
11	72	enhance	84.17978	17
11	44	enhance	84.01746	18
11	96	enhance	83.97907	19
11	171	enhance	83.47367	20
11	83	enhance	83.36083	21
11	59	enhance	83.1988	22
11	41	enhance	82.61378	23
11	78	enhance	82.505905	24
11	90	enhance	81.387535	25
11	21	enhance	81.345535	26
11	70	enhance	81.32291	27
11	593	enhance	79.809586	28
11	12	enhance	78.03125	29
11	69	enhance	77.57769	30
11	85	enhance	77.39412	31
11	35	enhance	76.72031	32
11	82	enhance	76.17731	33
11	20	enhance	75.45075	34
11	94	enhance	74.242455	35
11	126	enhance	73.905174	36
11	66	enhance	73.57008	37
11	79	enhance	72.105415	38
11	50	enhance	72.083115	39
11	8	enhance	70.99765	40
11	28	enhance	70.39979	41
11	99	enhance	69.71867	42
11	34	enhance	69.32658	43
11	18	enhance	68.92202	44
11	182	enhance	65.583084	45
11	80	enhance	65.469376	46
11	7	enhance	65.323875	47
11	39	enhance	65.2588	48
11	58	enhance	63.925964	49
11	92	enhance	63.40099	50
11	10	enhance	63.031544	51
11	63	enhance	62.079594	52
11	27	enhance	61.98815	53
11	43	enhance	60.002773	54
11	19	enhance	59.741505	55
11	49	enhance	58.310432	56
11	54	enhance	57.45772	57
11	95	enhance	56.434128	58
11	2	enhance	55.885563	59
11	455	enhance	55.08757	60
11	52	enhance	53.585304	61
11	187	enhance	53.554317	62
11	65	enhance	52.94031	63
11	13	enhance	52.558357	64
11	45	enhance	51.98615	65
11	86	enhance	49.55674	66
11	488	enhance	49.51118	67
11	77	enhance	48.127758	68
11	176	enhance	47.947647	69
11	100	enhance	47.258144	70
11	14	enhance	46.913746	71
11	285	enhance	46.63256	72
11	222	enhance	43.205276	73
11	640	enhance	42.69457	74
11	32	enhance	41.656086	75
11	73	enhance	40.915897	76
11	62	enhance	39.797054	77
11	230	enhance	39.526196	78
11	24	enhance	39.251286	79
11	108	enhance	38.905815	80
11	89	enhance	38.747124	81
11	30	enhance	38.5754	82
11	61	enhance	38.53277	83
11	56	enhance	38.221367	84
11	47	enhance	37.78777	85
11	921	enhance	37.328003	86
11	185	enhance	36.24646	87
11	33	enhance	35.237835	88
11	57	enhance	35.16565	89
11	15	enhance	35.077953	90
11	901	enhance	34.321064	91
11	26	enhance	34.25559	92
11	647	enhance	32.63222	93
11	31	enhance	31.850609	94
11	53	enhance	31.254112	95
11	51	enhance	30.84214	96
11	81	enhance	30.412743	97
11	98	enhance	30.127851	98
11	1	enhance	30.067253	99
11	785	enhance	29.241898	100
11	38	enhance	29.07658	101
11	42	enhance	28.276258	102
11	88	enhance	26.82064	103
11	84	enhance	26.503113	104
11	16	enhance	25.547207	105
11	76	enhance	25.41799	106
11	37	enhance	25.304457	107
11	6	enhance	25.148169	108
11	68	enhance	24.184021	109
11	36	enhance	24.056889	110
11	48	enhance	23.175564	111
11	71	enhance	22.108738	112
11	17	enhance	22.089622	113
11	97	enhance	21.335163	114
11	29	enhance	20.890532	115
11	67	enhance	20.039602	116
11	358	enhance	19.347683	117
11	87	enhance	17.525293	118
11	40	enhance	16.447916	119
11	25	enhance	13.179443	120
11	46	enhance	11.481724	121
11	75	enhance	11.072666	122
11	155	enhance	9.71527	123
11	882	enhance	9.195126	124
11	64	soften	100	1
12	85	enhance	100	1
12	21	enhance	99.01521	2
12	35	enhance	98.68303	3
12	59	enhance	98.052315	4
12	5	enhance	97.11616	5
12	69	enhance	96.78159	6
12	23	enhance	94.63953	7
12	335	enhance	93.66723	8
12	219	enhance	93.51859	9
12	9	enhance	93.35994	10
12	4	enhance	93.006516	11
12	41	enhance	91.93046	12
12	66	enhance	91.840065	13
12	593	enhance	91.839745	14
12	8	enhance	91.12658	15
12	96	enhance	88.86212	16
12	20	enhance	88.81022	17
12	91	enhance	88.09709	18
12	78	enhance	87.7722	19
12	74	enhance	86.58823	20
12	82	enhance	86.342995	21
12	22	enhance	85.264175	22
12	488	enhance	85.11745	23
12	18	enhance	84.973434	24
12	171	enhance	84.454834	25
12	184	enhance	84.29736	26
12	65	enhance	83.303856	27
12	55	enhance	82.26344	28
12	60	enhance	81.868256	29
12	32	enhance	81.741104	30
12	79	enhance	80.53591	31
12	44	enhance	80.51586	32
12	54	enhance	80.26705	33
12	868	enhance	79.86776	34
12	93	enhance	79.8454	35
12	3	enhance	79.52555	36
12	14	enhance	79.288124	37
12	64	enhance	78.44428	38
12	28	enhance	77.88149	39
12	77	enhance	77.570145	40
12	11	enhance	77.539444	41
12	95	enhance	77.239006	42
12	50	enhance	76.444145	43
12	100	enhance	76.26384	44
12	455	enhance	76.139366	45
12	27	enhance	76.099045	46
12	58	enhance	73.97146	47
12	53	enhance	72.569374	48
12	94	enhance	70.99982	49
12	52	enhance	70.54494	50
12	10	enhance	70.45648	51
12	83	enhance	68.971405	52
12	72	enhance	68.819756	53
12	70	enhance	68.76783	54
12	34	enhance	66.81961	55
12	90	enhance	66.349686	56
12	24	enhance	65.49244	57
12	921	enhance	65.14399	58
12	62	enhance	63.681263	59
12	7	enhance	63.346527	60
12	182	enhance	63.247753	61
12	39	enhance	59.572514	62
12	99	enhance	59.375668	63
12	185	enhance	59.05554	64
12	126	enhance	58.87773	65
12	81	enhance	58.79104	66
12	2	enhance	58.132122	67
12	42	enhance	57.021095	68
12	38	enhance	56.620415	69
12	19	enhance	55.810463	70
12	57	enhance	55.771385	71
12	63	enhance	54.89723	72
12	176	enhance	53.52269	73
12	92	enhance	52.910633	74
12	80	enhance	51.912716	75
12	76	enhance	51.469917	76
12	785	enhance	51.219486	77
12	49	enhance	51.170795	78
12	43	enhance	50.271107	79
12	29	enhance	49.760918	80
12	86	enhance	49.514816	81
12	16	enhance	48.69297	82
12	6	enhance	48.664234	83
12	187	enhance	48.01323	84
12	97	enhance	46.300716	85
12	647	enhance	45.361683	86
12	901	enhance	44.47545	87
12	26	enhance	44.079247	88
12	108	enhance	44.071327	89
12	358	enhance	43.82645	90
12	285	enhance	41.9234	91
12	45	enhance	41.780376	92
12	37	enhance	41.763878	93
12	73	enhance	41.58147	94
12	17	enhance	40.14176	95
12	13	enhance	37.78002	96
12	89	enhance	37.429913	97
12	15	enhance	37.07259	98
12	71	enhance	35.920353	99
12	222	enhance	32.976723	100
12	98	enhance	32.830933	101
12	230	enhance	32.78724	102
12	56	enhance	32.08655	103
12	48	enhance	32.07942	104
12	84	enhance	30.849194	105
12	68	enhance	30.338251	106
12	87	enhance	30.24287	107
12	31	enhance	30.15659	108
12	640	enhance	29.804491	109
12	61	enhance	28.772516	110
12	1	enhance	28.351162	111
12	36	enhance	27.2131	112
12	88	enhance	26.906923	113
12	30	enhance	26.724747	114
12	47	enhance	26.100119	115
12	40	enhance	23.900883	116
12	33	enhance	23.206379	117
12	51	enhance	22.304012	118
12	46	enhance	21.300339	119
12	25	enhance	20.257027	120
12	155	enhance	18.995996	121
12	75	enhance	18.18241	122
12	882	enhance	16.59339	123
12	67	enhance	13.424867	124
12	126	soften	100	1
12	90	soften	99.575035	2
12	11	soften	97.79709	3
12	3	soften	94.49399	4
12	55	soften	92.66662	5
12	93	soften	92.50132	6
12	79	soften	89.64131	7
12	91	soften	88.440475	8
12	184	soften	87.54989	9
12	868	soften	84.08151	10
12	44	soften	83.70511	11
12	4	soften	83.02119	12
12	22	soften	82.254715	13
12	23	soften	80.9721	14
12	96	soften	78.98418	15
12	171	soften	78.74112	16
12	59	soften	78.14993	17
12	219	soften	77.10883	18
12	9	soften	76.371475	19
12	21	soften	75.39655	20
12	80	soften	71.02795	21
12	72	soften	69.46228	22
12	13	soften	68.32995	23
12	83	soften	68.29519	24
12	64	soften	68.26722	25
12	49	soften	66.79573	26
12	70	soften	66.48655	27
12	45	soften	66.361435	28
12	60	soften	66.332375	29
12	74	soften	59.42818	30
12	78	soften	58.233467	31
12	335	soften	55.230858	32
12	5	soften	54.617416	33
12	20	soften	51.67556	34
13	640	enhance	100	1
13	61	enhance	98.36414	2
13	230	enhance	96.65021	3
13	33	enhance	95.83302	4
13	49	enhance	95.54343	5
13	182	enhance	93.601814	6
13	222	enhance	92.284096	7
13	99	enhance	92.26549	8
13	31	enhance	90.412415	9
13	70	enhance	89.79596	10
13	126	enhance	89.73619	11
13	98	enhance	89.50391	12
13	63	enhance	89.09046	13
13	47	enhance	88.30174	14
13	43	enhance	86.80395	15
13	90	enhance	86.71661	16
13	94	enhance	86.24528	17
13	285	enhance	83.31261	18
13	92	enhance	83.24342	19
13	50	enhance	83.09462	20
13	88	enhance	82.91312	21
13	72	enhance	82.89793	22
13	2	enhance	81.47087	23
13	34	enhance	81.059746	24
13	45	enhance	80.32222	25
13	39	enhance	79.6545	26
13	83	enhance	79.38661	27
13	51	enhance	77.28177	28
13	176	enhance	77.0842	29
13	67	enhance	77.075645	30
13	80	enhance	76.251526	31
13	187	enhance	72.775764	32
13	108	enhance	72.76499	33
13	93	enhance	72.65058	34
13	7	enhance	71.456245	35
13	3	enhance	70.245155	36
13	19	enhance	69.99583	37
13	82	enhance	69.7652	38
13	56	enhance	69.52627	39
13	30	enhance	69.18554	40
13	89	enhance	67.27757	41
13	36	enhance	66.873245	42
13	1	enhance	66.651924	43
13	84	enhance	65.591064	44
13	86	enhance	65.021736	45
13	593	enhance	64.85233	46
13	10	enhance	64.39641	47
13	79	enhance	64.38523	48
13	55	enhance	62.079334	49
13	68	enhance	61.804703	50
13	40	enhance	61.795883	51
13	73	enhance	61.646244	52
13	647	enhance	59.71501	53
13	28	enhance	58.247185	54
13	48	enhance	56.813026	55
13	15	enhance	56.695694	56
13	25	enhance	56.592693	57
13	71	enhance	56.3956	58
13	60	enhance	55.458042	59
13	23	enhance	55.113598	60
13	44	enhance	54.92716	61
13	66	enhance	54.866173	62
13	27	enhance	54.778244	63
13	5	enhance	54.77753	64
13	75	enhance	54.71249	65
13	18	enhance	54.706314	66
13	868	enhance	54.596416	67
13	54	enhance	54.251453	68
13	11	enhance	53.081375	69
13	91	enhance	52.640472	70
13	87	enhance	52.045628	71
13	78	enhance	51.89047	72
13	52	enhance	51.3471	73
13	184	enhance	51.060402	74
13	59	enhance	50.380077	75
13	455	enhance	50.303574	76
13	64	enhance	49.968838	77
13	17	enhance	48.689846	78
13	785	enhance	48.553535	79
13	24	enhance	48.44817	80
13	4	enhance	47.838306	81
13	74	enhance	47.776234	82
13	9	enhance	47.43624	83
13	37	enhance	46.3102	84
13	22	enhance	46.16387	85
13	46	enhance	45.746117	86
13	155	enhance	45.107178	87
13	185	enhance	44.420277	88
13	58	enhance	44.284916	89
13	96	enhance	44.24482	90
13	882	enhance	43.68438	91
13	21	enhance	42.823605	92
13	335	enhance	41.997753	93
13	62	enhance	41.545403	94
13	171	enhance	40.34074	95
13	219	enhance	40.23791	96
13	6	enhance	39.902023	97
13	8	enhance	39.431335	98
13	76	enhance	39.420948	99
13	97	enhance	38.805267	100
13	12	enhance	38.397987	101
13	358	enhance	38.190945	102
13	26	enhance	38.075214	103
13	100	enhance	38.05976	104
13	77	enhance	37.423878	105
13	85	enhance	37.38436	106
13	41	enhance	37.2813	107
13	69	enhance	37.089504	108
13	901	enhance	36.43791	109
13	38	enhance	36.36593	110
13	20	enhance	35.74511	111
13	16	enhance	34.7113	112
13	35	enhance	34.06412	113
13	42	enhance	33.857475	114
13	921	enhance	31.167469	115
13	14	enhance	30.441017	116
13	29	enhance	30.367897	117
13	32	enhance	29.379093	118
13	95	enhance	28.281464	119
13	81	enhance	27.697369	120
13	65	enhance	26.746086	121
13	57	enhance	24.49186	122
13	53	enhance	24.44319	123
13	488	enhance	24.282982	124
13	64	soften	100	1
13	74	soften	96.39821	2
13	11	soften	96.37533	3
13	91	soften	93.15468	4
13	60	soften	91.83699	5
13	96	soften	90.63572	6
13	184	soften	90.21563	7
13	335	soften	89.034004	8
13	55	soften	88.25442	9
13	22	soften	87.257744	10
13	4	soften	86.888275	11
13	219	soften	86.20697	12
13	21	soften	86.13905	13
13	868	soften	86.010956	14
13	171	soften	85.78704	15
13	3	soften	84.85082	16
13	93	soften	83.83647	17
13	23	soften	83.64012	18
13	78	soften	83.610054	19
13	59	soften	82.9236	20
13	9	soften	82.703766	21
13	80	soften	82.69062	22
13	83	soften	81.91587	23
13	44	soften	81.661285	24
13	79	soften	81.55324	25
13	72	soften	80.720825	26
13	90	soften	78.60941	27
13	70	soften	78.45251	28
13	126	soften	78.125854	29
13	45	soften	76.57463	30
14	65	enhance	100	1
14	488	enhance	99.33237	2
14	32	enhance	98.97014	3
14	921	enhance	96.42803	4
14	8	enhance	95.23235	5
14	95	enhance	93.12082	6
14	81	enhance	92.11238	7
14	77	enhance	91.89246	8
14	20	enhance	91.42586	9
14	100	enhance	90.67346	10
14	53	enhance	90.48356	11
14	62	enhance	90.23278	12
14	35	enhance	89.28127	13
14	185	enhance	88.97929	14
14	455	enhance	87.3124	15
14	171	enhance	86.67565	16
14	54	enhance	86.63277	17
14	58	enhance	85.137985	18
14	219	enhance	85.12152	19
14	42	enhance	84.96132	20
14	18	enhance	84.95765	21
14	24	enhance	84.42524	22
14	38	enhance	83.65627	23
14	12	enhance	83.02789	24
14	85	enhance	82.83907	25
14	593	enhance	81.987144	26
14	57	enhance	81.84418	27
14	82	enhance	81.72679	28
14	26	enhance	80.6103	29
14	69	enhance	79.86093	30
14	5	enhance	79.373566	31
14	785	enhance	78.84215	32
14	28	enhance	78.67786	33
14	76	enhance	78.32885	34
14	59	enhance	78.17027	35
14	21	enhance	77.682816	36
14	78	enhance	77.57208	37
14	66	enhance	77.48467	38
14	29	enhance	76.00955	39
14	41	enhance	75.9949	40
14	16	enhance	75.78117	41
14	901	enhance	75.11407	42
14	50	enhance	74.88508	43
14	37	enhance	74.25561	44
14	335	enhance	73.952576	45
14	52	enhance	73.83817	46
14	647	enhance	73.459724	47
14	6	enhance	72.07647	48
14	23	enhance	71.84368	49
14	34	enhance	71.5637	50
14	96	enhance	71.55157	51
14	27	enhance	70.7689	52
14	358	enhance	70.5647	53
14	9	enhance	70.48696	54
14	10	enhance	69.33831	55
14	7	enhance	69.12699	56
14	187	enhance	66.50559	57
14	4	enhance	66.45892	58
14	17	enhance	65.86163	59
14	89	enhance	65.85727	60
14	97	enhance	65.67523	61
14	19	enhance	64.815765	62
14	868	enhance	64.706985	63
14	2	enhance	62.69087	64
14	79	enhance	62.261585	65
14	63	enhance	62.05534	66
14	184	enhance	62.00067	67
14	74	enhance	59.84205	68
14	71	enhance	59.805912	69
14	108	enhance	59.580517	70
14	55	enhance	59.50635	71
14	56	enhance	59.18374	72
14	176	enhance	58.282227	73
14	22	enhance	57.568466	74
14	44	enhance	56.9179	75
14	43	enhance	56.09639	76
14	15	enhance	55.839417	77
14	182	enhance	55.79816	78
14	39	enhance	55.358677	79
14	94	enhance	55.289314	80
14	3	enhance	54.21618	81
14	87	enhance	53.324722	82
14	92	enhance	52.979088	83
14	73	enhance	52.292297	84
14	91	enhance	51.782528	85
14	1	enhance	51.700478	86
14	99	enhance	51.10564	87
14	48	enhance	50.32186	88
14	60	enhance	49.99954	89
14	93	enhance	49.939877	90
14	84	enhance	48.865334	91
14	11	enhance	48.81689	92
14	68	enhance	48.795536	93
14	64	enhance	48.62382	94
14	86	enhance	48.523735	95
14	83	enhance	47.649467	96
14	36	enhance	47.432247	97
14	70	enhance	47.183018	98
14	45	enhance	46.874588	99
14	31	enhance	45.83682	100
14	46	enhance	45.430172	101
14	49	enhance	44.870216	102
14	285	enhance	43.664467	103
14	126	enhance	43.21014	104
14	155	enhance	42.399567	105
14	98	enhance	41.717762	106
14	40	enhance	41.591747	107
14	30	enhance	41.4401	108
14	882	enhance	41.217606	109
14	90	enhance	41.134163	110
14	25	enhance	41.07232	111
14	72	enhance	40.42957	112
14	88	enhance	39.0276	113
14	80	enhance	38.725246	114
14	230	enhance	38.333515	115
14	75	enhance	36.15025	116
14	47	enhance	35.65536	117
14	61	enhance	33.701317	118
14	222	enhance	32.162308	119
14	13	enhance	31.36381	120
14	640	enhance	29.375345	121
14	33	enhance	27.230993	122
14	51	enhance	25.872984	123
14	67	enhance	24.17448	124
14	90	soften	100	1
14	11	soften	99.52396	2
14	126	soften	99.22032	3
14	93	soften	95.793564	4
14	91	soften	95.18486	5
14	3	soften	94.506615	6
14	79	soften	93.08587	7
14	55	soften	92.514336	8
14	30	soften	91.99715	9
14	99	soften	90.47817	10
14	184	soften	90.209785	11
14	182	soften	89.74915	12
14	39	soften	87.82632	13
14	2	soften	87.69354	14
14	285	soften	86.9597	15
14	868	soften	86.7526	16
14	34	soften	86.671936	17
14	63	soften	86.49763	18
14	22	soften	86.018684	19
14	44	soften	85.66207	20
14	23	soften	85.12493	21
14	4	soften	85.07997	22
14	96	soften	84.54941	23
14	28	soften	83.404915	24
14	50	soften	82.4054	25
14	82	soften	82.14569	26
14	176	soften	82.14563	27
14	59	soften	82.00815	28
14	21	soften	81.64479	29
14	18	soften	81.493126	30
14	66	soften	80.777885	31
14	9	soften	80.18166	32
14	27	soften	79.68585	33
14	7	soften	79.64431	34
14	171	soften	79.518776	35
14	219	soften	79.17275	36
14	10	soften	77.39032	37
14	54	soften	76.82223	38
14	12	soften	76.80776	39
14	85	soften	76.38764	40
14	52	soften	75.68458	41
14	647	soften	75.04396	42
14	35	soften	74.419075	43
14	455	soften	74.32774	44
14	69	soften	72.91108	45
14	8	soften	72.19796	46
14	80	soften	72.06283	47
14	64	soften	71.03093	48
14	58	soften	70.66069	49
14	72	soften	69.26225	50
14	60	soften	67.68417	51
14	83	soften	67.55074	52
14	70	soften	67.31395	53
14	13	soften	67.22402	54
14	33	soften	66.76741	55
14	49	soften	65.93815	56
14	45	soften	65.817986	57
14	74	soften	64.93461	58
14	488	soften	64.55541	59
14	640	soften	64.30559	60
14	61	soften	64.08514	61
14	222	soften	63.51104	62
14	230	soften	62.539654	63
14	43	soften	62.52855	64
14	94	soften	62.51389	65
14	73	soften	61.98322	66
14	51	soften	60.912777	67
14	98	soften	60.473156	68
14	31	soften	59.97215	69
14	47	soften	59.02243	70
14	92	soften	58.88723	71
14	78	soften	58.50109	72
14	335	soften	58.20289	73
14	67	soften	58.00456	74
14	86	soften	57.869144	75
14	88	soften	57.563507	76
14	593	soften	57.071663	77
14	5	soften	56.912342	78
14	56	soften	56.57274	79
14	187	soften	56.472942	80
14	84	soften	56.249046	81
14	108	soften	55.171677	82
14	89	soften	55.164753	83
14	1	soften	54.70245	84
14	20	soften	53.463253	85
14	19	soften	52.739388	86
14	41	soften	52.42428	87
14	24	soften	51.12102	88
14	95	soften	50.498672	89
14	26	soften	49.64691	90
15	37	enhance	100	1
15	19	enhance	99.67159	2
15	71	enhance	98.08893	3
15	1	enhance	96.90194	4
15	48	enhance	96.47168	5
15	68	enhance	95.20842	6
15	108	enhance	94.717285	7
15	76	enhance	94.56866	8
15	785	enhance	94.36463	9
15	17	enhance	94.0868	10
15	36	enhance	93.62554	11
15	92	enhance	93.409256	12
15	87	enhance	93.395065	13
15	38	enhance	93.39155	14
15	25	enhance	92.79928	15
15	42	enhance	91.98043	16
15	285	enhance	90.365395	17
15	16	enhance	90.26266	18
15	7	enhance	90.18455	19
15	40	enhance	90.06537	20
15	882	enhance	89.96826	21
15	75	enhance	89.81171	22
15	155	enhance	89.81037	23
15	176	enhance	89.48914	24
15	62	enhance	89.40167	25
15	10	enhance	88.96573	26
15	647	enhance	88.545456	27
15	185	enhance	88.437904	28
15	84	enhance	88.43767	29
15	100	enhance	88.37647	30
15	358	enhance	88.2606	31
15	46	enhance	87.684944	32
15	89	enhance	87.62736	33
15	86	enhance	87.19033	34
15	77	enhance	87.05122	35
15	52	enhance	86.98397	36
15	901	enhance	86.950005	37
15	88	enhance	85.819725	38
15	187	enhance	85.21681	39
15	6	enhance	85.03092	40
15	455	enhance	83.7478	41
15	81	enhance	83.68465	42
15	97	enhance	81.934555	43
15	39	enhance	81.550674	44
15	24	enhance	81.04904	45
15	26	enhance	80.81865	46
15	58	enhance	80.15523	47
15	29	enhance	80.008	48
15	222	enhance	79.425735	49
15	67	enhance	79.28258	50
15	31	enhance	78.50992	51
15	94	enhance	77.27916	52
15	51	enhance	77.074455	53
15	98	enhance	76.886894	54
15	56	enhance	75.72755	55
15	27	enhance	75.58994	56
15	57	enhance	75.21098	57
15	921	enhance	74.03998	58
15	54	enhance	73.48993	59
15	50	enhance	70.02782	60
15	65	enhance	69.64177	61
15	47	enhance	69.46913	62
15	63	enhance	68.67414	63
15	44	enhance	68.5119	64
15	66	enhance	65.65479	65
15	182	enhance	65.56956	66
15	593	enhance	65.212105	67
15	868	enhance	63.772163	68
15	49	enhance	63.637184	69
15	640	enhance	63.218773	70
15	78	enhance	62.26977	71
15	13	enhance	62.22821	72
15	14	enhance	59.485134	73
15	61	enhance	58.37042	74
15	34	enhance	58.343407	75
15	32	enhance	58.223793	76
15	28	enhance	58.213352	77
15	53	enhance	57.958305	78
15	41	enhance	57.35724	79
15	70	enhance	56.976753	80
15	99	enhance	56.801373	81
15	43	enhance	56.587704	82
15	18	enhance	55.879135	83
15	8	enhance	54.51337	84
15	230	enhance	54.323734	85
15	72	enhance	53.90159	86
15	22	enhance	53.17508	87
15	59	enhance	53.098232	88
15	184	enhance	52.573597	89
15	9	enhance	51.247074	90
15	82	enhance	51.020332	91
15	83	enhance	50.756622	92
15	219	enhance	49.64103	93
15	69	enhance	49.624336	94
15	55	enhance	49.030857	95
15	335	enhance	48.912395	96
15	30	enhance	48.794086	97
15	93	enhance	48.54456	98
15	33	enhance	47.057518	99
15	3	enhance	46.774467	100
15	45	enhance	46.008408	101
15	4	enhance	45.548122	102
15	171	enhance	45.17724	103
15	5	enhance	44.67201	104
15	73	enhance	43.1809	105
15	126	enhance	42.8083	106
15	96	enhance	42.306942	107
15	488	enhance	41.98822	108
15	60	enhance	41.950172	109
15	12	enhance	41.355797	110
15	90	enhance	41.104645	111
15	20	enhance	40.432934	112
15	2	enhance	40.179386	113
15	35	enhance	39.331432	114
15	23	enhance	39.138298	115
15	11	enhance	38.884083	116
15	21	enhance	37.996307	117
15	85	enhance	37.863567	118
15	95	enhance	37.827126	119
15	91	enhance	37.63776	120
15	64	enhance	36.733475	121
15	79	enhance	35.203773	122
15	74	enhance	30.6508	123
15	80	enhance	27.980312	124
15	11	soften	100	1
15	91	soften	97.01429	2
15	90	soften	94.59753	3
15	126	soften	93.50387	4
15	55	soften	92.835785	5
15	3	soften	92.77011	6
15	93	soften	91.63175	7
15	79	soften	90.89726	8
15	96	soften	90.33583	9
15	23	soften	89.6982	10
15	184	soften	88.82278	11
15	4	soften	88.512146	12
15	21	soften	87.53267	13
15	2	soften	86.55253	14
15	22	soften	86.01759	15
15	171	soften	85.64676	16
15	9	soften	85.33172	17
15	219	soften	84.406876	18
15	82	soften	84.11987	19
15	99	soften	84.015854	20
15	868	soften	83.97168	21
15	85	soften	83.90801	22
15	34	soften	83.791664	23
15	12	soften	83.41484	24
15	59	soften	83.329834	25
15	35	soften	82.90745	26
15	30	soften	82.701035	27
15	182	soften	81.3991	28
15	44	soften	80.941605	29
15	18	soften	80.60774	30
15	69	soften	79.81241	31
15	63	soften	79.70805	32
15	28	soften	78.64062	33
15	50	soften	77.41223	34
15	39	soften	76.95814	35
15	8	soften	76.54397	36
15	66	soften	76.49479	37
15	488	soften	73.444	38
15	7	soften	72.19154	39
15	54	soften	71.63754	40
15	285	soften	71.48974	41
15	58	soften	71.37354	42
15	64	soften	71.35253	43
15	27	soften	71.22582	44
15	176	soften	71.015076	45
15	74	soften	69.568474	46
15	80	soften	69.3114	47
15	14	soften	69.21315	48
15	455	soften	68.93878	49
15	10	soften	68.90252	50
15	60	soften	67.63777	51
15	52	soften	66.48357	52
15	647	soften	65.99338	53
15	32	soften	65.05558	54
15	83	soften	64.22269	55
15	72	soften	63.80038	56
15	901	soften	63.679806	57
15	53	soften	63.135685	58
15	70	soften	62.111366	59
15	6	soften	61.714233	60
15	45	soften	61.068897	61
15	335	soften	60.73606	62
15	17	soften	60.726986	63
15	97	soften	60.26148	64
15	20	soften	59.444695	65
15	5	soften	59.243618	66
15	33	soften	58.58975	67
15	43	soften	58.36119	68
15	13	soften	58.03231	69
15	95	soften	57.54826	70
15	78	soften	57.511147	71
15	49	soften	57.509663	72
15	73	soften	57.2293	73
15	41	soften	56.29041	74
15	593	soften	55.455605	75
15	61	soften	55.375797	76
15	230	soften	55.192455	77
15	94	soften	55.089905	78
15	640	soften	55.018513	79
15	222	soften	52.84077	80
15	187	soften	51.431774	81
15	31	soften	50.877823	82
15	47	soften	50.847572	83
15	92	soften	50.776245	84
15	56	soften	50.714046	85
15	98	soften	49.863472	86
15	51	soften	49.5681	87
15	89	soften	49.009163	88
15	19	soften	48.267006	89
15	86	soften	47.5888	90
15	24	soften	47.047947	91
15	65	soften	46.865158	92
15	108	soften	46.811428	93
15	88	soften	46.541584	94
15	67	soften	46.487812	95
15	84	soften	46.408344	96
15	26	soften	46.36032	97
15	1	soften	45.753113	98
15	921	soften	45.55006	99
15	62	soften	45.195	100
15	77	soften	44.67625	101
15	185	soften	44.6592	102
15	100	soften	44.44053	103
15	785	soften	43.84482	104
15	36	soften	43.3586	105
15	87	soften	42.25234	106
15	40	soften	42.176914	107
15	71	soften	42.037262	108
15	68	soften	41.88289	109
15	38	soften	41.6137	110
15	25	soften	41.518684	111
15	48	soften	41.45328	112
15	358	soften	41.193317	113
15	882	soften	40.31789	114
15	46	soften	40.26347	115
15	155	soften	40.20398	116
16	358	enhance	100	1
16	42	enhance	99.82632	2
16	29	enhance	99.14323	3
16	38	enhance	99.00762	4
16	785	enhance	98.756645	5
16	6	enhance	98.35414	6
16	76	enhance	98.21145	7
16	185	enhance	98.0792	8
16	17	enhance	97.866745	9
16	97	enhance	96.007904	10
16	71	enhance	95.31255	11
16	81	enhance	94.01707	12
16	62	enhance	94.00705	13
16	52	enhance	93.41298	14
16	48	enhance	92.69731	15
16	455	enhance	91.73007	16
16	901	enhance	91.6487	17
16	647	enhance	91.219864	18
16	37	enhance	90.52871	19
16	87	enhance	90.42593	20
16	921	enhance	90.107635	21
16	100	enhance	89.58664	22
16	24	enhance	89.20934	23
16	108	enhance	89.16656	24
16	68	enhance	88.82837	25
16	26	enhance	88.5514	26
16	77	enhance	87.92377	27
16	46	enhance	86.893776	28
16	40	enhance	86.44914	29
16	25	enhance	86.433784	30
16	54	enhance	86.27341	31
16	882	enhance	86.24045	32
16	53	enhance	86.075775	33
16	155	enhance	86.03584	34
16	36	enhance	85.08216	35
16	75	enhance	83.483116	36
16	15	enhance	83.189064	37
16	1	enhance	82.94286	38
16	10	enhance	82.32419	39
16	27	enhance	82.183014	40
16	89	enhance	81.49819	41
16	84	enhance	80.89342	42
16	7	enhance	78.6855	43
16	86	enhance	77.485016	44
16	65	enhance	76.01898	45
16	14	enhance	74.40242	46
16	187	enhance	73.35523	47
16	32	enhance	73.23935	48
16	88	enhance	72.42959	49
16	176	enhance	72.38185	50
16	285	enhance	70.86672	51
16	66	enhance	70.80601	52
16	28	enhance	70.64447	53
16	92	enhance	69.95989	54
16	56	enhance	69.797775	55
16	39	enhance	68.27588	56
16	98	enhance	65.87709	57
16	31	enhance	65.85284	58
16	19	enhance	65.8351	59
16	593	enhance	65.36317	60
16	18	enhance	65.289925	61
16	8	enhance	64.283554	62
16	58	enhance	64.08476	63
16	57	enhance	62.772545	64
16	50	enhance	62.264812	65
16	78	enhance	61.966534	66
16	94	enhance	60.155293	67
16	488	enhance	57.400257	68
16	67	enhance	54.32242	69
16	63	enhance	53.7844	70
16	59	enhance	53.521442	71
16	219	enhance	52.426506	72
16	222	enhance	51.833645	73
16	35	enhance	51.77227	74
16	44	enhance	51.66486	75
16	868	enhance	50.522545	76
16	12	enhance	50.061966	77
16	51	enhance	49.117237	78
16	34	enhance	48.645725	79
16	49	enhance	48.241833	80
16	171	enhance	48.11875	81
16	182	enhance	47.98194	82
16	69	enhance	47.85077	83
16	85	enhance	47.850395	84
16	20	enhance	47.54019	85
16	73	enhance	47.122498	86
16	335	enhance	46.850445	87
16	41	enhance	46.836723	88
16	5	enhance	45.43242	89
16	95	enhance	45.430508	90
16	47	enhance	45.39369	91
16	184	enhance	44.989418	92
16	21	enhance	44.918	93
16	43	enhance	43.93601	94
16	30	enhance	42.738754	95
16	82	enhance	42.520424	96
16	79	enhance	40.62535	97
16	22	enhance	40.61762	98
16	4	enhance	39.702763	99
16	61	enhance	38.94634	100
16	9	enhance	38.470535	101
16	230	enhance	38.35184	102
16	640	enhance	38.23409	103
16	99	enhance	37.823036	104
16	23	enhance	36.811596	105
16	96	enhance	36.275673	106
16	13	enhance	35.11286	107
16	55	enhance	32.93485	108
16	70	enhance	32.849453	109
16	45	enhance	32.498623	110
16	93	enhance	31.911646	111
16	3	enhance	31.010586	112
16	2	enhance	29.064043	113
16	60	enhance	27.87872	114
16	72	enhance	27.465345	115
16	91	enhance	27.160757	116
16	64	enhance	26.854563	117
16	83	enhance	26.84114	118
16	11	enhance	26.09992	119
16	74	enhance	25.581907	120
16	33	enhance	25.195314	121
16	126	enhance	21.060192	122
16	90	enhance	19.840412	123
16	80	enhance	15.031979	124
16	64	soften	100	1
16	80	soften	99.744736	2
16	11	soften	99.48085	3
16	60	soften	97.71972	4
16	74	soften	97.178085	5
16	91	soften	96.47564	6
16	90	soften	96.294136	7
16	126	soften	95.64624	8
16	83	soften	94.33985	9
16	72	soften	94.12836	10
16	55	soften	92.95935	11
16	3	soften	92.42474	12
16	93	soften	91.13581	13
16	70	soften	90.30214	14
16	79	soften	89.81518	15
16	23	soften	88.008194	16
16	45	soften	87.554756	17
16	96	soften	87.19278	18
16	4	soften	86.783905	19
16	2	soften	86.2747	20
16	33	soften	85.987335	21
16	13	soften	85.429535	22
16	184	soften	85.31769	23
16	21	soften	84.99204	24
16	82	soften	84.124825	25
16	99	soften	84.04789	26
16	9	soften	83.74435	27
16	34	soften	83.39893	28
16	335	soften	83.37019	29
16	171	soften	83.35538	30
16	5	soften	83.19635	31
16	49	soften	83.18514	32
16	182	soften	82.95298	33
16	22	soften	82.946686	34
16	868	soften	82.5595	35
16	43	soften	82.46894	36
16	20	soften	81.621315	37
16	59	soften	81.354645	38
16	85	soften	81.24414	39
16	12	soften	81.158646	40
16	61	soften	80.88276	41
16	219	soften	80.74975	42
16	30	soften	80.74488	43
16	640	soften	80.64308	44
16	230	soften	80.07644	45
16	35	soften	80.00945	46
16	73	soften	79.96811	47
16	95	soften	78.94817	48
16	94	soften	78.94444	49
16	63	soften	78.91551	50
16	78	soften	78.3093	51
16	44	soften	77.964584	52
16	222	soften	77.80239	53
16	18	soften	77.30984	54
16	41	soften	77.14227	55
16	593	soften	77.07401	56
16	69	soften	76.99854	57
16	50	soften	76.95679	58
16	28	soften	76.47041	59
16	47	soften	75.03405	60
16	39	soften	74.60069	61
16	66	soften	74.323265	62
16	51	soften	74.23306	63
16	8	soften	73.17103	64
16	92	soften	73.02329	65
16	31	soften	72.644005	66
16	285	soften	72.1558	67
16	98	soften	72.08647	68
16	176	soften	72.024475	69
16	187	soften	71.830284	70
16	488	soften	70.22681	71
16	56	soften	70.2186	72
16	7	soften	69.918724	73
16	67	soften	68.95165	74
16	54	soften	68.77903	75
16	19	soften	68.61801	76
16	58	soften	68.30087	77
16	27	soften	67.884995	78
16	89	soften	67.566895	79
16	10	soften	67.20697	80
16	88	soften	66.85169	81
16	86	soften	66.380104	82
16	14	soften	66.07255	83
16	455	soften	65.69048	84
16	84	soften	65.08331	85
16	24	soften	65.02055	86
16	108	soften	64.834404	87
16	1	soften	64.34911	88
16	52	soften	63.261555	89
16	647	soften	63.24185	90
16	65	soften	63.16556	91
16	32	soften	62.419617	92
16	26	soften	62.256153	93
16	62	soften	61.160427	94
16	921	soften	61.139683	95
16	185	soften	60.820827	96
16	36	soften	60.771	97
16	77	soften	60.612335	98
16	785	soften	60.392628	99
16	100	soften	60.239388	100
16	901	soften	59.981205	101
16	53	soften	59.007633	102
16	87	soften	58.649673	103
16	71	soften	58.548115	104
16	40	soften	58.509945	105
16	68	soften	58.324364	106
16	17	soften	58.204018	107
16	6	soften	57.802177	108
16	25	soften	57.738586	109
16	15	soften	57.44986	110
16	48	soften	57.250793	111
16	97	soften	56.339466	112
16	38	soften	56.18912	113
16	76	soften	55.817097	114
16	155	soften	55.72386	115
16	358	soften	55.55441	116
16	46	soften	55.477146	117
16	882	soften	55.274704	118
16	29	soften	54.22017	119
17	358	enhance	100	1
17	71	enhance	99.56948	2
17	785	enhance	99.43875	3
17	6	enhance	97.50214	4
17	76	enhance	97.11232	5
17	48	enhance	96.91561	6
17	16	enhance	96.78356	7
17	68	enhance	96.63728	8
17	97	enhance	96.61225	9
17	29	enhance	96.611824	10
17	46	enhance	96.000305	11
17	87	enhance	95.27348	12
17	38	enhance	94.072624	13
17	42	enhance	93.9354	14
17	882	enhance	93.61179	15
17	40	enhance	93.50929	16
17	647	enhance	93.44034	17
17	185	enhance	93.01267	18
17	75	enhance	93.00353	19
17	25	enhance	92.66437	20
17	155	enhance	92.181854	21
17	36	enhance	91.805824	22
17	108	enhance	89.98376	23
17	84	enhance	89.9128	24
17	37	enhance	89.60771	25
17	52	enhance	88.90379	26
17	1	enhance	88.593346	27
17	62	enhance	87.78992	28
17	10	enhance	86.31197	29
17	88	enhance	85.935326	30
17	455	enhance	85.78776	31
17	15	enhance	85.75378	32
17	24	enhance	85.736984	33
17	81	enhance	85.57086	34
17	100	enhance	83.75015	35
17	26	enhance	82.90627	36
17	54	enhance	82.89056	37
17	27	enhance	82.63179	38
17	285	enhance	81.832146	39
17	77	enhance	81.66002	40
17	86	enhance	81.065346	41
17	901	enhance	80.60714	42
17	176	enhance	80.55114	43
17	921	enhance	79.919464	44
17	89	enhance	79.75009	45
17	53	enhance	78.41928	46
17	92	enhance	77.5344	47
17	98	enhance	77.511	48
17	31	enhance	73.89013	49
17	7	enhance	73.142555	50
17	39	enhance	72.722305	51
17	56	enhance	72.20289	52
17	67	enhance	71.251366	53
17	187	enhance	70.23909	54
17	66	enhance	68.974724	55
17	19	enhance	67.98648	56
17	51	enhance	67.0391	57
17	222	enhance	66.70367	58
17	94	enhance	65.667366	59
17	28	enhance	65.50498	60
17	50	enhance	65.24815	61
17	65	enhance	64.384575	62
17	14	enhance	63.94766	63
17	32	enhance	61.668446	64
17	47	enhance	61.036896	65
17	18	enhance	59.929234	66
17	593	enhance	59.092537	67
17	182	enhance	57.577106	68
17	78	enhance	56.753525	69
17	49	enhance	56.499035	70
17	63	enhance	55.744995	71
17	58	enhance	55.476963	72
17	640	enhance	53.292473	73
17	61	enhance	52.700333	74
17	57	enhance	51.678467	75
17	8	enhance	50.38543	76
17	230	enhance	49.805424	77
17	44	enhance	49.26347	78
17	59	enhance	48.863106	79
17	34	enhance	48.78662	80
17	13	enhance	48.70799	81
17	868	enhance	47.27008	82
17	73	enhance	46.54397	83
17	30	enhance	45.96516	84
17	488	enhance	45.21776	85
17	43	enhance	44.27458	86
17	219	enhance	42.350067	87
17	184	enhance	41.831337	88
17	82	enhance	41.759724	89
17	99	enhance	41.40832	90
17	335	enhance	41.175694	91
17	12	enhance	40.813557	92
17	70	enhance	39.962673	93
17	35	enhance	39.22272	94
17	171	enhance	39.13229	95
17	33	enhance	38.252773	96
17	5	enhance	38.13934	97
17	79	enhance	37.972073	98
17	85	enhance	37.922855	99
17	41	enhance	37.80143	100
17	69	enhance	37.507725	101
17	22	enhance	37.15671	102
17	21	enhance	36.94521	103
17	45	enhance	36.789234	104
17	20	enhance	35.780914	105
17	95	enhance	35.15132	106
17	72	enhance	35.078762	107
17	2	enhance	32.901802	108
17	93	enhance	32.65136	109
17	83	enhance	32.535217	110
17	4	enhance	32.171967	111
17	96	enhance	31.267944	112
17	9	enhance	31.104122	113
17	55	enhance	30.86098	114
17	23	enhance	29.743555	115
17	3	enhance	29.038164	116
17	126	enhance	27.943642	117
17	60	enhance	26.191023	118
17	90	enhance	24.700628	119
17	91	enhance	23.51632	120
17	64	enhance	22.681011	121
17	11	enhance	22.317753	122
17	74	enhance	19.54829	123
17	80	enhance	18.145689	124
17	11	soften	100	1
17	80	soften	98.557365	2
17	60	soften	97.173294	3
17	91	soften	96.60882	4
17	90	soften	94.262634	5
17	126	soften	93.576866	6
17	55	soften	92.844696	7
17	83	soften	92.2771	8
17	3	soften	92.21093	9
17	72	soften	91.276726	10
17	93	soften	90.04854	11
17	79	soften	89.407364	12
17	23	soften	88.77133	13
17	96	soften	88.3535	14
17	70	soften	87.95654	15
17	4	soften	87.946144	16
17	45	soften	86.442116	17
17	21	soften	86.137695	18
17	184	soften	85.813225	19
17	171	soften	85.24723	20
17	2	soften	85.233086	21
17	9	soften	84.74266	22
17	335	soften	84.39778	23
17	20	soften	84.040405	24
17	5	soften	83.891464	25
17	82	soften	83.64258	26
17	22	soften	83.16223	27
17	34	soften	82.9946	28
17	85	soften	82.909515	29
17	868	soften	82.811035	30
17	33	soften	82.666466	31
17	219	soften	82.647606	32
17	99	soften	82.58792	33
17	12	soften	82.45494	34
17	35	soften	82.20078	35
17	43	soften	82.18697	36
17	13	soften	81.74473	37
17	59	soften	81.46044	38
17	182	soften	80.40971	39
17	30	soften	80.13526	40
17	73	soften	79.73536	41
17	78	soften	79.07143	42
17	41	soften	78.646034	43
17	69	soften	78.57296	44
17	63	soften	78.09588	45
17	18	soften	77.94121	46
17	44	soften	77.852905	47
17	593	soften	77.29527	48
17	230	soften	77.13458	49
17	640	soften	76.858986	50
17	28	soften	76.55049	51
17	50	soften	75.68996	52
17	8	soften	75.38772	53
17	66	soften	73.72594	54
17	39	soften	73.43649	55
17	488	soften	72.38128	56
17	187	soften	72.07282	57
17	64	soften	70.66367	58
17	7	soften	70.23409	59
17	58	soften	69.59031	60
17	285	soften	69.42322	61
17	176	soften	69.35425	62
17	98	soften	69.12077	63
17	74	soften	69.11074	64
17	54	soften	68.666695	65
17	19	soften	67.78106	66
17	89	soften	67.59973	67
17	14	soften	67.345955	68
17	27	soften	67.07181	69
17	455	soften	66.05155	70
17	10	soften	65.76975	71
17	65	soften	64.69225	72
17	24	soften	64.642586	73
17	86	soften	64.45771	74
17	108	soften	63.981792	75
17	52	soften	63.18636	76
17	26	soften	63.0634	77
17	647	soften	62.461487	78
17	901	soften	61.417015	79
17	185	soften	61.046886	80
17	785	soften	59.51117	81
17	6	soften	57.505344	82
17	95	soften	56.942375	83
17	87	soften	56.676807	84
17	49	soften	56.599937	85
17	97	soften	55.69722	86
17	61	soften	54.28072	87
17	94	soften	53.8854	88
17	222	soften	51.479156	89
17	47	soften	49.916862	90
17	92	soften	49.637035	91
17	31	soften	49.320915	92
17	56	soften	48.793507	93
17	51	soften	48.198242	94
17	67	soften	44.897808	95
17	88	soften	44.69894	96
17	1	soften	44.004257	97
17	84	soften	43.757572	98
17	921	soften	43.665733	99
17	62	soften	43.175728	100
17	77	soften	42.73342	101
17	100	soften	42.41713	102
17	36	soften	41.218853	103
17	40	soften	39.569874	104
17	25	soften	38.93276	105
18	79	enhance	100	1
18	78	enhance	99.98361	2
18	54	enhance	99.58065	3
18	593	enhance	97.09616	4
18	20	enhance	96.27384	5
18	21	enhance	96.10678	6
18	219	enhance	95.9505	7
18	455	enhance	95.94059	8
18	85	enhance	94.66685	9
18	35	enhance	94.54263	10
18	28	enhance	93.89027	11
18	66	enhance	93.82403	12
18	27	enhance	93.447914	13
18	5	enhance	93.12331	14
18	59	enhance	93.12203	15
18	69	enhance	92.41515	16
18	8	enhance	91.75206	17
18	12	enhance	91.7383	18
18	34	enhance	91.19004	19
18	74	enhance	90.71785	20
18	488	enhance	90.24735	21
18	171	enhance	89.82103	22
18	95	enhance	89.785385	23
18	96	enhance	89.74088	24
18	23	enhance	89.57725	25
18	65	enhance	89.4373	26
18	50	enhance	89.07515	27
18	58	enhance	88.97771	28
18	62	enhance	88.92636	29
18	335	enhance	88.83114	30
18	184	enhance	88.62239	31
18	921	enhance	87.66669	32
18	14	enhance	87.5899	33
18	82	enhance	87.58967	34
18	77	enhance	87.39673	35
18	52	enhance	87.300156	36
18	9	enhance	87.07478	37
18	24	enhance	86.90722	38
18	100	enhance	86.87845	39
18	73	enhance	86.484955	40
18	32	enhance	86.477165	41
18	41	enhance	85.55474	42
18	39	enhance	85.15975	43
18	3	enhance	84.75468	44
18	53	enhance	84.71109	45
18	94	enhance	84.544235	46
18	185	enhance	84.08086	47
18	4	enhance	82.53479	48
18	93	enhance	82.34461	49
18	10	enhance	82.28708	50
18	43	enhance	81.56213	51
18	80	enhance	81.4972	52
18	63	enhance	81.23066	53
18	44	enhance	80.91553	54
18	45	enhance	80.276566	55
18	647	enhance	80.19735	56
18	91	enhance	79.94676	57
18	22	enhance	79.941444	58
18	49	enhance	79.71889	59
18	70	enhance	79.50476	60
18	55	enhance	78.879295	61
18	2	enhance	78.21001	62
18	7	enhance	78.18922	63
18	64	enhance	77.989914	64
18	6	enhance	77.42166	65
18	868	enhance	77.26997	66
18	89	enhance	76.74554	67
18	126	enhance	76.59257	68
18	26	enhance	76.465805	69
18	83	enhance	75.92072	70
18	56	enhance	75.91484	71
18	81	enhance	75.717155	72
18	30	enhance	75.70912	73
18	42	enhance	75.11432	74
18	38	enhance	74.41803	75
18	11	enhance	73.94002	76
18	182	enhance	73.79594	77
18	97	enhance	73.28037	78
18	99	enhance	73.098145	79
18	90	enhance	72.97402	80
18	108	enhance	72.83732	81
18	29	enhance	72.380875	82
18	19	enhance	71.3641	83
18	76	enhance	71.27454	84
18	86	enhance	71.07818	85
18	785	enhance	71.01353	86
18	187	enhance	70.25947	87
18	60	enhance	70.20243	88
18	72	enhance	69.89511	89
18	16	enhance	68.56019	90
18	176	enhance	67.97745	91
18	285	enhance	66.94808	92
18	57	enhance	66.65063	93
18	358	enhance	65.857544	94
18	92	enhance	64.68749	95
18	37	enhance	63.969482	96
18	17	enhance	63.635303	97
18	84	enhance	62.727654	98
18	31	enhance	61.253178	99
18	1	enhance	61.017975	100
18	901	enhance	60.558075	101
18	230	enhance	60.02398	102
18	98	enhance	59.6814	103
18	36	enhance	59.307053	104
18	61	enhance	58.743694	105
18	13	enhance	58.111042	106
18	71	enhance	57.728622	107
18	88	enhance	56.89063	108
18	48	enhance	55.34646	109
18	68	enhance	55.170387	110
18	15	enhance	54.07962	111
18	40	enhance	54.071384	112
18	47	enhance	53.991894	113
18	87	enhance	52.13375	114
18	640	enhance	50.550434	115
18	222	enhance	47.549454	116
18	46	enhance	45.854263	117
18	33	enhance	45.277122	118
18	25	enhance	44.940937	119
18	75	enhance	41.54867	120
18	882	enhance	40.819683	121
18	155	enhance	40.4891	122
18	51	enhance	32.397736	123
18	67	enhance	29.972748	124
18	11	soften	100	1
18	60	soften	98.68266	2
18	72	soften	97.517944	3
18	83	soften	96.79692	4
18	80	soften	95.94266	5
18	126	soften	95.415634	6
18	90	soften	94.84431	7
18	55	soften	94.62608	8
18	91	soften	93.25591	9
18	3	soften	92.746216	10
18	70	soften	91.895294	11
18	93	soften	90.42235	12
18	13	soften	90.109436	13
18	45	soften	89.17567	14
18	33	soften	88.67547	15
18	184	soften	87.002556	16
18	868	soften	86.65046	17
18	182	soften	86.627	18
18	79	soften	86.618095	19
18	4	soften	86.60787	20
18	30	soften	86.34557	21
18	34	soften	85.65449	22
18	99	soften	85.01137	23
18	43	soften	84.973465	24
18	96	soften	83.96262	25
18	23	soften	83.72247	26
18	22	soften	83.602234	27
18	73	soften	83.42407	28
18	171	soften	83.29973	29
18	2	soften	82.97182	30
18	335	soften	82.81669	31
18	82	soften	82.534706	32
18	44	soften	81.60067	33
18	78	soften	81.3104	34
18	59	soften	81.21866	35
18	9	soften	81.00108	36
18	21	soften	80.63596	37
18	219	soften	80.46775	38
18	5	soften	80.39096	39
18	20	soften	79.08181	40
18	12	soften	78.20292	41
18	35	soften	77.08429	42
18	85	soften	76.84129	43
18	64	soften	69.366325	44
18	74	soften	63.54593	45
18	49	soften	61.336716	46
18	94	soften	58.858803	47
19	15	enhance	100	1
19	187	enhance	95.74154	2
19	92	enhance	93.349396	3
19	58	enhance	91.809395	4
19	7	enhance	91.41431	5
19	37	enhance	89.10619	6
19	50	enhance	89.011345	7
19	285	enhance	88.74357	8
19	94	enhance	88.194176	9
19	34	enhance	87.63615	10
19	176	enhance	87.06836	11
19	182	enhance	86.61597	12
19	10	enhance	86.455666	13
19	89	enhance	85.98101	14
19	83	enhance	85.32705	15
19	1	enhance	84.73213	16
19	62	enhance	83.814606	17
19	57	enhance	83.78123	18
19	56	enhance	83.382576	19
19	77	enhance	83.37072	20
19	100	enhance	83.32994	21
19	70	enhance	83.10416	22
19	39	enhance	82.69022	23
19	108	enhance	82.40312	24
19	72	enhance	82.31242	25
19	63	enhance	81.745575	26
19	901	enhance	81.185776	27
19	49	enhance	80.89574	28
19	185	enhance	80.58792	29
19	82	enhance	80.44486	30
19	455	enhance	80.36297	31
19	47	enhance	80.069534	32
19	26	enhance	80.057304	33
19	54	enhance	79.87418	34
19	43	enhance	79.77989	35
19	593	enhance	79.65393	36
19	785	enhance	79.29102	37
19	55	enhance	79.12632	38
19	81	enhance	78.9768	39
19	647	enhance	78.907646	40
19	222	enhance	78.9045	41
19	99	enhance	78.75444	42
19	3	enhance	78.59205	43
19	44	enhance	78.49328	44
19	71	enhance	78.329994	45
19	9	enhance	78.120155	46
19	65	enhance	78.056946	47
19	78	enhance	77.85717	48
19	88	enhance	77.66388	49
19	76	enhance	77.45873	50
19	52	enhance	77.40984	51
19	126	enhance	77.08144	52
19	13	enhance	77.07934	53
19	41	enhance	76.87296	54
19	38	enhance	76.43269	55
19	921	enhance	76.32887	56
19	66	enhance	75.97853	57
19	42	enhance	75.851	58
19	98	enhance	75.4424	59
19	36	enhance	75.43178	60
19	868	enhance	75.29025	61
19	86	enhance	75.274086	62
19	31	enhance	75.17673	63
19	8	enhance	74.934944	64
19	17	enhance	74.83875	65
19	27	enhance	74.812195	66
19	24	enhance	74.13042	67
19	18	enhance	73.98171	68
19	51	enhance	73.90879	69
19	68	enhance	73.76628	70
19	84	enhance	72.82362	71
19	90	enhance	72.46154	72
19	93	enhance	72.177956	73
19	48	enhance	71.91791	74
19	640	enhance	71.77353	75
19	16	enhance	71.66844	76
19	45	enhance	71.55661	77
19	69	enhance	71.35348	78
19	59	enhance	71.22886	79
19	5	enhance	71.155815	80
19	4	enhance	70.9987	81
19	219	enhance	70.79484	82
19	171	enhance	70.789024	83
19	61	enhance	70.24669	84
19	28	enhance	69.75004	85
19	184	enhance	69.70654	86
19	14	enhance	69.27505	87
19	22	enhance	69.22284	88
19	60	enhance	68.728355	89
19	67	enhance	68.479485	90
19	87	enhance	68.24957	91
19	6	enhance	67.5774	92
19	30	enhance	66.95268	93
19	358	enhance	66.912605	94
19	230	enhance	66.878555	95
19	11	enhance	66.441956	96
19	20	enhance	66.290764	97
19	335	enhance	66.27906	98
19	23	enhance	66.069695	99
19	40	enhance	65.84268	100
19	32	enhance	65.48742	101
19	2	enhance	65.206375	102
19	96	enhance	64.85364	103
19	25	enhance	64.78093	104
19	91	enhance	63.72559	105
19	73	enhance	63.603397	106
19	46	enhance	63.079914	107
19	35	enhance	62.646088	108
19	79	enhance	62.494938	109
19	12	enhance	62.4637	110
19	29	enhance	62.326614	111
19	75	enhance	62.211456	112
19	33	enhance	61.97267	113
19	155	enhance	61.68456	114
19	95	enhance	61.66607	115
19	64	enhance	61.647907	116
19	882	enhance	61.56123	117
19	97	enhance	61.44173	118
19	21	enhance	61.03741	119
19	80	enhance	60.865055	120
19	74	enhance	60.33039	121
19	488	enhance	60.185013	122
19	85	enhance	59.989174	123
19	53	enhance	54.514755	124
19	64	soften	100	1
19	74	soften	96.25461	2
19	11	soften	95.95884	3
19	91	soften	94.40093	4
19	80	soften	93.30649	5
19	60	soften	91.89536	6
19	184	soften	89.79823	7
19	93	soften	89.69425	8
19	96	soften	88.81727	9
19	90	soften	88.6053	10
19	3	soften	88.23057	11
19	55	soften	87.90458	12
19	79	soften	87.81924	13
19	126	soften	87.09395	14
19	72	soften	86.85936	15
19	22	soften	86.70563	16
19	335	soften	86.40872	17
19	83	soften	85.840965	18
19	70	soften	85.647766	19
19	23	soften	85.268036	20
19	21	soften	85.11122	21
19	4	soften	84.93682	22
19	868	soften	84.441	23
19	45	soften	83.4815	24
19	44	soften	82.7506	25
19	78	soften	82.487045	26
19	219	soften	82.289375	27
19	59	soften	82.234955	28
19	9	soften	81.31076	29
19	2	soften	81.25069	30
19	171	soften	81.17704	31
19	85	soften	80.857315	32
19	20	soften	80.68328	33
19	30	soften	80.4721	34
19	5	soften	80.3847	35
19	13	soften	80.36551	36
19	12	soften	80.290794	37
19	49	soften	80.262825	38
19	99	soften	79.99771	39
19	18	soften	79.66112	40
19	43	soften	79.46015	41
19	73	soften	79.27097	42
19	39	soften	79.21174	43
19	94	soften	79.16733	44
19	34	soften	78.79365	45
19	33	soften	78.74151	46
19	35	soften	78.71031	47
19	82	soften	78.45386	48
19	41	soften	78.240974	49
19	593	soften	77.98105	50
19	63	soften	77.67768	51
19	95	soften	77.61196	52
19	28	soften	77.58111	53
19	182	soften	77.526375	54
19	66	soften	76.842514	55
19	69	soften	76.76808	56
19	61	soften	76.59298	57
19	640	soften	76.52098	58
19	222	soften	76.314644	59
19	230	soften	75.66624	60
19	50	soften	74.47991	61
19	27	soften	74.35938	62
19	285	soften	73.60545	63
19	86	soften	73.46725	64
19	92	soften	73.392265	65
19	176	soften	72.74745	66
19	31	soften	72.74661	67
19	8	soften	72.732025	68
19	7	soften	72.465004	69
19	51	soften	72.10069	70
19	54	soften	71.82351	71
19	56	soften	71.503006	72
19	187	soften	71.42095	73
19	98	soften	71.147964	74
19	455	soften	70.964165	75
19	47	soften	70.93097	76
19	10	soften	70.88412	77
19	84	soften	70.67169	78
19	89	soften	70.46206	79
19	58	soften	70.38136	80
19	52	soften	70.19042	81
19	24	soften	69.564445	82
19	67	soften	68.49029	83
19	1	soften	68.01256	84
20	95	enhance	100	1
20	219	enhance	99.65881	2
20	171	enhance	99.27924	3
20	35	enhance	98.1543	4
20	8	enhance	95.46721	5
20	488	enhance	95.25911	6
20	85	enhance	94.25604	7
20	21	enhance	93.18937	8
20	96	enhance	92.821014	9
20	5	enhance	92.572426	10
20	18	enhance	92.50582	11
20	12	enhance	92.12789	12
20	69	enhance	91.8531	13
20	14	enhance	90.56937	14
20	23	enhance	90.38574	15
20	78	enhance	89.932014	16
20	335	enhance	89.86464	17
20	74	enhance	89.85065	18
20	58	enhance	89.555305	19
20	41	enhance	89.489136	20
20	65	enhance	89.48163	21
20	9	enhance	89.32497	22
20	82	enhance	89.27128	23
20	59	enhance	88.75902	24
20	593	enhance	88.17447	25
20	4	enhance	84.84742	26
20	32	enhance	84.62681	27
20	184	enhance	83.682396	28
20	55	enhance	82.43867	29
20	79	enhance	81.09855	30
20	34	enhance	80.62814	31
20	868	enhance	80.49126	32
20	3	enhance	79.5513	33
20	64	enhance	79.2672	34
20	28	enhance	78.82651	35
20	455	enhance	78.420746	36
20	91	enhance	78.34719	37
20	11	enhance	77.77605	38
20	66	enhance	77.248856	39
20	54	enhance	77.21639	40
20	921	enhance	77.14725	41
20	22	enhance	77.03827	42
20	77	enhance	76.75999	43
20	100	enhance	74.7508	44
20	50	enhance	74.711395	45
20	93	enhance	74.12325	46
20	62	enhance	74.0068	47
20	60	enhance	73.53283	48
20	44	enhance	71.8184	49
20	2	enhance	71.57736	50
20	24	enhance	70.034836	51
20	83	enhance	68.940636	52
20	57	enhance	68.79073	53
20	53	enhance	68.50015	54
20	185	enhance	67.92452	55
20	63	enhance	67.76106	56
20	70	enhance	66.77473	57
20	80	enhance	66.56975	58
20	7	enhance	66.55456	59
20	27	enhance	66.39453	60
20	43	enhance	66.36442	61
20	81	enhance	65.59682	62
20	126	enhance	64.48775	63
20	52	enhance	63.83089	64
20	94	enhance	63.614132	65
20	90	enhance	63.52005	66
20	45	enhance	63.145588	67
20	26	enhance	62.838852	68
20	10	enhance	61.783398	69
20	99	enhance	61.526714	70
20	19	enhance	61.44254	71
20	73	enhance	61.104713	72
20	72	enhance	60.189312	73
20	39	enhance	59.808723	74
20	187	enhance	59.330364	75
20	42	enhance	59.113506	76
20	38	enhance	58.686184	77
20	89	enhance	56.878006	78
20	182	enhance	56.66727	79
20	901	enhance	53.326763	80
20	647	enhance	53.092537	81
20	49	enhance	52.647816	82
20	56	enhance	52.612274	83
20	785	enhance	51.475082	84
20	76	enhance	50.47758	85
20	30	enhance	50.19794	86
20	176	enhance	49.288155	87
20	6	enhance	49.0948	88
20	92	enhance	48.913277	89
20	16	enhance	47.967545	90
20	37	enhance	47.03873	91
20	29	enhance	46.86568	92
20	108	enhance	45.342026	93
20	86	enhance	43.191093	94
20	97	enhance	42.16041	95
20	358	enhance	40.334515	96
20	285	enhance	38.050995	97
20	15	enhance	37.599316	98
20	1	enhance	37.308823	99
20	230	enhance	36.762463	100
20	17	enhance	36.506615	101
20	13	enhance	36.483673	102
20	31	enhance	33.71943	103
20	61	enhance	32.894867	104
20	84	enhance	32.549335	105
20	71	enhance	32.10952	106
20	47	enhance	31.964756	107
20	36	enhance	29.327892	108
20	640	enhance	27.28741	109
20	98	enhance	27.04973	110
20	87	enhance	27.036457	111
20	48	enhance	26.526148	112
20	33	enhance	26.376633	113
20	222	enhance	25.607376	114
20	68	enhance	25.274267	115
20	88	enhance	22.393759	116
20	40	enhance	19.518946	117
20	25	enhance	16.110542	118
20	46	enhance	16.107002	119
20	155	enhance	14.543664	120
20	51	enhance	13.151754	121
20	882	enhance	13.05802	122
20	75	enhance	10.2064495	123
20	67	enhance	7.4702873	124
20	80	soften	100	1
20	72	soften	99.42517	2
20	126	soften	98.331635	3
20	90	soften	98.32184	4
20	64	soften	97.76862	5
20	13	soften	97.539246	6
20	11	soften	97.15967	7
20	83	soften	96.51068	8
20	70	soften	95.275215	9
20	60	soften	94.817856	10
20	45	soften	93.19334	11
20	93	soften	93.072136	12
20	3	soften	92.88763	13
20	55	soften	91.36369	14
20	91	soften	89.962906	15
20	79	soften	89.118256	16
20	184	soften	88.05637	17
20	74	soften	85.65409	18
20	868	soften	85.25071	19
20	44	soften	84.363266	20
20	22	soften	83.24608	21
20	78	soften	82.32839	22
20	4	soften	82.055786	23
20	23	soften	80.231316	24
20	96	soften	79.57414	25
20	335	soften	79.51729	26
20	59	soften	78.816826	27
20	171	soften	76.69888	28
20	219	soften	75.93115	29
20	21	soften	75.8826	30
20	9	soften	75.71257	31
21	85	enhance	100	1
21	12	enhance	99.27004	2
21	59	enhance	98.4075	3
21	5	enhance	97.46997	4
21	35	enhance	97.24605	5
21	69	enhance	96.97033	6
21	23	enhance	96.53486	7
21	335	enhance	95.355354	8
21	219	enhance	94.88102	9
21	9	enhance	94.58078	10
21	4	enhance	93.3638	11
21	74	enhance	93.349815	12
21	96	enhance	93.13952	13
21	593	enhance	92.70444	14
21	41	enhance	92.106064	15
21	91	enhance	91.98096	16
21	78	enhance	91.4299	17
21	66	enhance	90.89394	18
21	20	enhance	90.064674	19
21	184	enhance	89.27234	20
21	18	enhance	89.24889	21
21	22	enhance	88.45977	22
21	8	enhance	87.863464	23
21	79	enhance	87.48218	24
21	82	enhance	85.73519	25
21	93	enhance	85.55897	26
21	3	enhance	84.46472	27
21	171	enhance	84.286095	28
21	55	enhance	84.01813	29
21	44	enhance	83.68799	30
21	64	enhance	83.68574	31
21	60	enhance	82.696144	32
21	488	enhance	82.247055	33
21	11	enhance	81.04088	34
21	868	enhance	81.00569	35
21	54	enhance	79.49063	36
21	65	enhance	78.99056	37
21	28	enhance	78.14861	38
21	95	enhance	78.04892	39
21	27	enhance	77.93348	40
21	50	enhance	76.74801	41
21	32	enhance	76.519035	42
21	455	enhance	76.09197	43
21	58	enhance	75.4452	44
21	94	enhance	74.732704	45
21	14	enhance	74.37472	46
21	70	enhance	74.326866	47
21	77	enhance	74.05191	48
21	100	enhance	72.789825	49
21	83	enhance	72.69753	50
21	72	enhance	72.06773	51
21	90	enhance	71.689674	52
21	52	enhance	70.28743	53
21	10	enhance	70.27132	54
21	34	enhance	70.1563	55
21	53	enhance	67.84724	56
21	126	enhance	65.33431	57
21	39	enhance	65.29664	58
21	24	enhance	64.76905	59
21	182	enhance	63.569256	60
21	7	enhance	63.42958	61
21	99	enhance	63.107647	62
21	2	enhance	62.95191	63
21	80	enhance	62.851738	64
21	62	enhance	62.305145	65
21	921	enhance	61.188942	66
21	63	enhance	59.53965	67
21	49	enhance	57.127686	68
21	43	enhance	56.2126	69
21	185	enhance	56.177807	70
21	19	enhance	54.676453	71
21	176	enhance	53.150097	72
21	86	enhance	53.008945	73
21	92	enhance	52.55323	74
21	81	enhance	52.526474	75
21	42	enhance	52.484604	76
21	38	enhance	52.47228	77
21	57	enhance	51.774464	78
21	45	enhance	50.860424	79
21	73	enhance	49.800827	80
21	6	enhance	47.676514	81
21	76	enhance	47.42584	82
21	187	enhance	46.781773	83
21	785	enhance	46.7361	84
21	647	enhance	46.149906	85
21	29	enhance	45.748215	86
21	97	enhance	45.50872	87
21	108	enhance	45.072193	88
21	285	enhance	44.213993	89
21	16	enhance	43.802116	90
21	26	enhance	42.47915	91
21	13	enhance	42.24286	92
21	89	enhance	40.05681	93
21	358	enhance	39.879368	94
21	901	enhance	38.558903	95
21	37	enhance	37.52669	96
21	230	enhance	37.15283	97
21	17	enhance	36.430603	98
21	56	enhance	36.144707	99
21	30	enhance	35.85235	100
21	15	enhance	34.148705	101
21	222	enhance	34.132225	102
21	61	enhance	33.747086	103
21	98	enhance	33.58696	104
21	84	enhance	33.24742	105
21	640	enhance	33.14205	106
21	31	enhance	32.350777	107
21	71	enhance	31.997252	108
21	48	enhance	30.491571	109
21	1	enhance	29.474548	110
21	47	enhance	29.364326	111
21	68	enhance	29.35393	112
21	36	enhance	28.607172	113
21	88	enhance	28.124472	114
21	87	enhance	28.097128	115
21	33	enhance	26.389425	116
21	40	enhance	24.6114	117
21	51	enhance	21.004107	118
21	25	enhance	19.216997	119
21	46	enhance	19.128225	120
21	75	enhance	17.093086	121
21	155	enhance	16.657114	122
21	882	enhance	14.804341	123
21	67	enhance	12.940872	124
21	126	soften	100	1
21	90	soften	98.808556	2
21	11	soften	98.570816	3
21	3	soften	94.64341	4
21	55	soften	94.4524	5
21	93	soften	90.75065	6
21	91	soften	87.445816	7
21	79	soften	87.32133	8
21	184	soften	86.058525	9
21	868	soften	84.286514	10
21	4	soften	83.871506	11
21	22	soften	80.96292	12
21	23	soften	80.34949	13
21	96	soften	77.97243	14
21	72	soften	70.208534	15
21	80	soften	69.59623	16
21	83	soften	69.55542	17
21	64	soften	67.52734	18
21	60	soften	67.51362	19
21	70	soften	66.10585	20
21	45	soften	65.85655	21
21	74	soften	58.24794	22
21	335	soften	54.77306	23
22	44	enhance	100	1
22	184	enhance	99.15616	2
22	335	enhance	98.43541	3
22	91	enhance	97.476295	4
22	4	enhance	96.59163	5
22	41	enhance	96.10306	6
22	96	enhance	95.26161	7
22	9	enhance	95.0253	8
22	78	enhance	94.47765	9
22	59	enhance	94.33484	10
22	93	enhance	94.23525	11
22	23	enhance	92.44475	12
22	74	enhance	91.37718	13
22	219	enhance	91.33531	14
22	64	enhance	91.0788	15
22	55	enhance	90.12564	16
22	3	enhance	89.88632	17
22	21	enhance	89.65643	18
22	60	enhance	89.00249	19
22	868	enhance	88.81251	20
22	593	enhance	88.444016	21
22	11	enhance	88.27843	22
22	5	enhance	88.19228	23
22	69	enhance	88.00919	24
22	12	enhance	86.64002	25
22	66	enhance	85.71345	26
22	85	enhance	85.51067	27
22	35	enhance	80.765785	28
22	72	enhance	80.590706	29
22	10	enhance	78.85564	30
22	70	enhance	78.848946	31
22	94	enhance	78.51918	32
22	27	enhance	78.365616	33
22	39	enhance	76.80098	34
22	8	enhance	76.548386	35
22	58	enhance	76.13307	36
22	90	enhance	75.799126	37
22	83	enhance	75.62059	38
22	82	enhance	75.566216	39
22	20	enhance	75.46235	40
22	18	enhance	75.241325	41
22	50	enhance	73.57665	42
22	7	enhance	73.13112	43
22	171	enhance	71.524086	44
22	79	enhance	70.30041	45
22	52	enhance	69.32805	46
22	455	enhance	69.30128	47
22	77	enhance	67.031105	48
22	65	enhance	66.67742	49
22	100	enhance	66.48569	50
22	54	enhance	66.366165	51
22	99	enhance	66.027115	52
22	92	enhance	65.023125	53
22	126	enhance	63.63554	54
22	86	enhance	63.16246	55
22	19	enhance	62.847683	56
22	34	enhance	61.99934	57
22	182	enhance	61.320908	58
22	28	enhance	60.526413	59
22	95	enhance	59.70483	60
22	63	enhance	57.875248	61
22	80	enhance	56.09435	62
22	488	enhance	55.98838	63
22	14	enhance	55.862545	64
22	176	enhance	53.73625	65
22	62	enhance	53.7123	66
22	2	enhance	52.65256	67
22	49	enhance	52.317	68
22	43	enhance	52.170643	69
22	24	enhance	51.302307	70
22	32	enhance	50.70231	71
22	187	enhance	50.69994	72
22	285	enhance	49.420494	73
22	15	enhance	48.436928	74
22	108	enhance	48.03769	75
22	185	enhance	47.82874	76
22	38	enhance	47.255203	77
22	57	enhance	46.32928	78
22	13	enhance	46.15385	79
22	42	enhance	45.994038	80
22	921	enhance	45.80938	81
22	222	enhance	44.71974	82
22	53	enhance	44.21544	83
22	647	enhance	43.80622	84
22	76	enhance	43.787758	85
22	785	enhance	43.37982	86
22	81	enhance	43.32278	87
22	6	enhance	41.563942	88
22	26	enhance	41.246418	89
22	45	enhance	41.095856	90
22	89	enhance	40.947395	91
22	901	enhance	40.59643	92
22	16	enhance	40.144382	93
22	37	enhance	39.432705	94
22	640	enhance	39.047813	95
22	97	enhance	39.010464	96
22	68	enhance	38.35668	97
22	29	enhance	37.93668	98
22	48	enhance	37.931263	99
22	84	enhance	37.832405	100
22	17	enhance	37.134808	101
22	56	enhance	36.806477	102
22	358	enhance	36.529205	103
22	1	enhance	35.98876	104
22	36	enhance	33.758324	105
22	230	enhance	33.47161	106
22	71	enhance	33.12829	107
22	87	enhance	32.91817	108
22	73	enhance	32.653	109
22	51	enhance	32.45583	110
22	47	enhance	31.808834	111
22	61	enhance	31.630482	112
22	31	enhance	31.61564	113
22	30	enhance	30.406038	114
22	88	enhance	29.902378	115
22	40	enhance	28.893211	116
22	98	enhance	28.455866	117
22	46	enhance	27.691946	118
22	25	enhance	26.97358	119
22	882	enhance	25.97179	120
22	33	enhance	25.698133	121
22	75	enhance	25.66122	122
22	155	enhance	24.99731	123
22	67	enhance	23.215841	124
22	11	soften	100	1
22	126	soften	99.27831	2
22	90	soften	98.09656	3
22	55	soften	95.25285	4
22	3	soften	94.541084	5
22	93	soften	89.39187	6
22	91	soften	89.2372	7
22	79	soften	86.732994	8
22	4	soften	85.16157	9
22	184	soften	84.10315	10
22	96	soften	79.19738	11
22	80	soften	69.562035	12
22	83	soften	69.29466	13
22	72	soften	69.11184	14
22	60	soften	68.57901	15
22	64	soften	68.17447	16
22	70	soften	64.653	17
22	74	soften	60.536488	18
22	335	soften	54.778774	19
23	5	enhance	100	1
23	4	enhance	97.6958	2
23	21	enhance	97.321205	3
23	9	enhance	97.301094	4
23	59	enhance	96.8983	5
23	91	enhance	95.96903	6
23	12	enhance	95.655975	7
23	85	enhance	95.64589	8
23	335	enhance	95.51225	9
23	593	enhance	95.44366	10
23	219	enhance	94.813484	11
23	96	enhance	94.26501	12
23	93	enhance	94.13115	13
23	74	enhance	94.1069	14
23	69	enhance	93.83251	15
23	35	enhance	93.608734	16
23	41	enhance	93.60157	17
23	3	enhance	93.25769	18
23	82	enhance	92.19113	19
23	55	enhance	92.12851	20
23	22	enhance	91.953835	21
23	184	enhance	91.689926	22
23	78	enhance	91.10433	23
23	60	enhance	89.33816	24
23	8	enhance	88.515	25
23	64	enhance	88.50589	26
23	20	enhance	88.06661	27
23	44	enhance	88.029884	28
23	11	enhance	87.8156	29
23	66	enhance	86.701225	30
23	90	enhance	85.565384	31
23	79	enhance	84.37079	32
23	868	enhance	84.3003	33
23	18	enhance	83.86289	34
23	50	enhance	83.60592	35
23	70	enhance	83.51132	36
23	171	enhance	83.36525	37
23	72	enhance	81.667046	38
23	83	enhance	80.739876	39
23	99	enhance	78.624794	40
23	94	enhance	78.05345	41
23	34	enhance	77.5873	42
23	126	enhance	76.361115	43
23	58	enhance	75.067955	44
23	28	enhance	74.255196	45
23	488	enhance	74.182175	46
23	95	enhance	73.7722	47
23	2	enhance	73.53943	48
23	65	enhance	73.20914	49
23	182	enhance	72.914955	50
23	54	enhance	72.24251	51
23	27	enhance	71.48921	52
23	7	enhance	71.30754	53
23	39	enhance	70.097664	54
23	63	enhance	69.88269	55
23	14	enhance	69.344536	56
23	455	enhance	68.8672	57
23	80	enhance	68.76895	58
23	10	enhance	68.633575	59
23	32	enhance	67.80395	60
23	43	enhance	67.26518	61
23	77	enhance	65.92968	62
23	100	enhance	64.52667	63
23	52	enhance	63.519592	64
23	49	enhance	62.66508	65
23	19	enhance	59.666393	66
23	92	enhance	58.660168	67
23	187	enhance	55.251465	68
23	45	enhance	55.187004	69
23	13	enhance	54.809025	70
23	53	enhance	54.57548	71
23	24	enhance	53.97667	72
23	62	enhance	53.96658	73
23	921	enhance	53.96212	74
23	57	enhance	51.291172	75
23	176	enhance	51.254536	76
23	86	enhance	49.851387	77
23	185	enhance	49.118446	78
23	230	enhance	48.929756	79
23	640	enhance	46.572617	80
23	73	enhance	45.96867	81
23	108	enhance	45.958652	82
23	81	enhance	45.869255	83
23	285	enhance	43.912827	84
23	61	enhance	43.798016	85
23	38	enhance	43.61506	86
23	42	enhance	43.384796	87
23	89	enhance	42.49659	88
23	33	enhance	42.479675	89
23	222	enhance	42.368313	90
23	647	enhance	41.755985	91
23	785	enhance	39.999176	92
23	26	enhance	39.79219	93
23	31	enhance	39.658447	94
23	56	enhance	39.375774	95
23	901	enhance	39.357395	96
23	30	enhance	38.52648	97
23	76	enhance	38.280106	98
23	98	enhance	36.874367	99
23	16	enhance	36.1895	100
23	6	enhance	36.181797	101
23	15	enhance	35.461575	102
23	37	enhance	35.230457	103
23	29	enhance	34.916824	104
23	47	enhance	34.40551	105
23	97	enhance	32.7496	106
23	358	enhance	30.20588	107
23	17	enhance	29.568165	108
23	88	enhance	28.617695	109
23	84	enhance	28.530819	110
23	1	enhance	28.083467	111
23	71	enhance	27.554499	112
23	48	enhance	27.100681	113
23	68	enhance	27.081476	114
23	36	enhance	25.880238	115
23	51	enhance	25.016573	116
23	87	enhance	22.689674	117
23	40	enhance	20.49753	118
23	67	enhance	16.603996	119
23	25	enhance	16.149744	120
23	46	enhance	13.054062	121
23	75	enhance	12.316824	122
23	155	enhance	10.894034	123
23	882	enhance	9.425725	124
23	11	soften	100	1
23	72	soften	98.14838	2
23	60	soften	97.46286	3
23	83	soften	96.750175	4
23	80	soften	96.02472	5
23	126	soften	95.410645	6
23	90	soften	94.644035	7
23	55	soften	94.48314	8
23	3	soften	93.50477	9
23	70	soften	93.18994	10
23	93	soften	91.78507	11
23	91	soften	91.7279	12
23	184	soften	90.76578	13
23	868	soften	88.795494	14
23	79	soften	87.630356	15
23	22	soften	86.21297	16
23	4	soften	86.19531	17
23	335	soften	84.002625	18
23	96	soften	83.72741	19
23	64	soften	70.105835	20
23	74	soften	61.97011	21
24	455	enhance	100	1
24	62	enhance	99.04984	2
24	185	enhance	98.3357	3
24	38	enhance	98.0145	4
24	42	enhance	96.552086	5
24	785	enhance	96.405464	6
24	76	enhance	95.25943	7
24	52	enhance	95.116684	8
24	6	enhance	95.09921	9
24	100	enhance	94.35545	10
24	77	enhance	93.837715	11
24	97	enhance	93.115875	12
24	358	enhance	92.03148	13
24	647	enhance	91.40329	14
24	54	enhance	91.11563	15
24	16	enhance	90.7545	16
24	176	enhance	89.090096	17
24	87	enhance	88.83454	18
24	921	enhance	88.227005	19
24	53	enhance	88.20323	20
24	17	enhance	88.198166	21
24	29	enhance	88.024284	22
24	108	enhance	87.92074	23
24	71	enhance	87.76356	24
24	84	enhance	87.56873	25
24	32	enhance	86.48503	26
24	36	enhance	85.405426	27
24	27	enhance	85.295746	28
24	1	enhance	85.24403	29
24	81	enhance	85.07155	30
24	48	enhance	84.794716	31
24	86	enhance	84.753456	32
24	10	enhance	84.60653	33
24	14	enhance	84.32489	34
24	18	enhance	84.19528	35
24	37	enhance	83.489136	36
24	89	enhance	82.70831	37
24	65	enhance	82.438644	38
24	40	enhance	81.88107	39
24	25	enhance	81.54184	40
24	68	enhance	81.26826	41
24	28	enhance	81.215744	42
24	155	enhance	80.6001	43
24	58	enhance	79.46823	44
24	26	enhance	79.04594	45
24	66	enhance	78.82329	46
24	285	enhance	78.687614	47
24	593	enhance	78.64635	48
24	7	enhance	77.70869	49
24	488	enhance	77.336426	50
24	882	enhance	77.18385	51
24	75	enhance	76.84647	52
24	46	enhance	76.66861	53
24	15	enhance	75.99129	54
24	94	enhance	75.51658	55
24	92	enhance	75.10256	56
24	39	enhance	75.03346	57
24	78	enhance	74.110954	58
24	901	enhance	73.869354	59
24	88	enhance	72.66962	60
24	59	enhance	71.39175	61
24	31	enhance	71.32127	62
24	95	enhance	71.20864	63
24	8	enhance	71.15339	64
24	50	enhance	70.73589	65
24	20	enhance	70.613106	66
24	35	enhance	69.94983	67
24	56	enhance	69.63213	68
24	19	enhance	69.27615	69
24	219	enhance	69.25524	70
24	63	enhance	69.063286	71
24	98	enhance	68.99997	72
24	85	enhance	68.77444	73
24	12	enhance	68.49999	74
24	187	enhance	67.801186	75
24	21	enhance	67.569496	76
24	171	enhance	67.51208	77
24	79	enhance	66.55742	78
24	69	enhance	66.38606	79
24	868	enhance	66.22478	80
24	73	enhance	65.18127	81
24	34	enhance	64.66541	82
24	49	enhance	64.652565	83
24	335	enhance	63.42391	84
24	5	enhance	63.419422	85
24	82	enhance	62.988766	86
24	222	enhance	62.444477	87
24	57	enhance	60.880146	88
24	67	enhance	60.852028	89
24	96	enhance	60.246777	90
24	41	enhance	60.00993	91
24	44	enhance	59.86556	92
24	184	enhance	59.704514	93
24	47	enhance	58.98438	94
24	45	enhance	58.20405	95
24	182	enhance	57.987225	96
24	43	enhance	57.116917	97
24	51	enhance	56.895576	98
24	9	enhance	56.180008	99
24	23	enhance	55.855495	100
24	70	enhance	54.397984	101
24	30	enhance	53.961544	102
24	74	enhance	53.341377	103
24	22	enhance	52.80613	104
24	2	enhance	52.75505	105
24	61	enhance	52.28766	106
24	4	enhance	52.108604	107
24	93	enhance	50.27967	108
24	230	enhance	50.183403	109
24	13	enhance	49.857502	110
24	99	enhance	48.650265	111
24	55	enhance	47.765938	112
24	3	enhance	47.6143	113
24	640	enhance	47.153866	114
24	91	enhance	46.67735	115
24	83	enhance	46.01016	116
24	80	enhance	43.95043	117
24	72	enhance	43.84076	118
24	64	enhance	43.684177	119
24	126	enhance	42.809612	120
24	60	enhance	40.93398	121
24	11	enhance	40.795048	122
24	90	enhance	36.992023	123
24	33	enhance	33.64514	124
24	80	soften	100	1
24	11	soften	97.99045	2
24	64	soften	97.2837	3
24	90	soften	97.09025	4
24	126	soften	96.98457	5
24	60	soften	95.00339	6
24	83	soften	94.52028	7
24	72	soften	93.544075	8
24	3	soften	92.96601	9
24	55	soften	92.28627	10
24	74	soften	90.46988	11
24	91	soften	90.43526	12
24	33	soften	90.21734	13
24	45	soften	89.75212	14
24	70	soften	89.603386	15
24	93	soften	89.27937	16
24	79	soften	88.669586	17
24	30	soften	88.318665	18
24	13	soften	87.38565	19
24	43	soften	86.91316	20
24	99	soften	86.761536	21
24	34	soften	86.40427	22
24	2	soften	86.12263	23
24	49	soften	86.02016	24
24	182	soften	85.176895	25
24	73	soften	85.16816	26
24	23	soften	84.86107	27
24	4	soften	84.7084	28
24	61	soften	83.7688	29
24	184	soften	83.73789	30
24	640	soften	83.226616	31
24	230	soften	82.96168	32
24	82	soften	82.665565	33
24	171	soften	82.02651	34
24	96	soften	81.71388	35
24	63	soften	80.96035	36
24	5	soften	80.934235	37
24	9	soften	80.11641	38
24	22	soften	79.7199	39
24	868	soften	79.623474	40
24	21	soften	79.5061	41
24	335	soften	79.27124	42
24	20	soften	79.114494	43
24	94	soften	79.091644	44
24	78	soften	78.99379	45
24	50	soften	78.987724	46
24	219	soften	78.91872	47
24	28	soften	78.76258	48
24	222	soften	78.46102	49
24	18	soften	77.995224	50
24	187	soften	77.946976	51
24	59	soften	77.62559	52
24	39	soften	77.39632	53
24	44	soften	77.22352	54
24	593	soften	76.93947	55
24	56	soften	76.72289	56
24	35	soften	76.695	57
24	47	soften	76.55051	58
24	31	soften	76.3481	59
24	12	soften	76.26759	60
24	98	soften	76.183395	61
24	85	soften	75.95897	62
24	95	soften	75.78673	63
24	285	soften	74.55644	64
24	8	soften	74.525764	65
24	92	soften	74.46308	66
24	66	soften	74.38702	67
24	51	soften	74.240875	68
24	41	soften	74.13448	69
24	7	soften	73.38226	70
24	89	soften	72.61935	71
24	69	soften	72.55353	72
24	54	soften	71.58891	73
24	176	soften	70.73936	74
24	27	soften	70.03831	75
24	67	soften	69.31107	76
24	10	soften	68.3431	77
24	58	soften	67.600334	78
24	86	soften	67.29296	79
24	84	soften	66.8902	80
24	455	soften	66.71866	81
24	52	soften	65.240974	82
25	48	enhance	100	1
25	87	enhance	99.87348	2
25	40	enhance	99.52903	3
25	75	enhance	99.337456	4
25	155	enhance	98.37409	5
25	68	enhance	98.06089	6
25	36	enhance	97.97459	7
25	882	enhance	97.26656	8
25	71	enhance	96.48155	9
25	84	enhance	95.3113	10
25	46	enhance	93.99129	11
25	108	enhance	93.04046	12
25	1	enhance	92.968185	13
25	17	enhance	92.395546	14
25	358	enhance	90.107155	15
25	785	enhance	89.70012	16
25	88	enhance	88.209724	17
25	86	enhance	87.73169	18
25	97	enhance	87.26099	19
25	6	enhance	86.26617	20
25	76	enhance	86.22123	21
25	647	enhance	85.962875	22
25	16	enhance	85.22917	23
25	15	enhance	84.33493	24
25	285	enhance	84.32027	25
25	67	enhance	84.10427	26
25	176	enhance	84.09154	27
25	38	enhance	83.67714	28
25	31	enhance	82.24298	29
25	52	enhance	81.40458	30
25	42	enhance	81.19352	31
25	92	enhance	80.16972	32
25	37	enhance	79.99375	33
25	98	enhance	79.43352	34
25	29	enhance	79.21839	35
25	185	enhance	79.21362	36
25	24	enhance	79.03645	37
25	89	enhance	78.28714	38
25	222	enhance	78.19167	39
25	10	enhance	76.585045	40
25	51	enhance	74.963005	41
25	455	enhance	74.2452	42
25	62	enhance	73.76116	43
25	39	enhance	72.74258	44
25	7	enhance	71.961365	45
25	27	enhance	68.41436	46
25	901	enhance	67.08363	47
25	100	enhance	66.99868	48
25	56	enhance	64.96275	49
25	94	enhance	64.55169	50
25	77	enhance	64.485214	51
25	26	enhance	64.47987	52
25	47	enhance	64.245224	53
25	81	enhance	62.635815	54
25	54	enhance	62.33449	55
25	187	enhance	62.16521	56
25	640	enhance	61.546707	57
25	61	enhance	58.835728	58
25	19	enhance	58.678825	59
25	63	enhance	57.642437	60
25	49	enhance	57.025826	61
25	13	enhance	56.44955	62
25	921	enhance	56.273117	63
25	230	enhance	54.506893	64
25	53	enhance	54.213654	65
25	50	enhance	51.98338	66
25	28	enhance	50.676243	67
25	66	enhance	50.21516	68
25	182	enhance	49.271683	69
25	593	enhance	47.65783	70
25	33	enhance	44.00745	71
25	58	enhance	43.85593	72
25	44	enhance	42.593136	73
25	30	enhance	42.2048	74
25	18	enhance	42.200832	75
25	43	enhance	42.137096	76
25	868	enhance	41.81309	77
25	78	enhance	41.163525	78
25	99	enhance	40.372818	79
25	32	enhance	40.341507	80
25	65	enhance	39.86214	81
25	14	enhance	39.763046	82
25	73	enhance	38.70122	83
25	70	enhance	37.999214	84
25	34	enhance	36.84562	85
25	45	enhance	36.39996	86
25	59	enhance	32.505272	87
25	184	enhance	31.230236	88
25	57	enhance	31.228104	89
25	72	enhance	30.030605	90
25	93	enhance	28.652443	91
25	2	enhance	27.870274	92
25	8	enhance	27.02956	93
25	22	enhance	26.911192	94
25	79	enhance	26.436022	95
25	335	enhance	25.676119	96
25	82	enhance	24.96552	97
25	219	enhance	24.28287	98
25	126	enhance	23.680397	99
25	83	enhance	23.112658	100
25	90	enhance	21.497374	101
25	41	enhance	21.12746	102
25	5	enhance	20.943905	103
25	12	enhance	20.536295	104
25	488	enhance	20.16783	105
25	3	enhance	20.036184	106
25	21	enhance	19.431913	107
25	69	enhance	19.020283	108
25	171	enhance	18.977737	109
25	55	enhance	18.665596	110
25	85	enhance	18.231853	111
25	96	enhance	18.073174	112
25	35	enhance	17.222773	113
25	80	enhance	17.03687	114
25	4	enhance	16.930109	115
25	23	enhance	16.198412	116
25	9	enhance	15.757871	117
25	20	enhance	15.744481	118
25	60	enhance	15.19314	119
25	64	enhance	14.5956545	120
25	91	enhance	14.392518	121
25	95	enhance	14.285876	122
25	11	enhance	13.276927	123
25	74	enhance	9.194636	124
25	11	soften	100	1
25	64	soften	99.66352	2
25	74	soften	97.80876	3
25	60	soften	96.96042	4
25	80	soften	96.77455	5
25	91	soften	94.57987	6
25	55	soften	93.61943	7
25	90	soften	92.798935	8
25	126	soften	92.55411	9
25	3	soften	92.05082	10
25	83	soften	92.03368	11
25	23	soften	89.062805	12
25	72	soften	89.05213	13
25	4	soften	88.581345	14
25	96	soften	87.811646	15
25	79	soften	87.65761	16
25	171	soften	87.60737	17
25	93	soften	87.31795	18
25	20	soften	86.4632	19
25	21	soften	85.7725	20
25	9	soften	85.46358	21
25	70	soften	85.15884	22
25	45	soften	84.82172	23
25	2	soften	84.55028	24
25	82	soften	84.54078	25
25	5	soften	84.40276	26
25	35	soften	84.29426	27
25	95	soften	84.27749	28
25	184	soften	84.01743	29
25	219	soften	83.811424	30
25	34	soften	83.72171	31
25	335	soften	83.679016	32
25	85	soften	83.37198	33
25	12	soften	83.017204	34
25	43	soften	81.41085	35
25	22	soften	81.32333	36
25	99	soften	81.21991	37
25	59	soften	80.36678	38
25	868	soften	80.21294	39
25	33	soften	80.04078	40
25	30	soften	79.57126	41
25	41	soften	79.47797	42
25	69	soften	79.190735	43
25	73	soften	79.1868	44
25	182	soften	78.928116	45
25	78	soften	78.50356	46
25	13	soften	77.707054	47
25	18	soften	77.62295	48
25	8	soften	77.538055	49
25	49	soften	77.3544	50
25	593	soften	76.0293	51
25	63	soften	76.01863	52
25	28	soften	75.50089	53
25	50	soften	75.078064	54
25	44	soften	75.03465	55
25	488	soften	74.66388	56
25	230	soften	74.19317	57
25	61	soften	73.91471	58
25	94	soften	72.9084	59
25	640	soften	72.88298	60
25	66	soften	72.16164	61
25	187	soften	71.91279	62
25	39	soften	69.666245	63
25	58	soften	69.31806	64
25	56	soften	69.23937	65
25	14	soften	69.121216	66
25	47	soften	68.27055	67
25	7	soften	68.23889	68
25	222	soften	68.18646	69
25	54	soften	67.95466	70
25	92	soften	67.3351	71
25	19	soften	67.16834	72
25	31	soften	66.58427	73
25	65	soften	66.28446	74
25	89	soften	66.085754	75
25	98	soften	65.03934	76
25	176	soften	64.79941	77
25	285	soften	64.73204	78
25	27	soften	64.226166	79
25	26	soften	64.14922	80
25	455	soften	63.960915	81
25	51	soften	63.692154	82
25	10	soften	62.9768	83
25	901	soften	61.90592	84
25	24	soften	61.637306	85
25	62	soften	60.621655	86
25	108	soften	60.351685	87
25	647	soften	60.303226	88
25	185	soften	60.158733	89
25	52	soften	59.82941	90
25	88	soften	59.44828	91
25	1	soften	59.33451	92
25	67	soften	58.416233	93
25	86	soften	58.37726	94
25	785	soften	57.466213	95
25	84	soften	57.464233	96
25	6	soften	54.715523	97
25	36	soften	54.373367	98
25	87	soften	51.94951	99
25	40	soften	50.999584	100
26	185	enhance	100	1
26	921	enhance	99.967926	2
26	81	enhance	98.83144	3
26	901	enhance	98.42121	4
26	62	enhance	96.07241	5
26	89	enhance	96.069984	6
26	56	enhance	96.05088	7
26	647	enhance	93.98879	8
26	16	enhance	93.72293	9
26	37	enhance	92.39458	10
26	785	enhance	91.68086	11
26	42	enhance	90.52955	12
26	29	enhance	90.2805	13
26	6	enhance	89.96832	14
26	187	enhance	89.83433	15
26	76	enhance	89.15803	16
26	38	enhance	88.78375	17
26	17	enhance	88.73019	18
26	358	enhance	88.55193	19
26	455	enhance	87.86996	20
26	54	enhance	85.98585	21
26	1	enhance	84.289085	22
26	14	enhance	83.76579	23
26	100	enhance	82.40817	24
26	71	enhance	82.33383	25
26	24	enhance	82.23793	26
26	108	enhance	81.995544	27
26	97	enhance	81.73817	28
26	65	enhance	81.711624	29
26	77	enhance	81.565575	30
26	52	enhance	80.93763	31
26	7	enhance	80.87528	32
26	15	enhance	78.8352	33
26	46	enhance	78.55509	34
26	68	enhance	78.540535	35
26	10	enhance	78.512115	36
26	36	enhance	78.471756	37
26	58	enhance	77.94319	38
26	19	enhance	77.83608	39
26	48	enhance	77.26532	40
26	27	enhance	77.18638	41
26	18	enhance	77.07115	42
26	53	enhance	76.942535	43
26	84	enhance	76.62562	44
26	57	enhance	75.84968	45
26	87	enhance	75.75588	46
26	8	enhance	75.13682	47
26	882	enhance	74.86822	48
26	34	enhance	73.12953	49
26	30	enhance	72.88479	50
26	78	enhance	72.63044	51
26	50	enhance	71.8647	52
26	155	enhance	71.38729	53
26	40	enhance	71.11286	54
26	39	enhance	70.6522	55
26	73	enhance	70.64054	56
26	32	enhance	69.308174	57
26	28	enhance	69.29866	58
26	25	enhance	69.210175	59
26	95	enhance	68.64386	60
26	92	enhance	66.975655	61
26	88	enhance	66.6205	62
26	75	enhance	66.607635	63
26	43	enhance	66.53807	64
26	285	enhance	66.421776	65
26	86	enhance	65.997284	66
26	20	enhance	65.91619	67
26	488	enhance	65.803444	68
26	31	enhance	65.36667	69
26	593	enhance	65.27672	70
26	63	enhance	65.23716	71
26	171	enhance	64.864876	72
26	219	enhance	64.55683	73
26	176	enhance	63.8564	74
26	66	enhance	63.585743	75
26	47	enhance	59.66451	76
26	98	enhance	58.879585	77
26	45	enhance	57.869816	78
26	94	enhance	56.7883	79
26	35	enhance	56.232986	80
26	49	enhance	55.10373	81
26	82	enhance	55.034554	82
26	182	enhance	53.518494	83
26	184	enhance	53.411774	84
26	41	enhance	53.26005	85
26	59	enhance	51.70768	86
26	44	enhance	51.537987	87
26	335	enhance	50.566944	88
26	868	enhance	50.378662	89
26	5	enhance	50.105236	90
26	99	enhance	49.172234	91
26	69	enhance	49.12875	92
26	79	enhance	48.988518	93
26	61	enhance	48.53644	94
26	96	enhance	48.161366	95
26	12	enhance	47.9652	96
26	85	enhance	47.7491	97
26	230	enhance	47.727497	98
26	67	enhance	47.325302	99
26	2	enhance	47.233612	100
26	3	enhance	47.149487	101
26	222	enhance	46.93102	102
26	55	enhance	46.754837	103
26	21	enhance	46.105377	104
26	9	enhance	45.743263	105
26	4	enhance	44.98383	106
26	51	enhance	44.66668	107
26	83	enhance	44.44104	108
26	22	enhance	44.16989	109
26	23	enhance	42.840084	110
26	70	enhance	42.57034	111
26	640	enhance	42.55641	112
26	126	enhance	41.46	113
26	13	enhance	40.76507	114
26	80	enhance	40.042137	115
26	74	enhance	39.044487	116
26	93	enhance	38.30204	117
26	11	enhance	37.04056	118
26	64	enhance	36.77084	119
26	72	enhance	35.875652	120
26	33	enhance	35.11615	121
26	90	enhance	32.843563	122
26	60	enhance	31.973106	123
26	91	enhance	30.575834	124
26	64	soften	100	1
26	11	soften	97.41793	2
26	91	soften	96.758316	3
26	74	soften	96.68536	4
26	80	soften	95.548485	5
26	60	soften	95.404724	6
26	90	soften	91.880974	7
26	72	soften	91.802505	8
26	93	soften	90.751816	9
26	126	soften	90.70363	10
26	83	soften	90.211006	11
26	55	soften	89.49087	12
26	3	soften	89.020004	13
26	70	soften	88.85459	14
26	79	soften	87.99946	15
26	96	soften	87.080414	16
26	184	soften	86.7243	17
26	23	soften	85.143684	18
26	45	soften	84.61446	19
26	4	soften	84.59022	20
26	868	soften	84.56788	21
26	22	soften	84.36433	22
26	21	soften	84.331215	23
26	335	soften	83.96916	24
26	13	soften	83.74522	25
26	49	soften	81.96165	26
26	2	soften	81.770134	27
26	59	soften	81.46445	28
26	33	soften	81.329834	29
26	9	soften	81.30877	30
26	99	soften	80.496765	31
26	94	soften	80.46374	32
26	5	soften	80.33798	33
26	44	soften	80.05156	34
26	85	soften	79.874664	35
26	171	soften	79.76318	36
26	82	soften	79.66968	37
26	182	soften	79.66157	38
26	12	soften	79.64729	39
26	219	soften	79.123375	40
26	222	soften	79.100525	41
26	640	soften	78.799614	42
26	61	soften	78.59347	43
26	34	soften	78.52379	44
26	43	soften	78.49602	45
26	78	soften	78.29676	46
26	20	soften	78.28273	47
26	63	soften	77.26885	48
26	230	soften	77.00967	49
26	35	soften	77.00927	50
26	30	soften	76.96805	51
26	73	soften	76.64437	52
26	593	soften	76.37348	53
26	39	soften	76.35352	54
26	18	soften	76.150215	55
26	51	soften	75.781364	56
26	41	soften	75.689606	57
26	28	soften	75.300385	58
26	69	soften	75.26374	59
26	95	soften	75.15244	60
26	66	soften	74.714645	61
26	176	soften	74.633	62
26	285	soften	74.5354	63
26	92	soften	74.25282	64
26	50	soften	74.03355	65
26	47	soften	73.47509	66
26	31	soften	72.42248	67
26	98	soften	71.8684	68
26	86	soften	71.71022	69
26	67	soften	71.12066	70
26	27	soften	70.00187	71
26	7	soften	69.930756	72
26	8	soften	69.23651	73
26	187	soften	68.994965	74
26	10	soften	68.732834	75
26	84	soften	68.62349	76
26	54	soften	68.19237	77
26	88	soften	67.95324	78
26	56	soften	67.60271	79
26	58	soften	67.58131	80
26	24	soften	67.52904	81
26	455	soften	67.43297	82
26	89	soften	67.10784	83
26	488	soften	66.67588	84
26	19	soften	66.642746	85
26	108	soften	66.57016	86
26	1	soften	66.539986	87
26	52	soften	66.50822	88
26	647	soften	63.87336	89
27	10	enhance	100	1
27	52	enhance	99.98172	2
27	54	enhance	99.51481	3
27	66	enhance	99.42602	4
27	455	enhance	97.00462	5
27	78	enhance	93.61773	6
27	39	enhance	91.66419	7
27	18	enhance	91.3815	8
27	6	enhance	90.756615	9
27	100	enhance	90.66389	10
27	593	enhance	90.49206	11
27	97	enhance	90.31919	12
27	77	enhance	89.41962	13
27	86	enhance	88.87819	14
27	29	enhance	88.46145	15
27	94	enhance	88.34704	16
27	59	enhance	88.11076	17
27	44	enhance	86.968544	18
27	62	enhance	86.66183	19
27	647	enhance	86.477554	20
27	28	enhance	86.38428	21
27	76	enhance	86.37911	22
27	185	enhance	86.24808	23
27	358	enhance	86.24358	24
27	24	enhance	86.096214	25
27	17	enhance	85.801575	26
27	50	enhance	85.72721	27
27	785	enhance	85.513016	28
27	184	enhance	85.13884	29
27	53	enhance	84.71248	30
27	42	enhance	84.407394	31
27	16	enhance	84.39109	32
27	38	enhance	84.29891	33
27	108	enhance	84.11086	34
27	335	enhance	82.969406	35
27	68	enhance	82.17507	36
27	21	enhance	82.06612	37
27	7	enhance	81.916794	38
27	22	enhance	81.41975	39
27	48	enhance	81.38277	40
27	12	enhance	80.34065	41
27	219	enhance	80.17122	42
27	84	enhance	80.017586	43
27	85	enhance	79.76594	44
27	285	enhance	79.701256	45
27	79	enhance	79.566795	46
27	921	enhance	79.375786	47
27	92	enhance	79.27581	48
27	71	enhance	79.120804	49
27	5	enhance	78.579475	50
27	69	enhance	78.47284	51
27	65	enhance	78.425385	52
27	81	enhance	78.074745	53
27	176	enhance	77.9838	54
27	40	enhance	77.63723	55
27	36	enhance	77.13356	56
27	41	enhance	76.867256	57
27	46	enhance	76.66859	58
27	93	enhance	76.26375	59
27	87	enhance	76.13526	60
27	35	enhance	76.08782	61
27	8	enhance	75.97995	62
27	4	enhance	75.64226	63
27	868	enhance	75.52189	64
27	26	enhance	74.88671	65
27	37	enhance	74.6817	66
27	23	enhance	74.67188	67
27	9	enhance	74.32723	68
27	96	enhance	74.11818	69
27	88	enhance	73.89985	70
27	91	enhance	73.12897	71
27	75	enhance	72.9484	72
27	58	enhance	72.92659	73
27	182	enhance	72.4	74
27	49	enhance	72.101524	75
27	1	enhance	72.08178	76
27	89	enhance	71.87663	77
27	15	enhance	71.53799	78
27	882	enhance	71.375175	79
27	14	enhance	71.348145	80
27	32	enhance	71.33924	81
27	25	enhance	71.24544	82
27	3	enhance	71.23789	83
27	70	enhance	70.97067	84
27	19	enhance	70.569405	85
27	74	enhance	69.96593	86
27	155	enhance	69.420944	87
27	98	enhance	69.1399	88
27	64	enhance	68.97101	89
27	56	enhance	68.94399	90
27	55	enhance	68.47858	91
27	34	enhance	68.373405	92
27	82	enhance	68.09831	93
27	20	enhance	67.57099	94
27	63	enhance	67.33305	95
27	72	enhance	67.207756	96
27	187	enhance	66.947426	97
27	60	enhance	66.77856	98
27	901	enhance	66.77736	99
27	171	enhance	66.01673	100
27	31	enhance	65.32079	101
27	11	enhance	65.03078	102
27	488	enhance	64.297134	103
27	83	enhance	63.358643	104
27	99	enhance	63.14304	105
27	222	enhance	62.858467	106
27	73	enhance	61.635406	107
27	90	enhance	60.913414	108
27	43	enhance	60.35811	109
27	126	enhance	57.130993	110
27	13	enhance	56.900753	111
27	47	enhance	56.65588	112
27	95	enhance	55.79113	113
27	640	enhance	55.494144	114
27	30	enhance	55.04207	115
27	61	enhance	55.021805	116
27	230	enhance	54.468983	117
27	51	enhance	54.251663	118
27	57	enhance	53.789062	119
27	80	enhance	52.60832	120
27	67	enhance	52.539886	121
27	45	enhance	52.531788	122
27	2	enhance	52.296547	123
27	33	enhance	38.760044	124
27	11	soften	100	1
27	60	soften	98.49648	2
27	80	soften	96.38391	3
27	83	soften	95.85294	4
27	126	soften	95.06644	5
27	55	soften	94.77394	6
27	72	soften	94.60048	7
27	90	soften	94.431526	8
27	91	soften	93.21482	9
27	3	soften	92.58122	10
27	70	soften	88.87872	11
27	93	soften	88.01753	12
27	4	soften	87.38429	13
27	45	soften	87.30623	14
27	79	soften	85.97242	15
27	33	soften	85.631584	16
27	23	soften	85.589386	17
27	171	soften	85.32233	18
27	34	soften	85.31777	19
27	13	soften	84.91364	20
27	96	soften	84.21502	21
27	82	soften	83.87553	22
27	2	soften	83.62945	23
27	43	soften	83.597626	24
27	182	soften	83.58858	25
27	184	soften	83.36351	26
27	99	soften	83.23663	27
27	868	soften	83.03305	28
27	9	soften	82.70236	29
27	30	soften	82.626144	30
27	20	soften	81.966125	31
27	5	soften	81.80661	32
27	21	soften	81.69042	33
27	335	soften	81.46124	34
27	73	soften	80.87854	35
27	219	soften	80.84766	36
27	22	soften	80.483795	37
27	640	soften	79.94035	38
27	35	soften	79.92739	39
27	12	soften	79.7309	40
27	59	soften	79.62159	41
27	85	soften	78.83199	42
27	230	soften	78.681206	43
27	63	soften	78.55036	44
27	78	soften	78.08933	45
27	50	soften	77.25354	46
27	28	soften	77.04505	47
27	187	soften	76.88506	48
27	44	soften	76.61408	49
27	593	soften	76.50518	50
27	41	soften	76.47507	51
27	18	soften	76.44265	52
27	8	soften	75.796715	53
27	69	soften	74.881454	54
27	66	soften	73.92093	55
27	285	soften	73.88336	56
27	39	soften	73.80292	57
27	176	soften	73.218605	58
27	64	soften	68.75478	59
27	74	soften	65.06348	60
27	49	soften	58.04213	61
27	61	soften	56.113483	62
27	95	soften	55.790176	63
27	222	soften	55.062046	64
27	94	soften	54.74401	65
27	51	soften	53.43405	66
27	92	soften	52.57813	67
28	54	enhance	100	1
28	18	enhance	96.189514	2
28	593	enhance	94.06853	3
28	66	enhance	93.5524	4
28	455	enhance	92.05387	5
28	171	enhance	91.802536	6
28	79	enhance	91.585365	7
28	50	enhance	91.20715	8
28	27	enhance	90.50096	9
28	53	enhance	90.04245	10
28	35	enhance	89.14988	11
28	52	enhance	88.5396	12
28	32	enhance	88.02701	13
28	5	enhance	87.88271	14
28	85	enhance	86.75273	15
28	8	enhance	86.51049	16
28	21	enhance	86.214355	17
28	12	enhance	86.1408	18
28	921	enhance	86.00558	19
28	24	enhance	85.884636	20
28	59	enhance	85.757416	21
28	100	enhance	85.24704	22
28	77	enhance	85.17975	23
28	219	enhance	85.02	24
28	78	enhance	84.8903	25
28	62	enhance	84.6939	26
28	20	enhance	84.04632	27
28	34	enhance	83.92536	28
28	65	enhance	83.884705	29
28	185	enhance	83.782875	30
28	94	enhance	83.48235	31
28	69	enhance	83.34481	32
28	14	enhance	83.10196	33
28	82	enhance	82.99403	34
28	488	enhance	82.41971	35
28	63	enhance	81.91293	36
28	868	enhance	81.85508	37
28	10	enhance	81.30687	38
28	23	enhance	81.25722	39
28	182	enhance	80.477745	40
28	49	enhance	80.414185	41
28	647	enhance	79.2099	42
28	6	enhance	79.12155	43
28	39	enhance	78.511475	44
28	81	enhance	78.25314	45
28	108	enhance	78.25141	46
28	42	enhance	78.20183	47
28	29	enhance	78.18989	48
28	335	enhance	78.01684	49
28	7	enhance	77.82509	50
28	64	enhance	77.65729	51
28	184	enhance	77.55144	52
28	11	enhance	77.3749	53
28	97	enhance	77.06751	54
28	38	enhance	76.99889	55
28	785	enhance	76.93646	56
28	55	enhance	76.925995	57
28	76	enhance	76.24161	58
28	60	enhance	76.157936	59
28	16	enhance	75.99958	60
28	43	enhance	75.77946	61
28	9	enhance	75.74102	62
28	73	enhance	75.288925	63
28	98	enhance	73.98511	64
28	99	enhance	73.96694	65
28	4	enhance	73.83665	66
28	358	enhance	73.35745	67
28	58	enhance	73.12641	68
28	70	enhance	72.9823	69
28	92	enhance	72.95607	70
28	3	enhance	72.85453	71
28	41	enhance	72.66964	72
28	89	enhance	72.45017	73
28	93	enhance	72.29632	74
28	2	enhance	72.20417	75
28	176	enhance	72.18239	76
28	187	enhance	71.42121	77
28	17	enhance	71.2592	78
28	31	enhance	71.12652	79
28	74	enhance	70.831276	80
28	95	enhance	70.60081	81
28	26	enhance	70.438065	82
28	86	enhance	70.08592	83
28	44	enhance	70.03888	84
28	285	enhance	69.94779	85
28	96	enhance	69.335266	86
28	126	enhance	69.208244	87
28	56	enhance	69.11005	88
28	37	enhance	69.004425	89
28	19	enhance	68.9298	90
28	90	enhance	68.736206	91
28	71	enhance	68.486305	92
28	91	enhance	68.35731	93
28	45	enhance	67.94729	94
28	230	enhance	67.26247	95
28	83	enhance	67.249886	96
28	88	enhance	66.87609	97
28	22	enhance	65.882126	98
28	80	enhance	65.531876	99
28	72	enhance	65.29637	100
28	84	enhance	65.00342	101
28	901	enhance	64.83546	102
28	61	enhance	64.46228	103
28	48	enhance	64.355385	104
28	36	enhance	64.128105	105
28	13	enhance	63.387463	106
28	68	enhance	63.309124	107
28	40	enhance	63.150566	108
28	30	enhance	62.871166	109
28	57	enhance	62.0921	110
28	1	enhance	61.176517	111
28	87	enhance	60.717907	112
28	640	enhance	59.27519	113
28	15	enhance	57.71833	114
28	222	enhance	56.825947	115
28	47	enhance	55.846733	116
28	25	enhance	55.28823	117
28	33	enhance	54.27168	118
28	46	enhance	53.77149	119
28	75	enhance	52.220238	120
28	155	enhance	49.98044	121
28	882	enhance	48.23178	122
28	51	enhance	42.477642	123
28	67	enhance	41.589134	124
28	11	soften	100	1
28	60	soften	97.97628	2
28	91	soften	95.1973	3
28	80	soften	94.07309	4
28	72	soften	94.052025	5
28	55	soften	93.72048	6
28	83	soften	93.58747	7
28	126	soften	91.8637	8
28	90	soften	91.83374	9
28	3	soften	91.5743	10
28	93	soften	90.28692	11
28	70	soften	89.56659	12
28	184	soften	89.23648	13
28	96	soften	87.81806	14
28	4	soften	87.69588	15
28	868	soften	87.431015	16
28	79	soften	86.871544	17
28	45	soften	86.50514	18
28	22	soften	86.248245	19
28	335	soften	86.159874	20
28	13	soften	85.49943	21
28	23	soften	85.37891	22
28	171	soften	84.695694	23
28	21	soften	84.06313	24
28	34	soften	83.32102	25
28	33	soften	83.25324	26
28	59	soften	83.227104	27
28	30	soften	83.11207	28
28	219	soften	83.083786	29
28	182	soften	83.021805	30
28	9	soften	82.849014	31
28	78	soften	82.77341	32
28	44	soften	82.70717	33
28	99	soften	82.27825	34
28	82	soften	82.094894	35
28	43	soften	82.04138	36
28	2	soften	81.9562	37
28	20	soften	81.815834	38
28	5	soften	81.467	39
28	73	soften	81.24729	40
28	12	soften	81.068306	41
28	85	soften	80.284744	42
28	35	soften	79.83531	43
28	39	soften	79.64251	44
28	18	soften	79.594246	45
28	41	soften	78.67333	46
28	64	soften	70.51191	47
28	74	soften	66.178635	48
28	49	soften	58.673748	49
28	222	soften	58.124706	50
28	94	soften	57.516205	51
28	95	soften	55.505157	52
29	358	enhance	100	1
29	6	enhance	99.36643	2
29	16	enhance	98.73309	3
29	97	enhance	98.355736	4
29	76	enhance	97.66775	5
29	17	enhance	97.28895	6
29	42	enhance	96.96234	7
29	785	enhance	95.88479	8
29	38	enhance	95.41649	9
29	185	enhance	94.69256	10
29	81	enhance	93.0184	11
29	53	enhance	92.82413	12
29	62	enhance	91.477394	13
29	71	enhance	90.123245	14
29	647	enhance	90.01241	15
29	921	enhance	89.96173	16
29	52	enhance	89.80411	17
29	54	enhance	89.45124	18
29	100	enhance	89.0094	19
29	455	enhance	88.91457	20
29	77	enhance	87.351006	21
29	37	enhance	87.1217	22
29	46	enhance	87.05035	23
29	48	enhance	86.84239	24
29	24	enhance	86.16769	25
29	27	enhance	85.790504	26
29	68	enhance	85.09762	27
29	87	enhance	85.06456	28
29	26	enhance	84.946045	29
29	882	enhance	83.01815	30
29	40	enhance	82.81664	31
29	108	enhance	81.24301	32
29	155	enhance	80.9078	33
29	10	enhance	80.29581	34
29	25	enhance	80.00571	35
29	75	enhance	79.80027	36
29	901	enhance	79.41158	37
29	36	enhance	78.880356	38
29	84	enhance	78.34122	39
29	65	enhance	76.340904	40
29	32	enhance	74.34013	41
29	14	enhance	74.317924	42
29	1	enhance	73.75426	43
29	66	enhance	73.4961	44
29	15	enhance	73.43299	45
29	89	enhance	72.60156	46
29	28	enhance	72.379776	47
29	86	enhance	70.98912	48
29	88	enhance	70.298355	49
29	18	enhance	68.64322	50
29	7	enhance	65.901566	51
29	56	enhance	65.799835	52
29	176	enhance	65.23798	53
29	39	enhance	65.20176	54
29	285	enhance	64.77489	55
29	98	enhance	64.01962	56
29	593	enhance	62.037918	57
29	78	enhance	61.61175	58
29	50	enhance	61.443058	59
29	187	enhance	60.8535	60
29	8	enhance	60.703297	61
29	31	enhance	60.593323	62
29	92	enhance	60.276764	63
29	488	enhance	59.85758	64
29	57	enhance	59.802814	65
29	58	enhance	57.468147	66
29	19	enhance	57.01678	67
29	94	enhance	55.163467	68
29	59	enhance	53.82417	69
29	35	enhance	51.995457	70
29	12	enhance	50.948296	71
29	219	enhance	50.642593	72
29	85	enhance	49.736904	73
29	69	enhance	48.19061	74
29	67	enhance	48.13296	75
29	73	enhance	47.93566	76
29	44	enhance	47.744503	77
29	63	enhance	47.37532	78
29	182	enhance	46.77093	79
29	21	enhance	46.719604	80
29	335	enhance	46.446835	81
29	20	enhance	46.255997	82
29	171	enhance	46.169186	83
29	49	enhance	45.5616	84
29	222	enhance	45.12104	85
29	34	enhance	45.05682	86
29	5	enhance	44.816475	87
29	95	enhance	44.73912	88
29	41	enhance	44.219276	89
29	79	enhance	44.124855	90
29	184	enhance	43.65583	91
29	51	enhance	43.64295	92
29	868	enhance	43.068665	93
29	30	enhance	41.664257	94
29	47	enhance	41.639225	95
29	82	enhance	41.152767	96
29	43	enhance	38.318363	97
29	22	enhance	38.225105	98
29	61	enhance	37.735424	99
29	230	enhance	37.723125	100
29	9	enhance	35.67772	101
29	4	enhance	35.381996	102
29	23	enhance	35.370113	103
29	640	enhance	35.24768	104
29	96	enhance	35.11568	105
29	99	enhance	32.540062	106
29	13	enhance	30.592133	107
29	2	enhance	29.493744	108
29	45	enhance	29.452854	109
29	70	enhance	28.51476	110
29	93	enhance	28.347189	111
29	55	enhance	27.24089	112
29	3	enhance	25.758554	113
29	74	enhance	24.120787	114
29	91	enhance	24.067907	115
29	60	enhance	23.702274	116
29	64	enhance	23.61254	117
29	33	enhance	23.463917	118
29	72	enhance	22.70085	119
29	83	enhance	22.08273	120
29	11	enhance	21.254206	121
29	126	enhance	18.440842	122
29	90	enhance	16.755331	123
29	80	enhance	14.348535	124
29	11	soften	100	1
29	80	soften	99.64504	2
29	64	soften	99.514244	3
29	60	soften	98.740875	4
29	90	soften	96.66444	5
29	74	soften	96.58397	6
29	126	soften	96.50116	7
29	91	soften	96.36822	8
29	83	soften	95.73509	9
29	72	soften	95.28042	10
29	55	soften	93.926895	11
29	3	soften	92.82612	12
29	70	soften	90.620415	13
29	93	soften	90.48922	14
29	79	soften	88.94134	15
29	45	soften	88.03345	16
29	23	soften	87.6838	17
29	4	soften	87.22028	18
29	33	soften	86.666145	19
29	96	soften	86.12335	20
29	2	soften	86.031555	21
29	13	soften	85.99457	22
29	82	soften	84.66715	23
29	21	soften	84.1979	24
29	34	soften	84.17195	25
29	99	soften	84.11117	26
29	171	soften	84.00812	27
29	9	soften	83.88046	28
29	184	soften	83.71954	29
29	49	soften	83.616776	30
29	182	soften	83.56481	31
29	5	soften	83.18867	32
29	43	soften	83.03573	33
29	868	soften	82.96328	34
29	335	soften	82.2314	35
29	20	soften	81.70618	36
29	22	soften	81.45024	37
29	61	soften	81.12788	38
29	12	soften	81.05616	39
29	85	soften	80.83006	40
29	640	soften	80.824554	41
29	59	soften	80.70135	42
29	30	soften	80.355385	43
29	219	soften	80.24153	44
29	35	soften	80.169106	45
29	230	soften	80.04766	46
29	73	soften	79.71641	47
29	95	soften	79.22686	48
29	63	soften	79.04358	49
29	94	soften	78.969	50
29	222	soften	78.3013	51
29	78	soften	77.031876	52
29	50	soften	76.900925	53
29	593	soften	76.81634	54
29	44	soften	76.7673	55
29	41	soften	76.66324	56
29	69	soften	76.61619	57
29	18	soften	76.20103	58
29	28	soften	76.20016	59
29	47	soften	75.58624	60
29	51	soften	74.898895	61
29	8	soften	73.81567	62
29	92	soften	73.72237	63
29	66	soften	73.43864	64
29	39	soften	73.40892	65
29	187	soften	73.15902	66
29	31	soften	72.976654	67
29	176	soften	72.674675	68
29	285	soften	72.60718	69
29	98	soften	72.48801	70
29	7	soften	70.481224	71
29	488	soften	70.44124	72
29	56	soften	70.12521	73
29	19	soften	69.6491	74
29	67	soften	69.35179	75
29	58	soften	68.412796	76
29	54	soften	68.06852	77
29	89	soften	67.86029	78
29	88	soften	66.86281	79
29	10	soften	66.44098	80
29	14	soften	66.1893	81
29	27	soften	66.149925	82
29	86	soften	65.712654	83
29	455	soften	65.22595	84
29	24	soften	64.93476	85
29	108	soften	64.76711	86
29	1	soften	64.68825	87
29	84	soften	64.26695	88
29	65	soften	62.92878	89
29	32	soften	62.763046	90
29	52	soften	62.662	91
29	647	soften	62.599113	92
29	26	soften	62.06824	93
29	901	soften	61.055233	94
29	921	soften	61.035564	95
29	62	soften	60.84362	96
29	185	soften	60.73041	97
29	36	soften	60.540672	98
29	77	soften	60.215958	99
29	785	soften	60.208073	100
29	100	soften	59.799427	101
29	71	soften	58.692772	102
29	87	soften	58.26054	103
29	53	soften	57.99577	104
29	40	soften	57.964188	105
29	15	soften	57.936195	106
29	68	soften	57.732025	107
29	17	soften	57.619377	108
29	25	soften	57.41359	109
29	48	soften	56.967064	110
29	6	soften	56.77995	111
29	38	soften	55.96958	112
29	76	soften	55.219288	113
29	155	soften	55.21158	114
29	97	soften	55.036385	115
29	358	soften	54.755375	116
29	882	soften	54.334084	117
29	46	soften	54.313297	118
30	73	enhance	100	1
30	45	enhance	96.94907	2
30	56	enhance	95.60803	3
30	43	enhance	92.007645	4
30	80	enhance	88.58439	5
30	34	enhance	86.33775	6
30	89	enhance	85.70709	7
30	49	enhance	85.46223	8
30	63	enhance	79.983635	9
30	61	enhance	79.64534	10
30	126	enhance	77.8361	11
30	230	enhance	76.17613	12
30	31	enhance	74.60802	13
30	47	enhance	74.098404	14
30	187	enhance	74.092766	15
30	18	enhance	73.106865	16
30	79	enhance	72.63287	17
30	647	enhance	72.21839	18
30	2	enhance	71.88597	19
30	39	enhance	71.637474	20
30	13	enhance	70.96538	21
30	26	enhance	69.82682	22
30	98	enhance	68.585365	23
30	33	enhance	68.37042	24
30	99	enhance	67.912125	25
30	1	enhance	67.766975	26
30	108	enhance	67.69199	27
30	285	enhance	67.436104	28
30	88	enhance	67.40551	29
30	640	enhance	66.201904	30
30	70	enhance	65.92842	31
30	50	enhance	64.926994	32
30	83	enhance	63.156635	33
30	36	enhance	63.11415	34
30	94	enhance	62.57708	35
30	182	enhance	62.475445	36
30	19	enhance	62.363907	37
30	90	enhance	61.55121	38
30	84	enhance	61.489677	39
30	54	enhance	61.23248	40
30	7	enhance	60.623363	41
30	3	enhance	60.427246	42
30	28	enhance	59.258995	43
30	62	enhance	58.95687	44
30	185	enhance	58.55171	45
30	78	enhance	57.40865	46
30	455	enhance	57.253494	47
30	921	enhance	57.178192	48
30	58	enhance	56.4837	49
30	86	enhance	55.18409	50
30	40	enhance	54.779293	51
30	6	enhance	54.510876	52
30	27	enhance	54.352062	53
30	24	enhance	53.785152	54
30	92	enhance	52.98406	55
30	72	enhance	52.660397	56
30	222	enhance	52.2917	57
30	95	enhance	51.972656	58
30	593	enhance	51.807163	59
30	176	enhance	51.259373	60
30	93	enhance	51.197376	61
30	82	enhance	51.153816	62
30	74	enhance	50.512264	63
30	20	enhance	50.446976	64
30	68	enhance	50.23321	65
30	37	enhance	50.143124	66
30	52	enhance	49.976192	67
30	10	enhance	48.857327	68
30	97	enhance	48.846615	69
30	901	enhance	48.472122	70
30	171	enhance	48.061947	71
30	17	enhance	47.13008	72
30	71	enhance	46.554302	73
30	48	enhance	46.535454	74
30	785	enhance	46.057507	75
30	15	enhance	45.59961	76
30	184	enhance	45.56394	77
30	55	enhance	45.506683	78
30	81	enhance	44.54393	79
30	219	enhance	44.257877	80
30	25	enhance	43.40032	81
30	16	enhance	43.336884	82
30	8	enhance	43.295338	83
30	29	enhance	42.422844	84
30	76	enhance	41.97829	85
30	67	enhance	41.898163	86
30	358	enhance	41.825718	87
30	96	enhance	41.75782	88
30	64	enhance	41.694546	89
30	14	enhance	41.255547	90
30	42	enhance	41.131706	91
30	87	enhance	41.070713	92
30	46	enhance	40.71776	93
30	38	enhance	40.715	94
30	66	enhance	40.672344	95
30	57	enhance	40.64942	96
30	5	enhance	40.608612	97
30	75	enhance	40.269184	98
30	11	enhance	39.961517	99
30	23	enhance	39.737194	100
30	100	enhance	39.487743	101
30	77	enhance	38.96072	102
30	44	enhance	38.639027	103
30	488	enhance	38.457848	104
30	51	enhance	37.87157	105
30	882	enhance	37.684338	106
30	65	enhance	37.60323	107
30	21	enhance	37.280247	108
30	9	enhance	36.719227	109
30	155	enhance	35.08015	110
30	53	enhance	35.04316	111
30	868	enhance	34.97859	112
30	35	enhance	34.483345	113
30	59	enhance	34.342068	114
30	32	enhance	34.077045	115
30	69	enhance	33.900772	116
30	91	enhance	33.870144	117
30	85	enhance	32.097485	118
30	335	enhance	31.696241	119
30	4	enhance	31.572206	120
30	22	enhance	31.195023	121
30	41	enhance	30.576464	122
30	60	enhance	29.309452	123
30	12	enhance	27.860636	124
30	11	soften	100	1
30	91	soften	98.83507	2
30	60	soften	98.56406	3
30	96	soften	92.22232	4
30	55	soften	92.09115	5
30	184	soften	90.831924	6
30	335	soften	90.537605	7
30	868	soften	90.52359	8
30	22	soften	89.10799	9
30	72	soften	89.05347	10
30	4	soften	88.906654	11
30	83	soften	88.37046	12
30	21	soften	88.19599	13
30	93	soften	87.754074	14
30	3	soften	86.94282	15
30	171	soften	85.998024	16
30	59	soften	85.98924	17
30	219	soften	85.447685	18
30	23	soften	85.405014	19
30	12	soften	85.20686	20
30	80	soften	84.9754	21
30	9	soften	84.795876	22
30	70	soften	84.556854	23
30	20	soften	84.21389	24
30	90	soften	83.154785	25
30	44	soften	83.00126	26
30	79	soften	82.83078	27
30	126	soften	82.70787	28
30	78	soften	82.307014	29
30	5	soften	81.27567	30
30	45	soften	78.63541	31
30	13	soften	76.02062	32
30	64	soften	71.61174	33
30	74	soften	69.272125	34
30	49	soften	52.59787	35
31	98	enhance	100	1
31	61	enhance	97.7689	2
31	230	enhance	96.6061	3
31	640	enhance	96.26922	4
31	88	enhance	96.20744	5
31	108	enhance	95.09603	6
31	13	enhance	93.5764	7
31	222	enhance	92.341736	8
31	63	enhance	92.02663	9
31	49	enhance	91.87871	10
31	33	enhance	91.02253	11
31	36	enhance	90.83971	12
31	89	enhance	89.15647	13
31	40	enhance	89.02212	14
31	285	enhance	88.862495	15
31	1	enhance	87.312195	16
31	84	enhance	87.17339	17
31	47	enhance	86.567955	18
31	43	enhance	85.74541	19
31	92	enhance	85.68065	20
31	68	enhance	85.58962	21
31	647	enhance	85.45207	22
31	25	enhance	85.33692	23
31	39	enhance	84.86161	24
31	56	enhance	84.82376	25
31	67	enhance	84.56942	26
31	48	enhance	84.1782	27
31	176	enhance	83.99861	28
31	182	enhance	83.26511	29
31	71	enhance	82.73393	30
31	99	enhance	81.90204	31
31	7	enhance	81.50159	32
31	187	enhance	80.98283	33
31	87	enhance	80.76302	34
31	94	enhance	80.43188	35
31	75	enhance	80.302025	36
31	50	enhance	79.95486	37
31	86	enhance	78.594864	38
31	34	enhance	76.75052	39
31	51	enhance	76.61404	40
31	45	enhance	76.526344	41
31	17	enhance	76.44743	42
31	785	enhance	75.927986	43
31	30	enhance	75.28225	44
31	2	enhance	74.8741	45
31	155	enhance	74.27858	46
31	15	enhance	74.033035	47
31	37	enhance	73.47054	48
31	46	enhance	72.87209	49
31	882	enhance	72.84164	50
31	185	enhance	72.2318	51
31	24	enhance	71.73055	52
31	10	enhance	71.60491	53
31	52	enhance	70.99571	54
31	70	enhance	70.74457	55
31	19	enhance	70.657104	56
31	6	enhance	70.62662	57
31	358	enhance	70.277794	58
31	126	enhance	69.840126	59
31	455	enhance	69.779175	60
31	97	enhance	69.25726	61
31	76	enhance	69.12846	62
31	73	enhance	68.8263	63
31	54	enhance	67.74977	64
31	28	enhance	67.64589	65
31	16	enhance	67.377884	66
31	62	enhance	67.30453	67
31	38	enhance	66.536156	68
31	27	enhance	65.08483	69
31	593	enhance	65.04368	70
31	42	enhance	64.71347	71
31	90	enhance	64.40426	72
31	26	enhance	63.190067	73
31	29	enhance	62.254105	74
31	80	enhance	62.011044	75
31	901	enhance	60.52364	76
31	18	enhance	59.682312	77
31	72	enhance	58.501198	78
31	100	enhance	57.719536	79
31	82	enhance	57.70681	80
31	79	enhance	57.13573	81
31	921	enhance	56.867195	82
31	77	enhance	56.247078	83
31	83	enhance	55.33583	84
31	81	enhance	55.120827	85
31	66	enhance	54.73916	86
31	93	enhance	54.070435	87
31	58	enhance	51.1355	88
31	78	enhance	50.421688	89
31	3	enhance	50.260445	90
31	53	enhance	48.390076	91
31	868	enhance	47.56124	92
31	44	enhance	47.294086	93
31	14	enhance	46.045063	94
31	32	enhance	45.82084	95
31	5	enhance	43.743084	96
31	8	enhance	42.33291	97
31	55	enhance	42.161995	98
31	59	enhance	42.07949	99
31	23	enhance	41.274387	100
31	65	enhance	41.034683	101
31	184	enhance	40.623318	102
31	57	enhance	38.465942	103
31	171	enhance	37.005554	104
31	219	enhance	36.25562	105
31	20	enhance	34.192947	106
31	21	enhance	33.943207	107
31	60	enhance	33.33119	108
31	11	enhance	33.293266	109
31	9	enhance	32.79635	110
31	22	enhance	32.729137	111
31	335	enhance	32.624855	112
31	488	enhance	32.27972	113
31	64	enhance	32.20175	114
31	96	enhance	31.844526	115
31	4	enhance	31.72799	116
31	12	enhance	31.72245	117
31	91	enhance	31.360682	118
31	35	enhance	31.173855	119
31	69	enhance	31.112759	120
31	85	enhance	31.087923	121
31	95	enhance	30.992468	122
31	74	enhance	30.777868	123
31	41	enhance	29.262003	124
31	64	soften	100	1
31	11	soften	97.79345	2
31	74	soften	97.31694	3
31	91	soften	94.8373	4
31	60	soften	94.63064	5
31	55	soften	90.4017	6
31	96	soften	90.350204	7
31	184	soften	88.51625	8
31	335	soften	88.01615	9
31	4	soften	87.70108	10
31	3	soften	87.01689	11
31	21	soften	86.83931	12
31	80	soften	86.72739	13
31	171	soften	86.3428	14
31	83	soften	86.18348	15
31	22	soften	86.15323	16
31	23	soften	85.615715	17
31	93	soften	85.603714	18
31	20	soften	85.48902	19
31	219	soften	85.43411	20
31	868	soften	85.29421	21
31	72	soften	84.80706	22
31	9	soften	84.237915	23
31	85	soften	84.04213	24
31	12	soften	83.91022	25
31	35	soften	83.64653	26
31	79	soften	83.56756	27
31	95	soften	83.52375	28
31	90	soften	83.305885	29
31	59	soften	83.21665	30
31	126	soften	82.903496	31
31	78	soften	81.89305	32
31	70	soften	81.66453	33
31	5	soften	81.59464	34
31	41	soften	81.270744	35
31	44	soften	80.131645	36
31	69	soften	79.50013	37
31	82	soften	79.48347	38
31	45	soften	79.048325	39
31	18	soften	78.50358	40
31	34	soften	77.588165	41
31	2	soften	76.63062	42
31	593	soften	76.386	43
31	66	soften	75.68453	44
31	28	soften	75.33626	45
31	8	soften	75.234116	46
31	94	soften	74.980675	47
31	73	soften	74.7243	48
31	43	soften	74.48692	49
31	99	soften	74.4782	50
31	30	soften	74.32934	51
31	182	soften	73.95586	52
31	49	soften	73.57874	53
31	63	soften	73.0233	54
31	39	soften	72.92778	55
31	13	soften	72.90535	56
31	50	soften	72.13078	57
31	92	soften	70.78868	58
31	176	soften	70.656235	59
31	27	soften	70.4585	60
31	222	soften	70.288315	61
31	33	soften	69.929214	62
31	7	soften	69.637695	63
31	187	soften	69.57731	64
31	285	soften	69.26079	65
31	61	soften	68.5261	66
31	640	soften	68.37863	67
31	51	soften	68.269035	68
31	86	soften	67.929085	69
31	230	soften	67.64716	70
32	488	enhance	100	1
32	14	enhance	98.33808	2
32	65	enhance	98.25017	3
32	53	enhance	95.38233	4
32	77	enhance	94.01889	5
32	100	enhance	92.786995	6
32	921	enhance	91.63555	7
32	8	enhance	89.551796	8
32	35	enhance	89.422424	9
32	62	enhance	88.12267	10
32	81	enhance	87.748375	11
32	54	enhance	87.41685	12
32	455	enhance	86.21402	13
32	24	enhance	86.034966	14
32	85	enhance	85.37696	15
32	42	enhance	85.05066	16
32	12	enhance	85.04994	17
32	20	enhance	84.88154	18
32	95	enhance	84.54587	19
32	185	enhance	84.23036	20
32	69	enhance	84.11362	21
32	38	enhance	83.600845	22
32	18	enhance	83.34268	23
32	28	enhance	82.80848	24
32	593	enhance	80.65701	25
32	57	enhance	80.64118	26
32	171	enhance	80.41527	27
32	58	enhance	79.84701	28
32	66	enhance	79.43938	29
32	21	enhance	79.4121	30
32	5	enhance	78.83406	31
32	76	enhance	78.40976	32
32	219	enhance	78.04777	33
32	59	enhance	77.65827	34
32	82	enhance	77.24473	35
32	29	enhance	75.54671	36
32	785	enhance	75.440285	37
32	52	enhance	75.42155	38
32	16	enhance	74.120155	39
32	41	enhance	72.88666	40
32	6	enhance	71.992874	41
32	37	enhance	70.77225	42
32	27	enhance	70.30818	43
32	50	enhance	70.07642	44
32	78	enhance	70.069916	45
32	23	enhance	69.79895	46
32	9	enhance	69.77811	47
32	358	enhance	69.4342	48
32	97	enhance	68.67108	49
32	335	enhance	68.624565	50
32	79	enhance	67.15925	51
32	647	enhance	66.47455	52
32	26	enhance	66.271355	53
32	901	enhance	64.7172	54
32	10	enhance	64.46573	55
32	34	enhance	64.16649	56
32	96	enhance	64.026436	57
32	17	enhance	63.10858	58
32	4	enhance	62.174366	59
32	7	enhance	61.896	60
32	19	enhance	60.880653	61
32	868	enhance	59.739853	62
32	71	enhance	59.52537	63
32	108	enhance	58.84408	64
32	176	enhance	58.71522	65
32	2	enhance	58.10881	66
32	63	enhance	57.321075	67
32	89	enhance	56.789303	68
32	74	enhance	56.290115	69
32	94	enhance	56.029266	70
32	187	enhance	55.524117	71
32	184	enhance	54.497757	72
32	15	enhance	54.306335	73
32	182	enhance	54.256058	74
32	44	enhance	52.98043	75
32	87	enhance	51.957184	76
32	22	enhance	51.91696	77
32	55	enhance	51.782974	78
32	73	enhance	51.30701	79
32	39	enhance	50.148174	80
32	48	enhance	50.06781	81
32	43	enhance	49.765057	82
32	91	enhance	49.736595	83
32	92	enhance	47.951347	84
32	3	enhance	47.8277	85
32	56	enhance	47.11737	86
32	60	enhance	46.88019	87
32	86	enhance	46.661037	88
32	49	enhance	46.59446	89
32	68	enhance	46.335285	90
32	99	enhance	46.281208	91
32	98	enhance	46.164993	92
32	1	enhance	46.132755	93
32	93	enhance	46.057644	94
32	36	enhance	46.034084	95
32	84	enhance	45.957287	96
32	31	enhance	45.32231	97
32	70	enhance	44.017258	98
32	40	enhance	43.94444	99
32	285	enhance	43.754307	100
32	64	enhance	43.328747	101
32	11	enhance	43.069126	102
32	45	enhance	42.81668	103
32	83	enhance	41.931522	104
32	25	enhance	41.40371	105
32	46	enhance	40.81651	106
32	88	enhance	40.452255	107
32	155	enhance	40.11453	108
32	126	enhance	39.07904	109
32	90	enhance	37.561028	110
32	230	enhance	37.251152	111
32	75	enhance	36.940224	112
32	72	enhance	36.756695	113
32	882	enhance	36.692734	114
32	80	enhance	35.89702	115
32	30	enhance	34.01089	116
32	61	enhance	32.677467	117
32	47	enhance	30.174604	118
32	13	enhance	30.076385	119
32	222	enhance	29.963554	120
32	640	enhance	27.101854	121
32	33	enhance	25.227552	122
32	51	enhance	22.183908	123
32	67	enhance	21.888819	124
32	90	soften	100	1
32	126	soften	99.59279	2
32	11	soften	98.0505	3
32	93	soften	94.42882	4
32	3	soften	94.32258	5
32	30	soften	94.1127	6
32	55	soften	92.38336	7
32	91	soften	92.32824	8
32	79	soften	91.90736	9
32	99	soften	91.32502	10
32	182	soften	90.94873	11
32	184	soften	88.81468	12
32	2	soften	88.168655	13
32	34	soften	88.12451	14
32	39	soften	87.94261	15
32	285	soften	87.330666	16
32	63	soften	86.860245	17
32	868	soften	85.009384	18
32	44	soften	84.74134	19
32	22	soften	84.5525	20
32	4	soften	84.2356	21
32	23	soften	84.04267	22
32	28	soften	83.807274	23
32	50	soften	83.502846	24
32	96	soften	82.75623	25
32	82	soften	82.57958	26
32	176	soften	81.953575	27
32	18	soften	81.520676	28
32	59	soften	80.85616	29
32	66	soften	80.84338	30
32	7	soften	80.26316	31
32	27	soften	80.04061	32
32	21	soften	79.67601	33
32	171	soften	79.38327	34
32	9	soften	79.18852	35
32	219	soften	78.57011	36
32	54	soften	77.94229	37
32	10	soften	77.87768	38
32	647	soften	76.64057	39
32	52	soften	75.72036	40
32	12	soften	75.530785	41
32	85	soften	74.61984	42
32	455	soften	74.44179	43
32	17	soften	73.819984	44
32	35	soften	73.70423	45
32	8	soften	73.082375	46
32	6	soften	72.86481	47
32	97	soften	72.77025	48
32	901	soften	71.92808	49
32	69	soften	71.76554	50
32	80	soften	71.52106	51
32	58	soften	70.74877	52
32	64	soften	69.335655	53
32	72	soften	69.104836	54
32	33	soften	67.96535	55
32	83	soften	67.798965	56
32	13	soften	67.67451	57
32	70	soften	66.960304	58
32	60	soften	66.75862	59
32	14	soften	66.599945	60
32	49	soften	66.18757	61
32	45	soften	65.97902	62
32	53	soften	65.65031	63
32	640	soften	65.06445	64
32	61	soften	64.79852	65
32	488	soften	64.63583	66
32	222	soften	63.974014	67
32	230	soften	63.34707	68
32	43	soften	63.29701	69
32	73	soften	62.89853	70
32	74	soften	62.778187	71
32	94	soften	62.041225	72
32	51	soften	61.78068	73
32	98	soften	61.45262	74
32	31	soften	60.796284	75
32	47	soften	59.84096	76
32	92	soften	59.12242	77
32	67	soften	58.680965	78
32	88	soften	58.430912	79
32	78	soften	58.425716	80
32	56	soften	58.246677	81
32	187	soften	57.91546	82
32	86	soften	57.556873	83
32	335	soften	57.14546	84
32	593	soften	56.927933	85
32	84	soften	56.75053	86
32	5	soften	56.410255	87
32	89	soften	56.15536	88
32	108	soften	55.73275	89
32	1	soften	55.311127	90
32	40	soften	54.23827	91
32	19	soften	53.840797	92
32	36	soften	53.520267	93
32	25	soften	53.40232	94
32	20	soften	53.151024	95
32	882	soften	52.504803	96
32	87	soften	52.225147	97
32	68	soften	52.18034	98
32	41	soften	52.031483	99
32	48	soften	52.009792	100
32	155	soften	51.987705	101
32	71	soften	51.661175	102
32	26	soften	51.567482	103
32	24	soften	51.040985	104
32	785	soften	50.532597	105
32	95	soften	50.474762	106
32	185	soften	49.23727	107
32	62	soften	48.794403	108
32	921	soften	47.86241	109
32	100	soften	46.76157	110
32	77	soften	46.485615	111
32	65	soften	45.152973	112
33	230	enhance	100	1
33	61	enhance	98.48247	2
33	640	enhance	98.408394	3
33	13	enhance	96.74257	4
33	99	enhance	89.46691	5
33	31	enhance	88.77959	6
33	49	enhance	87.41895	7
33	182	enhance	87.34337	8
33	43	enhance	86.223785	9
33	63	enhance	85.89798	10
33	98	enhance	85.743866	11
33	2	enhance	85.35857	12
33	126	enhance	82.83054	13
33	222	enhance	79.43523	14
33	90	enhance	78.94632	15
33	47	enhance	78.750206	16
33	34	enhance	76.889984	17
33	50	enhance	75.82126	18
33	70	enhance	75.221985	19
33	45	enhance	75.13856	20
33	88	enhance	74.50208	21
33	80	enhance	69.590996	22
33	94	enhance	67.42526	23
33	30	enhance	67.2883	24
33	187	enhance	66.62964	25
33	56	enhance	66.2031	26
33	39	enhance	66.08639	27
33	92	enhance	66.03015	28
33	72	enhance	66.02183	29
33	285	enhance	65.37081	30
33	67	enhance	64.30263	31
33	83	enhance	63.719273	32
33	82	enhance	63.371212	33
33	108	enhance	62.32183	34
33	51	enhance	61.435593	35
33	89	enhance	60.7909	36
33	7	enhance	59.441452	37
33	176	enhance	56.989185	38
33	19	enhance	56.811573	39
33	73	enhance	56.65679	40
33	93	enhance	56.38842	41
33	3	enhance	54.985355	42
33	36	enhance	54.080967	43
33	79	enhance	52.588593	44
33	593	enhance	52.23714	45
33	1	enhance	52.0619	46
33	647	enhance	51.732197	47
33	40	enhance	51.296143	48
33	28	enhance	50.343952	49
33	84	enhance	50.21664	50
33	68	enhance	49.886444	51
33	55	enhance	46.013706	52
33	10	enhance	45.64786	53
33	71	enhance	45.072136	54
33	25	enhance	44.537777	55
33	48	enhance	44.179253	56
33	15	enhance	43.280693	57
33	23	enhance	43.12115	58
33	86	enhance	43.03186	59
33	18	enhance	43.028885	60
33	54	enhance	42.67329	61
33	5	enhance	42.58072	62
33	75	enhance	41.84471	63
33	37	enhance	40.26661	64
33	17	enhance	38.601448	65
33	66	enhance	38.182106	66
33	87	enhance	38.07356	67
33	60	enhance	37.78964	68
33	27	enhance	37.668373	69
33	785	enhance	37.10528	70
33	11	enhance	35.92626	71
33	868	enhance	35.385025	72
33	44	enhance	35.179436	73
33	78	enhance	35.047558	74
33	455	enhance	35.01177	75
33	185	enhance	34.937607	76
33	46	enhance	34.12607	77
33	52	enhance	33.426346	78
33	26	enhance	33.110332	79
33	24	enhance	33.004387	80
33	59	enhance	32.585037	81
33	91	enhance	32.51575	82
33	64	enhance	32.09255	83
33	8	enhance	32.079716	84
33	184	enhance	31.806921	85
33	58	enhance	31.69689	86
33	9	enhance	31.013773	87
33	62	enhance	30.832872	88
33	155	enhance	30.678894	89
33	882	enhance	30.523054	90
33	171	enhance	30.405205	91
33	4	enhance	30.316265	92
33	74	enhance	30.002598	93
33	901	enhance	29.957584	94
33	6	enhance	28.804293	95
33	76	enhance	28.478357	96
33	358	enhance	27.801243	97
33	96	enhance	27.712723	98
33	921	enhance	27.28878	99
33	97	enhance	27.156378	100
33	21	enhance	27.006128	101
33	14	enhance	26.680641	102
33	20	enhance	26.087946	103
33	22	enhance	25.947668	104
33	219	enhance	25.841734	105
33	100	enhance	25.689243	106
33	77	enhance	25.295162	107
33	38	enhance	25.28471	108
33	16	enhance	25.143566	109
33	32	enhance	24.876558	110
33	57	enhance	24.747158	111
33	335	enhance	24.324823	112
33	42	enhance	24.100647	113
33	12	enhance	23.809818	114
33	81	enhance	23.642136	115
33	29	enhance	23.512993	116
33	85	enhance	23.195496	117
33	69	enhance	22.588785	118
33	35	enhance	22.256613	119
33	95	enhance	21.960962	120
33	41	enhance	21.446266	121
33	488	enhance	19.81658	122
33	65	enhance	19.538109	123
33	53	enhance	19.097462	124
33	64	soften	100	1
33	74	soften	97.33764	2
33	11	soften	95.24534	3
33	91	soften	94.5065	4
33	96	soften	92.578674	5
33	184	soften	91.67956	6
33	335	soften	91.43489	7
33	60	soften	91.357254	8
33	22	soften	89.51243	9
33	868	soften	88.69011	10
33	21	soften	87.768234	11
33	219	soften	86.97715	12
33	4	soften	86.75647	13
33	55	soften	86.729065	14
33	171	soften	85.45679	15
33	20	soften	85.29214	16
33	59	soften	84.876175	17
33	85	soften	84.85322	18
33	12	soften	84.6872	19
33	78	soften	84.18216	20
33	35	soften	83.571304	21
33	44	soften	83.384094	22
33	9	soften	83.09002	23
33	93	soften	82.89734	24
33	23	soften	82.57524	25
33	3	soften	81.90101	26
33	79	soften	79.392624	27
33	83	soften	79.259926	28
33	5	soften	78.95546	29
33	72	soften	78.80445	30
33	80	soften	77.1951	31
33	70	soften	76.724174	32
33	94	soften	74.64726	33
33	82	soften	74.39637	34
33	90	soften	73.62034	35
33	126	soften	73.04024	36
33	45	soften	72.91957	37
33	34	soften	71.53978	38
33	73	soften	70.12364	39
33	2	soften	69.141304	40
33	30	soften	68.78881	41
33	49	soften	68.37336	42
33	43	soften	67.83921	43
33	182	soften	67.64808	44
33	99	soften	67.393585	45
33	13	soften	66.20101	46
34	43	enhance	100	1
34	126	enhance	96.85241	2
34	50	enhance	94.487564	3
34	45	enhance	94.20545	4
34	63	enhance	94.02982	5
34	82	enhance	92.63106	6
34	49	enhance	92.51984	7
34	2	enhance	92.46136	8
34	99	enhance	92.40117	9
34	80	enhance	91.51381	10
34	83	enhance	90.85678	11
34	70	enhance	90.78874	12
34	182	enhance	90.74122	13
34	90	enhance	89.64275	14
34	3	enhance	89.229126	15
34	18	enhance	88.32487	16
34	187	enhance	87.43457	17
34	79	enhance	87.40294	18
34	30	enhance	86.60169	19
34	73	enhance	86.37279	20
34	56	enhance	85.88622	21
34	593	enhance	85.443405	22
34	94	enhance	83.62422	23
34	72	enhance	83.40796	24
34	13	enhance	83.39924	25
34	230	enhance	83.30672	26
34	55	enhance	82.83728	27
34	61	enhance	82.65265	28
34	5	enhance	81.96885	29
34	19	enhance	81.879326	30
34	89	enhance	81.394104	31
34	20	enhance	81.275856	32
34	93	enhance	80.99249	33
34	78	enhance	80.93316	34
34	7	enhance	80.62635	35
34	171	enhance	80.33801	36
34	8	enhance	80.334885	37
34	23	enhance	80.270164	38
34	39	enhance	79.76274	39
34	28	enhance	79.34538	40
34	54	enhance	78.89161	41
34	33	enhance	78.365364	42
34	219	enhance	77.94929	43
34	58	enhance	77.41555	44
34	74	enhance	76.943954	45
34	95	enhance	76.91081	46
34	640	enhance	76.57599	47
34	31	enhance	76.29568	48
34	47	enhance	75.83418	49
34	9	enhance	75.81821	50
34	35	enhance	73.89607	51
34	96	enhance	73.52415	52
34	59	enhance	73.32627	53
34	92	enhance	73.31337	54
34	21	enhance	73.17345	55
34	4	enhance	73.08083	56
34	455	enhance	72.53052	57
34	98	enhance	72.35231	58
34	66	enhance	72.33647	59
34	11	enhance	72.03722	60
34	184	enhance	71.987625	61
34	14	enhance	71.462776	62
34	285	enhance	71.416466	63
34	85	enhance	70.70909	64
34	921	enhance	70.578964	65
34	69	enhance	70.40028	66
34	26	enhance	70.275475	67
34	647	enhance	70.12484	68
34	12	enhance	69.87261	69
34	91	enhance	69.86402	70
34	108	enhance	69.62612	71
34	64	enhance	69.57659	72
34	60	enhance	69.37267	73
34	488	enhance	69.23911	74
34	10	enhance	68.93574	75
34	41	enhance	68.55884	76
34	868	enhance	68.50981	77
34	62	enhance	68.38998	78
34	335	enhance	68.29571	79
34	185	enhance	68.19387	80
34	27	enhance	67.72269	81
34	65	enhance	67.3997	82
34	176	enhance	67.33777	83
34	44	enhance	66.750565	84
34	88	enhance	64.78473	85
34	222	enhance	64.782875	86
34	24	enhance	64.65107	87
34	32	enhance	64.48785	88
34	22	enhance	63.802574	89
34	52	enhance	63.008247	90
34	1	enhance	62.94705	91
34	77	enhance	62.349625	92
34	100	enhance	61.642006	93
34	901	enhance	59.902122	94
34	81	enhance	59.601303	95
34	57	enhance	59.356762	96
34	86	enhance	57.211685	97
34	37	enhance	57.16021	98
34	785	enhance	56.822166	99
34	36	enhance	56.01896	100
34	15	enhance	54.690437	101
34	84	enhance	54.239815	102
34	53	enhance	53.253548	103
34	6	enhance	52.459938	104
34	42	enhance	52.41679	105
34	38	enhance	52.150986	106
34	71	enhance	51.13847	107
34	17	enhance	50.17597	108
34	76	enhance	49.80708	109
34	16	enhance	49.477318	110
34	68	enhance	49.11222	111
34	51	enhance	48.4402	112
34	40	enhance	46.051086	113
34	29	enhance	46.01743	114
34	48	enhance	45.99741	115
34	97	enhance	45.600357	116
34	67	enhance	44.943142	117
34	358	enhance	44.29414	118
34	87	enhance	40.64377	119
34	25	enhance	38.005157	120
34	46	enhance	34.4335	121
34	75	enhance	33.77068	122
34	155	enhance	29.634144	123
34	882	enhance	29.396355	124
34	11	soften	100	1
34	91	soften	98.17949	2
34	60	soften	96.45081	3
34	184	soften	94.951385	4
34	96	soften	92.22094	5
34	93	soften	91.9967	6
34	22	soften	91.71808	7
34	55	soften	91.42771	8
34	868	soften	91.31828	9
34	80	soften	91.196175	10
34	335	soften	91.10126	11
34	72	soften	90.60086	12
34	3	soften	89.72733	13
34	83	soften	88.79649	14
34	70	soften	88.25499	15
34	4	soften	88.14016	16
34	44	soften	88.02172	17
34	79	soften	87.98466	18
34	90	soften	87.61642	19
34	21	soften	87.58009	20
34	78	soften	86.8121	21
34	126	soften	86.62817	22
34	59	soften	86.47405	23
34	23	soften	85.76285	24
34	219	soften	85.68403	25
34	45	soften	84.32128	26
34	171	soften	84.16784	27
34	9	soften	83.47548	28
34	12	soften	83.10194	29
34	85	soften	83.030045	30
34	20	soften	82.605606	31
34	13	soften	82.457375	32
34	5	soften	81.50374	33
34	30	soften	81.105995	34
34	64	soften	73.02003	35
34	74	soften	68.88251	36
34	49	soften	57.662117	37
35	85	enhance	100	1
35	12	enhance	99.64238	2
35	21	enhance	97.93938	3
35	5	enhance	96.85517	4
35	69	enhance	96.829834	5
35	219	enhance	96.23658	6
35	8	enhance	95.70259	7
35	20	enhance	95.53946	8
35	59	enhance	94.84354	9
35	23	enhance	93.5144	10
35	9	enhance	92.16985	11
35	488	enhance	91.7463	12
35	335	enhance	91.25878	13
35	171	enhance	91.19885	14
35	41	enhance	91.18679	15
35	593	enhance	90.97885	16
35	4	enhance	90.44541	17
35	65	enhance	88.45353	18
35	18	enhance	88.42231	19
35	66	enhance	87.79925	20
35	78	enhance	87.73908	21
35	96	enhance	87.701126	22
35	82	enhance	87.071365	23
35	32	enhance	86.77899	24
35	74	enhance	86.1132	25
35	14	enhance	86.08869	26
35	95	enhance	85.68282	27
35	91	enhance	83.24	28
35	184	enhance	81.925865	29
35	54	enhance	81.53766	30
35	79	enhance	81.388855	31
35	28	enhance	81.385635	32
35	55	enhance	81.35708	33
35	22	enhance	80.25592	34
35	60	enhance	78.62202	35
35	77	enhance	78.44734	36
35	58	enhance	78.19183	37
35	868	enhance	78.057	38
35	3	enhance	77.97496	39
35	64	enhance	77.513535	40
35	455	enhance	77.47422	41
35	11	enhance	76.977905	42
35	100	enhance	76.84327	43
35	50	enhance	75.93113	44
35	53	enhance	75.609146	45
35	44	enhance	75.15056	46
35	93	enhance	75.0195	47
35	921	enhance	73.192696	48
35	27	enhance	72.77139	49
35	34	enhance	71.35426	50
35	52	enhance	68.825676	51
35	62	enhance	68.24907	52
35	24	enhance	67.52878	53
35	83	enhance	66.59237	54
35	10	enhance	65.84714	55
35	94	enhance	65.70733	56
35	81	enhance	64.772644	57
35	70	enhance	64.506584	58
35	185	enhance	63.689423	59
35	7	enhance	63.450115	60
35	90	enhance	63.03494	61
35	72	enhance	62.920994	62
35	57	enhance	62.4309	63
35	2	enhance	60.457275	64
35	182	enhance	59.801342	65
35	42	enhance	59.269043	66
35	38	enhance	58.25837	67
35	126	enhance	58.21496	68
35	99	enhance	58.15519	69
35	63	enhance	57.103115	70
35	19	enhance	56.51757	71
35	39	enhance	56.140854	72
35	43	enhance	54.59638	73
35	80	enhance	54.358063	74
35	76	enhance	52.30889	75
35	26	enhance	52.179592	76
35	785	enhance	52.005974	77
35	187	enhance	51.801807	78
35	29	enhance	51.27737	79
35	16	enhance	50.84605	80
35	901	enhance	49.91574	81
35	176	enhance	49.660355	82
35	49	enhance	49.543324	83
35	6	enhance	49.42915	84
35	92	enhance	48.796528	85
35	73	enhance	48.71805	86
35	647	enhance	47.458027	87
35	45	enhance	46.659542	88
35	97	enhance	45.288246	89
35	37	enhance	44.821945	90
35	86	enhance	44.768227	91
35	358	enhance	43.964413	92
35	108	enhance	43.439194	93
35	89	enhance	43.28479	94
35	17	enhance	38.952137	95
35	56	enhance	38.41153	96
35	285	enhance	37.421234	97
35	15	enhance	35.60065	98
35	71	enhance	34.444355	99
35	13	enhance	33.841732	100
35	30	enhance	33.39901	101
35	230	enhance	32.243023	102
35	31	enhance	29.923174	103
35	98	enhance	29.701149	104
35	84	enhance	29.13628	105
35	48	enhance	29.077726	106
35	1	enhance	29.058037	107
35	87	enhance	28.058224	108
35	61	enhance	27.580462	109
35	68	enhance	27.010311	110
35	222	enhance	26.868881	111
35	36	enhance	25.919868	112
35	640	enhance	25.703846	113
35	47	enhance	25.141861	114
35	88	enhance	23.103493	115
35	33	enhance	21.903425	116
35	40	enhance	20.730286	117
35	46	enhance	18.678955	118
35	25	enhance	17.15372	119
35	155	enhance	16.42946	120
35	51	enhance	15.780172	121
35	882	enhance	13.944606	122
35	75	enhance	13.558975	123
35	67	enhance	7.9978247	124
35	80	soften	100	1
35	72	soften	98.391655	2
35	126	soften	98.09565	3
35	90	soften	98.057365	4
35	13	soften	97.359634	5
35	11	soften	95.953384	6
35	83	soften	95.65933	7
35	30	soften	95.168686	8
35	70	soften	94.624825	9
35	60	soften	93.24789	10
35	45	soften	93.23021	11
35	3	soften	92.4921	12
35	93	soften	92.42351	13
35	55	soften	90.44231	14
35	99	soften	89.77553	15
35	43	soften	89.635185	16
35	79	soften	88.8924	17
35	91	soften	88.501884	18
35	184	soften	87.35013	19
35	34	soften	86.649826	20
35	2	soften	84.89489	21
35	868	soften	84.05339	22
35	44	soften	83.88195	23
35	22	soften	82.40059	24
35	78	soften	82.10589	25
35	4	soften	81.18447	26
35	23	soften	79.57014	27
35	82	soften	78.9649	28
35	96	soften	78.66664	29
35	335	soften	78.55741	30
35	59	soften	77.88721	31
35	5	soften	76.41309	32
35	171	soften	75.99738	33
35	219	soften	75.32434	34
35	21	soften	74.8929	35
35	9	soften	74.87756	36
35	20	soften	71.37922	37
35	12	soften	70.88231	38
35	85	soften	69.54279	39
35	64	soften	67.661255	40
35	49	soften	66.33798	41
35	94	soften	61.961285	42
35	74	soften	59.14652	43
36	40	enhance	100	1
36	68	enhance	99.54904	2
36	1	enhance	99.44593	3
36	48	enhance	99.02574	4
36	25	enhance	98.597626	5
36	75	enhance	98.148605	6
36	84	enhance	98.14377	7
36	108	enhance	97.040955	8
36	87	enhance	96.3893	9
36	71	enhance	96.23912	10
36	88	enhance	95.055725	11
36	155	enhance	93.05765	12
36	285	enhance	92.50639	13
36	882	enhance	92.40395	14
36	17	enhance	92.12162	15
36	46	enhance	91.971725	16
36	647	enhance	91.9669	17
36	86	enhance	90.62123	18
36	785	enhance	89.93248	19
36	89	enhance	89.05633	20
36	176	enhance	88.53295	21
36	6	enhance	88.20198	22
36	31	enhance	88.10299	23
36	358	enhance	87.952705	24
36	97	enhance	87.56085	25
36	92	enhance	85.97442	26
36	98	enhance	85.70987	27
36	15	enhance	85.62691	28
36	67	enhance	85.5241	29
36	76	enhance	85.11796	30
36	185	enhance	84.75752	31
36	16	enhance	84.4299	32
36	52	enhance	84.08853	33
36	38	enhance	83.31196	34
36	24	enhance	83.30776	35
36	10	enhance	82.56189	36
36	222	enhance	81.25552	37
36	42	enhance	81.10961	38
36	39	enhance	80.87539	39
36	56	enhance	80.15231	40
36	37	enhance	80.14579	41
36	455	enhance	80.08891	42
36	62	enhance	79.72955	43
36	47	enhance	79.00471	44
36	29	enhance	78.60081	45
36	7	enhance	77.93071	46
36	51	enhance	76.77547	47
36	94	enhance	74.698235	48
36	27	enhance	74.53953	49
36	26	enhance	73.57337	50
36	187	enhance	72.9206	51
36	49	enhance	71.73599	52
36	61	enhance	71.38685	53
36	640	enhance	70.29423	54
36	54	enhance	70.289246	55
36	63	enhance	70.06383	56
36	901	enhance	69.93047	57
36	100	enhance	69.35477	58
36	19	enhance	68.76091	59
36	77	enhance	67.17239	60
36	13	enhance	67.128296	61
36	230	enhance	66.40921	62
36	81	enhance	66.02645	63
36	50	enhance	64.07823	64
36	921	enhance	62.946865	65
36	30	enhance	61.765892	66
36	182	enhance	60.270405	67
36	28	enhance	59.152508	68
36	43	enhance	58.88206	69
36	73	enhance	58.64027	70
36	45	enhance	56.985764	71
36	53	enhance	56.06817	72
36	18	enhance	56.04518	73
36	66	enhance	55.894604	74
36	593	enhance	55.642918	75
36	34	enhance	54.655186	76
36	58	enhance	53.959694	77
36	33	enhance	53.77682	78
36	70	enhance	52.281254	79
36	99	enhance	52.23455	80
36	78	enhance	51.536495	81
36	868	enhance	48.31884	82
36	44	enhance	48.179234	83
36	14	enhance	46.212254	84
36	65	enhance	45.271133	85
36	32	enhance	45.138325	86
36	79	enhance	42.742485	87
36	72	enhance	42.676704	88
36	2	enhance	42.141926	89
36	126	enhance	41.911808	90
36	184	enhance	40.768234	91
36	93	enhance	39.893818	92
36	83	enhance	39.8502	93
36	59	enhance	39.66119	94
36	80	enhance	38.065628	95
36	82	enhance	37.417934	96
36	57	enhance	36.79005	97
36	8	enhance	35.6863	98
36	90	enhance	35.528225	99
36	3	enhance	34.792175	100
36	219	enhance	34.553143	101
36	22	enhance	33.89443	102
36	335	enhance	32.91538	103
36	171	enhance	31.454206	104
36	5	enhance	31.018686	105
36	55	enhance	30.872866	106
36	488	enhance	29.345682	107
36	21	enhance	29.111061	108
36	96	enhance	28.95093	109
36	20	enhance	28.843773	110
36	41	enhance	28.408068	111
36	95	enhance	28.074142	112
36	12	enhance	27.763704	113
36	69	enhance	27.385502	114
36	85	enhance	26.748924	115
36	35	enhance	26.189703	116
36	23	enhance	26.1233	117
36	9	enhance	25.865274	118
36	64	enhance	25.517458	119
36	4	enhance	25.51652	120
36	11	enhance	24.388943	121
36	91	enhance	24.244068	122
36	60	enhance	24.064905	123
36	74	enhance	23.53017	124
36	64	soften	100	1
36	11	soften	99.489525	2
36	74	soften	97.616776	3
36	60	soften	96.315346	4
36	80	soften	95.09033	5
36	91	soften	94.8531	6
36	55	soften	93.01341	7
36	90	soften	91.38715	8
36	3	soften	91.34878	9
36	83	soften	91.00568	10
36	126	soften	90.98252	11
36	72	soften	88.863945	12
36	96	soften	88.74666	13
36	4	soften	88.437	14
36	23	soften	88.32263	15
36	93	soften	87.83612	16
36	79	soften	87.2127	17
36	171	soften	86.98414	18
36	21	soften	85.9886	19
36	20	soften	85.90442	20
36	184	soften	85.84737	21
36	70	soften	85.349236	22
36	335	soften	85.102394	23
36	9	soften	85.01644	24
36	45	soften	84.3689	25
36	219	soften	84.221794	26
36	95	soften	83.78947	27
36	35	soften	83.722	28
36	5	soften	83.69484	29
36	82	soften	83.55907	30
36	2	soften	83.55606	31
36	85	soften	83.19609	32
36	22	soften	83.17641	33
36	12	soften	83.10797	34
36	34	soften	82.915504	35
36	868	soften	82.1644	36
36	59	soften	81.51246	37
36	43	soften	80.859276	38
36	99	soften	80.77638	39
36	78	soften	80.074554	40
36	41	soften	80.03615	41
36	30	soften	79.65879	42
36	33	soften	79.3145	43
36	69	soften	79.132355	44
36	73	soften	79.05871	45
36	182	soften	78.78657	46
36	18	soften	78.39834	47
36	13	soften	78.31786	48
36	49	soften	77.928665	49
36	44	soften	77.441086	50
36	8	soften	77.21305	51
36	593	soften	76.97825	52
36	63	soften	76.49235	53
36	28	soften	76.354225	54
36	50	soften	75.111916	55
36	94	soften	74.67576	56
36	61	soften	74.221375	57
36	488	soften	74.18769	58
36	230	soften	74.07263	59
36	66	soften	73.89676	60
36	640	soften	73.573235	61
36	187	soften	72.63011	62
36	39	soften	72.16675	63
36	222	soften	70.953766	64
36	58	soften	70.47527	65
36	56	soften	70.21577	66
36	7	soften	69.92604	67
36	14	soften	69.59435	68
36	92	soften	69.55566	69
36	54	soften	69.52982	70
36	47	soften	69.06368	71
36	31	soften	68.39915	72
36	19	soften	68.05051	73
36	176	soften	67.81922	74
36	89	soften	67.81098	75
36	285	soften	67.54566	76
36	27	soften	67.06408	77
36	51	soften	66.964005	78
36	98	soften	66.75437	79
36	455	soften	66.50222	80
36	26	soften	65.67154	81
36	10	soften	65.480774	82
36	24	soften	64.71982	83
36	52	soften	63.136475	84
36	108	soften	63.053276	85
36	647	soften	62.910328	86
36	62	soften	62.849575	87
36	86	soften	62.840557	88
36	1	soften	62.32836	89
36	88	soften	61.763958	90
36	67	soften	61.711067	91
36	84	soften	61.559464	92
37	76	enhance	100	1
37	785	enhance	96.33576	2
37	81	enhance	96.24787	3
37	42	enhance	94.79294	4
37	15	enhance	94.77462	5
37	38	enhance	94.46466	6
37	358	enhance	94.43968	7
37	185	enhance	93.22177	8
37	17	enhance	93.17787	9
37	16	enhance	93.09369	10
37	62	enhance	92.75467	11
37	647	enhance	90.03428	12
37	29	enhance	89.962296	13
37	87	enhance	89.81012	14
37	26	enhance	89.76973	15
37	100	enhance	89.76484	16
37	71	enhance	89.76219	17
37	921	enhance	89.18107	18
37	77	enhance	88.79216	19
37	6	enhance	88.47667	20
37	46	enhance	88.45595	21
37	882	enhance	87.84293	22
37	901	enhance	87.189804	23
37	155	enhance	87.02554	24
37	68	enhance	86.2735	25
37	48	enhance	86.164894	26
37	84	enhance	85.22798	27
37	108	enhance	84.999886	28
37	24	enhance	84.39293	29
37	97	enhance	84.308304	30
37	19	enhance	84.17271	31
37	25	enhance	83.42288	32
37	57	enhance	83.230804	33
37	455	enhance	83.206635	34
37	89	enhance	83.13312	35
37	36	enhance	83.05329	36
37	1	enhance	82.97672	37
37	52	enhance	81.58316	38
37	40	enhance	80.55567	39
37	65	enhance	80.16393	40
37	54	enhance	79.931625	41
37	75	enhance	79.869385	42
37	10	enhance	79.47101	43
37	56	enhance	78.30903	44
37	187	enhance	77.232864	45
37	7	enhance	77.17258	46
37	53	enhance	75.94237	47
37	176	enhance	75.92436	48
37	58	enhance	75.1298	49
37	14	enhance	74.97023	50
37	27	enhance	74.788284	51
37	88	enhance	73.92186	52
37	31	enhance	73.84213	53
37	92	enhance	73.244255	54
37	86	enhance	72.45172	55
37	32	enhance	71.912605	56
37	285	enhance	70.20023	57
37	98	enhance	68.90583	58
37	39	enhance	68.275	59
37	50	enhance	68.07484	60
37	67	enhance	67.07356	61
37	28	enhance	65.95957	62
37	222	enhance	64.913445	63
37	66	enhance	63.851532	64
37	51	enhance	63.564445	65
37	8	enhance	63.043797	66
37	18	enhance	62.644196	67
37	593	enhance	62.157455	68
37	63	enhance	60.944515	69
37	47	enhance	60.235558	70
37	78	enhance	59.391926	71
37	94	enhance	58.42538	72
37	488	enhance	58.081776	73
37	34	enhance	57.7918	74
37	182	enhance	56.477432	75
37	43	enhance	53.46974	76
37	44	enhance	53.099236	77
37	640	enhance	52.952953	78
37	61	enhance	52.85717	79
37	49	enhance	52.55768	80
37	41	enhance	52.44697	81
37	230	enhance	52.260506	82
37	30	enhance	50.85216	83
37	219	enhance	50.773617	84
37	69	enhance	50.57272	85
37	73	enhance	49.935192	86
37	82	enhance	49.593533	87
37	59	enhance	49.574238	88
37	171	enhance	49.506443	89
37	95	enhance	48.425163	90
37	13	enhance	48.173244	91
37	868	enhance	47.961517	92
37	20	enhance	47.940536	93
37	99	enhance	47.10945	94
37	35	enhance	46.931515	95
37	5	enhance	44.542297	96
37	12	enhance	44.154636	97
37	9	enhance	44.11794	98
37	335	enhance	43.782173	99
37	184	enhance	43.09153	100
37	2	enhance	42.45215	101
37	85	enhance	42.284515	102
37	33	enhance	41.492714	103
37	22	enhance	41.027977	104
37	45	enhance	40.98043	105
37	21	enhance	39.573044	106
37	70	enhance	39.49996	107
37	79	enhance	38.146782	108
37	4	enhance	37.513924	109
37	23	enhance	36.85142	110
37	96	enhance	36.74716	111
37	55	enhance	36.448353	112
37	3	enhance	34.80388	113
37	83	enhance	34.084385	114
37	72	enhance	33.939606	115
37	93	enhance	33.729088	116
37	126	enhance	31.920525	117
37	90	enhance	28.547594	118
37	60	enhance	27.9764	119
37	11	enhance	26.584387	120
37	64	enhance	25.600418	121
37	91	enhance	24.705404	122
37	74	enhance	24.567585	123
37	80	enhance	23.464708	124
37	11	soften	100	1
37	80	soften	97.81893	2
37	91	soften	97.66403	3
37	60	soften	97.2498	4
37	90	soften	94.198975	5
37	126	soften	93.11666	6
37	72	soften	92.381645	7
37	83	soften	92.30376	8
37	55	soften	92.24142	9
37	3	soften	91.89019	10
37	93	soften	91.82454	11
37	79	soften	90.3195	12
37	70	soften	89.588684	13
37	96	soften	88.63098	14
37	23	soften	88.18457	15
37	184	soften	88.13127	16
37	4	soften	87.56896	17
37	45	soften	87.07255	18
37	21	soften	86.49618	19
37	335	soften	85.54602	20
37	22	soften	85.32529	21
37	868	soften	84.95626	22
37	2	soften	84.46048	23
37	9	soften	84.26726	24
37	171	soften	83.77978	25
37	13	soften	83.72039	26
37	5	soften	83.68793	27
37	99	soften	83.29375	28
37	33	soften	83.04883	29
37	59	soften	82.84697	30
37	82	soften	82.76634	31
37	85	soften	82.67179	32
37	20	soften	82.514725	33
37	219	soften	82.445305	34
37	12	soften	82.26162	35
37	34	soften	82.1774	36
37	43	soften	81.99123	37
37	182	soften	81.54797	38
37	35	soften	81.01064	39
37	44	soften	80.936584	40
37	78	soften	80.81798	41
37	30	soften	80.55746	42
37	73	soften	80.100365	43
37	63	soften	79.46297	44
37	18	soften	79.08824	45
37	640	soften	78.88035	46
37	593	soften	78.70811	47
37	41	soften	78.63328	48
37	230	soften	78.39251	49
37	69	soften	78.281296	50
37	28	soften	78.024345	51
37	39	soften	77.245224	52
37	50	soften	76.73152	53
37	66	soften	76.355675	54
37	285	soften	74.08425	55
37	8	soften	73.91655	56
37	176	soften	73.006966	57
37	187	soften	72.6011	58
37	98	soften	72.53076	59
37	7	soften	72.229744	60
37	64	soften	71.3403	61
37	27	soften	71.110374	62
37	54	soften	70.96364	63
37	488	soften	70.861595	64
37	58	soften	70.337944	65
37	86	soften	70.06783	66
37	89	soften	69.80145	67
37	10	soften	69.39203	68
37	19	soften	69.13543	69
37	455	soften	69.10766	70
37	74	soften	68.94679	71
37	108	soften	67.73241	72
37	24	soften	67.673225	73
37	52	soften	67.55097	74
37	14	soften	66.88162	75
37	647	soften	65.52185	76
37	65	soften	64.862595	77
37	26	soften	64.1733	78
37	32	soften	63.832245	79
37	185	soften	63.411663	80
37	785	soften	62.656265	81
37	901	soften	62.424717	82
37	6	soften	61.8621	83
37	53	soften	61.842228	84
37	87	soften	61.347286	85
37	17	soften	61.01062	86
37	97	soften	60.938198	87
37	48	soften	60.896877	88
37	15	soften	59.91906	89
37	38	soften	59.624638	90
37	42	soften	58.63058	91
37	358	soften	58.60621	92
37	155	soften	58.441643	93
37	76	soften	58.387257	94
37	49	soften	58.21574	95
37	16	soften	58.03724	96
37	94	soften	56.51419	97
37	95	soften	55.51035	98
37	61	soften	55.462975	99
37	222	soften	53.769638	100
37	92	soften	51.961525	101
37	47	soften	51.369743	102
37	31	soften	51.112614	103
37	51	soften	50.73235	104
37	56	soften	49.51473	105
37	67	soften	47.748936	106
37	88	soften	47.72725	107
37	84	soften	46.971104	108
37	1	soften	46.89114	109
37	62	soften	44.936104	110
37	36	soften	44.50783	111
37	77	soften	44.31562	112
37	921	soften	44.143112	113
37	100	soften	44.131115	114
37	40	soften	43.559856	115
37	71	soften	43.07951	116
37	25	soften	42.82576	117
37	68	soften	42.731457	118
37	882	soften	40.689686	119
37	29	soften	40.542263	120
37	46	soften	40.371716	121
37	75	soften	40.193733	122
38	42	enhance	100	1
38	76	enhance	97.52424	2
38	62	enhance	96.48619	3
38	785	enhance	96.479065	4
38	185	enhance	96.41946	5
38	16	enhance	95.982834	6
38	100	enhance	94.724915	7
38	6	enhance	94.70322	8
38	358	enhance	94.62279	9
38	77	enhance	93.81137	10
38	24	enhance	93.402275	11
38	455	enhance	93.164024	12
38	29	enhance	92.88566	13
38	97	enhance	92.55942	14
38	17	enhance	92.219284	15
38	52	enhance	91.04686	16
38	81	enhance	90.992516	17
38	71	enhance	90.13369	18
38	37	enhance	89.055435	19
38	647	enhance	88.37821	20
38	921	enhance	87.86143	21
38	87	enhance	87.72499	22
38	48	enhance	87.3255	23
38	53	enhance	85.20259	24
38	108	enhance	84.884094	25
38	54	enhance	83.57601	26
38	15	enhance	83.44314	27
38	68	enhance	83.18491	28
38	25	enhance	82.26725	29
38	65	enhance	81.89015	30
38	36	enhance	81.39064	31
38	40	enhance	81.34886	32
38	26	enhance	81.32198	33
38	901	enhance	81.20934	34
38	155	enhance	81.20909	35
38	10	enhance	81.17156	36
38	882	enhance	80.36104	37
38	1	enhance	80.31927	38
38	32	enhance	80.083626	39
38	46	enhance	79.89724	40
38	14	enhance	79.62495	41
38	27	enhance	79.58521	42
38	84	enhance	79.05033	43
38	75	enhance	78.257614	44
38	89	enhance	77.62804	45
38	86	enhance	76.25523	46
38	7	enhance	75.80189	47
38	176	enhance	75.633224	48
38	58	enhance	74.57949	49
38	66	enhance	71.16381	50
38	28	enhance	69.38673	51
38	92	enhance	69.2109	52
38	285	enhance	68.77865	53
38	18	enhance	68.70324	54
38	593	enhance	68.65356	55
38	39	enhance	68.45566	56
38	57	enhance	68.32581	57
38	19	enhance	68.06653	58
38	88	enhance	67.34581	59
38	488	enhance	66.76658	60
38	187	enhance	65.68557	61
38	8	enhance	65.378586	62
38	78	enhance	64.908585	63
38	31	enhance	63.043415	64
38	56	enhance	63.011925	65
38	94	enhance	61.990707	66
38	50	enhance	61.524044	67
38	98	enhance	61.2195	68
38	59	enhance	59.807907	69
38	219	enhance	58.85323	70
38	868	enhance	57.57439	71
38	35	enhance	57.50733	72
38	63	enhance	57.23238	73
38	95	enhance	57.060028	74
38	69	enhance	56.46136	75
38	12	enhance	56.433838	76
38	20	enhance	56.38638	77
38	44	enhance	55.989166	78
38	41	enhance	55.223442	79
38	171	enhance	54.93406	80
38	85	enhance	54.919	81
38	335	enhance	54.4792	82
38	67	enhance	52.94042	83
38	21	enhance	52.16511	84
38	222	enhance	51.66328	85
38	5	enhance	50.548138	86
38	82	enhance	50.093407	87
38	184	enhance	49.87013	88
38	34	enhance	49.707966	89
38	51	enhance	47.933624	90
38	49	enhance	47.627716	91
38	182	enhance	47.33069	92
38	96	enhance	47.249783	93
38	22	enhance	46.351543	94
38	9	enhance	46.277386	95
38	73	enhance	45.03433	96
38	47	enhance	44.17494	97
38	79	enhance	43.717484	98
38	43	enhance	43.271957	99
38	23	enhance	43.009403	100
38	4	enhance	42.6875	101
38	30	enhance	38.92634	102
38	99	enhance	38.517963	103
38	61	enhance	38.238583	104
38	230	enhance	37.77653	105
38	2	enhance	37.68832	106
38	70	enhance	37.29923	107
38	640	enhance	37.199642	108
38	93	enhance	36.65867	109
38	55	enhance	36.282497	110
38	45	enhance	36.22852	111
38	13	enhance	35.66276	112
38	74	enhance	34.20315	113
38	3	enhance	33.032932	114
38	91	enhance	32.646908	115
38	64	enhance	30.816599	116
38	60	enhance	30.530254	117
38	72	enhance	29.50818	118
38	83	enhance	29.274149	119
38	11	enhance	28.79811	120
38	33	enhance	24.562685	121
38	126	enhance	24.056885	122
38	90	enhance	22.259764	123
38	80	enhance	19.939959	124
38	80	soften	100	1
38	11	soften	97.37372	2
38	90	soften	97.09182	3
38	64	soften	96.824196	4
38	126	soften	96.80422	5
38	60	soften	95.27192	6
38	83	soften	94.37291	7
38	72	soften	93.84702	8
38	3	soften	92.194885	9
38	74	soften	91.86263	10
38	91	soften	91.85519	11
38	55	soften	91.76357	12
38	70	soften	89.884315	13
38	33	soften	89.60364	14
38	93	soften	89.489395	15
38	45	soften	88.85086	16
38	79	soften	88.67802	17
38	13	soften	87.24422	18
38	2	soften	86.439255	19
38	99	soften	85.8975	20
38	23	soften	85.41854	21
38	43	soften	85.16895	22
38	49	soften	85.14392	23
38	34	soften	85.04658	24
38	30	soften	84.93152	25
38	182	soften	84.59696	26
38	4	soften	84.471306	27
38	61	soften	83.3508	28
38	82	soften	83.083435	29
38	640	soften	82.93328	30
38	184	soften	82.767166	31
38	73	soften	82.70089	32
38	230	soften	82.56835	33
38	96	soften	82.49445	34
38	171	soften	81.363716	35
38	5	soften	81.20582	36
38	9	soften	80.707954	37
38	21	soften	80.56198	38
38	63	soften	80.06155	39
38	868	soften	79.62365	40
38	22	soften	79.578094	41
38	335	soften	79.37097	42
38	20	soften	78.84086	43
38	94	soften	78.72045	44
38	222	soften	78.47684	45
38	219	soften	78.183754	46
38	50	soften	78.06368	47
38	59	soften	78.06182	48
38	78	soften	77.281876	49
38	12	soften	77.177345	50
38	28	soften	77.15606	51
38	85	soften	76.97506	52
38	35	soften	76.87154	53
38	18	soften	76.66273	54
38	47	soften	76.42156	55
38	593	soften	76.31855	56
38	44	soften	76.31727	57
38	95	soften	75.845726	58
38	39	soften	75.56813	59
38	187	soften	75.18919	60
38	31	soften	75.117325	61
38	98	soften	74.99333	62
38	51	soften	74.51028	63
38	41	soften	74.125275	64
38	56	soften	73.72632	65
38	92	soften	73.60501	66
38	66	soften	73.449104	67
38	69	soften	73.39364	68
38	285	soften	73.356606	69
38	8	soften	73.15609	70
38	7	soften	71.444305	71
38	176	soften	70.975365	72
38	89	soften	70.03548	73
38	19	soften	70.00164	74
38	54	soften	69.63148	75
38	67	soften	69.53694	76
38	88	soften	69.34671	77
38	27	soften	68.110245	78
38	488	soften	67.67606	79
38	10	soften	67.20047	80
38	58	soften	67.04513	81
38	108	soften	66.740776	82
38	86	soften	66.149864	83
38	1	soften	65.738464	84
38	84	soften	65.611176	85
38	455	soften	65.28685	86
38	14	soften	65.234505	87
38	26	soften	65.07477	88
38	647	soften	64.871864	89
38	24	soften	63.627174	90
38	52	soften	63.41855	91
38	901	soften	63.302624	92
38	921	soften	62.586395	93
38	65	soften	62.333515	94
38	36	soften	62.163166	95
38	185	soften	61.62599	96
38	62	soften	61.335854	97
38	785	soften	61.07191	98
38	32	soften	60.894672	99
38	40	soften	60.445038	100
38	71	soften	60.251274	101
38	17	soften	59.99054	102
38	68	soften	59.975178	103
38	77	soften	59.645897	104
38	100	soften	59.433903	105
38	87	soften	59.171623	106
38	25	soften	59.087925	107
38	6	soften	58.974346	108
38	53	soften	58.96078	109
38	48	soften	58.84064	110
38	97	soften	57.294685	111
38	46	soften	57.207855	112
38	358	soften	56.821423	113
38	882	soften	56.758068	114
38	155	soften	56.636955	115
39	94	enhance	100	1
39	7	enhance	97.648834	2
39	108	enhance	96.35958	3
39	10	enhance	95.86046	4
39	86	enhance	95.38246	5
39	63	enhance	94.65123	6
39	27	enhance	94.1922	7
39	92	enhance	93.152794	8
39	52	enhance	92.28163	9
39	44	enhance	91.989815	10
39	78	enhance	91.96551	11
39	593	enhance	91.707344	12
39	285	enhance	91.56135	13
39	49	enhance	91.49413	14
39	70	enhance	90.55512	15
39	50	enhance	90.38464	16
39	455	enhance	90.24389	17
39	93	enhance	90.06033	18
39	99	enhance	89.026054	19
39	647	enhance	88.693954	20
39	89	enhance	88.65697	21
39	184	enhance	88.05539	22
39	31	enhance	87.51815	23
39	43	enhance	86.31869	24
39	36	enhance	85.99799	25
39	18	enhance	85.573296	26
39	13	enhance	85.022804	27
39	66	enhance	84.77457	28
39	1	enhance	84.7176	29
39	68	enhance	84.60308	30
39	88	enhance	84.54676	31
39	84	enhance	84.52599	32
39	54	enhance	84.480865	33
39	182	enhance	84.16676	34
39	48	enhance	83.98459	35
39	176	enhance	83.932884	36
39	40	enhance	83.70938	37
39	3	enhance	83.00764	38
39	34	enhance	82.75006	39
39	222	enhance	82.53386	40
39	56	enhance	82.489525	41
39	640	enhance	82.32538	42
39	98	enhance	82.22293	43
39	868	enhance	82.129776	44
39	90	enhance	82.00079	45
39	22	enhance	81.99477	46
39	187	enhance	81.64965	47
39	72	enhance	80.79402	48
39	19	enhance	80.15183	49
39	61	enhance	80.11137	50
39	126	enhance	79.502205	51
39	15	enhance	79.30772	52
39	230	enhance	79.29442	53
39	6	enhance	79.270905	54
39	59	enhance	79.20811	55
39	62	enhance	79.20797	56
39	58	enhance	78.57304	57
39	335	enhance	78.28861	58
39	185	enhance	78.00345	59
39	25	enhance	77.84194	60
39	24	enhance	77.82639	61
39	79	enhance	77.80385	62
39	71	enhance	77.77575	63
39	17	enhance	77.59449	64
39	97	enhance	77.42784	65
39	96	enhance	77.103676	66
39	28	enhance	77.006935	67
39	100	enhance	76.974625	68
39	785	enhance	76.7377	69
39	45	enhance	76.67667	70
39	2	enhance	76.13662	71
39	83	enhance	76.031334	72
39	87	enhance	75.83492	73
39	77	enhance	75.72947	74
39	23	enhance	75.23766	75
39	219	enhance	75.19792	76
39	55	enhance	75.140724	77
39	80	enhance	74.73344	78
39	91	enhance	74.63498	79
39	30	enhance	74.54768	80
39	38	enhance	74.509926	81
39	64	enhance	74.12322	82
39	75	enhance	73.89386	83
39	5	enhance	73.517166	84
39	82	enhance	73.29808	85
39	74	enhance	73.165924	86
39	76	enhance	72.93548	87
39	42	enhance	72.58089	88
39	47	enhance	72.09179	89
39	16	enhance	72.04388	90
39	4	enhance	71.93526	91
39	358	enhance	71.895096	92
39	41	enhance	71.38454	93
39	9	enhance	71.12289	94
39	21	enhance	70.65548	95
39	26	enhance	70.43767	96
39	11	enhance	70.350075	97
39	37	enhance	70.057976	98
39	33	enhance	69.87706	99
39	882	enhance	69.4743	100
39	46	enhance	69.416084	101
39	29	enhance	69.08589	102
39	73	enhance	68.946045	103
39	60	enhance	67.74116	104
39	155	enhance	67.36145	105
39	69	enhance	65.88385	106
39	67	enhance	65.61369	107
39	8	enhance	65.60058	108
39	85	enhance	64.64093	109
39	12	enhance	64.62749	110
39	901	enhance	64.02243	111
39	921	enhance	63.817337	112
39	51	enhance	63.75662	113
39	20	enhance	62.547173	114
39	65	enhance	61.6881	115
39	171	enhance	60.79187	116
39	35	enhance	60.31825	117
39	81	enhance	60.128136	118
39	14	enhance	57.351017	119
39	53	enhance	56.666748	120
39	32	enhance	52.286907	121
39	95	enhance	51.93583	122
39	57	enhance	48.080967	123
39	488	enhance	46.968586	124
39	11	soften	100	1
39	60	soften	98.58148	2
39	55	soften	94.56681	3
39	91	soften	93.60303	4
39	83	soften	93.59814	5
39	72	soften	92.08663	6
39	80	soften	91.508575	7
39	3	soften	90.7217	8
39	126	soften	90.54626	9
39	90	soften	89.78658	10
39	4	soften	88.29919	11
39	171	soften	87.04654	12
39	96	soften	86.44314	13
39	93	soften	86.40105	14
39	70	soften	86.21732	15
39	23	soften	85.34859	16
39	184	soften	85.17723	17
39	868	soften	84.73562	18
39	335	soften	84.238174	19
39	20	soften	83.93765	20
39	45	soften	83.87034	21
39	79	soften	83.80016	22
39	9	soften	83.69302	23
39	21	soften	83.3933	24
39	219	soften	83.20624	25
39	34	soften	83.05492	26
39	82	soften	82.890144	27
39	22	soften	82.64302	28
39	35	soften	81.977356	29
39	12	soften	81.75302	30
39	5	soften	81.73357	31
39	59	soften	81.3343	32
39	85	soften	80.87657	33
39	182	soften	80.61531	34
39	13	soften	80.59385	35
39	2	soften	80.24066	36
39	43	soften	79.8877	37
39	78	soften	79.669876	38
39	33	soften	79.51337	39
39	99	soften	79.40113	40
39	30	soften	79.31919	41
39	73	soften	78.24673	42
39	44	soften	77.75037	43
39	18	soften	77.06563	44
39	64	soften	69.0705	45
39	74	soften	65.68424	46
39	95	soften	57.466232	47
39	49	soften	55.348305	48
39	94	soften	53.886837	49
40	48	enhance	100	1
40	25	enhance	99.68985	2
40	36	enhance	99.528656	3
40	75	enhance	98.823975	4
40	68	enhance	98.814285	5
40	71	enhance	96.351715	6
40	87	enhance	95.86092	7
40	108	enhance	95.84853	8
40	84	enhance	94.61973	9
40	88	enhance	93.99299	10
40	17	enhance	93.38868	11
40	1	enhance	92.95394	12
40	155	enhance	92.845375	13
40	882	enhance	92.81367	14
40	46	enhance	91.99212	15
40	97	enhance	91.54783	16
40	6	enhance	90.10908	17
40	647	enhance	89.97884	18
40	358	enhance	89.704216	19
40	86	enhance	88.56752	20
40	285	enhance	88.333405	21
40	785	enhance	88.13275	22
40	98	enhance	86.288506	23
40	31	enhance	85.93319	24
40	16	enhance	85.38206	25
40	76	enhance	85.0616	26
40	52	enhance	84.23633	27
40	38	enhance	82.8767	28
40	176	enhance	82.18957	29
40	29	enhance	82.13416	30
40	15	enhance	81.982635	31
40	89	enhance	81.62038	32
40	42	enhance	81.161156	33
40	185	enhance	80.59744	34
40	67	enhance	79.90966	35
40	24	enhance	79.4935	36
40	92	enhance	79.42976	37
40	10	enhance	78.795845	38
40	39	enhance	78.352036	39
40	37	enhance	77.3692	40
40	455	enhance	77.35912	41
40	222	enhance	76.28788	42
40	62	enhance	75.891045	43
40	27	enhance	74.67262	44
40	7	enhance	72.36814	45
40	56	enhance	71.19721	46
40	51	enhance	70.24435	47
40	94	enhance	70.05417	48
40	54	enhance	69.25428	49
40	100	enhance	68.375305	50
40	47	enhance	67.817795	51
40	49	enhance	67.1629	52
40	26	enhance	66.35957	53
40	61	enhance	66.304855	54
40	640	enhance	66.13836	55
40	77	enhance	65.778915	56
40	901	enhance	64.98847	57
40	187	enhance	64.27788	58
40	63	enhance	63.36102	59
40	81	enhance	63.24648	60
40	230	enhance	62.048107	61
40	13	enhance	61.739174	62
40	19	enhance	59.736942	63
40	921	enhance	59.202797	64
40	53	enhance	58.911827	65
40	28	enhance	57.97625	66
40	50	enhance	57.861073	67
40	182	enhance	55.684536	68
40	66	enhance	55.615036	69
40	30	enhance	53.356396	70
40	593	enhance	51.9126	71
40	73	enhance	51.00215	72
40	18	enhance	50.85663	73
40	33	enhance	50.767235	74
40	43	enhance	50.589123	75
40	45	enhance	46.50351	76
40	99	enhance	46.420395	77
40	78	enhance	45.90498	78
40	58	enhance	44.822906	79
40	44	enhance	44.735134	80
40	34	enhance	44.7182	81
40	70	enhance	44.377068	82
40	32	enhance	42.886242	83
40	868	enhance	41.808445	84
40	65	enhance	41.0409	85
40	14	enhance	40.330982	86
40	79	enhance	38.294933	87
40	59	enhance	35.822433	88
40	2	enhance	35.52024	89
40	184	enhance	34.963337	90
40	72	enhance	34.909904	91
40	93	enhance	34.001465	92
40	126	enhance	32.88573	93
40	57	enhance	32.01845	94
40	82	enhance	29.336716	95
40	8	enhance	29.301132	96
40	83	enhance	29.225674	97
40	90	enhance	28.9614	98
40	22	enhance	28.872967	99
40	80	enhance	28.573118	100
40	335	enhance	28.014412	101
40	219	enhance	26.878754	102
40	3	enhance	25.865229	103
40	5	enhance	25.539507	104
40	21	enhance	24.92686	105
40	12	enhance	24.269535	106
40	488	enhance	23.672857	107
40	69	enhance	23.168335	108
40	85	enhance	22.834332	109
40	41	enhance	22.352951	110
40	171	enhance	21.930117	111
40	55	enhance	21.605537	112
40	96	enhance	21.262468	113
40	35	enhance	20.847364	114
40	23	enhance	20.59252	115
40	4	enhance	19.2492	116
40	20	enhance	19.106258	117
40	9	enhance	18.893774	118
40	64	enhance	18.799784	119
40	91	enhance	18.42438	120
40	60	enhance	17.77606	121
40	95	enhance	16.970615	122
40	11	enhance	16.596348	123
40	74	enhance	15.24009	124
40	11	soften	100	1
40	64	soften	99.28861	2
40	74	soften	97.86824	3
40	60	soften	97.707855	4
40	91	soften	94.97044	5
40	55	soften	94.19114	6
40	80	soften	94.17686	7
40	83	soften	92.065025	8
40	3	soften	91.33784	9
40	126	soften	91.008575	10
40	90	soften	90.97723	11
40	4	soften	89.33063	12
40	72	soften	89.14454	13
40	23	soften	88.9105	14
40	96	soften	88.82801	15
40	171	soften	88.69911	16
40	20	soften	87.388504	17
40	93	soften	86.54478	18
40	21	soften	86.45132	19
40	9	soften	86.21762	20
40	79	soften	86.038315	21
40	95	soften	85.804825	22
40	35	soften	85.39503	23
40	335	soften	84.89132	24
40	82	soften	84.86976	25
40	219	soften	84.719765	26
40	70	soften	84.62607	27
40	5	soften	84.432	28
40	12	soften	84.33504	29
40	85	soften	84.31269	30
40	184	soften	84.25255	31
40	45	soften	83.36758	32
40	2	soften	83.24762	33
40	34	soften	83.124535	34
40	22	soften	82.11355	35
40	868	soften	81.685165	36
40	59	soften	81.48359	37
40	41	soften	80.68037	38
40	69	soften	80.07876	39
40	43	soften	79.75864	40
40	99	soften	79.65463	41
40	78	soften	78.74484	42
40	182	soften	78.43596	43
40	8	soften	78.10764	44
40	33	soften	78.04885	45
40	30	soften	77.459785	46
40	73	soften	77.43711	47
40	18	soften	77.383606	48
40	13	soften	76.83261	49
40	593	soften	76.06207	50
40	49	soften	76.03605	51
40	488	soften	75.948425	52
40	44	soften	75.42667	53
40	28	soften	75.09478	54
40	63	soften	75.05454	55
40	50	soften	74.738914	56
40	94	soften	72.862854	57
40	66	soften	72.77269	58
40	61	soften	72.68521	59
40	230	soften	72.630264	60
40	640	soften	71.968094	61
40	187	soften	71.799614	62
40	14	soften	70.48358	63
40	58	soften	70.23261	64
40	222	soften	69.28038	65
40	39	soften	69.010155	66
40	47	soften	68.72454	67
40	56	soften	68.65747	68
40	92	soften	68.335625	69
40	7	soften	68.27489	70
40	54	soften	68.156975	71
40	19	soften	67.87115	72
40	65	soften	67.4906	73
40	176	soften	66.77925	74
40	31	soften	66.11827	75
40	51	soften	66.1062	76
40	89	soften	65.94807	77
40	285	soften	65.321396	78
40	455	soften	64.81465	79
40	26	soften	64.61161	80
40	27	soften	64.42195	81
40	98	soften	64.411156	82
40	10	soften	63.866913	83
40	24	soften	63.40313	84
40	901	soften	62.57801	85
40	62	soften	61.576885	86
40	185	soften	61.17627	87
40	647	soften	60.684376	88
40	52	soften	60.544476	89
40	1	soften	60.306812	90
40	108	soften	60.29997	91
40	67	soften	60.224606	92
40	86	soften	59.39296	93
40	88	soften	59.319256	94
40	785	soften	59.019844	95
40	84	soften	58.70481	96
40	6	soften	55.49039	97
40	36	soften	54.944653	98
40	87	soften	53.72761	99
41	9	enhance	100	1
41	69	enhance	98.1009	2
41	335	enhance	97.68695	3
41	219	enhance	96.802185	4
41	22	enhance	96.24877	5
41	4	enhance	96.13063	6
41	59	enhance	95.437126	7
41	96	enhance	94.92096	8
41	23	enhance	94.24395	9
41	44	enhance	93.613655	10
41	12	enhance	93.555504	11
41	21	enhance	93.4936	12
41	78	enhance	93.314026	13
41	5	enhance	92.96289	14
41	85	enhance	92.79753	15
41	184	enhance	92.73028	16
41	35	enhance	91.90523	17
41	91	enhance	91.43494	18
41	593	enhance	90.366394	19
41	74	enhance	89.61346	20
41	8	enhance	89.26112	21
41	58	enhance	88.006256	22
41	55	enhance	87.883484	23
41	20	enhance	87.79141	24
41	868	enhance	85.8824	25
41	66	enhance	85.74189	26
41	93	enhance	85.35513	27
41	3	enhance	85.25434	28
41	65	enhance	85.149925	29
41	64	enhance	84.9313	30
41	60	enhance	84.61703	31
41	11	enhance	83.54425	32
41	171	enhance	82.80411	33
41	82	enhance	82.53805	34
41	18	enhance	80.64668	35
41	77	enhance	79.370224	36
41	100	enhance	77.97423	37
41	488	enhance	76.45921	38
41	95	enhance	75.903725	39
41	27	enhance	74.09607	40
41	50	enhance	73.99962	41
41	14	enhance	73.85476	42
41	455	enhance	73.740074	43
41	10	enhance	72.96694	44
41	54	enhance	72.013535	45
41	72	enhance	71.6768	46
41	7	enhance	71.612114	47
41	32	enhance	71.28932	48
41	79	enhance	71.16884	49
41	83	enhance	71.11687	50
41	70	enhance	70.86735	51
41	94	enhance	70.39369	52
41	19	enhance	69.899086	53
41	57	enhance	69.207436	54
41	90	enhance	68.70747	55
41	52	enhance	68.550316	56
41	39	enhance	66.9642	57
41	28	enhance	66.86338	58
41	34	enhance	66.7222	59
41	62	enhance	65.0581	60
41	921	enhance	62.52492	61
41	99	enhance	61.991646	62
41	81	enhance	59.731598	63
41	126	enhance	59.358818	64
41	182	enhance	58.522316	65
41	24	enhance	58.389347	66
41	53	enhance	57.75033	67
41	92	enhance	57.60139	68
41	63	enhance	57.30905	69
41	185	enhance	56.884373	70
41	38	enhance	56.38543	71
41	42	enhance	56.32476	72
41	2	enhance	56.13809	73
41	187	enhance	53.899128	74
41	86	enhance	53.06617	75
41	43	enhance	52.921864	76
41	80	enhance	52.568775	77
41	15	enhance	52.325657	78
41	76	enhance	51.621975	79
41	37	enhance	50.484127	80
41	176	enhance	50.47933	81
41	26	enhance	49.810333	82
41	901	enhance	49.51238	83
41	785	enhance	48.382164	84
41	49	enhance	46.84574	85
41	16	enhance	46.361214	86
41	647	enhance	45.455765	87
41	108	enhance	45.218243	88
41	6	enhance	44.32808	89
41	29	enhance	43.952164	90
41	89	enhance	43.37352	91
41	45	enhance	41.251312	92
41	285	enhance	41.164913	93
41	97	enhance	39.944954	94
41	358	enhance	39.843517	95
41	56	enhance	37.96719	96
41	17	enhance	37.836426	97
41	13	enhance	37.32972	98
41	73	enhance	36.574898	99
41	222	enhance	34.32404	100
41	71	enhance	33.323544	101
41	48	enhance	33.026184	102
41	1	enhance	32.827995	103
41	68	enhance	31.883554	104
41	84	enhance	31.60509	105
41	87	enhance	30.204165	106
41	30	enhance	29.84831	107
41	640	enhance	29.821766	108
41	230	enhance	29.18658	109
41	36	enhance	28.336893	110
41	31	enhance	28.30932	111
41	47	enhance	25.702864	112
41	61	enhance	25.652603	113
41	98	enhance	24.415232	114
41	88	enhance	22.835407	115
41	51	enhance	22.820868	116
41	46	enhance	22.517721	117
41	40	enhance	22.402538	118
41	33	enhance	21.272224	119
41	25	enhance	21.208546	120
41	155	enhance	20.488697	121
41	882	enhance	20.220936	122
41	75	enhance	17.785471	123
41	67	enhance	13.752377	124
41	80	soften	100	1
41	126	soften	98.79725	2
41	72	soften	98.48048	3
41	90	soften	98.41516	4
41	11	soften	96.900024	5
41	83	soften	96.825745	6
41	33	soften	96.337204	7
41	64	soften	96.273476	8
41	13	soften	95.77631	9
41	60	soften	94.65223	10
41	70	soften	93.85384	11
41	30	soften	93.638306	12
41	49	soften	93.22839	13
41	3	soften	92.98739	14
41	45	soften	92.856445	15
41	55	soften	91.737274	16
41	93	soften	91.196846	17
41	182	soften	89.98168	18
41	43	soften	89.489746	19
41	99	soften	89.340355	20
41	73	soften	88.62947	21
41	91	soften	88.57636	22
41	79	soften	88.21995	23
41	34	soften	87.34837	24
41	94	soften	86.42307	25
41	184	soften	85.30148	26
41	39	soften	85.186104	27
41	2	soften	85.02878	28
41	74	soften	84.924934	29
41	868	soften	82.962326	30
41	4	soften	82.21116	31
41	44	soften	81.35682	32
41	22	soften	80.59754	33
41	78	soften	80.49885	34
41	23	soften	80.46336	35
41	82	soften	80.33257	36
41	18	soften	78.37708	37
41	96	soften	78.18163	38
41	171	soften	77.80611	39
41	335	soften	77.6781	40
41	5	soften	77.45749	41
41	59	soften	77.24522	42
41	9	soften	76.063736	43
41	219	soften	75.66143	44
41	21	soften	75.12146	45
41	20	soften	72.99069	46
41	12	soften	71.80292	47
41	35	soften	70.59313	48
41	85	soften	70.4946	49
41	95	soften	69.11716	50
42	38	enhance	100	1
42	76	enhance	97.42504	2
42	16	enhance	96.77651	3
42	185	enhance	96.74108	4
42	62	enhance	96.728165	5
42	785	enhance	95.87936	6
42	6	enhance	94.98034	7
42	100	enhance	94.977264	8
42	358	enhance	94.67081	9
42	29	enhance	94.39051	10
42	77	enhance	94.075676	11
42	81	enhance	93.18244	12
42	455	enhance	92.75684	13
42	97	enhance	92.62604	14
42	17	enhance	92.08476	15
42	24	enhance	92.008675	16
42	52	enhance	90.496574	17
42	921	enhance	90.20911	18
42	37	enhance	89.36491	19
42	71	enhance	89.17558	20
42	647	enhance	88.08303	21
42	53	enhance	87.40849	22
42	48	enhance	85.735405	23
42	87	enhance	85.38983	24
42	54	enhance	84.91271	25
42	108	enhance	83.52176	26
42	65	enhance	83.49689	27
42	26	enhance	82.92105	28
42	901	enhance	82.41083	29
42	15	enhance	82.182335	30
42	68	enhance	81.61663	31
42	32	enhance	81.47244	32
42	14	enhance	80.867096	33
42	10	enhance	79.90982	34
42	25	enhance	79.82548	35
42	27	enhance	79.68762	36
42	40	enhance	79.66493	37
42	36	enhance	79.23909	38
42	155	enhance	78.86958	39
42	46	enhance	78.73584	40
42	882	enhance	78.43013	41
42	1	enhance	78.01523	42
42	89	enhance	77.00689	43
42	84	enhance	76.40043	44
42	75	enhance	76.095116	45
42	7	enhance	74.54292	46
42	58	enhance	73.92581	47
42	86	enhance	73.43775	48
42	176	enhance	72.19166	49
42	66	enhance	71.512344	50
42	57	enhance	70.47981	51
42	28	enhance	70.47073	52
42	18	enhance	69.34606	53
42	593	enhance	68.27236	54
42	488	enhance	68.17993	55
42	19	enhance	67.54851	56
42	8	enhance	66.89006	57
42	39	enhance	66.68336	58
42	92	enhance	66.40701	59
42	285	enhance	66.37565	60
42	88	enhance	65.88499	61
42	187	enhance	65.76343	62
42	78	enhance	64.70632	63
42	56	enhance	63.384342	64
42	50	enhance	61.5423	65
42	31	enhance	61.316414	66
42	98	enhance	60.262135	67
42	94	enhance	59.80431	68
42	59	enhance	59.235474	69
42	219	enhance	58.859596	70
42	35	enhance	58.50498	71
42	95	enhance	57.315807	72
42	69	enhance	57.04811	73
42	12	enhance	56.8332	74
42	20	enhance	56.79696	75
42	63	enhance	55.68364	76
42	868	enhance	55.371334	77
42	171	enhance	55.363438	78
42	85	enhance	55.351643	79
42	41	enhance	55.16403	80
42	44	enhance	54.613583	81
42	335	enhance	53.646664	82
42	21	enhance	52.177364	83
42	5	enhance	50.793335	84
42	34	enhance	49.96132	85
42	82	enhance	49.807564	86
42	67	enhance	49.074528	87
42	184	enhance	48.701797	88
42	222	enhance	47.945942	89
42	182	enhance	46.687325	90
42	49	enhance	46.44865	91
42	9	enhance	46.132874	92
42	96	enhance	45.89598	93
42	73	enhance	45.88391	94
42	22	enhance	45.1145	95
42	51	enhance	44.238827	96
42	79	enhance	44.044933	97
42	43	enhance	42.966072	98
42	23	enhance	42.78234	99
42	4	enhance	42.458504	100
42	47	enhance	41.8313	101
42	30	enhance	39.324738	102
42	99	enhance	37.527916	103
42	2	enhance	36.79575	104
42	61	enhance	36.56079	105
42	230	enhance	36.553665	106
42	55	enhance	35.50596	107
42	70	enhance	35.164806	108
42	45	enhance	35.141747	109
42	640	enhance	34.9553	110
42	93	enhance	34.94907	111
42	13	enhance	33.202812	112
42	74	enhance	33.168095	113
42	3	enhance	32.301876	114
42	91	enhance	31.419464	115
42	64	enhance	29.834753	116
42	60	enhance	29.735126	117
42	83	enhance	28.134218	118
42	11	enhance	28.005453	119
42	72	enhance	27.736073	120
42	33	enhance	23.412434	121
42	126	enhance	23.043587	122
42	90	enhance	21.175814	123
42	80	enhance	18.97647	124
42	80	soften	100	1
42	11	soften	97.5593	2
42	64	soften	97.19484	3
42	90	soften	97.141785	4
42	126	soften	96.78649	5
42	60	soften	95.685394	6
42	83	soften	94.5316	7
42	72	soften	94.30975	8
42	91	soften	92.66515	9
42	74	soften	92.51932	10
42	3	soften	92.18974	11
42	55	soften	91.882454	12
42	70	soften	90.350624	13
42	93	soften	89.98344	14
42	33	soften	89.54119	15
42	79	soften	88.89442	16
42	45	soften	88.83051	17
42	13	soften	87.64205	18
42	2	soften	86.51129	19
42	99	soften	85.826996	20
42	23	soften	85.691574	21
42	49	soften	85.34032	22
42	43	soften	84.843475	23
42	34	soften	84.776665	24
42	182	soften	84.714714	25
42	4	soften	84.70537	26
42	30	soften	84.3045	27
42	61	soften	83.59194	28
42	640	soften	83.28362	29
42	82	soften	83.24755	30
42	184	soften	83.215675	31
42	96	soften	83.149055	32
42	230	soften	82.692276	33
42	73	soften	82.277596	34
42	5	soften	81.41046	35
42	171	soften	81.3638	36
42	21	soften	81.168304	37
42	9	soften	81.056335	38
42	868	soften	80.38862	39
42	22	soften	80.222946	40
42	63	soften	80.162766	41
42	335	soften	79.978096	42
42	222	soften	79.34315	43
42	94	soften	79.329094	44
42	20	soften	78.896996	45
42	59	soften	78.69699	46
42	219	soften	78.34895	47
42	50	soften	78.092384	48
42	12	soften	77.69909	49
42	85	soften	77.4866	50
42	78	soften	77.41862	51
42	28	soften	77.16139	52
42	35	soften	77.05439	53
42	47	soften	76.8974	54
42	44	soften	76.85236	55
42	18	soften	76.71936	56
42	593	soften	76.580635	57
42	95	soften	75.95795	58
42	39	soften	75.86055	59
42	51	soften	75.57819	60
42	31	soften	75.37865	61
42	98	soften	75.26446	62
42	187	soften	74.83279	63
42	41	soften	74.45857	64
42	92	soften	74.16954	65
42	285	soften	73.95234	66
42	66	soften	73.82659	67
42	69	soften	73.81996	68
42	56	soften	73.343216	69
42	8	soften	72.916115	70
42	176	soften	71.96729	71
42	7	soften	71.5113	72
42	67	soften	70.57284	73
42	19	soften	70.07581	74
42	89	soften	69.920494	75
42	88	soften	69.74168	76
42	54	soften	69.64742	77
42	27	soften	68.44032	78
42	488	soften	67.83021	79
42	10	soften	67.68958	80
42	58	soften	67.29228	81
42	86	soften	67.03581	82
42	108	soften	66.994255	83
42	84	soften	66.348305	84
42	1	soften	66.15753	85
42	455	soften	65.64741	86
42	14	soften	65.26977	87
42	647	soften	65.01608	88
42	26	soften	64.62483	89
42	24	soften	64.3422	90
42	52	soften	63.850246	91
42	901	soften	62.885765	92
42	36	soften	62.694218	93
42	65	soften	62.3552	94
42	921	soften	62.2876	95
42	185	soften	61.752502	96
42	62	soften	61.53376	97
42	785	soften	61.439682	98
42	32	soften	61.163147	99
42	40	soften	60.99359	100
42	71	soften	60.621677	101
42	68	soften	60.44453	102
42	17	soften	60.242886	103
42	77	soften	60.053288	104
42	87	soften	59.917007	105
42	100	soften	59.837612	106
42	25	soften	59.7941	107
42	48	soften	59.345127	108
42	6	soften	59.233063	109
42	15	soften	59.19815	110
42	53	soften	59.057613	111
42	97	soften	57.709667	112
42	46	soften	57.70551	113
42	155	soften	57.42534	114
42	882	soften	57.3854	115
42	358	soften	57.13831	116
42	76	soften	56.67757	117
42	38	soften	56.63157	118
42	16	soften	56.27885	119
42	29	soften	56.06273	120
43	34	enhance	100	1
43	63	enhance	99.41008	2
43	45	enhance	97.35284	3
43	99	enhance	96.042725	4
43	49	enhance	95.40977	5
43	126	enhance	95.221375	6
43	2	enhance	94.52615	7
43	80	enhance	93.54756	8
43	30	enhance	92.28892	9
43	230	enhance	91.699394	10
43	61	enhance	90.51665	11
43	13	enhance	89.30922	12
43	56	enhance	88.50289	13
43	90	enhance	88.35044	14
43	33	enhance	87.87826	15
43	70	enhance	87.709045	16
43	50	enhance	87.51207	17
43	187	enhance	87.0294	18
43	73	enhance	86.90208	19
43	182	enhance	86.02878	20
43	31	enhance	85.23724	21
43	89	enhance	85.20411	22
43	640	enhance	84.340515	23
43	39	enhance	83.20253	24
43	3	enhance	82.11392	25
43	7	enhance	81.79442	26
43	83	enhance	81.06674	27
43	79	enhance	81.03898	28
43	94	enhance	80.694214	29
43	82	enhance	80.58514	30
43	18	enhance	78.99947	31
43	593	enhance	77.59117	32
43	98	enhance	76.87282	33
43	93	enhance	76.795715	34
43	47	enhance	75.97645	35
43	72	enhance	75.76936	36
43	108	enhance	74.72326	37
43	19	enhance	74.539154	38
43	28	enhance	71.644005	39
43	78	enhance	70.95498	40
43	285	enhance	70.84312	41
43	92	enhance	70.785484	42
43	55	enhance	70.73316	43
43	23	enhance	69.591125	44
43	58	enhance	69.41999	45
43	647	enhance	69.12356	46
43	5	enhance	68.97929	47
43	88	enhance	68.46128	48
43	222	enhance	67.959145	49
43	54	enhance	67.64523	50
43	74	enhance	67.08881	51
43	20	enhance	66.89754	52
43	8	enhance	66.40655	53
43	171	enhance	65.21254	54
43	455	enhance	64.837364	55
43	1	enhance	64.65173	56
43	219	enhance	64.149704	57
43	26	enhance	63.94126	58
43	184	enhance	63.487038	59
43	176	enhance	62.431767	60
43	11	enhance	62.34886	61
43	95	enhance	62.265156	62
43	96	enhance	62.203224	63
43	9	enhance	61.81616	64
43	64	enhance	61.413845	65
43	10	enhance	60.834057	66
43	62	enhance	60.64746	67
43	36	enhance	60.351307	68
43	185	enhance	60.317463	69
43	44	enhance	60.24095	70
43	27	enhance	59.78367	71
43	868	enhance	59.67152	72
43	4	enhance	59.22048	73
43	91	enhance	58.93822	74
43	921	enhance	58.75149	75
43	59	enhance	58.74609	76
43	21	enhance	58.630077	77
43	66	enhance	58.59375	78
43	86	enhance	58.380108	79
43	52	enhance	57.49178	80
43	24	enhance	57.104248	81
43	60	enhance	56.724243	82
43	35	enhance	56.54123	83
43	84	enhance	56.51065	84
43	14	enhance	56.017284	85
43	901	enhance	55.74183	86
43	69	enhance	55.287445	87
43	335	enhance	54.9535	88
43	85	enhance	54.63711	89
43	41	enhance	54.37863	90
43	22	enhance	53.68801	91
43	15	enhance	53.044655	92
43	37	enhance	52.885387	93
43	488	enhance	52.79418	94
43	12	enhance	52.56801	95
43	40	enhance	52.096996	96
43	65	enhance	51.765957	97
43	57	enhance	51.612526	98
43	68	enhance	50.886547	99
43	77	enhance	50.37578	100
43	100	enhance	50.122215	101
43	32	enhance	50.01429	102
43	785	enhance	49.58821	103
43	71	enhance	49.03997	104
43	48	enhance	48.33347	105
43	6	enhance	48.10904	106
43	81	enhance	47.962036	107
43	67	enhance	47.83401	108
43	51	enhance	46.172726	109
43	17	enhance	45.53543	110
43	38	enhance	45.398663	111
43	42	enhance	45.077744	112
43	16	enhance	44.687088	113
43	25	enhance	43.46316	114
43	76	enhance	42.95537	115
43	97	enhance	42.252525	116
43	87	enhance	41.30558	117
43	53	enhance	39.861343	118
43	358	enhance	39.293392	119
43	29	enhance	39.1353	120
43	75	enhance	37.188026	121
43	46	enhance	33.288136	122
43	882	enhance	31.073648	123
43	155	enhance	30.910414	124
43	64	soften	100	1
43	11	soften	97.08926	2
43	74	soften	95.1445	3
43	91	soften	95.07592	4
43	60	soften	94.83411	5
43	184	soften	90.714874	6
43	96	soften	89.89156	7
43	55	soften	89.67157	8
43	335	soften	88.856224	9
43	868	soften	88.74449	10
43	22	soften	88.39537	11
43	72	soften	87.21314	12
43	93	soften	86.67241	13
43	83	soften	86.45216	14
43	4	soften	86.341545	15
43	3	soften	85.68054	16
43	21	soften	85.43783	17
43	59	soften	84.34155	18
43	80	soften	84.11877	19
43	219	soften	84.0202	20
43	171	soften	83.65974	21
43	70	soften	83.58345	22
43	44	soften	83.571655	23
43	78	soften	83.15212	24
43	23	soften	82.79991	25
43	79	soften	82.29081	26
43	12	soften	82.26563	27
43	9	soften	82.12008	28
43	90	soften	81.85931	29
43	20	soften	81.851	30
43	85	soften	81.744514	31
43	126	soften	81.55951	32
43	94	soften	79.470474	33
43	5	soften	79.15915	34
43	45	soften	78.791374	35
43	13	soften	76.49821	36
43	49	soften	76.1177	37
43	34	soften	75.99076	38
43	30	soften	74.30275	39
43	2	soften	74.147934	40
43	99	soften	73.81671	41
44	22	enhance	100	1
44	184	enhance	97.42341	2
44	335	enhance	94.55721	3
44	78	enhance	94.5067	4
44	93	enhance	93.88063	5
44	41	enhance	93.47194	6
44	91	enhance	93.09928	7
44	4	enhance	92.25832	8
44	9	enhance	91.72508	9
44	59	enhance	91.60112	10
44	593	enhance	90.43242	11
44	96	enhance	90.32168	12
44	868	enhance	89.22943	13
44	23	enhance	88.49985	14
44	3	enhance	88.25368	15
44	64	enhance	87.6504	16
44	219	enhance	87.49535	17
44	55	enhance	87.147095	18
44	66	enhance	87.13702	19
44	39	enhance	86.16291	20
44	74	enhance	85.9447	21
44	60	enhance	85.455864	22
44	69	enhance	85.11587	23
44	94	enhance	84.90178	24
44	10	enhance	84.875694	25
44	11	enhance	84.83511	26
44	21	enhance	84.8201	27
44	5	enhance	84.577774	28
44	27	enhance	83.706276	29
44	7	enhance	82.14207	30
44	12	enhance	81.81509	31
44	72	enhance	81.16344	32
44	70	enhance	81.08341	33
44	85	enhance	80.39266	34
44	58	enhance	79.30121	35
44	52	enhance	78.048065	36
44	50	enhance	77.03402	37
44	90	enhance	76.61955	38
44	18	enhance	76.15815	39
44	455	enhance	75.829765	40
44	35	enhance	75.62798	41
44	83	enhance	74.77846	42
44	92	enhance	74.30797	43
44	8	enhance	74.16603	44
44	86	enhance	74.05908	45
44	82	enhance	73.42599	46
44	77	enhance	72.77493	47
44	100	enhance	72.76088	48
44	19	enhance	71.26435	49
44	54	enhance	71.15797	50
44	99	enhance	71.13361	51
44	20	enhance	70.34925	52
44	79	enhance	69.80785	53
44	65	enhance	67.632164	54
44	171	enhance	67.408295	55
44	182	enhance	66.435196	56
44	63	enhance	65.87818	57
44	126	enhance	65.170425	58
44	34	enhance	64.86401	59
44	28	enhance	64.345245	60
44	15	enhance	62.40717	61
44	176	enhance	62.335377	62
44	108	enhance	62.278614	63
44	62	enhance	61.660973	64
44	285	enhance	61.035988	65
44	49	enhance	60.74038	66
44	187	enhance	59.114594	67
44	43	enhance	58.538383	68
44	24	enhance	58.160694	69
44	38	enhance	57.08072	70
44	80	enhance	56.841553	71
44	185	enhance	56.02248	72
44	42	enhance	55.678314	73
44	647	enhance	55.317154	74
44	14	enhance	55.23126	75
44	222	enhance	55.22254	76
44	13	enhance	54.915234	77
44	2	enhance	54.75396	78
44	95	enhance	54.488834	79
44	76	enhance	54.083645	80
44	785	enhance	53.399998	81
44	89	enhance	52.72995	82
44	48	enhance	52.66179	83
44	6	enhance	52.285095	84
44	488	enhance	52.202625	85
44	68	enhance	51.999477	86
44	32	enhance	51.7409	87
44	16	enhance	51.062916	88
44	37	enhance	51.0346	89
44	57	enhance	50.823208	90
44	921	enhance	50.765663	91
44	97	enhance	50.188084	92
44	84	enhance	49.887966	93
44	81	enhance	49.67963	94
44	1	enhance	49.235832	95
44	17	enhance	49.23443	96
44	901	enhance	49.01569	97
44	640	enhance	48.933605	98
44	26	enhance	48.126835	99
44	36	enhance	47.985767	100
44	53	enhance	47.446938	101
44	358	enhance	47.41784	102
44	29	enhance	47.384254	103
44	71	enhance	46.92973	104
44	87	enhance	46.139153	105
44	56	enhance	46.087185	106
44	45	enhance	45.792255	107
44	31	enhance	45.68507	108
44	40	enhance	44.766502	109
44	88	enhance	43.821667	110
44	25	enhance	42.69187	111
44	230	enhance	42.394318	112
44	98	enhance	41.957832	113
44	61	enhance	41.29532	114
44	51	enhance	40.982143	115
44	75	enhance	40.010777	116
44	46	enhance	39.81646	117
44	882	enhance	39.451733	118
44	47	enhance	39.126495	119
44	155	enhance	38.370003	120
44	30	enhance	37.66177	121
44	73	enhance	37.645695	122
44	33	enhance	34.841118	123
44	67	enhance	34.349598	124
44	11	soften	100	1
44	126	soften	96.73528	2
44	90	soften	95.7212	3
44	55	soften	95.15439	4
44	3	soften	93.42941	5
44	91	soften	90.884834	6
44	93	soften	88.45004	7
44	4	soften	86.36215	8
44	79	soften	86.072975	9
44	184	soften	84.22769	10
44	171	soften	84.22391	11
44	23	soften	83.7195	12
44	868	soften	83.073685	13
44	96	soften	81.932785	14
44	9	soften	80.6627	15
44	22	soften	80.466705	16
44	219	soften	79.962166	17
44	21	soften	79.003624	18
44	59	soften	78.75018	19
44	60	soften	68.80645	20
44	64	soften	68.41333	21
44	83	soften	68.14933	22
44	80	soften	68.08836	23
44	72	soften	67.55632	24
44	70	soften	63.23748	25
44	74	soften	62.583225	26
44	45	soften	62.52211	27
44	335	soften	56.22555	28
44	78	soften	55.72291	29
45	80	enhance	100	1
45	43	enhance	98.271194	2
45	30	enhance	98.1628	3
45	73	enhance	97.00055	4
45	34	enhance	95.09412	5
45	49	enhance	94.891785	6
45	126	enhance	93.24309	7
45	63	enhance	91.334984	8
45	2	enhance	88.027824	9
45	61	enhance	86.65622	10
45	56	enhance	85.248604	11
45	79	enhance	84.048325	12
45	70	enhance	83.98054	13
45	230	enhance	83.76152	14
45	13	enhance	83.41999	15
45	99	enhance	81.48162	16
45	89	enhance	81.060005	17
45	83	enhance	79.695335	18
45	47	enhance	79.08068	19
45	90	enhance	78.51093	20
45	18	enhance	78.48778	21
45	33	enhance	77.302734	22
45	31	enhance	76.79044	23
45	94	enhance	76.516754	24
45	182	enhance	75.54381	25
45	39	enhance	74.605804	26
45	640	enhance	74.602776	27
45	50	enhance	74.501656	28
45	3	enhance	74.18859	29
45	187	enhance	72.94984	30
45	285	enhance	72.38613	31
45	98	enhance	71.559	32
45	82	enhance	71.16039	33
45	72	enhance	69.829926	34
45	93	enhance	67.79632	35
45	19	enhance	67.48673	36
45	74	enhance	67.28144	37
45	88	enhance	66.17396	38
45	108	enhance	65.81756	39
45	1	enhance	65.590004	40
45	647	enhance	65.03498	41
45	58	enhance	64.87199	42
45	28	enhance	64.84526	43
45	95	enhance	64.77559	44
45	593	enhance	64.66377	45
45	7	enhance	64.65253	46
45	20	enhance	64.25331	47
45	78	enhance	63.332912	48
45	176	enhance	62.85522	49
45	92	enhance	61.80531	50
45	171	enhance	61.582947	51
45	55	enhance	61.464943	52
45	54	enhance	61.346607	53
45	222	enhance	61.319626	54
45	455	enhance	59.912205	55
45	36	enhance	58.958675	56
45	24	enhance	58.740074	57
45	5	enhance	58.174786	58
45	96	enhance	57.95199	59
45	23	enhance	57.633896	60
45	62	enhance	57.515614	61
45	84	enhance	57.335304	62
45	26	enhance	56.135906	63
45	86	enhance	56.108494	64
45	219	enhance	55.96569	65
45	184	enhance	55.88109	66
45	64	enhance	55.30735	67
45	185	enhance	54.735836	68
45	11	enhance	54.528366	69
45	21	enhance	53.54814	70
45	9	enhance	52.73159	71
45	27	enhance	52.522667	72
45	91	enhance	51.821728	73
45	868	enhance	51.414906	74
45	10	enhance	51.31454	75
45	921	enhance	50.951694	76
45	8	enhance	50.877087	77
45	59	enhance	50.063972	78
45	52	enhance	49.967995	79
45	488	enhance	49.93628	80
45	35	enhance	48.7775	81
45	66	enhance	48.54667	82
45	40	enhance	48.34137	83
45	85	enhance	48.127377	84
45	69	enhance	47.74287	85
45	44	enhance	47.56865	86
45	14	enhance	47.250046	87
45	4	enhance	46.421886	88
45	60	enhance	46.35301	89
45	67	enhance	45.724148	90
45	335	enhance	45.67302	91
45	6	enhance	45.507008	92
45	12	enhance	44.10147	93
45	51	enhance	44.00486	94
45	15	enhance	43.534588	95
45	32	enhance	43.43704	96
45	68	enhance	43.41666	97
45	41	enhance	42.78668	98
45	22	enhance	42.690063	99
45	71	enhance	42.426147	100
45	77	enhance	42.33755	101
45	785	enhance	42.337055	102
45	100	enhance	41.9358	103
45	65	enhance	41.54728	104
45	37	enhance	40.91492	105
45	48	enhance	40.51276	106
45	97	enhance	40.41784	107
45	57	enhance	38.63726	108
45	901	enhance	38.49693	109
45	38	enhance	38.36761	110
45	17	enhance	38.193848	111
45	25	enhance	37.89966	112
45	42	enhance	37.21667	113
45	87	enhance	36.155724	114
45	81	enhance	35.952374	115
45	76	enhance	35.56537	116
45	53	enhance	33.41233	117
45	16	enhance	33.365993	118
45	75	enhance	33.23827	119
45	358	enhance	31.533201	120
45	29	enhance	30.36455	121
45	46	enhance	27.441238	122
45	155	enhance	26.24597	123
45	882	enhance	25.496202	124
45	64	soften	100	1
45	11	soften	97.63914	2
45	60	soften	94.79579	3
45	74	soften	94.22809	4
45	91	soften	93.79934	5
45	184	soften	90.86495	6
45	55	soften	90.54116	7
45	96	soften	89.33949	8
45	335	soften	88.47975	9
45	868	soften	88.201675	10
45	22	soften	87.96261	11
45	72	soften	87.41699	12
45	3	soften	87.03037	13
45	83	soften	86.99997	14
45	4	soften	86.88449	15
45	93	soften	86.71775	16
45	80	soften	85.62506	17
45	70	soften	83.736046	18
45	90	soften	83.26061	19
45	23	soften	83.19116	20
45	126	soften	83.05692	21
45	79	soften	82.66098	22
46	882	enhance	100	1
46	155	enhance	98.223656	2
46	75	enhance	97.170784	3
46	68	enhance	97.13966	4
46	87	enhance	96.63543	5
46	17	enhance	95.78559	6
46	358	enhance	94.58199	7
46	48	enhance	94.290955	8
46	84	enhance	94.27608	9
46	25	enhance	94.05391	10
46	71	enhance	92.74494	11
46	40	enhance	91.904915	12
46	785	enhance	91.454094	13
46	36	enhance	91.45145	14
46	76	enhance	89.99729	15
46	97	enhance	87.46633	16
46	6	enhance	87.34358	17
46	29	enhance	86.25114	18
46	16	enhance	85.73984	19
46	1	enhance	85.70639	20
46	37	enhance	84.87644	21
46	647	enhance	84.79741	22
46	88	enhance	83.53656	23
46	108	enhance	81.679115	24
46	67	enhance	81.6551	25
46	38	enhance	81.320656	26
46	10	enhance	80.1794	27
46	42	enhance	80.138565	28
46	185	enhance	79.918816	29
46	15	enhance	79.74017	30
46	86	enhance	79.60792	31
46	52	enhance	77.12382	32
46	176	enhance	77.09946	33
46	285	enhance	76.696335	34
46	51	enhance	76.310265	35
46	24	enhance	74.362465	36
46	27	enhance	73.67107	37
46	92	enhance	73.43481	38
46	26	enhance	73.23487	39
46	62	enhance	72.655205	40
46	81	enhance	71.482506	41
46	222	enhance	71.07623	42
46	98	enhance	70.88641	43
46	455	enhance	70.62162	44
46	89	enhance	70.434494	45
46	31	enhance	70.27686	46
46	901	enhance	68.29633	47
46	100	enhance	67.579384	48
46	56	enhance	67.35106	49
46	54	enhance	66.67326	50
46	47	enhance	65.3872	51
46	77	enhance	65.00804	52
46	39	enhance	64.91191	53
46	921	enhance	62.36744	54
46	7	enhance	61.335804	55
46	53	enhance	60.778557	56
46	187	enhance	58.35451	57
46	19	enhance	57.176113	58
46	94	enhance	55.330715	59
46	66	enhance	53.844963	60
46	640	enhance	53.72888	61
46	50	enhance	53.245514	62
46	61	enhance	51.162266	63
46	28	enhance	49.318863	64
46	230	enhance	46.65016	65
46	49	enhance	46.640438	66
46	182	enhance	46.616257	67
46	13	enhance	45.66081	68
46	65	enhance	44.799564	69
46	14	enhance	44.01129	70
46	63	enhance	43.184093	71
46	18	enhance	43.087162	72
46	78	enhance	42.954388	73
46	593	enhance	41.80111	74
46	32	enhance	39.79587	75
46	44	enhance	39.750843	76
46	30	enhance	39.62252	77
46	58	enhance	39.115997	78
46	73	enhance	36.39726	79
46	57	enhance	35.385754	80
46	868	enhance	34.53915	81
46	33	enhance	33.742184	82
46	34	enhance	33.405174	83
46	59	enhance	32.84563	84
46	43	enhance	32.294014	85
46	184	enhance	31.283606	86
46	8	enhance	30.146395	87
46	99	enhance	30.066235	88
46	70	enhance	30.025589	89
46	22	enhance	27.646309	90
46	72	enhance	26.676298	91
46	335	enhance	26.595758	92
46	45	enhance	26.372944	93
46	219	enhance	25.367727	94
46	79	enhance	23.183632	95
46	488	enhance	22.834297	96
46	82	enhance	22.707321	97
46	41	enhance	22.446577	98
46	93	enhance	22.15313	99
46	12	enhance	21.608376	100
46	83	enhance	21.25759	101
46	171	enhance	20.15137	102
46	5	enhance	19.84453	103
46	21	enhance	19.355038	104
46	69	enhance	19.31684	105
46	85	enhance	18.984823	106
46	35	enhance	18.766642	107
46	2	enhance	18.583183	108
46	55	enhance	17.70046	109
46	4	enhance	17.402838	110
46	126	enhance	17.129654	111
46	3	enhance	16.777246	112
46	96	enhance	16.504429	113
46	20	enhance	15.751508	114
46	9	enhance	15.273573	115
46	95	enhance	14.863622	116
46	60	enhance	14.664914	117
46	90	enhance	14.449547	118
46	23	enhance	13.102124	119
46	64	enhance	12.327702	120
46	91	enhance	11.5940695	121
46	11	enhance	11.574357	122
46	80	enhance	8.935243	123
46	74	enhance	5.820287	124
46	64	soften	100	1
46	11	soften	99.257126	2
46	74	soften	98.47866	3
46	80	soften	96.80781	4
46	60	soften	95.774826	5
46	91	soften	95.38763	6
46	90	soften	92.260635	7
46	55	soften	91.68497	8
46	126	soften	91.54341	9
46	3	soften	90.934044	10
46	83	soften	90.29003	11
46	23	soften	88.17199	12
46	72	soften	88.05113	13
46	79	soften	87.80865	14
46	93	soften	87.58964	15
46	4	soften	87.2813	16
46	96	soften	86.97187	17
46	21	soften	85.253914	18
46	171	soften	85.141205	19
46	70	soften	84.88181	20
46	20	soften	84.36744	21
46	45	soften	84.32749	22
46	9	soften	84.20397	23
46	2	soften	83.355644	24
46	5	soften	83.33752	25
46	184	soften	83.273384	26
46	335	soften	82.51735	27
46	85	soften	82.45536	28
46	82	soften	82.443085	29
46	35	soften	82.43008	30
46	219	soften	81.83506	31
46	12	soften	81.79433	32
46	95	soften	81.61845	33
46	34	soften	81.41916	34
46	22	soften	80.4631	35
46	99	soften	80.31947	36
46	43	soften	80.298546	37
46	868	soften	80.16313	38
46	59	soften	79.32231	39
46	33	soften	78.809364	40
46	69	soften	78.09042	41
46	41	soften	77.706604	42
46	73	soften	77.45102	43
46	49	soften	77.32119	44
46	30	soften	77.29482	45
46	182	soften	77.18845	46
46	13	soften	77.069244	47
46	78	soften	76.824326	48
46	18	soften	75.98336	49
46	63	soften	75.56404	50
46	593	soften	75.35693	51
46	8	soften	75.08515	52
46	44	soften	74.6338	53
46	28	soften	74.308136	54
46	94	soften	73.19631	55
46	230	soften	72.98043	56
46	50	soften	72.96747	57
46	61	soften	72.803635	58
46	488	soften	72.41567	59
46	640	soften	71.64979	60
46	66	soften	70.64479	61
46	187	soften	69.909615	62
46	39	soften	69.27966	63
46	58	soften	68.1981	64
46	7	soften	67.58036	65
46	222	soften	66.936356	66
46	56	soften	66.36828	67
46	92	soften	66.2896	68
46	14	soften	66.23379	69
46	54	soften	65.9503	70
46	47	soften	65.84039	71
46	31	soften	65.83695	72
46	19	soften	65.275345	73
46	89	soften	64.693436	74
46	98	soften	64.42678	75
46	285	soften	64.329475	76
46	176	soften	63.971928	77
46	65	soften	63.66358	78
46	455	soften	63.060642	79
46	32	soften	62.79614	80
46	27	soften	62.71666	81
46	10	soften	61.257935	82
46	51	soften	61.049213	83
46	921	soften	60.85254	84
46	24	soften	60.766113	85
46	26	soften	60.613853	86
46	108	soften	59.96396	87
46	901	soften	59.485115	88
46	52	soften	59.454105	89
46	62	soften	59.076008	90
46	86	soften	58.601326	91
46	88	soften	58.47196	92
46	647	soften	58.461433	93
46	77	soften	58.400276	94
46	1	soften	58.210556	95
46	185	soften	58.094986	96
46	100	soften	57.80501	97
46	53	soften	57.479782	98
46	67	soften	56.53525	99
46	84	soften	56.03429	100
46	785	soften	55.27092	101
46	36	soften	53.60452	102
46	6	soften	53.31475	103
46	71	soften	52.648376	104
46	17	soften	52.224953	105
46	97	soften	50.957047	106
46	40	soften	50.819256	107
46	68	soften	50.785065	108
46	87	soften	50.62571	109
46	48	soften	50.5249	110
46	358	soften	49.971348	111
46	25	soften	49.474464	112
46	155	soften	46.345882	113
46	882	soften	45.977913	114
47	61	enhance	100	1
47	222	enhance	97.918434	2
47	67	enhance	97.63602	3
47	640	enhance	97.46436	4
47	51	enhance	96.9111	5
47	13	enhance	96.88174	6
47	88	enhance	96.61637	7
47	285	enhance	95.02332	8
47	230	enhance	93.67486	9
47	98	enhance	92.45591	10
47	49	enhance	92.36647	11
47	31	enhance	91.76806	12
47	176	enhance	90.978424	13
47	92	enhance	90.73248	14
47	182	enhance	88.99307	15
47	56	enhance	88.47148	16
47	1	enhance	87.95724	17
47	84	enhance	86.722336	18
47	36	enhance	86.35202	19
47	33	enhance	85.589775	20
47	45	enhance	83.54271	21
47	50	enhance	82.717415	22
47	94	enhance	82.45452	23
47	126	enhance	81.27523	24
47	43	enhance	81.02048	25
47	34	enhance	80.86877	26
47	63	enhance	80.7714	27
47	187	enhance	80.7007	28
47	70	enhance	80.618996	29
47	68	enhance	80.45342	30
47	89	enhance	80.18078	31
47	19	enhance	79.776344	32
47	30	enhance	79.25932	33
47	108	enhance	77.320915	34
47	83	enhance	77.07214	35
47	99	enhance	76.13972	36
47	75	enhance	75.78502	37
47	72	enhance	75.39856	38
47	10	enhance	74.914474	39
47	40	enhance	74.47578	40
47	39	enhance	74.102585	41
47	647	enhance	73.84553	42
47	73	enhance	72.951706	43
47	71	enhance	72.94549	44
47	86	enhance	72.036354	45
47	46	enhance	71.87469	46
47	25	enhance	70.66647	47
47	48	enhance	70.64689	48
47	87	enhance	70.28395	49
47	80	enhance	70.12027	50
47	15	enhance	69.4428	51
47	90	enhance	69.156364	52
47	2	enhance	68.304276	53
47	7	enhance	67.968834	54
47	785	enhance	67.23886	55
47	155	enhance	66.9635	56
47	17	enhance	66.9427	57
47	882	enhance	65.82522	58
47	37	enhance	63.532555	59
47	24	enhance	62.886364	60
47	185	enhance	62.512196	61
47	82	enhance	61.69888	62
47	26	enhance	61.14246	63
47	54	enhance	60.349785	64
47	27	enhance	59.842224	65
47	3	enhance	58.9176	66
47	79	enhance	57.7221	67
47	76	enhance	57.141552	68
47	455	enhance	56.961666	69
47	358	enhance	56.779945	70
47	28	enhance	56.30436	71
47	93	enhance	55.882206	72
47	52	enhance	55.85028	73
47	18	enhance	55.767345	74
47	62	enhance	55.5761	75
47	6	enhance	55.179043	76
47	55	enhance	53.47819	77
47	593	enhance	53.343964	78
47	97	enhance	52.185673	79
47	66	enhance	51.13506	80
47	901	enhance	50.615562	81
47	38	enhance	49.42291	82
47	16	enhance	49.234863	83
47	78	enhance	47.99736	84
47	868	enhance	47.20742	85
47	42	enhance	46.800846	86
47	58	enhance	46.695217	87
47	81	enhance	45.410492	88
47	29	enhance	45.35031	89
47	921	enhance	45.302826	90
47	100	enhance	44.767746	91
47	77	enhance	43.785015	92
47	60	enhance	43.614697	93
47	44	enhance	42.93761	94
47	5	enhance	42.415806	95
47	184	enhance	42.043835	96
47	11	enhance	41.87205	97
47	59	enhance	41.39158	98
47	171	enhance	41.23505	99
47	14	enhance	37.968884	100
47	23	enhance	37.95835	101
47	91	enhance	37.571873	102
47	64	enhance	37.31709	103
47	74	enhance	36.91471	104
47	9	enhance	36.633137	105
47	8	enhance	36.481613	106
47	4	enhance	35.743645	107
47	219	enhance	34.93794	108
47	22	enhance	34.907173	109
47	96	enhance	34.44253	110
47	20	enhance	34.360706	111
47	95	enhance	33.81706	112
47	21	enhance	32.660484	113
47	32	enhance	32.33903	114
47	53	enhance	32.148808	115
47	335	enhance	31.866747	116
47	65	enhance	31.408266	117
47	57	enhance	29.182096	118
47	12	enhance	29.104582	119
47	85	enhance	28.339136	120
47	41	enhance	28.16375	121
47	69	enhance	27.789452	122
47	35	enhance	27.766087	123
47	488	enhance	27.325186	124
47	64	soften	100	1
47	74	soften	96.97169	2
47	11	soften	95.05953	3
47	91	soften	92.96433	4
47	96	soften	89.58988	5
47	184	soften	89.33752	6
47	60	soften	89.1666	7
47	335	soften	87.056244	8
47	80	soften	86.903114	9
47	55	soften	86.06793	10
47	22	soften	85.90102	11
47	93	soften	85.44623	12
47	21	soften	85.42209	13
47	3	soften	85.34014	14
47	4	soften	85.114944	15
47	79	soften	84.256386	16
47	23	soften	84.123215	17
47	219	soften	84.05741	18
47	868	soften	83.32657	19
47	20	soften	83.29816	20
47	171	soften	82.814545	21
47	78	soften	82.51841	22
47	85	soften	81.81431	23
47	90	soften	81.53154	24
47	9	soften	81.31955	25
47	59	soften	81.2193	26
47	12	soften	81.09197	27
47	44	soften	81.07764	28
47	35	soften	80.85745	29
47	83	soften	80.50603	30
47	95	soften	80.4813	31
47	126	soften	80.07266	32
47	72	soften	79.66873	33
47	41	soften	79.57496	34
47	5	soften	79.45397	35
47	70	soften	79.1944	36
47	18	soften	78.854774	37
47	45	soften	78.428246	38
47	69	soften	77.72273	39
47	593	soften	76.35205	40
47	30	soften	76.030235	41
47	2	soften	75.96659	42
47	73	soften	75.73869	43
47	28	soften	75.5043	44
47	82	soften	75.498924	45
47	34	soften	75.40158	46
47	39	soften	75.02509	47
47	43	soften	74.951584	48
47	66	soften	74.620445	49
47	99	soften	74.18666	50
47	8	soften	73.86365	51
47	94	soften	73.849205	52
47	63	soften	73.27172	53
47	49	soften	73.09869	54
47	27	soften	71.44018	55
47	13	soften	70.65503	56
47	182	soften	70.60959	57
47	7	soften	70.288216	58
47	50	soften	69.81966	59
47	187	soften	68.90527	60
47	86	soften	68.7809	61
47	33	soften	68.491776	62
47	92	soften	67.83753	63
47	285	soften	67.41212	64
47	176	soften	66.851006	65
47	222	soften	66.77411	66
47	61	soften	66.735054	67
47	230	soften	66.42274	68
47	640	soften	66.21608	69
47	31	soften	65.80163	70
47	51	soften	61.62985	71
48	68	enhance	100	1
48	25	enhance	99.68036	2
48	40	enhance	99.51955	3
48	71	enhance	98.85171	4
48	75	enhance	98.58273	5
48	36	enhance	98.085464	6
48	87	enhance	98.00777	7
48	17	enhance	96.325584	8
48	108	enhance	95.5918	9
48	155	enhance	95.080124	10
48	882	enhance	94.87132	11
48	46	enhance	93.92698	12
48	358	enhance	93.35848	13
48	1	enhance	93.265564	14
48	785	enhance	93.19529	15
48	84	enhance	93.03402	16
48	97	enhance	91.615074	17
48	6	enhance	91.304375	18
48	16	enhance	91.11323	19
48	647	enhance	89.7977	20
48	76	enhance	89.765205	21
48	86	enhance	89.60573	22
48	88	enhance	89.3084	23
48	52	enhance	88.70786	24
48	38	enhance	88.538155	25
48	15	enhance	87.39212	26
48	42	enhance	86.92598	27
48	285	enhance	86.52521	28
48	29	enhance	85.712944	29
48	185	enhance	85.53841	30
48	10	enhance	84.81112	31
48	176	enhance	84.0285	32
48	92	enhance	83.67843	33
48	37	enhance	82.35895	34
48	24	enhance	81.92667	35
48	455	enhance	81.86889	36
48	89	enhance	81.355415	37
48	31	enhance	80.86695	38
48	98	enhance	80.22965	39
48	62	enhance	80.1557	40
48	67	enhance	78.750786	41
48	7	enhance	78.4487	42
48	39	enhance	78.23196	43
48	27	enhance	77.89906	44
48	100	enhance	75.26263	45
48	222	enhance	75.18357	46
48	901	enhance	74.05076	47
48	77	enhance	72.85358	48
48	54	enhance	72.2006	49
48	26	enhance	71.75439	50
48	51	enhance	71.12274	51
48	81	enhance	71.07269	52
48	94	enhance	70.69063	53
48	56	enhance	68.93157	54
48	187	enhance	68.44141	55
48	921	enhance	65.05237	56
48	19	enhance	64.9353	57
48	47	enhance	64.022125	58
48	53	enhance	62.805393	59
48	66	enhance	61.52965	60
48	640	enhance	60.9912	61
48	63	enhance	60.94424	62
48	50	enhance	60.845245	63
48	49	enhance	60.76964	64
48	28	enhance	58.798492	65
48	61	enhance	58.339725	66
48	593	enhance	57.47776	67
48	13	enhance	56.488182	68
48	182	enhance	55.476463	69
48	230	enhance	54.780327	70
48	44	enhance	52.372055	71
48	78	enhance	52.21132	72
48	18	enhance	51.805786	73
48	58	enhance	51.50394	74
48	65	enhance	50.234257	75
48	868	enhance	49.967415	76
48	32	enhance	48.6274	77
48	14	enhance	48.56202	78
48	43	enhance	46.709026	79
48	99	enhance	45.677326	80
48	30	enhance	45.10892	81
48	34	enhance	44.45148	82
48	70	enhance	44.098747	83
48	33	enhance	43.513657	84
48	59	enhance	43.430405	85
48	73	enhance	42.870502	86
48	184	enhance	41.57531	87
48	8	enhance	39.07213	88
48	57	enhance	38.85142	89
48	45	enhance	38.78529	90
48	22	enhance	37.72257	91
48	72	enhance	37.637375	92
48	93	enhance	37.284203	93
48	335	enhance	36.944744	94
48	219	enhance	35.733124	95
48	79	enhance	34.8264	96
48	82	enhance	34.13283	97
48	41	enhance	32.794758	98
48	12	enhance	32.417717	99
48	5	enhance	32.19054	100
48	2	enhance	31.553513	101
48	83	enhance	31.422293	102
48	21	enhance	30.734024	103
48	69	enhance	30.519648	104
48	3	enhance	29.96508	105
48	85	enhance	29.78188	106
48	126	enhance	29.585257	107
48	488	enhance	29.45814	108
48	55	enhance	29.258347	109
48	4	enhance	29.107407	110
48	35	enhance	29.101458	111
48	171	enhance	28.94501	112
48	90	enhance	28.59729	113
48	96	enhance	28.030287	114
48	9	enhance	27.269426	115
48	23	enhance	27.095463	116
48	20	enhance	25.84056	117
48	60	enhance	25.762493	118
48	91	enhance	24.982244	119
48	64	enhance	24.36765	120
48	11	enhance	23.272356	121
48	95	enhance	22.481977	122
48	80	enhance	21.479927	123
48	74	enhance	18.97684	124
48	11	soften	100	1
48	64	soften	99.99455	2
48	74	soften	98.04505	3
48	60	soften	97.24173	4
48	80	soften	97.23781	5
48	91	soften	95.33064	6
48	55	soften	93.72486	7
48	90	soften	93.41179	8
48	126	soften	93.083176	9
48	83	soften	92.54879	10
48	3	soften	92.26304	11
48	72	soften	90.2998	12
48	23	soften	89.06465	13
48	4	soften	88.57233	14
48	96	soften	88.43687	15
48	93	soften	88.415115	16
48	79	soften	88.14837	17
48	171	soften	87.06442	18
48	70	soften	86.46481	19
48	21	soften	86.05786	20
48	20	soften	85.85643	21
48	45	soften	85.4473	22
48	9	soften	85.42903	23
48	2	soften	85.1125	24
48	184	soften	84.91899	25
48	82	soften	84.68888	26
48	335	soften	84.362335	27
48	5	soften	84.30561	28
48	34	soften	83.82951	29
48	35	soften	83.762054	30
48	95	soften	83.73927	31
48	219	soften	83.69464	32
48	85	soften	83.31087	33
48	12	soften	83.13506	34
48	22	soften	82.392456	35
48	99	soften	81.89256	36
48	43	soften	81.733894	37
48	868	soften	81.44158	38
48	33	soften	81.33893	39
48	59	soften	81.207115	40
48	30	soften	79.99631	41
48	182	soften	79.93388	42
48	13	soften	79.63901	43
48	41	soften	79.61024	44
48	73	soften	79.48643	45
48	69	soften	79.19123	46
48	78	soften	79.07307	47
48	49	soften	78.75254	48
48	18	soften	77.9774	49
48	8	soften	77.05848	50
48	63	soften	76.91302	51
48	593	soften	76.730415	52
48	44	soften	76.38895	53
48	28	soften	76.07169	54
48	50	soften	75.66932	55
48	61	soften	75.576195	56
48	230	soften	75.54126	57
48	640	soften	74.82621	58
48	94	soften	74.57846	59
48	488	soften	74.248505	60
48	66	soften	73.204765	61
48	187	soften	72.32479	62
48	39	soften	71.307274	63
48	222	soften	71.14062	64
48	47	soften	70.02549	65
48	56	soften	69.88335	66
48	58	soften	69.792984	67
48	7	soften	69.15483	68
48	92	soften	69.15275	69
48	14	soften	69.15119	70
48	54	soften	68.655304	71
48	31	soften	68.43886	72
48	19	soften	67.95103	73
48	176	soften	67.267586	74
48	51	soften	67.01817	75
48	98	soften	66.94902	76
48	89	soften	66.920044	77
48	285	soften	66.91286	78
48	65	soften	66.26856	79
48	27	soften	65.68695	80
48	455	soften	65.085365	81
48	10	soften	64.546936	82
48	26	soften	64.385185	83
48	921	soften	63.920105	84
48	24	soften	63.381554	85
48	901	soften	62.204	86
48	108	soften	61.959873	87
48	647	soften	61.711414	88
48	67	soften	61.621914	89
48	62	soften	61.48624	90
48	88	soften	61.47636	91
48	52	soften	61.345505	92
48	86	soften	61.12298	93
48	1	soften	61.11401	94
48	185	soften	60.999004	95
48	77	soften	60.89513	96
48	100	soften	60.344883	97
48	84	soften	60.181488	98
48	785	soften	59.032333	99
48	36	soften	56.41412	100
48	6	soften	56.316162	101
48	17	soften	56.10148	102
48	71	soften	55.679214	103
48	87	soften	54.603447	104
48	97	soften	53.8184	105
48	40	soften	53.380436	106
48	25	soften	52.702934	107
49	13	enhance	100	1
49	61	enhance	98.83465	2
49	43	enhance	97.05886	3
49	126	enhance	97.028305	4
49	182	enhance	96.28738	5
49	230	enhance	96.23677	6
49	94	enhance	95.97785	7
49	63	enhance	95.948715	8
49	45	enhance	95.629814	9
49	70	enhance	95.55968	10
49	98	enhance	95.15314	11
49	640	enhance	94.12404	12
49	34	enhance	94.11898	13
49	99	enhance	93.72449	14
49	31	enhance	92.91285	15
49	285	enhance	91.85704	16
49	80	enhance	91.26886	17
49	33	enhance	90.63633	18
49	50	enhance	90.47228	19
49	90	enhance	90.06466	20
49	39	enhance	89.71546	21
49	88	enhance	88.77946	22
49	47	enhance	88.11318	23
49	30	enhance	87.205154	24
49	79	enhance	87.179054	25
49	83	enhance	86.96657	26
49	2	enhance	86.43659	27
49	73	enhance	86.27939	28
49	72	enhance	86.154785	29
49	222	enhance	84.83461	30
49	92	enhance	83.65517	31
49	108	enhance	83.35655	32
49	56	enhance	82.53539	33
49	176	enhance	80.89925	34
49	89	enhance	80.752815	35
49	3	enhance	80.36879	36
49	187	enhance	80.17892	37
49	93	enhance	79.97875	38
49	7	enhance	78.65929	39
49	18	enhance	78.54873	40
49	593	enhance	78.26308	41
49	28	enhance	77.339874	42
49	82	enhance	77.14408	43
49	19	enhance	76.88808	44
49	54	enhance	75.68116	45
49	86	enhance	75.32011	46
49	1	enhance	74.86592	47
49	36	enhance	74.79682	48
49	647	enhance	74.689316	49
49	10	enhance	73.49824	50
49	27	enhance	72.64968	51
49	84	enhance	71.64531	52
49	66	enhance	70.67178	53
49	40	enhance	70.360245	54
49	455	enhance	70.012566	55
49	55	enhance	69.386505	56
49	52	enhance	69.25071	57
49	78	enhance	68.95474	58
49	5	enhance	67.57492	59
49	67	enhance	67.48641	60
49	51	enhance	67.14632	61
49	68	enhance	66.72016	62
49	23	enhance	65.95253	63
49	24	enhance	65.755455	64
49	71	enhance	64.4672	65
49	74	enhance	64.3762	66
49	48	enhance	63.969975	67
49	59	enhance	63.662693	68
49	44	enhance	63.587387	69
49	184	enhance	63.24011	70
49	91	enhance	62.875793	71
49	868	enhance	62.008118	72
49	11	enhance	61.63761	73
49	185	enhance	61.423107	74
49	60	enhance	61.208107	75
49	62	enhance	60.97123	76
49	64	enhance	60.821716	77
49	15	enhance	60.68382	78
49	21	enhance	60.614388	79
49	25	enhance	59.837112	80
49	9	enhance	59.602177	81
49	6	enhance	59.312954	82
49	58	enhance	59.139774	83
49	17	enhance	59.112373	84
49	785	enhance	58.594982	85
49	4	enhance	57.94009	86
49	97	enhance	57.79538	87
49	75	enhance	57.79428	88
49	96	enhance	56.890373	89
49	171	enhance	55.995083	90
49	87	enhance	55.97934	91
49	219	enhance	55.897655	92
49	85	enhance	55.092785	93
49	22	enhance	54.769188	94
49	100	enhance	54.544655	95
49	12	enhance	54.433662	96
49	8	enhance	54.372307	97
49	69	enhance	54.333565	98
49	20	enhance	53.988045	99
49	335	enhance	53.98171	100
49	26	enhance	53.86843	101
49	77	enhance	53.8649	102
49	37	enhance	52.881783	103
49	35	enhance	52.195	104
49	921	enhance	51.768356	105
49	76	enhance	51.31504	106
49	38	enhance	50.83217	107
49	358	enhance	50.29523	108
49	16	enhance	49.914597	109
49	42	enhance	49.573772	110
49	41	enhance	48.967236	111
49	46	enhance	48.907154	112
49	32	enhance	47.637196	113
49	29	enhance	47.337257	114
49	901	enhance	46.65642	115
49	155	enhance	46.580376	116
49	95	enhance	46.42521	117
49	53	enhance	45.754753	118
49	14	enhance	45.5814	119
49	882	enhance	45.507256	120
49	65	enhance	43.770466	121
49	488	enhance	43.749416	122
49	81	enhance	43.08401	123
49	57	enhance	35.922337	124
49	64	soften	100	1
49	11	soften	97.62407	2
49	74	soften	96.188446	3
49	60	soften	94.372246	4
49	91	soften	94.05981	5
49	96	soften	90.78673	6
49	55	soften	90.49507	7
49	184	soften	90.11454	8
49	335	soften	89.19084	9
49	4	soften	87.87064	10
49	22	soften	87.55425	11
49	868	soften	87.02367	12
49	3	soften	86.615166	13
49	171	soften	86.57172	14
49	21	soften	86.307884	15
49	219	soften	86.2153	16
49	83	soften	85.48804	17
49	93	soften	85.2785	18
49	20	soften	85.27611	19
49	80	soften	84.77454	20
49	72	soften	84.69497	21
49	23	soften	84.57355	22
49	59	soften	83.847176	23
49	9	soften	83.56921	24
49	78	soften	83.56577	25
49	79	soften	82.27702	26
49	44	soften	81.98318	27
49	90	soften	81.68683	28
49	126	soften	81.481804	29
49	70	soften	81.32383	30
49	45	soften	78.54238	31
49	13	soften	73.44264	32
50	182	enhance	100	1
50	82	enhance	95.76309	2
50	593	enhance	95.24156	3
50	99	enhance	95.14536	4
50	34	enhance	94.9112	5
50	94	enhance	93.49117	6
50	70	enhance	92.2941	7
50	63	enhance	90.62284	8
50	66	enhance	90.51911	9
50	90	enhance	90.46127	10
50	5	enhance	90.40902	11
50	10	enhance	89.53551	12
50	54	enhance	89.37262	13
50	49	enhance	89.333855	14
50	126	enhance	88.566154	15
50	72	enhance	88.22224	16
50	43	enhance	87.904434	17
50	3	enhance	87.85447	18
50	83	enhance	87.7948	19
50	7	enhance	87.69901	20
50	39	enhance	87.51233	21
50	93	enhance	87.22118	22
50	92	enhance	87.17323	23
50	23	enhance	86.88471	24
50	18	enhance	86.66325	25
50	28	enhance	86.61641	26
50	78	enhance	86.37231	27
50	59	enhance	86.35122	28
50	2	enhance	85.975586	29
50	13	enhance	85.87615	30
50	187	enhance	85.677574	31
50	55	enhance	85.54469	32
50	230	enhance	85.326675	33
50	27	enhance	85.29203	34
50	8	enhance	84.746574	35
50	640	enhance	84.04628	36
50	19	enhance	83.53707	37
50	79	enhance	83.382355	38
50	61	enhance	82.61722	39
50	4	enhance	82.13581	40
50	455	enhance	81.10776	41
50	9	enhance	81.01007	42
50	219	enhance	80.92726	43
50	98	enhance	80.52015	44
50	21	enhance	80.40753	45
50	12	enhance	80.2953	46
50	31	enhance	79.83738	47
50	184	enhance	79.73277	48
50	44	enhance	79.62997	49
50	35	enhance	78.988556	50
50	60	enhance	78.874466	51
50	176	enhance	78.84058	52
50	85	enhance	78.80724	53
50	335	enhance	78.75733	54
50	285	enhance	78.52987	55
50	47	enhance	77.91553	56
50	52	enhance	77.88709	57
50	108	enhance	77.802086	58
50	222	enhance	77.6339	59
50	33	enhance	77.622604	60
50	868	enhance	77.187935	61
50	171	enhance	77.179665	62
50	91	enhance	77.09408	63
50	56	enhance	76.98137	64
50	69	enhance	76.73602	65
50	41	enhance	76.3775	66
50	22	enhance	76.05609	67
50	20	enhance	75.64924	68
50	88	enhance	75.43079	69
50	11	enhance	75.237366	70
50	14	enhance	75.11477	71
50	96	enhance	75.02904	72
50	185	enhance	74.94071	73
50	89	enhance	74.901726	74
50	77	enhance	74.784515	75
50	647	enhance	74.73075	76
50	100	enhance	74.72293	77
50	65	enhance	74.186905	78
50	45	enhance	74.13634	79
50	58	enhance	73.39158	80
50	80	enhance	73.05963	81
50	74	enhance	72.76125	82
50	62	enhance	72.70776	83
50	64	enhance	72.61059	84
50	921	enhance	72.45495	85
50	785	enhance	71.96839	86
50	24	enhance	71.03729	87
50	32	enhance	70.74314	88
50	26	enhance	69.369644	89
50	81	enhance	69.193825	90
50	86	enhance	68.97012	91
50	488	enhance	68.31542	92
50	68	enhance	68.178764	93
50	37	enhance	67.63275	94
50	53	enhance	67.49541	95
50	17	enhance	67.407166	96
50	71	enhance	66.864075	97
50	73	enhance	66.222916	98
50	1	enhance	66.060616	99
50	76	enhance	66.01133	100
50	36	enhance	65.9716	101
50	15	enhance	65.937584	102
50	84	enhance	65.51857	103
50	30	enhance	65.41747	104
50	901	enhance	65.280205	105
50	95	enhance	65.08206	106
50	42	enhance	64.856445	107
50	38	enhance	64.837204	108
50	51	enhance	64.65519	109
50	16	enhance	63.613163	110
50	6	enhance	63.554256	111
50	48	enhance	63.24361	112
50	29	enhance	63.034378	113
50	358	enhance	62.106853	114
50	67	enhance	60.522957	115
50	40	enhance	59.852856	116
50	97	enhance	59.591106	117
50	57	enhance	59.073627	118
50	87	enhance	57.547672	119
50	46	enhance	55.130676	120
50	75	enhance	54.001842	121
50	25	enhance	53.85972	122
50	882	enhance	47.573006	123
50	155	enhance	47.531654	124
50	11	soften	100	1
50	91	soften	97.029396	2
50	60	soften	96.33591	3
50	184	soften	92.67646	4
50	80	soften	92.66684	5
50	55	soften	92.31166	6
50	96	soften	91.24364	7
50	93	soften	91.02961	8
50	3	soften	90.76898	9
50	72	soften	90.560135	10
50	83	soften	89.92713	11
50	868	soften	89.57022	12
50	335	soften	89.50597	13
50	22	soften	89.49416	14
50	90	soften	88.93496	15
50	4	soften	88.61505	16
50	126	soften	88.37124	17
50	79	soften	88.01351	18
50	70	soften	87.93645	19
50	21	soften	86.96605	20
50	23	soften	86.39943	21
50	44	soften	85.83157	22
50	219	soften	85.688736	23
50	78	soften	85.67185	24
50	171	soften	85.49906	25
50	45	soften	85.366684	26
50	59	soften	85.27926	27
50	9	soften	84.07975	28
50	20	soften	83.93352	29
50	12	soften	83.19787	30
50	85	soften	82.98332	31
50	30	soften	82.44326	32
50	13	soften	82.297455	33
50	5	soften	82.29069	34
50	18	soften	81.88393	35
50	35	soften	81.81066	36
50	39	soften	81.669525	37
50	34	soften	81.57524	38
50	41	soften	81.314354	39
50	73	soften	81.291275	40
50	43	soften	80.89454	41
50	2	soften	80.83331	42
50	99	soften	80.6754	43
50	82	soften	80.66512	44
50	593	soften	80.521645	45
50	28	soften	80.45959	46
50	66	soften	80.117714	47
50	182	soften	80.04251	48
50	63	soften	79.50412	49
50	33	soften	78.94008	50
50	69	soften	78.81554	51
50	285	soften	78.77319	52
50	640	soften	77.84095	53
50	230	soften	75.844	54
50	64	soften	72.226105	55
50	74	soften	68.54338	56
50	94	soften	57.773365	57
50	49	soften	57.65395	58
50	95	soften	56.856716	59
50	222	soften	56.473682	60
50	92	soften	54.93536	61
50	61	soften	54.33323	62
51	67	enhance	100	1
51	222	enhance	96.89242	2
51	176	enhance	90.03331	3
51	47	enhance	88.76946	4
51	92	enhance	87.105934	5
51	285	enhance	85.22755	6
51	88	enhance	83.3552	7
51	84	enhance	82.48768	8
51	640	enhance	79.67465	9
51	75	enhance	78.66998	10
51	68	enhance	78.164314	11
51	155	enhance	78.07624	12
51	13	enhance	77.66757	13
51	98	enhance	77.49552	14
51	1	enhance	77.26184	15
51	87	enhance	77.16646	16
51	36	enhance	76.8656	17
51	46	enhance	76.8345	18
51	882	enhance	75.70165	19
51	25	enhance	75.528275	20
51	31	enhance	74.39313	21
51	71	enhance	73.70619	22
51	61	enhance	72.58487	23
51	182	enhance	72.17641	24
51	48	enhance	71.88885	25
51	10	enhance	71.13544	26
51	86	enhance	71.11913	27
51	40	enhance	70.65986	28
51	15	enhance	70.57256	29
51	94	enhance	70.4121	30
51	785	enhance	67.45946	31
51	19	enhance	67.451706	32
51	17	enhance	67.34868	33
51	108	enhance	67.01422	34
51	230	enhance	65.70986	35
51	49	enhance	64.47417	36
51	72	enhance	63.217014	37
51	50	enhance	62.87332	38
51	37	enhance	61.411217	39
51	70	enhance	61.35224	40
51	187	enhance	61.258686	41
51	33	enhance	61.161804	42
51	39	enhance	60.029243	43
51	358	enhance	59.597824	44
51	647	enhance	59.137444	45
51	76	enhance	58.81883	46
51	7	enhance	58.186954	47
51	83	enhance	56.68691	48
51	56	enhance	56.171696	49
51	89	enhance	55.588726	50
51	24	enhance	55.5633	51
51	63	enhance	53.648853	52
51	99	enhance	53.566124	53
51	52	enhance	53.071667	54
51	27	enhance	52.488705	55
51	185	enhance	50.664257	56
51	126	enhance	50.572086	57
51	97	enhance	49.332077	58
51	6	enhance	49.209743	59
51	38	enhance	49.12275	60
51	16	enhance	48.797913	61
51	66	enhance	47.489853	62
51	90	enhance	47.39346	63
51	34	enhance	47.31641	64
51	455	enhance	47.12434	65
51	54	enhance	46.667892	66
51	42	enhance	45.336292	67
51	43	enhance	45.101543	68
51	901	enhance	44.983425	69
51	868	enhance	44.189953	70
51	29	enhance	43.53933	71
51	62	enhance	43.084934	72
51	82	enhance	42.9811	73
51	93	enhance	42.68169	74
51	45	enhance	42.582275	75
51	100	enhance	42.05072	76
51	26	enhance	41.92765	77
51	593	enhance	41.400166	78
51	55	enhance	41.352665	79
51	44	enhance	41.19568	80
51	77	enhance	40.53769	81
51	3	enhance	39.70184	82
51	60	enhance	39.273163	83
51	28	enhance	39.227867	84
51	81	enhance	37.14206	85
51	30	enhance	37.10606	86
51	59	enhance	36.797592	87
51	2	enhance	36.72878	88
51	78	enhance	34.404415	89
51	184	enhance	32.903625	90
51	22	enhance	32.62494	91
51	11	enhance	31.30456	92
51	73	enhance	31.086098	93
51	18	enhance	30.65181	94
51	58	enhance	30.621656	95
51	91	enhance	30.57463	96
51	80	enhance	30.42669	97
51	4	enhance	30.401196	98
51	5	enhance	29.758596	99
51	921	enhance	29.460238	100
51	79	enhance	28.786114	101
51	335	enhance	27.283594	102
51	9	enhance	27.062895	103
51	53	enhance	26.112879	104
51	64	enhance	26.105774	105
51	23	enhance	25.281174	106
51	14	enhance	25.237106	107
51	8	enhance	23.003788	108
51	41	enhance	22.905046	109
51	12	enhance	22.782005	110
51	171	enhance	22.493065	111
51	65	enhance	22.292389	112
51	96	enhance	22.166666	113
51	32	enhance	21.777777	114
51	219	enhance	21.776722	115
51	21	enhance	21.399166	116
51	85	enhance	18.649393	117
51	69	enhance	18.44547	118
51	74	enhance	18.05508	119
51	57	enhance	16.622128	120
51	35	enhance	15.963166	121
51	20	enhance	12.9498415	122
51	488	enhance	10.185204	123
51	95	enhance	9.34449	124
51	64	soften	100	1
51	74	soften	97.29511	2
51	11	soften	95.15045	3
51	91	soften	91.51015	4
51	80	soften	90.91523	5
51	60	soften	87.807526	6
51	96	soften	87.600365	7
51	184	soften	87.071075	8
51	3	soften	86.34912	9
51	79	soften	85.98428	10
51	55	soften	85.31712	11
51	23	soften	84.93509	12
51	93	soften	84.81437	13
51	21	soften	84.344406	14
51	4	soften	84.33435	15
51	335	soften	84.22327	16
51	90	soften	83.745544	17
51	20	soften	83.3972	18
51	219	soften	83.023735	19
51	22	soften	82.771515	20
51	171	soften	82.46958	21
51	126	soften	82.05184	22
51	85	soften	81.00031	23
51	9	soften	80.68234	24
51	78	soften	80.67831	25
51	35	soften	80.53742	26
51	5	soften	79.81511	27
51	95	soften	79.81506	28
51	83	soften	79.72979	29
51	45	soften	79.60159	30
51	12	soften	79.389626	31
51	868	soften	78.963425	32
51	18	soften	78.29086	33
51	59	soften	78.197365	34
51	30	soften	78.160576	35
51	70	soften	77.875465	36
51	2	soften	77.82713	37
51	41	soften	77.796524	38
51	44	soften	77.69121	39
51	72	soften	77.63032	40
51	73	soften	77.61833	41
51	43	soften	77.10634	42
51	69	soften	76.84876	43
51	34	soften	76.37811	44
51	99	soften	75.445015	45
51	82	soften	75.32154	46
51	593	soften	74.95207	47
51	28	soften	74.71449	48
51	63	soften	73.10155	49
51	49	soften	72.446205	50
51	39	soften	72.3909	51
51	66	soften	71.34088	52
51	94	soften	70.4054	53
51	33	soften	69.84331	54
51	182	soften	69.606255	55
51	50	soften	69.13445	56
51	13	soften	68.90984	57
51	230	soften	66.76625	58
51	61	soften	66.02654	59
51	640	soften	64.54658	60
51	92	soften	62.74564	61
51	285	soften	61.835197	62
51	222	soften	60.30113	63
52	455	enhance	100	1
52	27	enhance	97.064674	2
52	6	enhance	94.67558	3
52	10	enhance	94.503716	4
52	54	enhance	93.96708	5
52	97	enhance	93.88571	6
52	38	enhance	93.62572	7
52	24	enhance	93.20818	8
52	16	enhance	93.12415	9
52	42	enhance	93.059845	10
52	100	enhance	92.89026	11
52	185	enhance	92.46529	12
52	62	enhance	92.324875	13
52	86	enhance	92.244804	14
52	108	enhance	91.9486	15
52	785	enhance	91.83017	16
52	77	enhance	91.55205	17
52	76	enhance	91.205864	18
52	358	enhance	90.97385	19
52	48	enhance	89.97108	20
52	29	enhance	89.89833	21
52	66	enhance	89.70836	22
52	17	enhance	89.620834	23
52	647	enhance	89.091805	24
52	71	enhance	88.28252	25
52	7	enhance	87.22978	26
52	39	enhance	87.18478	27
52	593	enhance	86.17599	28
52	68	enhance	86.0818	29
52	87	enhance	85.576164	30
52	40	enhance	85.02539	31
52	36	enhance	84.47614	32
52	94	enhance	84.161026	33
52	78	enhance	84.01802	34
52	53	enhance	83.44579	35
52	18	enhance	82.87895	36
52	84	enhance	82.72909	37
52	176	enhance	82.601746	38
52	25	enhance	82.29988	39
52	28	enhance	82.04642	40
52	921	enhance	81.68554	41
52	1	enhance	81.52165	42
52	285	enhance	81.41557	43
52	92	enhance	81.250626	44
52	81	enhance	80.92418	45
52	15	enhance	79.91944	46
52	75	enhance	79.28343	47
52	89	enhance	79.21177	48
52	37	enhance	79.090034	49
52	59	enhance	78.76649	50
52	44	enhance	78.72396	51
52	155	enhance	78.39108	52
52	46	enhance	77.92011	53
52	65	enhance	77.671486	54
52	882	enhance	77.58408	55
52	901	enhance	76.269485	56
52	26	enhance	76.23512	57
52	50	enhance	76.00047	58
52	58	enhance	74.89048	59
52	32	enhance	74.29484	60
52	88	enhance	74.28357	61
52	868	enhance	73.86334	62
52	184	enhance	73.6581	63
52	219	enhance	73.01053	64
52	335	enhance	72.98984	65
52	12	enhance	72.30404	66
52	14	enhance	72.270615	67
52	8	enhance	71.93407	68
52	21	enhance	71.85518	69
52	85	enhance	71.117134	70
52	19	enhance	70.88933	71
52	69	enhance	70.585495	72
52	187	enhance	70.24078	73
52	22	enhance	69.92843	74
52	35	enhance	69.86274	75
52	98	enhance	69.58647	76
52	31	enhance	69.17423	77
52	5	enhance	69.11648	78
52	41	enhance	69.039276	79
52	63	enhance	67.755646	80
52	79	enhance	67.63761	81
52	49	enhance	66.723	82
52	56	enhance	66.33351	83
52	4	enhance	65.728	84
52	9	enhance	64.83903	85
52	93	enhance	64.794495	86
52	23	enhance	64.41171	87
52	96	enhance	64.26911	88
52	20	enhance	63.0666	89
52	182	enhance	62.984768	90
52	222	enhance	62.67754	91
52	488	enhance	62.340763	92
52	34	enhance	61.757687	93
52	171	enhance	61.445656	94
52	91	enhance	61.265606	95
52	70	enhance	61.219574	96
52	82	enhance	59.987076	97
52	3	enhance	59.594925	98
52	74	enhance	58.657387	99
52	55	enhance	58.49356	100
52	64	enhance	57.736282	101
52	99	enhance	56.41988	102
52	43	enhance	56.35071	103
52	73	enhance	56.252808	104
52	60	enhance	55.79141	105
52	72	enhance	55.417953	106
52	67	enhance	55.33157	107
52	57	enhance	54.80029	108
52	11	enhance	54.57535	109
52	95	enhance	54.048367	110
52	51	enhance	53.253784	111
52	83	enhance	51.93425	112
52	13	enhance	51.780518	113
52	47	enhance	51.33377	114
52	640	enhance	49.732998	115
52	61	enhance	49.196087	116
52	30	enhance	49.134037	117
52	45	enhance	48.518562	118
52	230	enhance	48.169575	119
52	90	enhance	48.102978	120
52	126	enhance	45.449734	121
52	2	enhance	44.86681	122
52	80	enhance	41.516068	123
52	33	enhance	33.391575	124
52	11	soften	100	1
52	80	soften	99.49896	2
52	60	soften	98.362114	3
52	126	soften	97.38769	4
52	90	soften	97.07407	5
52	83	soften	96.641014	6
52	72	soften	95.36249	7
52	55	soften	94.99107	8
52	3	soften	93.79136	9
52	91	soften	93.23212	10
52	70	soften	90.154396	11
52	93	soften	89.4185	12
52	45	soften	88.906235	13
52	33	soften	88.79954	14
52	79	soften	88.11413	15
52	4	soften	87.338554	16
52	23	soften	86.978226	17
52	34	soften	86.81255	18
52	13	soften	86.7782	19
52	2	soften	86.60045	20
52	99	soften	85.58543	21
52	43	soften	85.468864	22
52	82	soften	85.27269	23
52	182	soften	85.241196	24
52	171	soften	85.22666	25
52	30	soften	85.06854	26
52	96	soften	84.71862	27
52	184	soften	83.88164	28
52	9	soften	83.11622	29
52	73	soften	82.891045	30
52	5	soften	82.774254	31
52	640	soften	82.288086	32
52	21	soften	82.285255	33
52	20	soften	82.218956	34
52	868	soften	81.72351	35
52	335	soften	81.62303	36
52	230	soften	81.59283	37
52	219	soften	81.06797	38
52	22	soften	80.94489	39
52	35	soften	80.06664	40
52	59	soften	79.883995	41
52	63	soften	79.86444	42
52	12	soften	79.82043	43
52	85	soften	79.19784	44
52	50	soften	78.88209	45
52	78	soften	78.70697	46
52	28	soften	77.82018	47
52	18	soften	77.64363	48
52	593	soften	77.07591	49
52	187	soften	76.97596	50
52	44	soften	76.82813	51
52	41	soften	76.72019	52
52	8	soften	76.154305	53
52	69	soften	75.39468	54
52	39	soften	74.75327	55
52	66	soften	74.42544	56
52	98	soften	74.0004	57
52	285	soften	73.3303	58
52	176	soften	72.28408	59
52	7	soften	72.19479	60
52	89	soften	70.69265	61
52	54	soften	70.47873	62
52	64	soften	68.84344	63
52	58	soften	68.67691	64
52	27	soften	68.08248	65
52	10	soften	67.8742	66
52	455	soften	66.10641	67
52	86	soften	65.685486	68
52	74	soften	65.40754	69
52	49	soften	59.00936	70
52	61	soften	57.81673	71
52	95	soften	55.9009	72
52	222	soften	55.38889	73
52	94	soften	54.845715	74
52	47	soften	54.100433	75
52	51	soften	53.45658	76
52	56	soften	52.329517	77
52	31	soften	52.251915	78
52	92	soften	52.227093	79
52	67	soften	49.203804	80
52	84	soften	46.109043	81
53	32	enhance	100	1
53	54	enhance	99.994354	2
53	29	enhance	98.89746	3
53	921	enhance	98.65679	4
53	100	enhance	96.85529	5
53	77	enhance	96.602264	6
53	81	enhance	96.31563	7
53	42	enhance	95.6649	8
53	65	enhance	94.63225	9
53	14	enhance	94.25823	10
53	62	enhance	94.03747	11
53	185	enhance	93.8342	12
53	455	enhance	93.8253	13
53	38	enhance	93.25063	14
53	6	enhance	92.88113	15
53	76	enhance	92.736404	16
53	24	enhance	91.99211	17
53	97	enhance	91.75361	18
53	16	enhance	91.32819	19
53	358	enhance	90.86701	20
53	488	enhance	90.37926	21
53	785	enhance	89.31499	22
53	52	enhance	88.81233	23
53	28	enhance	88.80515	24
53	66	enhance	87.532265	25
53	27	enhance	87.52996	26
53	18	enhance	85.59302	27
53	17	enhance	84.135704	28
53	8	enhance	82.233406	29
53	35	enhance	81.68423	30
53	647	enhance	80.71037	31
53	12	enhance	79.162384	32
53	85	enhance	79.02352	33
53	37	enhance	78.356346	34
53	593	enhance	77.420586	35
53	26	enhance	77.13294	36
53	10	enhance	75.7255	37
53	71	enhance	75.5489	38
53	69	enhance	74.36689	39
53	59	enhance	74.2782	40
53	21	enhance	73.82124	41
53	20	enhance	72.03257	42
53	78	enhance	71.3313	43
53	901	enhance	70.89761	44
53	219	enhance	70.1415	45
53	5	enhance	70.10765	46
53	50	enhance	70.09609	47
53	57	enhance	69.80695	48
53	95	enhance	69.55433	49
53	108	enhance	68.89698	50
53	171	enhance	68.88569	51
53	87	enhance	68.14123	52
53	48	enhance	67.79639	53
53	58	enhance	66.40861	54
53	79	enhance	66.23501	55
53	46	enhance	65.35522	56
53	68	enhance	64.99998	57
53	335	enhance	63.35799	58
53	82	enhance	63.355553	59
53	40	enhance	63.28787	60
53	41	enhance	61.902763	61
53	84	enhance	61.81503	62
53	176	enhance	60.817398	63
53	89	enhance	60.76518	64
53	7	enhance	60.02778	65
53	36	enhance	59.949078	66
53	155	enhance	59.345936	67
53	23	enhance	58.901115	68
53	882	enhance	58.76668	69
53	86	enhance	58.434628	70
53	25	enhance	58.334816	71
53	75	enhance	57.27757	72
53	39	enhance	56.980003	73
53	94	enhance	56.864	74
53	15	enhance	56.675808	75
53	9	enhance	56.60787	76
53	98	enhance	56.44204	77
53	34	enhance	55.553444	78
53	88	enhance	54.824707	79
53	1	enhance	54.730663	80
53	56	enhance	54.066505	81
53	73	enhance	54.055492	82
53	187	enhance	53.674316	83
53	4	enhance	53.54825	84
53	19	enhance	53.133392	85
53	96	enhance	52.98368	86
53	182	enhance	52.642033	87
53	184	enhance	52.43369	88
53	285	enhance	52.361706	89
53	868	enhance	51.080082	90
53	44	enhance	50.93564	91
53	31	enhance	50.18077	92
53	92	enhance	49.526623	93
53	63	enhance	49.39901	94
53	22	enhance	47.46653	95
53	49	enhance	46.91982	96
53	74	enhance	44.863644	97
53	2	enhance	44.283226	98
53	43	enhance	41.582863	99
53	91	enhance	41.08575	100
53	55	enhance	40.286304	101
53	93	enhance	38.4754	102
53	60	enhance	38.138275	103
53	3	enhance	37.616505	104
53	99	enhance	37.57324	105
53	30	enhance	36.668346	106
53	64	enhance	36.181137	107
53	230	enhance	36.079777	108
53	70	enhance	35.358665	109
53	45	enhance	34.529602	110
53	11	enhance	33.878708	111
53	61	enhance	32.712738	112
53	222	enhance	32.306335	113
53	83	enhance	31.45599	114
53	47	enhance	31.449337	115
53	67	enhance	28.975817	116
53	72	enhance	28.798094	117
53	51	enhance	27.88761	118
53	126	enhance	27.862364	119
53	90	enhance	26.952366	120
53	640	enhance	26.88489	121
53	13	enhance	26.234764	122
53	80	enhance	25.44494	123
53	33	enhance	20.304506	124
53	126	soften	100	1
53	11	soften	99.95281	2
53	90	soften	99.9061	3
53	91	soften	94.69855	4
53	3	soften	94.66285	5
53	55	soften	94.53233	6
53	93	soften	92.847	7
53	79	soften	90.60811	8
53	182	soften	88.98132	9
53	99	soften	88.85141	10
53	30	soften	88.08992	11
53	2	soften	87.97261	12
53	34	soften	87.56842	13
53	4	soften	86.37307	14
53	23	soften	86.11797	15
53	184	soften	85.56683	16
53	82	soften	84.76269	17
53	868	soften	84.643135	18
53	96	soften	83.895515	19
53	63	soften	83.874825	20
53	22	soften	82.39248	21
53	171	soften	82.378174	22
53	9	soften	81.95738	23
53	21	soften	81.61846	24
53	285	soften	81.317795	25
53	50	soften	81.18386	26
53	59	soften	80.74647	27
53	39	soften	80.64934	28
53	28	soften	80.4109	29
53	44	soften	80.380486	30
53	219	soften	79.20968	31
53	176	soften	78.79881	32
53	18	soften	78.57028	33
53	12	soften	78.390724	34
53	85	soften	77.60537	35
53	66	soften	77.12147	36
53	35	soften	77.09828	37
53	7	soften	76.25644	38
53	8	soften	74.109924	39
53	69	soften	74.05633	40
53	54	soften	73.018906	41
53	27	soften	72.60405	42
53	10	soften	72.48576	43
53	80	soften	71.48426	44
53	647	soften	69.80377	45
53	455	soften	69.78275	46
53	58	soften	69.75243	47
53	64	soften	69.5131	48
53	72	soften	69.41317	49
53	52	soften	69.09554	50
53	60	soften	69.009766	51
53	83	soften	68.902954	52
53	488	soften	67.72049	53
53	901	soften	67.45249	54
53	14	soften	66.653465	55
53	70	soften	66.1725	56
53	17	soften	65.95771	57
53	33	soften	65.86353	58
53	13	soften	65.35226	59
53	74	soften	65.02616	60
53	45	soften	64.7381	61
53	6	soften	64.46161	62
53	49	soften	63.41517	63
53	97	soften	63.377308	64
53	640	soften	62.14613	65
53	61	soften	62.10666	66
53	43	soften	61.65947	67
53	230	soften	60.810173	68
53	222	soften	60.774982	69
53	73	soften	59.893368	70
53	94	soften	59.29978	71
53	51	soften	58.751205	72
53	47	soften	57.886276	73
53	5	soften	57.62786	74
53	98	soften	57.156513	75
53	335	soften	56.962234	76
53	31	soften	56.918327	77
53	92	soften	56.42307	78
53	78	soften	55.80443	79
53	187	soften	55.672897	80
53	593	soften	55.528267	81
53	20	soften	55.231224	82
53	67	soften	55.04757	83
53	56	soften	54.30241	84
53	88	soften	53.506485	85
53	95	soften	53.088108	86
53	41	soften	52.7059	87
53	89	soften	52.360786	88
53	19	soften	52.24868	89
53	86	soften	51.989326	90
53	84	soften	51.24503	91
53	1	soften	50.99994	92
53	108	soften	50.958942	93
53	24	soften	48.489227	94
53	36	soften	48.481197	95
53	40	soften	47.72921	96
53	26	soften	47.716183	97
53	25	soften	47.210396	98
53	71	soften	46.890633	99
53	87	soften	46.871815	100
53	68	soften	46.68659	101
53	785	soften	46.653347	102
53	48	soften	46.301643	103
53	185	soften	46.09368	104
53	155	soften	45.70428	105
53	62	soften	45.68088	106
53	882	soften	45.46022	107
53	921	soften	45.35764	108
53	65	soften	44.53109	109
53	77	soften	44.26906	110
53	100	soften	44.248516	111
54	27	enhance	100	1
54	455	enhance	99.82224	2
54	66	enhance	98.717316	3
54	18	enhance	97.85341	4
54	52	enhance	97.262955	5
54	53	enhance	97.24749	6
54	28	enhance	95.9166	7
54	100	enhance	95.12289	8
54	921	enhance	94.991066	9
54	62	enhance	94.691505	10
54	185	enhance	94.62015	11
54	77	enhance	94.558334	12
54	29	enhance	92.685875	13
54	6	enhance	92.557816	14
54	24	enhance	92.419136	15
54	593	enhance	92.32009	16
54	10	enhance	92.00825	17
54	42	enhance	90.38048	18
54	65	enhance	90.332535	19
54	81	enhance	90.27476	20
54	50	enhance	90.26658	21
54	97	enhance	90.11804	22
54	78	enhance	90.06189	23
54	785	enhance	89.68689	24
54	76	enhance	89.35287	25
54	647	enhance	89.34091	26
54	32	enhance	89.13127	27
54	16	enhance	89.02332	28
54	38	enhance	88.9577	29
54	14	enhance	87.7677	30
54	358	enhance	87.592224	31
54	8	enhance	87.53071	32
54	59	enhance	87.02843	33
54	17	enhance	86.489914	34
54	35	enhance	85.66927	35
54	12	enhance	85.15414	36
54	79	enhance	84.98832	37
54	85	enhance	84.91892	38
54	21	enhance	84.11396	39
54	94	enhance	83.93374	40
54	26	enhance	83.83076	41
54	5	enhance	83.81196	42
54	108	enhance	83.477234	43
54	39	enhance	82.61434	44
54	488	enhance	82.599075	45
54	219	enhance	82.4757	46
54	69	enhance	82.352875	47
54	71	enhance	80.789665	48
54	7	enhance	80.718414	49
54	37	enhance	80.20687	50
54	34	enhance	80.037994	51
54	20	enhance	78.96774	52
54	82	enhance	78.66577	53
54	89	enhance	77.983116	54
54	335	enhance	77.71894	55
54	58	enhance	77.694336	56
54	86	enhance	77.675575	57
54	171	enhance	77.66478	58
54	182	enhance	77.34814	59
54	176	enhance	77.262146	60
54	285	enhance	76.84619	61
54	901	enhance	76.004326	62
54	23	enhance	75.82662	63
54	48	enhance	75.79723	64
54	19	enhance	75.71167	65
54	187	enhance	75.48171	66
54	49	enhance	75.47634	67
54	184	enhance	75.37576	68
54	68	enhance	75.32283	69
54	56	enhance	75.15314	70
54	41	enhance	75.071075	71
54	9	enhance	74.53451	72
54	84	enhance	74.43178	73
54	44	enhance	74.29166	74
54	92	enhance	74.01287	75
54	98	enhance	73.62774	76
54	4	enhance	73.44702	77
54	73	enhance	73.179	78
54	36	enhance	73.08999	79
54	88	enhance	72.81514	80
54	40	enhance	72.35483	81
54	63	enhance	72.25973	82
54	87	enhance	72.0028	83
54	1	enhance	71.473045	84
54	95	enhance	71.31819	85
54	96	enhance	70.19242	86
54	868	enhance	70.00506	87
54	15	enhance	69.88964	88
54	46	enhance	69.72436	89
54	22	enhance	69.28883	90
54	3	enhance	69.26708	91
54	43	enhance	68.6282	92
54	70	enhance	68.42978	93
54	31	enhance	68.326904	94
54	93	enhance	68.21097	95
54	55	enhance	67.60784	96
54	57	enhance	67.46803	97
54	74	enhance	67.21825	98
54	91	enhance	65.78104	99
54	99	enhance	65.53254	100
54	83	enhance	65.293304	101
54	25	enhance	65.23047	102
54	75	enhance	64.322235	103
54	882	enhance	63.453407	104
54	72	enhance	63.150673	105
54	155	enhance	63.04292	106
54	60	enhance	62.791523	107
54	30	enhance	62.312172	108
54	64	enhance	61.89835	109
54	2	enhance	61.751915	110
54	45	enhance	61.656418	111
54	126	enhance	61.21042	112
54	11	enhance	60.571873	113
54	90	enhance	59.725243	114
54	230	enhance	58.4696	115
54	61	enhance	57.815807	116
54	47	enhance	57.414986	117
54	222	enhance	57.101807	118
54	13	enhance	56.628304	119
54	80	enhance	56.039436	120
54	640	enhance	53.54552	121
54	51	enhance	48.47052	122
54	67	enhance	46.38645	123
54	33	enhance	44.124104	124
54	11	soften	100	1
54	60	soften	97.948006	2
54	80	soften	97.24434	3
54	91	soften	95.70666	4
54	72	soften	94.74657	5
54	90	soften	94.380714	6
54	83	soften	94.312454	7
54	126	soften	94.22079	8
54	55	soften	93.644	9
54	3	soften	92.481895	10
54	93	soften	91.085594	11
54	70	soften	90.56581	12
54	79	soften	88.47876	13
54	45	soften	88.028984	14
54	184	soften	87.75887	15
54	4	soften	87.51125	16
54	96	soften	87.251205	17
54	13	soften	86.82936	18
54	23	soften	86.41574	19
54	868	soften	86.13064	20
54	33	soften	85.89358	21
54	22	soften	84.85479	22
54	335	soften	84.817825	23
54	2	soften	84.26224	24
54	171	soften	84.18986	25
54	34	soften	84.185104	26
54	21	soften	84.13683	27
54	99	soften	83.97161	28
54	182	soften	83.840866	29
54	43	soften	83.65708	30
54	30	soften	83.589134	31
54	9	soften	83.11485	32
54	82	soften	83.021164	33
54	59	soften	82.40702	34
54	640	soften	82.25087	35
54	5	soften	82.224045	36
54	219	soften	82.092224	37
54	73	soften	81.93292	38
54	20	soften	81.58514	39
54	44	soften	81.3435	40
54	78	soften	81.24718	41
54	12	soften	80.86679	42
54	230	soften	80.43271	43
54	63	soften	80.40391	44
54	85	soften	80.39478	45
54	35	soften	79.70628	46
54	28	soften	79.00624	47
54	18	soften	79.00166	48
54	593	soften	78.76884	49
54	39	soften	78.75838	50
54	50	soften	78.11464	51
54	41	soften	77.93946	52
54	285	soften	77.7143	53
54	66	soften	77.16088	54
54	176	soften	77.00377	55
54	187	soften	76.43605	56
54	69	soften	76.30238	57
54	98	soften	75.73294	58
54	8	soften	74.87139	59
54	7	soften	74.56413	60
54	86	soften	73.29423	61
54	27	soften	72.60133	62
54	64	soften	70.427574	63
54	74	soften	66.79854	64
54	49	soften	59.497334	65
54	222	soften	57.612724	66
54	61	soften	57.512756	67
54	94	soften	57.31631	68
54	51	soften	55.81709	69
54	95	soften	55.23018	70
54	92	soften	54.549862	71
54	47	soften	54.353817	72
54	31	soften	53.57146	73
54	56	soften	52.16304	74
55	60	enhance	100	1
55	11	enhance	99.63614	2
55	3	enhance	97.99251	3
55	64	enhance	96.778076	4
55	4	enhance	96.592705	5
55	91	enhance	95.25163	6
55	93	enhance	94.29081	7
55	9	enhance	93.86551	8
55	83	enhance	93.52602	9
55	23	enhance	93.2263	10
55	72	enhance	93.20742	11
55	184	enhance	93.06949	12
55	868	enhance	92.747955	13
55	5	enhance	91.35243	14
55	335	enhance	91.1428	15
55	22	enhance	90.71526	16
55	219	enhance	90.41332	17
55	74	enhance	90.0983	18
55	70	enhance	89.881996	19
55	59	enhance	89.427864	20
55	96	enhance	89.13644	21
55	90	enhance	88.99739	22
55	82	enhance	88.758675	23
55	41	enhance	88.324524	24
55	44	enhance	87.71724	25
55	78	enhance	87.59263	26
55	593	enhance	86.99236	27
55	171	enhance	86.571106	28
55	21	enhance	85.711815	29
55	12	enhance	84.13774	30
55	50	enhance	83.29735	31
55	126	enhance	83.18767	32
55	69	enhance	82.62682	33
55	85	enhance	82.47074	34
55	35	enhance	82.40958	35
55	94	enhance	81.811485	36
55	20	enhance	81.28058	37
55	34	enhance	81.022705	38
55	8	enhance	80.42503	39
55	66	enhance	80.26282	40
55	99	enhance	79.199	41
55	182	enhance	78.04084	42
55	79	enhance	75.54586	43
55	18	enhance	74.72734	44
55	7	enhance	74.06633	45
55	19	enhance	72.30909	46
55	92	enhance	72.24555	47
55	58	enhance	72.20676	48
55	28	enhance	71.13486	49
55	10	enhance	71.076996	50
55	39	enhance	70.841545	51
55	63	enhance	70.13993	52
55	80	enhance	70.11422	53
55	43	enhance	69.18373	54
55	49	enhance	66.713486	55
55	27	enhance	66.34108	56
55	187	enhance	66.259995	57
55	2	enhance	66.21745	58
55	95	enhance	65.64653	59
55	54	enhance	65.17974	60
55	13	enhance	62.47191	61
55	65	enhance	62.017593	62
55	455	enhance	61.89058	63
55	45	enhance	59.556717	64
55	488	enhance	58.49816	65
55	52	enhance	58.370754	66
55	14	enhance	58.120773	67
55	176	enhance	58.097347	68
55	77	enhance	56.631157	69
55	285	enhance	55.77064	70
55	100	enhance	55.603825	71
55	86	enhance	53.029198	72
55	222	enhance	52.953575	73
55	640	enhance	52.67355	74
55	32	enhance	50.902313	75
55	47	enhance	49.050316	76
55	230	enhance	48.975258	77
55	62	enhance	48.14173	78
55	61	enhance	48.133663	79
55	56	enhance	47.748558	80
55	89	enhance	47.696712	81
55	921	enhance	46.847973	82
55	24	enhance	46.709248	83
55	108	enhance	46.304955	84
55	73	enhance	46.05251	85
55	33	enhance	45.869343	86
55	185	enhance	45.797256	87
55	15	enhance	44.95417	88
55	57	enhance	44.819736	89
55	901	enhance	44.76658	90
55	30	enhance	44.645916	91
55	26	enhance	43.94591	92
55	51	enhance	41.40745	93
55	647	enhance	41.09162	94
55	31	enhance	40.99403	95
55	81	enhance	40.633045	96
55	98	enhance	40.101715	97
55	785	enhance	39.233383	98
55	1	enhance	38.91749	99
55	53	enhance	37.772514	100
55	38	enhance	37.231853	101
55	42	enhance	36.434994	102
55	88	enhance	36.199905	103
55	37	enhance	35.260334	104
55	76	enhance	33.35742	105
55	16	enhance	32.76408	106
55	84	enhance	32.4348	107
55	71	enhance	31.534418	108
55	68	enhance	31.49673	109
55	17	enhance	31.044569	110
55	6	enhance	30.972395	111
55	36	enhance	30.950064	112
55	48	enhance	29.612688	113
55	67	enhance	29.40285	114
55	29	enhance	27.212221	115
55	358	enhance	26.292269	116
55	97	enhance	25.953959	117
55	87	enhance	24.151598	118
55	40	enhance	21.762136	119
55	25	enhance	18.831264	120
55	46	enhance	17.845673	121
55	75	enhance	16.751804	122
55	155	enhance	15.144643	123
55	882	enhance	14.495662	124
55	11	soften	100	1
55	80	soften	96.8847	2
55	60	soften	95.13729	3
55	91	soften	94.8989	4
55	64	soften	72.75261	5
55	74	soften	66.33798	6
56	89	enhance	100	1
56	30	enhance	97.099884	2
56	26	enhance	93.456825	3
56	187	enhance	92.82193	4
56	647	enhance	90.28906	5
56	73	enhance	89.61148	6
56	43	enhance	89.60993	7
56	1	enhance	87.44818	8
56	34	enhance	86.960526	9
56	45	enhance	85.50831	10
56	108	enhance	85.39484	11
56	31	enhance	85.3758	12
56	47	enhance	84.00133	13
56	63	enhance	83.34439	14
56	36	enhance	83.17991	15
56	185	enhance	82.42217	16
56	49	enhance	82.14791	17
56	88	enhance	82.02298	18
56	61	enhance	80.93567	19
56	84	enhance	80.82434	20
56	39	enhance	80.50618	21
56	7	enhance	79.7272	22
56	285	enhance	79.47046	23
56	19	enhance	78.879654	24
56	62	enhance	78.59072	25
56	901	enhance	78.476974	26
56	37	enhance	78.422035	27
56	98	enhance	78.222374	28
56	230	enhance	78.09316	29
56	50	enhance	77.59638	30
56	921	enhance	77.24609	31
56	68	enhance	76.68991	32
56	17	enhance	75.18795	33
56	6	enhance	75.07394	34
56	54	enhance	75.00331	35
56	785	enhance	74.93976	36
56	18	enhance	74.44936	37
56	40	enhance	74.23646	38
56	455	enhance	74.072105	39
56	71	enhance	73.67286	40
56	92	enhance	73.387436	41
56	640	enhance	72.71609	42
56	13	enhance	72.42765	43
56	81	enhance	72.35422	44
56	48	enhance	72.221085	45
56	16	enhance	71.87895	46
56	15	enhance	71.874054	47
56	10	enhance	71.539215	48
56	80	enhance	70.50188	49
56	24	enhance	70.48749	50
56	46	enhance	70.29275	51
56	99	enhance	70.2531	52
56	182	enhance	70.16229	53
56	358	enhance	70.15114	54
56	76	enhance	69.782074	55
56	126	enhance	69.33836	56
56	86	enhance	69.33122	57
56	27	enhance	69.14201	58
56	94	enhance	69.05689	59
56	176	enhance	68.78006	60
56	52	enhance	68.52327	61
56	33	enhance	68.31741	62
56	87	enhance	68.30919	63
56	97	enhance	68.17851	64
56	29	enhance	68.04329	65
56	25	enhance	67.8453	66
56	2	enhance	67.683334	67
56	58	enhance	67.34914	68
56	42	enhance	67.33133	69
56	222	enhance	67.10184	70
56	38	enhance	66.93573	71
56	882	enhance	66.61464	72
56	28	enhance	66.15586	73
56	75	enhance	65.92592	74
56	78	enhance	65.117645	75
56	70	enhance	63.91572	76
56	155	enhance	63.584538	77
56	67	enhance	62.651985	78
56	79	enhance	61.763313	79
56	83	enhance	61.211555	80
56	593	enhance	61.106583	81
56	100	enhance	60.847183	82
56	14	enhance	59.839542	83
56	77	enhance	59.815563	84
56	3	enhance	58.33636	85
56	51	enhance	58.22511	86
56	57	enhance	57.75413	87
56	8	enhance	57.5854	88
56	82	enhance	56.950966	89
56	90	enhance	56.44805	90
56	65	enhance	55.8638	91
56	95	enhance	55.23933	92
56	171	enhance	53.97114	93
56	20	enhance	53.698315	94
56	72	enhance	53.474724	95
56	66	enhance	53.294323	96
56	53	enhance	52.476463	97
56	219	enhance	51.53482	98
56	184	enhance	50.25682	99
56	93	enhance	50.070667	100
56	55	enhance	49.42857	101
56	44	enhance	48.020866	102
56	32	enhance	47.945656	103
56	488	enhance	46.249928	104
56	868	enhance	45.39505	105
56	5	enhance	44.979034	106
56	96	enhance	43.11362	107
56	74	enhance	42.796745	108
56	59	enhance	42.21816	109
56	23	enhance	41.246895	110
56	35	enhance	40.27743	111
56	11	enhance	40.212593	112
56	9	enhance	40.065193	113
56	64	enhance	39.79432	114
56	41	enhance	39.500294	115
56	335	enhance	39.26548	116
56	22	enhance	38.350765	117
56	21	enhance	38.170704	118
56	4	enhance	38.02441	119
56	69	enhance	37.446312	120
56	85	enhance	35.430256	121
56	12	enhance	33.972286	122
56	60	enhance	33.143677	123
56	91	enhance	32.658375	124
56	64	soften	100	1
56	74	soften	97.2155	2
56	11	soften	97.05873	3
56	91	soften	96.34012	4
56	60	soften	94.702614	5
56	96	soften	89.149826	6
56	55	soften	88.963	7
56	80	soften	88.19126	8
56	184	soften	87.907135	9
56	93	soften	87.45257	10
56	72	soften	87.20869	11
56	335	soften	86.63389	12
56	83	soften	86.59291	13
56	3	soften	86.301636	14
56	868	soften	85.92816	15
56	22	soften	85.82785	16
56	21	soften	85.763306	17
56	4	soften	85.72117	18
56	90	soften	84.99262	19
56	23	soften	84.3858	20
56	79	soften	84.18384	21
56	70	soften	84.10682	22
56	126	soften	84.061905	23
56	59	soften	82.697655	24
56	9	soften	82.30973	25
56	171	soften	82.27834	26
56	85	soften	82.0036	27
56	219	soften	81.99632	28
56	12	soften	81.917244	29
56	20	soften	81.2124	30
56	44	soften	80.411896	31
56	5	soften	79.97366	32
56	35	soften	79.889114	33
56	78	soften	79.713425	34
56	45	soften	79.61338	35
56	95	soften	78.747284	36
56	41	soften	78.38404	37
56	82	soften	78.04692	38
56	94	soften	77.53129	39
56	69	soften	77.14363	40
56	2	soften	76.66058	41
56	13	soften	76.471016	42
56	18	soften	76.31127	43
56	49	soften	75.9425	44
56	593	soften	75.69797	45
56	34	soften	75.594536	46
56	66	soften	75.022026	47
56	99	soften	74.99853	48
56	182	soften	74.824455	49
56	222	soften	74.46672	50
56	28	soften	74.09442	51
56	39	soften	73.96362	52
56	43	soften	73.66333	53
56	176	soften	73.46867	54
56	63	soften	73.445404	55
56	73	soften	72.841606	56
56	92	soften	72.43078	57
56	51	soften	72.349724	58
56	30	soften	72.30525	59
56	33	soften	72.23341	60
56	285	soften	71.87993	61
56	640	soften	71.49509	62
56	50	soften	71.30807	63
56	61	soften	71.208664	64
56	86	soften	70.83816	65
56	8	soften	70.765594	66
56	27	soften	70.0522	67
56	230	soften	69.6391	68
56	7	soften	68.89866	69
56	47	soften	68.790955	70
56	31	soften	67.67343	71
56	187	soften	67.34062	72
57	65	enhance	100	1
57	58	enhance	96.072685	2
57	81	enhance	94.91957	3
57	77	enhance	91.68693	4
57	921	enhance	91.45732	5
57	100	enhance	90.27616	6
57	37	enhance	90.09206	7
57	14	enhance	89.44371	8
57	32	enhance	88.69546	9
57	488	enhance	87.00869	10
57	62	enhance	86.98362	11
57	8	enhance	86.11566	12
57	19	enhance	85.6668	13
57	42	enhance	80.923775	14
57	26	enhance	79.77001	15
57	901	enhance	79.1385	16
57	38	enhance	78.450584	17
57	69	enhance	77.94936	18
57	41	enhance	77.825294	19
57	95	enhance	77.73365	20
57	185	enhance	77.547585	21
57	76	enhance	77.18615	22
57	15	enhance	77.157074	23
57	20	enhance	75.88915	24
57	53	enhance	73.23373	25
57	455	enhance	72.87959	26
57	54	enhance	72.77924	27
57	171	enhance	72.5486	28
57	187	enhance	70.95662	29
57	219	enhance	70.9262	30
57	35	enhance	70.75806	31
57	18	enhance	70.65041	32
57	9	enhance	69.96063	33
57	16	enhance	69.87247	34
57	593	enhance	68.10332	35
57	82	enhance	68.03829	36
57	7	enhance	67.76414	37
57	785	enhance	67.24287	38
57	29	enhance	66.84336	39
57	24	enhance	66.61227	40
57	78	enhance	66.25006	41
57	34	enhance	64.95986	42
57	89	enhance	64.911644	43
57	5	enhance	64.68273	44
57	50	enhance	64.36143	45
57	28	enhance	64.24505	46
57	647	enhance	64.16786	47
57	85	enhance	64.06539	48
57	12	enhance	63.824787	49
57	56	enhance	62.425102	50
57	6	enhance	61.92201	51
57	66	enhance	61.474186	52
57	358	enhance	61.42815	53
57	52	enhance	61.18769	54
57	59	enhance	60.63963	55
57	335	enhance	59.190067	56
57	21	enhance	59.09861	57
57	27	enhance	58.30634	58
57	96	enhance	58.24662	59
57	17	enhance	58.167377	60
57	23	enhance	58.073902	61
57	10	enhance	57.73351	62
57	44	enhance	57.238476	63
57	63	enhance	57.138187	64
57	43	enhance	56.484592	65
57	2	enhance	55.76694	66
57	108	enhance	55.643486	67
57	4	enhance	55.562325	68
57	97	enhance	54.662567	69
57	22	enhance	52.177296	70
57	71	enhance	52.17506	71
57	868	enhance	52.174625	72
57	184	enhance	51.40091	73
57	39	enhance	50.720062	74
57	55	enhance	50.149113	75
57	99	enhance	48.878635	76
57	73	enhance	48.362347	77
57	3	enhance	48.221405	78
57	79	enhance	47.72337	79
57	182	enhance	47.529274	80
57	74	enhance	46.647873	81
57	1	enhance	46.439575	82
57	92	enhance	44.856594	83
57	87	enhance	44.64867	84
57	30	enhance	44.622604	85
57	94	enhance	44.123882	86
57	48	enhance	43.997593	87
57	176	enhance	43.860157	88
57	68	enhance	42.877808	89
57	45	enhance	41.889347	90
57	31	enhance	41.84753	91
57	36	enhance	41.26758	92
57	93	enhance	40.880413	93
57	84	enhance	40.500675	94
57	83	enhance	40.06747	95
57	11	enhance	39.989933	96
57	46	enhance	39.918186	97
57	91	enhance	39.323288	98
57	60	enhance	39.23629	99
57	64	enhance	39.026096	100
57	70	enhance	38.8634	101
57	49	enhance	38.64534	102
57	126	enhance	38.12481	103
57	882	enhance	37.80238	104
57	86	enhance	37.171864	105
57	98	enhance	36.46599	106
57	155	enhance	36.430332	107
57	285	enhance	36.332603	108
57	40	enhance	36.085335	109
57	90	enhance	35.884853	110
57	25	enhance	35.25147	111
57	230	enhance	34.799915	112
57	88	enhance	34.350887	113
57	80	enhance	33.37235	114
57	72	enhance	32.779613	115
57	61	enhance	30.15153	116
57	47	enhance	29.948532	117
57	75	enhance	29.896524	118
57	33	enhance	27.602892	119
57	13	enhance	27.577408	120
57	640	enhance	26.785908	121
57	222	enhance	25.497938	122
57	51	enhance	18.623255	123
57	67	enhance	17.75363	124
57	11	soften	100	1
57	72	soften	99.213104	2
57	60	soften	98.903465	3
57	80	soften	98.47853	4
57	91	soften	98.462074	5
57	90	soften	97.07367	6
57	83	soften	96.43227	7
57	126	soften	96.16534	8
57	70	soften	95.799446	9
57	93	soften	95.73125	10
57	13	soften	93.68431	11
57	55	soften	93.23207	12
57	3	soften	92.87872	13
57	79	soften	91.634834	14
57	184	soften	91.473526	15
57	45	soften	90.80425	16
57	33	soften	90.33026	17
57	868	soften	89.71993	18
57	640	soften	89.37415	19
57	22	soften	88.79303	20
57	182	soften	88.40741	21
57	96	soften	87.969154	22
57	285	soften	87.34913	23
57	99	soften	87.276825	24
57	44	soften	86.8504	25
57	4	soften	86.8056	26
57	335	soften	86.64517	27
57	23	soften	86.340706	28
57	39	soften	86.12001	29
57	230	soften	86.00191	30
57	2	soften	85.534225	31
57	59	soften	85.4639	32
57	176	soften	85.36817	33
57	21	soften	85.23821	34
57	30	soften	85.03783	35
57	43	soften	84.47881	36
57	98	soften	84.23243	37
57	63	soften	84.215355	38
57	34	soften	84.0334	39
57	86	soften	84.003876	40
57	78	soften	83.84962	41
57	73	soften	83.32511	42
57	82	soften	83.24558	43
57	9	soften	82.87146	44
57	5	soften	82.71266	45
57	66	soften	82.37311	46
57	28	soften	81.99662	47
57	593	soften	81.82889	48
57	50	soften	81.61558	49
57	171	soften	81.16116	50
57	18	soften	81.11743	51
57	219	soften	81.08237	52
57	12	soften	80.88081	53
57	85	soften	80.22148	54
57	27	soften	80.00823	55
57	10	soften	79.01704	56
57	20	soften	78.41922	57
57	7	soften	77.976746	58
57	41	soften	77.87265	59
57	108	soften	77.45928	60
57	35	soften	77.37207	61
57	187	soften	77.27546	62
57	52	soften	76.622154	63
57	54	soften	76.61	64
57	89	soften	76.463455	65
57	69	soften	76.215866	66
57	24	soften	75.87108	67
57	455	soften	75.555824	68
57	87	soften	75.46669	69
57	19	soften	75.41771	70
57	155	soften	74.770905	71
57	647	soften	74.37413	72
57	48	soften	74.05364	73
57	97	soften	72.58081	74
57	17	soften	72.49373	75
57	785	soften	72.33575	76
57	58	soften	72.04836	77
57	6	soften	71.9647	78
57	8	soften	71.74277	79
57	64	soften	71.40206	80
57	185	soften	69.84798	81
57	15	soften	69.73983	82
57	358	soften	69.49787	83
57	26	soften	68.91718	84
57	76	soften	67.73533	85
57	38	soften	67.45028	86
57	488	soften	67.37737	87
57	14	soften	67.20237	88
57	901	soften	66.99346	89
57	74	soften	66.80159	90
57	16	soften	66.20726	91
57	53	soften	66.02631	92
57	42	soften	65.88463	93
57	37	soften	65.664696	94
57	65	soften	65.34826	95
57	32	soften	64.12123	96
57	222	soften	63.91016	97
57	49	soften	63.878845	98
57	94	soften	62.936935	99
57	51	soften	62.91038	100
57	61	soften	61.954094	101
57	81	soften	61.5608	102
57	67	soften	59.599495	103
57	92	soften	59.576485	104
57	47	soften	59.16482	105
57	31	soften	58.21002	106
57	88	soften	56.961884	107
57	84	soften	56.950573	108
57	1	soften	55.063835	109
57	56	soften	53.79822	110
57	40	soften	53.606754	111
57	25	soften	53.477745	112
57	36	soften	53.37635	113
57	95	soften	52.502518	114
57	882	soften	52.02353	115
57	68	soften	51.846138	116
57	71	soften	51.385757	117
57	75	soften	51.2901	118
57	46	soften	50.970833	119
57	62	soften	48.963276	120
57	100	soften	48.092415	121
57	77	soften	47.95506	122
57	29	soften	46.62427	123
57	921	soften	46.012012	124
58	65	enhance	100	1
58	77	enhance	98.08135	2
58	41	enhance	98.080765	3
58	20	enhance	97.91367	4
58	219	enhance	97.738235	5
58	100	enhance	96.78373	6
58	62	enhance	96.71591	7
58	95	enhance	96.41739	8
58	78	enhance	96.408775	9
58	57	enhance	95.21431	10
58	455	enhance	94.48112	11
58	96	enhance	94.060616	12
58	69	enhance	93.84176	13
58	18	enhance	93.47468	14
58	8	enhance	93.386024	15
58	19	enhance	93.03692	16
58	593	enhance	92.89619	17
58	9	enhance	92.71142	18
58	14	enhance	92.21205	19
58	171	enhance	91.29867	20
58	488	enhance	90.38391	21
58	335	enhance	90.09066	22
58	7	enhance	89.957855	23
58	44	enhance	88.513214	24
58	921	enhance	88.04668	25
58	35	enhance	87.82942	26
58	184	enhance	87.810394	27
58	868	enhance	87.45249	28
58	59	enhance	87.39818	29
58	32	enhance	87.0373	30
58	185	enhance	86.74946	31
58	24	enhance	86.17363	32
58	82	enhance	85.70821	33
58	5	enhance	85.640305	34
58	21	enhance	85.348434	35
58	74	enhance	85.319016	36
58	85	enhance	85.07326	37
58	22	enhance	84.97705	38
58	38	enhance	84.86588	39
58	23	enhance	84.23552	40
58	42	enhance	84.12204	41
58	34	enhance	83.96636	42
58	12	enhance	83.89661	43
58	81	enhance	83.832405	44
58	54	enhance	83.06177	45
58	52	enhance	82.872444	46
58	89	enhance	82.35024	47
58	39	enhance	82.14524	48
58	4	enhance	81.97243	49
58	63	enhance	81.49938	50
58	15	enhance	81.49455	51
58	26	enhance	81.239334	52
58	10	enhance	80.6618	53
58	37	enhance	80.59664	54
58	3	enhance	80.18491	55
58	55	enhance	80.07078	56
58	66	enhance	79.7753	57
58	50	enhance	79.24658	58
58	187	enhance	78.79653	59
58	27	enhance	78.344765	60
58	93	enhance	77.75996	61
58	94	enhance	77.71624	62
58	76	enhance	77.30779	63
58	647	enhance	76.76777	64
58	91	enhance	75.45191	65
58	43	enhance	75.29423	66
58	901	enhance	75.084	67
58	28	enhance	74.98594	68
58	64	enhance	74.55805	69
58	785	enhance	74.13273	70
58	79	enhance	73.82321	71
58	108	enhance	73.51127	72
58	70	enhance	73.13059	73
58	2	enhance	72.88387	74
58	56	enhance	72.145706	75
58	11	enhance	72.04629	76
58	92	enhance	71.618355	77
58	6	enhance	70.90796	78
58	16	enhance	70.69576	79
58	176	enhance	70.385445	80
58	83	enhance	69.97097	81
58	86	enhance	69.79996	82
58	45	enhance	69.70384	83
58	53	enhance	69.0461	84
58	99	enhance	68.698296	85
58	1	enhance	68.68994	86
58	60	enhance	67.28934	87
58	80	enhance	65.64447	88
58	73	enhance	65.080215	89
58	126	enhance	65.003944	90
58	72	enhance	63.96272	91
58	29	enhance	63.659927	92
58	97	enhance	63.633812	93
58	90	enhance	63.130684	94
58	49	enhance	63.054264	95
58	358	enhance	62.88751	96
58	285	enhance	62.56188	97
58	17	enhance	61.884922	98
58	182	enhance	61.606464	99
58	30	enhance	61.45057	100
58	36	enhance	59.986057	101
58	71	enhance	59.95656	102
58	84	enhance	59.817085	103
58	48	enhance	57.804913	104
58	87	enhance	57.109943	105
58	68	enhance	55.178886	106
58	31	enhance	55.133842	107
58	40	enhance	50.06483	108
58	13	enhance	49.41853	109
58	25	enhance	49.063915	110
58	47	enhance	47.49345	111
58	222	enhance	47.14841	112
58	88	enhance	46.492893	113
58	230	enhance	45.960518	114
58	155	enhance	45.622383	115
58	882	enhance	45.178265	116
58	61	enhance	44.759205	117
58	98	enhance	44.670994	118
58	46	enhance	43.731968	119
58	640	enhance	41.96647	120
58	75	enhance	41.29383	121
58	33	enhance	35.038715	122
58	51	enhance	34.001648	123
58	67	enhance	32.400875	124
58	11	soften	100	1
58	90	soften	99.6821	2
58	126	soften	99.61273	3
58	3	soften	94.878	4
58	55	soften	94.563515	5
58	93	soften	93.51021	6
58	91	soften	93.373955	7
58	30	soften	91.58566	8
58	79	soften	90.695526	9
58	182	soften	90.37399	10
58	99	soften	89.98007	11
58	34	soften	88.30397	12
58	184	soften	88.22835	13
58	2	soften	87.51911	14
58	4	soften	86.17056	15
58	868	soften	85.438644	16
58	23	soften	85.27068	17
58	63	soften	85.05754	18
58	285	soften	84.724495	19
58	39	soften	84.654976	20
58	22	soften	84.35926	21
58	82	soften	84.10334	22
58	96	soften	83.677376	23
58	44	soften	83.2062	24
58	50	soften	83.02237	25
58	28	soften	82.58012	26
58	171	soften	82.086555	27
58	59	soften	81.47788	28
58	9	soften	80.97581	29
58	176	soften	80.86453	30
58	21	soften	80.85389	31
58	18	soften	80.74501	32
58	219	soften	80.04374	33
58	66	soften	79.948555	34
58	7	soften	78.5847	35
58	12	soften	77.454704	36
58	27	soften	77.41588	37
58	85	soften	76.49305	38
58	54	soften	76.3925	39
58	10	soften	76.194626	40
58	35	soften	76.16573	41
58	8	soften	74.52389	42
58	69	soften	73.04318	43
58	455	soften	72.64302	44
58	80	soften	70.83749	45
58	64	soften	69.746735	46
58	72	soften	69.619995	47
58	83	soften	68.81283	48
58	60	soften	68.72431	49
58	33	soften	66.608894	50
58	70	soften	66.498604	51
58	13	soften	66.368454	52
58	45	soften	65.113556	53
58	49	soften	64.527374	54
58	640	soften	63.596302	55
58	74	soften	63.580242	56
58	61	soften	63.355965	57
58	222	soften	62.689453	58
58	43	soften	62.45068	59
58	230	soften	61.880814	60
58	73	soften	61.458046	61
58	51	soften	61.121174	62
58	94	soften	60.699627	63
58	47	soften	59.379585	64
58	98	soften	59.139133	65
58	31	soften	58.750977	66
58	92	soften	58.270573	67
58	78	soften	57.932014	68
58	335	soften	57.732227	69
58	187	soften	57.379845	70
58	5	soften	57.214577	71
58	56	soften	56.97468	72
58	593	soften	56.33318	73
58	86	soften	54.924698	74
58	20	soften	54.745346	75
58	89	soften	54.627193	76
58	84	soften	54.522247	77
58	41	soften	52.89078	78
58	95	soften	52.326668	79
59	21	enhance	100	1
59	12	enhance	99.8955	2
59	335	enhance	99.46244	3
59	85	enhance	98.92379	4
59	5	enhance	98.81024	5
59	23	enhance	97.67078	6
59	4	enhance	97.42831	7
59	66	enhance	97.21459	8
59	593	enhance	97.0687	9
59	9	enhance	96.67787	10
59	69	enhance	96.46809	11
59	219	enhance	96.12516	12
59	35	enhance	95.69608	13
59	41	enhance	95.54227	14
59	78	enhance	95.3166	15
59	91	enhance	94.868744	16
59	96	enhance	94.741234	17
59	22	enhance	94.58194	18
59	184	enhance	93.904175	19
59	44	enhance	91.84107	20
59	74	enhance	91.09424	21
59	93	enhance	90.28275	22
59	8	enhance	89.40953	23
59	82	enhance	89.085335	24
59	55	enhance	89.07933	25
59	868	enhance	88.480835	26
59	60	enhance	88.236305	27
59	18	enhance	87.876564	28
59	3	enhance	87.39413	29
59	20	enhance	87.17107	30
59	64	enhance	85.7527	31
59	27	enhance	85.027794	32
59	11	enhance	84.228546	33
59	50	enhance	83.75498	34
59	171	enhance	83.706635	35
59	54	enhance	83.57584	36
59	94	enhance	83.360634	37
59	79	enhance	82.78625	38
59	10	enhance	82.37213	39
59	455	enhance	81.66918	40
59	65	enhance	81.28506	41
59	77	enhance	80.31418	42
59	70	enhance	80.174835	43
59	72	enhance	79.81048	44
59	100	enhance	79.47811	45
59	28	enhance	78.99236	46
59	488	enhance	78.641	47
59	58	enhance	78.50734	48
59	52	enhance	78.29479	49
59	83	enhance	77.59556	50
59	14	enhance	76.05256	51
59	32	enhance	76.04004	52
59	90	enhance	75.44619	53
59	39	enhance	74.38518	54
59	95	enhance	74.110016	55
59	7	enhance	73.658394	56
59	182	enhance	72.157326	57
59	34	enhance	71.44052	58
59	24	enhance	69.54033	59
59	53	enhance	69.371956	60
59	99	enhance	68.90521	61
59	62	enhance	67.31139	62
59	126	enhance	67.08235	63
59	92	enhance	67.043015	64
59	176	enhance	64.971535	65
59	19	enhance	64.83836	66
59	63	enhance	64.05092	67
59	921	enhance	63.53303	68
59	86	enhance	63.418034	69
59	2	enhance	63.01752	70
59	185	enhance	62.88726	71
59	38	enhance	61.133625	72
59	49	enhance	60.971615	73
59	42	enhance	60.548504	74
59	81	enhance	58.50543	75
59	80	enhance	58.115307	76
59	785	enhance	58.019497	77
59	43	enhance	57.235306	78
59	76	enhance	57.1126	79
59	285	enhance	55.81857	80
59	187	enhance	55.70534	81
59	108	enhance	55.05256	82
59	6	enhance	54.895725	83
59	57	enhance	53.984203	84
59	647	enhance	53.950817	85
59	29	enhance	53.557976	86
59	16	enhance	53.03643	87
59	97	enhance	52.866093	88
59	13	enhance	50.50108	89
59	358	enhance	50.182667	90
59	17	enhance	48.96222	91
59	15	enhance	48.49363	92
59	26	enhance	48.411785	93
59	45	enhance	48.32064	94
59	222	enhance	48.09087	95
59	901	enhance	48.015137	96
59	37	enhance	47.771473	97
59	89	enhance	46.216316	98
59	71	enhance	45.30245	99
59	73	enhance	44.053375	100
59	84	enhance	44.026745	101
59	48	enhance	43.78507	102
59	68	enhance	43.171432	103
59	640	enhance	42.79267	104
59	98	enhance	42.629784	105
59	230	enhance	42.02852	106
59	87	enhance	41.193363	107
59	1	enhance	40.794373	108
59	31	enhance	40.75436	109
59	56	enhance	40.62428	110
59	36	enhance	39.605404	111
59	88	enhance	39.403824	112
59	61	enhance	39.38848	113
59	47	enhance	37.81649	114
59	51	enhance	36.702747	115
59	40	enhance	35.941456	116
59	30	enhance	33.56117	117
59	46	enhance	32.98603	118
59	25	enhance	32.665966	119
59	33	enhance	32.35621	120
59	75	enhance	30.889147	121
59	155	enhance	30.530073	122
59	882	enhance	29.169514	123
59	67	enhance	27.766111	124
59	11	soften	100	1
59	126	soften	99.25897	2
59	90	soften	98.62848	3
59	3	soften	95.15739	4
59	55	soften	94.61734	5
59	93	soften	91.612076	6
59	91	soften	90.43812	7
59	79	soften	89.280556	8
59	184	soften	87.37982	9
59	4	soften	85.61377	10
59	868	soften	84.48141	11
59	23	soften	83.28524	12
59	22	soften	82.470924	13
59	171	soften	82.38182	14
59	96	soften	81.442535	15
59	219	soften	79.706726	16
59	21	soften	78.04205	17
59	80	soften	70.62716	18
59	64	soften	69.41704	19
59	72	soften	68.72675	20
59	83	soften	68.47163	21
59	60	soften	67.85661	22
59	45	soften	65.38631	23
59	70	soften	65.35908	24
59	74	soften	61.819542	25
59	335	soften	56.432583	26
60	11	enhance	100	1
60	55	enhance	99.719864	2
60	64	enhance	97.02471	3
60	4	enhance	95.00533	4
60	91	enhance	94.78156	5
60	868	enhance	92.15848	6
60	3	enhance	91.73954	7
60	9	enhance	90.863525	8
60	93	enhance	90.82706	9
60	184	enhance	90.32785	10
60	23	enhance	90.14946	11
60	72	enhance	89.93685	12
60	22	enhance	89.33382	13
60	335	enhance	89.292786	14
60	5	enhance	88.47647	15
60	59	enhance	88.3334	16
60	83	enhance	86.71188	17
60	44	enhance	85.77399	18
60	219	enhance	84.83216	19
60	41	enhance	84.803444	20
60	74	enhance	84.77363	21
60	21	enhance	84.126854	22
60	70	enhance	83.77187	23
60	90	enhance	83.55277	24
60	12	enhance	83.498985	25
60	96	enhance	82.96979	26
60	593	enhance	82.315315	27
60	85	enhance	81.23616	28
60	82	enhance	81.171074	29
60	78	enhance	81.100296	30
60	171	enhance	81.02709	31
60	69	enhance	80.69735	32
60	66	enhance	80.489365	33
60	35	enhance	79.41604	34
60	94	enhance	78.00717	35
60	50	enhance	76.5872	36
60	126	enhance	73.947624	37
60	8	enhance	73.37669	38
60	182	enhance	72.972595	39
60	20	enhance	72.296745	40
60	99	enhance	71.03025	41
60	79	enhance	70.46234	42
60	28	enhance	70.22733	43
60	92	enhance	68.06729	44
60	10	enhance	67.876854	45
60	34	enhance	67.662964	46
60	18	enhance	66.32088	47
60	7	enhance	65.48961	48
60	27	enhance	64.51289	49
60	39	enhance	63.68643	50
60	19	enhance	62.63103	51
60	58	enhance	60.510628	52
60	54	enhance	60.36681	53
60	63	enhance	58.930134	54
60	49	enhance	58.68528	55
60	80	enhance	58.65606	56
60	13	enhance	55.65241	57
60	52	enhance	55.518314	58
60	43	enhance	55.326256	59
60	455	enhance	55.25985	60
60	65	enhance	54.96986	61
60	2	enhance	54.365356	62
60	176	enhance	53.673237	63
60	187	enhance	53.537697	64
60	95	enhance	52.51355	65
60	77	enhance	51.7599	66
60	488	enhance	50.953323	67
60	100	enhance	50.920517	68
60	285	enhance	50.213173	69
60	86	enhance	49.91455	70
60	222	enhance	49.133186	71
60	14	enhance	48.698517	72
60	640	enhance	46.42975	73
60	32	enhance	45.953815	74
60	45	enhance	44.78812	75
60	230	enhance	40.46944	76
60	24	enhance	39.916294	77
60	47	enhance	39.891434	78
60	61	enhance	39.42308	79
60	51	enhance	39.21503	80
60	108	enhance	38.85712	81
60	62	enhance	38.465527	82
60	15	enhance	38.354465	83
60	33	enhance	37.56554	84
60	921	enhance	36.513535	85
60	185	enhance	36.264828	86
60	53	enhance	35.658348	87
60	98	enhance	35.09588	88
60	57	enhance	34.96839	89
60	901	enhance	34.823025	90
60	785	enhance	33.143616	91
60	89	enhance	32.806988	92
60	73	enhance	32.56604	93
60	81	enhance	32.397488	94
60	31	enhance	32.317066	95
60	56	enhance	31.927477	96
60	38	enhance	31.241333	97
60	647	enhance	31.106796	98
60	88	enhance	30.91978	99
60	42	enhance	30.427685	100
60	26	enhance	29.968046	101
60	1	enhance	28.918488	102
60	30	enhance	28.674505	103
60	76	enhance	28.553984	104
60	16	enhance	27.656477	105
60	68	enhance	27.3957	106
60	37	enhance	26.9887	107
60	71	enhance	26.979101	108
60	17	enhance	26.273024	109
60	84	enhance	26.238247	110
60	67	enhance	26.217539	111
60	48	enhance	26.001453	112
60	6	enhance	25.350702	113
60	36	enhance	24.057497	114
60	29	enhance	23.611	115
60	97	enhance	22.660242	116
60	358	enhance	22.512348	117
60	87	enhance	20.216022	118
60	40	enhance	17.854744	119
60	25	enhance	15.28505	120
60	75	enhance	14.9025345	121
60	46	enhance	14.743804	122
60	155	enhance	12.303598	123
60	882	enhance	11.070147	124
60	64	soften	100	1
60	11	soften	96.407196	2
60	74	soften	90.124504	3
61	230	enhance	100	1
61	640	enhance	98.434006	2
61	13	enhance	97.485085	3
61	33	enhance	96.68472	4
61	31	enhance	93.61896	5
61	49	enhance	93.58611	6
61	98	enhance	91.52381	7
61	47	enhance	90.32932	8
61	182	enhance	87.24761	9
61	43	enhance	87.19127	10
61	63	enhance	87.18575	11
61	222	enhance	85.9552	12
61	88	enhance	85.68242	13
61	99	enhance	85.177246	14
61	126	enhance	83.018074	15
61	45	enhance	82.6926	16
61	2	enhance	81.37292	17
61	34	enhance	79.61618	18
61	50	enhance	79.22683	19
61	285	enhance	78.80979	20
61	70	enhance	78.26758	21
61	56	enhance	76.99913	22
61	30	enhance	76.95388	23
61	94	enhance	76.3469	24
61	90	enhance	75.82587	25
61	67	enhance	75.48384	26
61	80	enhance	74.935844	27
61	92	enhance	74.55625	28
61	39	enhance	74.38244	29
61	108	enhance	72.96587	30
61	51	enhance	71.57886	31
61	89	enhance	71.527885	32
61	176	enhance	71.11581	33
61	36	enhance	70.48008	34
61	187	enhance	70.22057	35
61	73	enhance	69.98062	36
61	84	enhance	68.70483	37
61	72	enhance	68.063	38
61	1	enhance	67.725044	39
61	83	enhance	66.94873	40
61	40	enhance	65.77266	41
61	647	enhance	65.21163	42
61	68	enhance	64.397156	43
61	7	enhance	64.18847	44
61	19	enhance	63.221004	45
61	79	enhance	62.324947	46
61	82	enhance	61.98319	47
61	86	enhance	59.795414	48
61	10	enhance	58.973568	49
61	28	enhance	58.70548	50
61	93	enhance	58.697918	51
61	25	enhance	58.45779	52
61	48	enhance	58.150852	53
61	75	enhance	58.070084	54
61	71	enhance	57.79046	55
61	3	enhance	57.307922	56
61	593	enhance	56.70144	57
61	54	enhance	54.89411	58
61	18	enhance	54.80768	59
61	87	enhance	53.760536	60
61	15	enhance	52.70562	61
61	27	enhance	52.49601	62
61	17	enhance	52.209908	63
61	785	enhance	50.93093	64
61	46	enhance	50.79977	65
61	37	enhance	50.358875	66
61	24	enhance	50.35556	67
61	455	enhance	49.372173	68
61	185	enhance	49.030247	69
61	52	enhance	48.348328	70
61	55	enhance	47.403732	71
61	155	enhance	47.209835	72
61	66	enhance	47.097824	73
61	882	enhance	46.628853	74
61	6	enhance	45.55832	75
61	62	enhance	45.09432	76
61	26	enhance	44.92866	77
61	5	enhance	44.784847	78
61	97	enhance	44.25494	79
61	78	enhance	44.251404	80
61	23	enhance	43.64781	81
61	76	enhance	43.293518	82
61	358	enhance	43.2173	83
61	44	enhance	40.935158	84
61	868	enhance	40.88717	85
61	58	enhance	39.751156	86
61	184	enhance	39.11523	87
61	59	enhance	38.942944	88
61	60	enhance	38.934315	89
61	38	enhance	38.64407	90
61	11	enhance	38.568428	91
61	16	enhance	38.15686	92
61	921	enhance	37.42114	93
61	29	enhance	37.12407	94
61	100	enhance	37.09068	95
61	74	enhance	36.956665	96
61	42	enhance	36.948486	97
61	901	enhance	36.603188	98
61	91	enhance	36.487026	99
61	64	enhance	36.437073	100
61	77	enhance	36.317818	101
61	171	enhance	35.5458	102
61	8	enhance	34.715565	103
61	9	enhance	34.436935	104
61	21	enhance	33.9053	105
61	81	enhance	33.42407	106
61	96	enhance	33.0294	107
61	4	enhance	32.699806	108
61	14	enhance	32.41743	109
61	219	enhance	31.955828	110
61	20	enhance	31.940931	111
61	32	enhance	31.634613	112
61	22	enhance	31.354612	113
61	53	enhance	30.206402	114
61	335	enhance	29.787203	115
61	85	enhance	29.378342	116
61	12	enhance	28.981808	117
61	95	enhance	28.427439	118
61	69	enhance	28.418518	119
61	35	enhance	27.513605	120
61	57	enhance	26.538662	121
61	65	enhance	26.394531	122
61	488	enhance	25.911806	123
61	41	enhance	25.390377	124
61	64	soften	100	1
61	74	soften	96.91974	2
61	11	soften	96.481445	3
61	91	soften	94.057846	4
61	60	soften	92.457985	5
61	96	soften	91.2635	6
61	184	soften	90.16627	7
61	335	soften	89.602165	8
61	55	soften	88.548996	9
61	22	soften	87.64041	10
61	4	soften	87.31056	11
61	868	soften	86.88698	12
61	21	soften	86.87596	13
61	219	soften	86.44593	14
61	171	soften	86.14682	15
61	20	soften	85.65664	16
61	3	soften	84.556816	17
61	85	soften	84.04283	18
61	12	soften	84.018906	19
61	93	soften	83.88776	20
61	23	soften	83.8419	21
61	95	soften	83.80697	22
61	59	soften	83.73516	23
61	35	soften	83.64876	24
61	78	soften	83.46117	25
61	9	soften	83.4196	26
61	83	soften	82.31815	27
61	41	soften	82.13455	28
61	44	soften	81.88462	29
61	80	soften	81.59841	30
61	79	soften	81.17739	31
61	72	soften	81.141	32
61	5	soften	80.07463	33
61	18	soften	78.86639	34
61	70	soften	78.6763	35
61	90	soften	78.08445	36
61	126	soften	77.633354	37
61	82	soften	76.6651	38
61	593	soften	76.40991	39
61	45	soften	76.04993	40
61	28	soften	75.23077	41
61	34	soften	74.91769	42
61	94	soften	74.52177	43
61	39	soften	73.77149	44
61	73	soften	73.00615	45
61	2	soften	72.68213	46
61	30	soften	72.42731	47
61	43	soften	71.691605	48
61	63	soften	71.37493	49
61	99	soften	71.02123	50
61	49	soften	70.90847	51
61	182	soften	70.54514	52
61	13	soften	69.08886	53
61	222	soften	69.04841	54
61	640	soften	64.61247	55
61	33	soften	64.361	56
62	185	enhance	100	1
62	42	enhance	98.790016	2
62	38	enhance	98.54288	3
62	455	enhance	98.00328	4
62	100	enhance	97.06771	5
62	77	enhance	96.700424	6
62	24	enhance	96.40088	7
62	921	enhance	96.110504	8
62	76	enhance	95.16065	9
62	6	enhance	94.56166	10
62	81	enhance	94.46591	11
62	785	enhance	93.837204	12
62	16	enhance	93.07766	13
62	647	enhance	91.96896	14
62	52	enhance	91.69563	15
62	29	enhance	90.94925	16
62	54	enhance	90.85926	17
62	97	enhance	90.36991	18
62	358	enhance	90.095634	19
62	65	enhance	90.090324	20
62	26	enhance	89.87383	21
62	37	enhance	89.30729	22
62	17	enhance	87.8948	23
62	53	enhance	87.75301	24
62	14	enhance	87.71524	25
62	58	enhance	86.80492	26
62	89	enhance	86.3125	27
62	32	enhance	86.2146	28
62	108	enhance	85.06821	29
62	71	enhance	84.648506	30
62	18	enhance	83.84741	31
62	27	enhance	83.55998	32
62	901	enhance	82.654335	33
62	10	enhance	82.01607	34
62	15	enhance	81.580956	35
62	1	enhance	81.45654	36
62	48	enhance	80.74304	37
62	87	enhance	80.46581	38
62	36	enhance	79.55117	39
62	7	enhance	79.47415	40
62	488	enhance	78.58604	41
62	84	enhance	78.01884	42
62	28	enhance	77.947845	43
62	68	enhance	77.75509	44
62	57	enhance	77.37241	45
62	593	enhance	76.70658	46
62	78	enhance	76.553154	47
62	19	enhance	76.23146	48
62	40	enhance	76.07985	49
62	8	enhance	75.772026	50
62	66	enhance	75.58885	51
62	56	enhance	75.56074	52
62	86	enhance	75.500114	53
62	176	enhance	74.98618	54
62	39	enhance	74.32316	55
62	25	enhance	74.06415	56
62	95	enhance	73.86715	57
62	187	enhance	73.44431	58
62	46	enhance	72.90507	59
62	20	enhance	72.6223	60
62	155	enhance	72.20661	61
62	882	enhance	71.93747	62
62	219	enhance	71.390526	63
62	285	enhance	70.46601	64
62	50	enhance	70.46306	65
62	75	enhance	69.50804	66
62	171	enhance	69.1843	67
62	92	enhance	68.8662	68
62	35	enhance	68.805275	69
62	94	enhance	67.83353	70
62	63	enhance	67.816414	71
62	69	enhance	67.48111	72
62	59	enhance	67.25539	73
62	34	enhance	66.57574	74
62	88	enhance	66.460556	75
62	31	enhance	65.1308	76
62	85	enhance	65.076836	77
62	41	enhance	65.075584	78
62	12	enhance	64.82436	79
62	73	enhance	64.44228	80
62	21	enhance	63.26074	81
62	335	enhance	62.86155	82
62	868	enhance	62.75352	83
62	82	enhance	61.85453	84
62	44	enhance	61.771057	85
62	98	enhance	61.759655	86
62	5	enhance	61.61523	87
62	79	enhance	60.42434	88
62	184	enhance	60.190483	89
62	96	enhance	59.72002	90
62	43	enhance	59.038616	91
62	49	enhance	58.345337	92
62	9	enhance	58.16819	93
62	30	enhance	57.568325	94
62	45	enhance	55.466618	95
62	23	enhance	54.35155	96
62	182	enhance	54.070946	97
62	22	enhance	53.80819	98
62	4	enhance	51.827446	99
62	2	enhance	51.71019	100
62	47	enhance	50.733612	101
62	74	enhance	50.322628	102
62	222	enhance	49.380337	103
62	70	enhance	48.503975	104
62	99	enhance	48.502716	105
62	55	enhance	47.914207	106
62	3	enhance	47.427624	107
62	93	enhance	47.06637	108
62	67	enhance	46.825012	109
62	61	enhance	45.57229	110
62	230	enhance	45.19651	111
62	83	enhance	43.07206	112
62	51	enhance	42.93813	113
62	64	enhance	42.775898	114
62	91	enhance	42.598835	115
62	13	enhance	41.61054	116
62	80	enhance	40.583454	117
62	11	enhance	40.2561	118
62	640	enhance	40.22803	119
62	126	enhance	40.031216	120
62	72	enhance	38.514183	121
62	60	enhance	38.391285	122
62	90	enhance	34.62225	123
62	33	enhance	30.590874	124
62	80	soften	100	1
62	11	soften	98.715416	2
62	64	soften	98.519	3
62	90	soften	97.3804	4
62	126	soften	97.13196	5
62	60	soften	96.86092	6
62	72	soften	95.75573	7
62	83	soften	95.4942	8
62	91	soften	93.604774	9
62	3	soften	92.98865	10
62	55	soften	92.95433	11
62	74	soften	92.90655	12
62	70	soften	91.61706	13
62	93	soften	91.13317	14
62	33	soften	90.298485	15
62	45	soften	89.7543	16
62	79	soften	89.34135	17
62	13	soften	89.31416	18
62	49	soften	86.933426	19
62	99	soften	86.51139	20
62	2	soften	86.48304	21
62	182	soften	85.91872	22
62	23	soften	85.87852	23
62	30	soften	85.81437	24
62	43	soften	85.71063	25
62	4	soften	85.68406	26
62	34	soften	85.53951	27
62	184	soften	85.23101	28
62	61	soften	85.054794	29
62	640	soften	84.97952	30
62	96	soften	84.18492	31
62	230	soften	83.701744	32
62	82	soften	83.52522	33
62	73	soften	83.491844	34
62	868	soften	82.7743	35
62	222	soften	82.45375	36
62	171	soften	82.15155	37
62	22	soften	82.09291	38
62	21	soften	81.789185	39
62	5	soften	81.734695	40
62	94	soften	81.56882	41
62	9	soften	81.551285	42
62	335	soften	81.53611	43
62	63	soften	81.41457	44
62	59	soften	80.12456	45
62	219	soften	79.49166	46
62	20	soften	79.33008	47
62	78	soften	79.31899	48
62	51	soften	79.26859	49
62	50	soften	79.24232	50
62	44	soften	79.167755	51
62	47	soften	78.999214	52
62	28	soften	78.754425	53
62	39	soften	78.399605	54
62	12	soften	78.363495	55
62	18	soften	78.059875	56
62	85	soften	77.94186	57
62	593	soften	77.93528	58
62	31	soften	77.65026	59
62	98	soften	77.5009	60
62	35	soften	77.4416	61
62	285	soften	77.16082	62
62	92	soften	77.04114	63
62	187	soften	76.77948	64
62	95	soften	76.33475	65
62	66	soften	75.8289	66
62	41	soften	75.426704	67
62	56	soften	75.36745	68
62	176	soften	75.12719	69
62	69	soften	74.22032	70
62	67	soften	74.08775	71
62	7	soften	73.74546	72
62	8	soften	73.70261	73
62	88	soften	72.48257	74
62	89	soften	72.25722	75
62	19	soften	71.78095	76
62	54	soften	71.60842	77
62	27	soften	71.19208	78
62	86	soften	70.89164	79
62	10	soften	70.37936	80
62	84	soften	70.06097	81
62	108	soften	69.74576	82
62	1	soften	69.42624	83
62	58	soften	68.65498	84
62	455	soften	68.12385	85
62	488	soften	68.00632	86
62	647	soften	67.58724	87
62	24	soften	67.11242	88
62	52	soften	66.88889	89
62	26	soften	66.84137	90
62	14	soften	66.22846	91
63	43	enhance	100	1
63	99	enhance	98.26202	2
63	2	enhance	96.45663	3
63	49	enhance	94.8782	4
63	34	enhance	94.587814	5
63	230	enhance	93.23136	6
63	13	enhance	92.20567	7
63	31	enhance	92.02412	8
63	39	enhance	91.77567	9
63	61	enhance	91.04803	10
63	45	enhance	91.01839	11
63	50	enhance	90.753716	12
63	7	enhance	90.05702	13
63	70	enhance	89.6062	14
63	126	enhance	89.47734	15
63	94	enhance	88.94214	16
63	640	enhance	88.75007	17
63	182	enhance	88.27487	18
63	89	enhance	88.105736	19
63	33	enhance	88.06572	20
63	90	enhance	86.39478	21
63	108	enhance	85.73651	22
63	593	enhance	85.4254	23
63	187	enhance	85.08314	24
63	80	enhance	84.66017	25
63	82	enhance	83.86695	26
63	92	enhance	83.14715	27
63	98	enhance	82.82468	28
63	56	enhance	82.80323	29
63	30	enhance	80.70424	30
63	93	enhance	80.44885	31
63	18	enhance	79.14531	32
63	285	enhance	78.7096	33
63	3	enhance	78.6685	34
63	28	enhance	77.902336	35
63	222	enhance	77.74812	36
63	79	enhance	77.09268	37
63	19	enhance	76.82893	38
63	647	enhance	76.69719	39
63	83	enhance	76.619354	40
63	47	enhance	76.19236	41
63	88	enhance	76.0102	42
63	73	enhance	75.83382	43
63	455	enhance	75.61284	44
63	58	enhance	75.58694	45
63	176	enhance	75.35703	46
63	72	enhance	75.25541	47
63	78	enhance	74.37217	48
63	1	enhance	74.27703	49
63	868	enhance	73.421555	50
63	23	enhance	72.72818	51
63	10	enhance	72.26881	52
63	36	enhance	72.238235	53
63	5	enhance	72.2329	54
63	55	enhance	72.13633	55
63	54	enhance	71.647415	56
63	86	enhance	70.54251	57
63	62	enhance	70.077866	58
63	52	enhance	69.53788	59
63	24	enhance	69.45771	60
63	184	enhance	69.42825	61
63	185	enhance	69.38807	62
63	171	enhance	68.997086	63
63	20	enhance	68.71075	64
63	219	enhance	68.52482	65
63	44	enhance	68.19654	66
63	84	enhance	67.42886	67
63	96	enhance	67.282875	68
63	27	enhance	67.08799	69
63	8	enhance	66.767265	70
63	59	enhance	66.13174	71
63	74	enhance	66.08069	72
63	66	enhance	65.67106	73
63	40	enhance	65.63679	74
63	64	enhance	64.94317	75
63	11	enhance	64.88969	76
63	15	enhance	64.75636	77
63	68	enhance	64.511635	78
63	9	enhance	63.632652	79
63	48	enhance	63.437992	80
63	95	enhance	63.069763	81
63	26	enhance	63.06314	82
63	335	enhance	62.894478	83
63	71	enhance	62.84769	84
63	785	enhance	62.77158	85
63	77	enhance	62.592373	86
63	100	enhance	62.530178	87
63	21	enhance	62.468727	88
63	14	enhance	62.335567	89
63	91	enhance	61.229626	90
63	921	enhance	61.10692	91
63	4	enhance	60.95002	92
63	60	enhance	60.777725	93
63	37	enhance	60.636177	94
63	38	enhance	60.401527	95
63	22	enhance	59.911964	96
63	25	enhance	59.80929	97
63	35	enhance	59.4882	98
63	41	enhance	59.23603	99
63	67	enhance	59.225056	100
63	42	enhance	58.76703	101
63	85	enhance	58.72701	102
63	6	enhance	58.66444	103
63	69	enhance	58.56002	104
63	901	enhance	58.09624	105
63	65	enhance	58.00747	106
63	32	enhance	57.950005	107
63	12	enhance	57.74616	108
63	17	enhance	57.67273	109
63	87	enhance	57.493515	110
63	488	enhance	55.922398	111
63	76	enhance	55.760155	112
63	51	enhance	55.24897	113
63	16	enhance	55.02846	114
63	97	enhance	54.330624	115
63	81	enhance	53.163235	116
63	57	enhance	52.519566	117
63	75	enhance	52.459904	118
63	358	enhance	51.400333	119
63	29	enhance	48.67249	120
63	53	enhance	47.634914	121
63	155	enhance	45.692524	122
63	46	enhance	44.777603	123
63	882	enhance	44.66473	124
63	11	soften	100	1
63	60	soften	97.632965	2
63	91	soften	95.57274	3
63	55	soften	93.504654	4
63	83	soften	91.21968	5
63	72	soften	91.09441	6
63	184	soften	91.05983	7
63	96	soften	90.132225	8
63	3	soften	90.11746	9
63	80	soften	89.74515	10
63	868	soften	88.94595	11
63	4	soften	88.92875	12
63	335	soften	88.90394	13
63	93	soften	88.85773	14
63	22	soften	88.29272	15
63	126	soften	87.67188	16
63	90	soften	87.585655	17
63	70	soften	86.89775	18
63	171	soften	86.887665	19
63	21	soften	86.08942	20
63	219	soften	85.86139	21
63	23	soften	85.67647	22
63	79	soften	85.38386	23
63	59	soften	84.97824	24
63	78	soften	84.73572	25
63	20	soften	84.52666	26
63	9	soften	84.31249	27
63	44	soften	83.99948	28
63	45	soften	83.73693	29
63	12	soften	83.4651	30
63	85	soften	82.78843	31
63	35	soften	82.579956	32
63	5	soften	82.08982	33
63	34	soften	81.76663	34
63	82	soften	81.53771	35
63	41	soften	81.4198	36
63	13	soften	81.10434	37
63	18	soften	80.824554	38
63	30	soften	80.67382	39
63	182	soften	80.26889	40
63	73	soften	79.55551	41
63	28	soften	79.356476	42
63	43	soften	79.305595	43
63	2	soften	79.28879	44
63	593	soften	79.258255	45
63	99	soften	79.21186	46
63	39	soften	79.13839	47
63	33	soften	77.588875	48
63	64	soften	70.92835	49
63	74	soften	67.02951	50
63	95	soften	57.66861	51
63	94	soften	56.739742	52
63	222	soften	56.304054	53
63	49	soften	56.302574	54
64	11	enhance	100	1
64	60	enhance	95.7332	2
64	184	enhance	95.507095	3
64	55	enhance	95.22235	4
64	91	enhance	93.146095	5
64	868	enhance	92.01678	6
64	74	enhance	91.008	7
64	93	enhance	90.90933	8
64	3	enhance	90.61456	9
64	335	enhance	90.26708	10
64	22	enhance	90.200966	11
64	4	enhance	90.03632	12
64	23	enhance	88.12081	13
64	219	enhance	87.949394	14
64	9	enhance	87.92007	15
64	96	enhance	87.77103	16
64	44	enhance	86.80561	17
64	78	enhance	85.98508	18
64	59	enhance	84.70433	19
64	5	enhance	84.12839	20
64	21	enhance	84.00034	21
64	41	enhance	83.985374	22
64	171	enhance	82.34037	23
64	593	enhance	81.07479	24
64	72	enhance	80.60281	25
64	70	enhance	80.05237	26
64	90	enhance	79.38721	27
64	83	enhance	79.38303	28
64	69	enhance	79.26971	29
64	85	enhance	79.23772	30
64	12	enhance	78.941826	31
64	35	enhance	77.25414	32
64	20	enhance	76.89731	33
64	79	enhance	75.17989	34
64	66	enhance	74.56872	35
64	94	enhance	74.28399	36
64	82	enhance	73.319916	37
64	18	enhance	72.69706	38
64	126	enhance	71.58009	39
64	28	enhance	70.656715	40
64	8	enhance	69.825226	41
64	50	enhance	69.56647	42
64	39	enhance	68.758896	43
64	80	enhance	67.54825	44
64	99	enhance	67.444855	45
64	34	enhance	66.95854	46
64	58	enhance	66.154625	47
64	27	enhance	65.744026	48
64	7	enhance	64.70911	49
64	10	enhance	63.874306	50
64	63	enhance	62.13076	51
64	182	enhance	60.970257	52
64	92	enhance	60.28789	53
64	43	enhance	59.102943	54
64	54	enhance	58.716007	55
64	455	enhance	58.32023	56
64	95	enhance	58.175472	57
64	49	enhance	57.538578	58
64	52	enhance	56.688896	59
64	2	enhance	56.139957	60
64	19	enhance	55.430927	61
64	65	enhance	53.66743	62
64	86	enhance	52.835327	63
64	45	enhance	52.728813	64
64	488	enhance	50.536247	65
64	77	enhance	50.195206	66
64	13	enhance	49.476494	67
64	100	enhance	49.415665	68
64	187	enhance	49.045444	69
64	14	enhance	46.728203	70
64	176	enhance	46.2157	71
64	285	enhance	45.313766	72
64	73	enhance	43.192074	73
64	62	enhance	42.28812	74
64	24	enhance	42.031086	75
64	32	enhance	41.90719	76
64	30	enhance	40.248314	77
64	108	enhance	40.077877	78
64	222	enhance	39.90404	79
64	640	enhance	39.59733	80
64	89	enhance	39.213943	81
64	56	enhance	37.823803	82
64	230	enhance	37.573658	83
64	921	enhance	37.54467	84
64	185	enhance	37.11716	85
64	61	enhance	36.403385	86
64	647	enhance	34.880245	87
64	57	enhance	34.318085	88
64	26	enhance	34.006145	89
64	47	enhance	33.67711	90
64	53	enhance	33.378178	91
64	15	enhance	33.137856	92
64	33	enhance	31.477583	93
64	901	enhance	31.168638	94
64	38	enhance	31.11459	95
64	31	enhance	30.806393	96
64	42	enhance	30.123247	97
64	1	enhance	29.706917	98
64	81	enhance	29.593718	99
64	785	enhance	29.13968	100
64	6	enhance	28.945072	101
64	84	enhance	28.67958	102
64	98	enhance	27.742855	103
64	76	enhance	26.942871	104
64	16	enhance	26.28587	105
64	97	enhance	25.752699	106
64	51	enhance	25.72015	107
64	88	enhance	25.344093	108
64	36	enhance	25.170038	109
64	68	enhance	24.70352	110
64	37	enhance	24.367863	111
64	48	enhance	24.266302	112
64	29	enhance	23.208511	113
64	17	enhance	22.449167	114
64	358	enhance	21.02352	115
64	71	enhance	20.958311	116
64	87	enhance	18.72951	117
64	40	enhance	18.631645	118
64	67	enhance	16.388624	119
64	25	enhance	14.48849	120
64	46	enhance	12.22904	121
64	75	enhance	11.983217	122
64	882	enhance	10.617556	123
64	155	enhance	10.599312	124
65	14	enhance	100	1
65	77	enhance	99.13774	2
65	32	enhance	98.88166	3
65	100	enhance	97.99781	4
65	488	enhance	97.41675	5
65	921	enhance	96.26432	6
65	8	enhance	95.89329	7
65	81	enhance	94.61155	8
65	62	enhance	92.67603	9
65	58	enhance	92.32848	10
65	35	enhance	91.73381	11
65	57	enhance	91.503555	12
65	53	enhance	90.842606	13
65	69	enhance	90.409454	14
65	20	enhance	90.327835	15
65	455	enhance	89.5195	16
65	54	enhance	89.16444	17
65	219	enhance	88.88473	18
65	95	enhance	88.03594	19
65	42	enhance	87.72425	20
65	41	enhance	87.61738	21
65	185	enhance	87.2634	22
65	12	enhance	87.23305	23
65	85	enhance	86.972725	24
65	18	enhance	86.74953	25
65	38	enhance	86.03616	26
65	171	enhance	85.44187	27
65	593	enhance	85.08476	28
65	66	enhance	83.76825	29
65	78	enhance	83.72261	30
65	59	enhance	83.54848	31
65	24	enhance	82.53674	32
65	21	enhance	82.50397	33
65	5	enhance	82.43342	34
65	76	enhance	82.08087	35
65	9	enhance	80.82569	36
65	335	enhance	80.374344	37
65	28	enhance	79.41894	38
65	37	enhance	79.3998	39
65	52	enhance	79.356186	40
65	26	enhance	78.633514	41
65	82	enhance	78.52949	42
65	29	enhance	78.07858	43
65	27	enhance	77.78868	44
65	785	enhance	77.52132	45
65	16	enhance	77.427704	46
65	23	enhance	75.847565	47
65	96	enhance	75.6188	48
65	901	enhance	74.35916	49
65	50	enhance	73.96005	50
65	10	enhance	73.83095	51
65	6	enhance	73.71778	52
65	4	enhance	73.30811	53
65	19	enhance	73.03237	54
65	358	enhance	71.464615	55
65	7	enhance	71.039986	56
65	647	enhance	70.003	57
65	184	enhance	69.81444	58
65	44	enhance	69.6975	59
65	868	enhance	69.008385	60
65	22	enhance	68.713615	61
65	97	enhance	68.188545	62
65	34	enhance	67.49487	63
65	17	enhance	66.31162	64
65	15	enhance	65.37357	65
65	74	enhance	64.91149	66
65	79	enhance	64.428856	67
65	187	enhance	63.580555	68
65	55	enhance	63.496067	69
65	89	enhance	62.509678	70
65	108	enhance	59.912537	71
65	91	enhance	59.639244	72
65	39	enhance	59.54509	73
65	71	enhance	59.358604	74
65	3	enhance	58.64955	75
65	94	enhance	58.44121	76
65	63	enhance	57.7467	77
65	176	enhance	56.445484	78
65	60	enhance	56.438427	79
65	64	enhance	55.844555	80
65	93	enhance	55.579884	81
65	2	enhance	55.293694	82
65	56	enhance	55.251575	83
65	11	enhance	55.08794	84
65	182	enhance	53.67853	85
65	92	enhance	53.606834	86
65	87	enhance	52.815117	87
65	48	enhance	52.0547	88
65	43	enhance	51.839058	89
65	86	enhance	51.656265	90
65	68	enhance	49.707108	91
65	1	enhance	49.701427	92
65	99	enhance	49.27395	93
65	73	enhance	49.05664	94
65	83	enhance	48.742325	95
65	70	enhance	48.256157	96
65	84	enhance	47.92357	97
65	36	enhance	46.466278	98
65	46	enhance	46.24386	99
65	285	enhance	44.164536	100
65	72	enhance	43.69552	101
65	49	enhance	43.087536	102
65	155	enhance	42.637665	103
65	90	enhance	42.342426	104
65	40	enhance	42.32386	105
65	882	enhance	42.24231	106
65	45	enhance	41.217133	107
65	126	enhance	41.18667	108
65	25	enhance	41.17467	109
65	31	enhance	40.8491	110
65	98	enhance	38.156425	111
65	30	enhance	37.771446	112
65	88	enhance	36.99916	113
65	75	enhance	36.89281	114
65	80	enhance	36.858955	115
65	230	enhance	31.773327	116
65	222	enhance	29.659224	117
65	47	enhance	29.494495	118
65	13	enhance	27.556871	119
65	61	enhance	27.439882	120
65	640	enhance	24.82624	121
65	51	enhance	22.854069	122
65	33	enhance	19.941128	123
65	67	enhance	19.919174	124
65	80	soften	100	1
65	90	soften	97.68539	2
65	126	soften	97.25314	3
65	72	soften	96.8233	4
65	64	soften	96.7255	5
65	11	soften	95.905334	6
65	83	soften	94.637245	7
65	13	soften	93.93954	8
65	33	soften	93.925026	9
65	60	soften	93.88805	10
65	70	soften	93.40478	11
65	93	soften	92.00987	12
65	3	soften	91.59052	13
65	49	soften	91.41335	14
65	45	soften	91.26339	15
65	91	soften	91.21503	16
65	55	soften	89.94646	17
65	640	soften	89.89069	18
65	61	soften	89.54446	19
65	79	soften	89.32361	20
65	30	soften	88.87384	21
65	222	soften	88.48206	22
65	74	soften	88.44941	23
65	99	soften	88.00382	24
65	182	soften	87.817055	25
65	230	soften	87.340775	26
65	43	soften	86.84363	27
65	94	soften	85.81528	28
65	2	soften	85.44215	29
65	73	soften	85.40278	30
65	51	soften	85.33655	31
65	184	soften	85.29931	32
65	34	soften	84.6025	33
65	98	soften	83.91835	34
65	285	soften	83.771576	35
65	63	soften	83.5664	36
65	39	soften	83.55225	37
65	31	soften	83.07686	38
65	868	soften	82.90455	39
65	47	soften	82.705154	40
65	23	soften	81.97683	41
65	4	soften	81.94844	42
65	22	soften	81.50312	43
65	92	soften	81.34628	44
65	44	soften	81.160194	45
65	67	soften	80.90575	46
65	96	soften	80.44106	47
65	82	soften	80.224625	48
65	50	soften	79.98657	49
65	28	soften	79.959	50
65	88	soften	79.470146	51
65	176	soften	79.42655	52
65	78	soften	79.24333	53
65	335	soften	78.884125	54
65	187	soften	78.44019	55
65	86	soften	78.376595	56
65	59	soften	78.36788	57
65	5	soften	78.35783	58
65	593	soften	78.11973	59
65	56	soften	78.10167	60
65	21	soften	77.8284	61
65	18	soften	77.614044	62
65	9	soften	77.21581	63
65	66	soften	77.09241	64
65	84	soften	76.79566	65
65	171	soften	76.747	66
65	7	soften	76.464645	67
65	89	soften	75.635994	68
65	219	soften	75.48153	69
65	108	soften	75.334595	70
65	27	soften	75.318306	71
65	1	soften	74.946175	72
65	10	soften	73.94975	73
65	12	soften	73.639915	74
65	54	soften	73.34236	75
65	20	soften	73.28561	76
65	19	soften	73.249214	77
65	85	soften	72.94217	78
65	36	soften	72.4518	79
65	647	soften	71.69685	80
65	41	soften	71.508835	81
65	52	soften	71.46719	82
65	35	soften	71.44866	83
65	455	soften	70.47167	84
65	87	soften	70.24926	85
65	8	soften	69.74144	86
65	69	soften	69.700485	87
65	24	soften	69.60841	88
65	95	soften	69.48279	89
65	26	soften	67.990105	90
65	785	soften	67.72276	91
65	6	soften	67.56272	92
65	58	soften	67.52066	93
65	185	soften	65.95783	94
65	62	soften	65.40638	95
65	14	soften	62.98842	96
65	488	soften	62.18757	97
66	59	enhance	100	1
66	27	enhance	98.696236	2
66	593	enhance	97.5965	3
66	54	enhance	97.51728	4
66	12	enhance	96.24737	5
66	21	enhance	95.01131	6
66	78	enhance	94.70009	7
66	85	enhance	94.39229	8
66	5	enhance	94.23849	9
66	10	enhance	93.839455	10
66	335	enhance	92.77463	11
66	69	enhance	91.834145	12
66	52	enhance	91.72608	13
66	35	enhance	91.12673	14
66	18	enhance	91.07586	15
66	455	enhance	90.93082	16
66	4	enhance	90.91081	17
66	50	enhance	90.31315	18
66	23	enhance	89.89641	19
66	44	enhance	89.868484	20
66	94	enhance	89.18183	21
66	219	enhance	89.12809	22
66	9	enhance	89.02601	23
66	184	enhance	88.73458	24
66	100	enhance	88.721924	25
66	28	enhance	88.64147	26
66	77	enhance	88.5066	27
66	22	enhance	88.40028	28
66	41	enhance	88.295746	29
66	8	enhance	87.66623	30
66	91	enhance	86.517624	31
66	93	enhance	84.51195	32
66	82	enhance	84.39388	33
66	79	enhance	84.10387	34
66	53	enhance	84.0929	35
66	65	enhance	83.834	36
66	96	enhance	83.27288	37
66	868	enhance	82.929756	38
66	60	enhance	82.70457	39
66	55	enhance	82.240746	40
66	39	enhance	81.893776	41
66	3	enhance	81.35853	42
66	32	enhance	80.01271	43
66	182	enhance	79.9996	44
66	74	enhance	79.654205	45
66	24	enhance	78.97903	46
66	7	enhance	78.55975	47
66	72	enhance	78.36092	48
66	70	enhance	78.13762	49
66	20	enhance	78.04058	50
66	62	enhance	77.81939	51
66	64	enhance	77.65464	52
66	14	enhance	77.545494	53
66	171	enhance	77.38483	54
66	11	enhance	76.61469	55
66	185	enhance	76.33048	56
66	92	enhance	75.781006	57
66	488	enhance	75.66513	58
66	29	enhance	75.22803	59
66	42	enhance	75.19192	60
66	86	enhance	75.09864	61
66	921	enhance	75.03063	62
66	785	enhance	75.01023	63
66	38	enhance	74.82545	64
66	83	enhance	74.76375	65
66	6	enhance	74.60021	66
66	76	enhance	74.451324	67
66	176	enhance	74.26547	68
66	97	enhance	73.89034	69
66	58	enhance	73.713135	70
66	81	enhance	72.56988	71
66	34	enhance	72.495476	72
66	16	enhance	72.17473	73
66	90	enhance	71.59103	74
66	358	enhance	71.20578	75
66	19	enhance	71.14354	76
66	17	enhance	71.09491	77
66	285	enhance	70.55898	78
66	647	enhance	70.50261	79
66	108	enhance	70.46218	80
66	49	enhance	69.62373	81
66	99	enhance	68.99829	82
66	71	enhance	66.14732	83
66	63	enhance	65.42715	84
66	126	enhance	64.65832	85
66	95	enhance	64.1093	86
66	187	enhance	64.02422	87
66	48	enhance	63.809475	88
66	68	enhance	63.69984	89
66	37	enhance	63.29253	90
66	98	enhance	61.799683	91
66	15	enhance	61.679325	92
66	26	enhance	61.23847	93
66	84	enhance	60.35359	94
66	901	enhance	60.322132	95
66	88	enhance	60.196045	96
66	87	enhance	58.96191	97
66	43	enhance	58.72255	98
66	2	enhance	58.474792	99
66	222	enhance	57.913116	100
66	36	enhance	57.415237	101
66	40	enhance	57.39861	102
66	89	enhance	56.660454	103
66	13	enhance	56.573765	104
66	57	enhance	56.29522	105
66	46	enhance	55.6245	106
66	1	enhance	54.995876	107
66	31	enhance	54.534363	108
66	80	enhance	53.06528	109
66	56	enhance	52.75163	110
66	75	enhance	52.536877	111
66	25	enhance	51.909298	112
66	640	enhance	51.77211	113
66	73	enhance	51.60342	114
66	230	enhance	50.441757	115
66	155	enhance	49.762573	116
66	882	enhance	49.598305	117
66	61	enhance	49.001553	118
66	51	enhance	48.724632	119
66	45	enhance	48.198708	120
66	47	enhance	48.056988	121
66	67	enhance	41.452286	122
66	30	enhance	40.88636	123
66	33	enhance	39.00029	124
66	11	soften	100	1
66	126	soften	95.7574	2
66	90	soften	95.49572	3
66	55	soften	94.0632	4
66	3	soften	93.46938	5
66	91	soften	93.22805	6
66	93	soften	90.48098	7
66	79	soften	88.38568	8
66	30	soften	87.835815	9
66	184	soften	87.04823	10
66	4	soften	86.98611	11
66	34	soften	86.3172	12
66	99	soften	85.59121	13
66	23	soften	85.32356	14
66	182	soften	85.25874	15
66	96	soften	84.958824	16
66	868	soften	84.82934	17
66	2	soften	84.77335	18
66	171	soften	84.145485	19
66	22	soften	83.30871	20
66	82	soften	82.81455	21
66	9	soften	81.789406	22
66	21	soften	81.73001	23
66	63	soften	81.59654	24
66	219	soften	81.500755	25
66	44	soften	80.83579	26
66	59	soften	80.68705	27
66	28	soften	80.247055	28
66	39	soften	79.86569	29
66	18	soften	79.45732	30
66	12	soften	78.77946	31
66	35	soften	78.49376	32
66	85	soften	78.086136	33
66	64	soften	69.92201	34
66	80	soften	68.87764	35
66	60	soften	68.08995	36
66	83	soften	66.64505	37
66	72	soften	66.56257	38
66	74	soften	64.96958	39
66	70	soften	63.454468	40
66	45	soften	62.7806	41
66	33	soften	61.94466	42
66	13	soften	61.687637	43
66	49	soften	60.649746	44
66	43	soften	60.429302	45
66	73	soften	59.512615	46
66	61	soften	58.670223	47
66	640	soften	58.58749	48
66	335	soften	58.066673	49
66	222	soften	57.876884	50
66	94	soften	57.274544	51
66	78	soften	57.13534	52
66	5	soften	57.0335	53
66	20	soften	56.62235	54
66	593	soften	55.14562	55
66	95	soften	54.56001	56
66	41	soften	53.69082	57
67	51	enhance	100	1
67	222	enhance	96.79644	2
67	47	enhance	89.43348	3
67	176	enhance	89.42735	4
67	84	enhance	88.497696	5
67	88	enhance	88.47735	6
67	75	enhance	87.06968	7
67	92	enhance	85.65448	8
67	36	enhance	85.6245	9
67	285	enhance	85.6213	10
67	68	enhance	85.10437	11
67	25	enhance	84.73847	12
67	155	enhance	84.686485	13
67	87	enhance	84.15034	14
67	1	enhance	83.23483	15
67	46	enhance	82.21605	16
67	31	enhance	82.11789	17
67	882	enhance	82.091995	18
67	640	enhance	81.95109	19
67	98	enhance	81.87495	20
67	40	enhance	80.38235	21
67	48	enhance	79.59906	22
67	71	enhance	78.970345	23
67	13	enhance	77.46043	24
67	61	enhance	76.54474	25
67	108	enhance	74.36547	26
67	86	enhance	74.15396	27
67	15	enhance	72.59442	28
67	17	enhance	71.5804	29
67	785	enhance	70.93592	30
67	230	enhance	70.35445	31
67	10	enhance	69.04822	32
67	94	enhance	67.13076	33
67	182	enhance	66.526436	34
67	647	enhance	65.23209	35
67	37	enhance	64.80147	36
67	49	enhance	64.80073	37
67	358	enhance	64.77907	38
67	33	enhance	64.01607	39
67	76	enhance	62.961308	40
67	89	enhance	62.568596	41
67	19	enhance	62.49674	42
67	39	enhance	61.77775	43
67	187	enhance	60.537205	44
67	56	enhance	60.442448	45
67	7	enhance	59.474693	46
67	24	enhance	59.427105	47
67	50	enhance	58.854973	48
67	63	enhance	57.50979	49
67	97	enhance	55.775265	50
67	6	enhance	55.183723	51
67	52	enhance	55.14234	52
67	185	enhance	54.997902	53
67	70	enhance	54.48777	54
67	38	enhance	54.253754	55
67	16	enhance	53.969257	56
67	72	enhance	51.80162	57
67	99	enhance	51.72128	58
67	27	enhance	50.832558	59
67	42	enhance	50.291958	60
67	455	enhance	49.127514	61
67	29	enhance	48.018684	62
67	62	enhance	46.985107	63
67	43	enhance	46.72429	64
67	901	enhance	46.369473	65
67	83	enhance	44.92025	66
67	54	enhance	44.66133	67
67	26	enhance	44.423244	68
67	126	enhance	44.411583	69
67	45	enhance	44.245987	70
67	34	enhance	43.900482	71
67	100	enhance	42.383343	72
67	30	enhance	41.05126	73
67	77	enhance	40.57263	74
67	66	enhance	40.401802	75
67	90	enhance	40.099762	76
67	81	enhance	38.698654	77
67	28	enhance	38.407333	78
67	868	enhance	38.096878	79
67	593	enhance	37.81167	80
67	2	enhance	37.617844	81
67	82	enhance	35.114506	82
67	93	enhance	35.091965	83
67	44	enhance	34.528572	84
67	73	enhance	34.087044	85
67	921	enhance	30.811878	86
67	3	enhance	29.773212	87
67	55	enhance	29.363943	88
67	58	enhance	29.180012	89
67	80	enhance	28.629225	90
67	78	enhance	28.550167	91
67	18	enhance	28.357506	92
67	59	enhance	27.837866	93
67	53	enhance	27.131832	94
67	60	enhance	26.256403	95
67	184	enhance	25.281786	96
67	79	enhance	24.97681	97
67	14	enhance	23.580347	98
67	22	enhance	23.336805	99
67	32	enhance	21.488089	100
67	5	enhance	20.957731	101
67	11	enhance	20.340057	102
67	65	enhance	19.429623	103
67	91	enhance	19.164879	104
67	335	enhance	18.460772	105
67	4	enhance	18.402422	106
67	23	enhance	16.779617	107
67	64	enhance	16.63434	108
67	8	enhance	16.629581	109
67	9	enhance	16.344788	110
67	57	enhance	15.845946	111
67	171	enhance	15.517598	112
67	219	enhance	14.54474	113
67	96	enhance	14.195302	114
67	41	enhance	13.803104	115
67	12	enhance	13.712572	116
67	21	enhance	13.184274	117
67	85	enhance	10.475707	118
67	69	enhance	10.366626	119
67	74	enhance	9.4577675	120
67	35	enhance	8.090571	121
67	20	enhance	7.3555994	122
67	488	enhance	6.9365296	123
67	95	enhance	5.736367	124
67	64	soften	100	1
67	74	soften	97.62986	2
67	11	soften	96.325386	3
67	91	soften	92.250046	4
67	80	soften	90.84298	5
67	60	soften	89.858284	6
67	96	soften	88.34945	7
67	55	soften	87.42219	8
67	3	soften	87.41594	9
67	184	soften	86.83259	10
67	23	soften	86.064575	11
67	79	soften	85.88821	12
67	4	soften	85.875755	13
67	21	soften	85.27804	14
67	20	soften	85.23197	15
67	93	soften	84.94178	16
67	335	soften	84.91675	17
67	90	soften	84.66976	18
67	171	soften	84.59824	19
67	219	soften	84.20503	20
67	126	soften	83.36902	21
67	22	soften	82.9841	22
67	35	soften	82.50573	23
67	9	soften	82.40514	24
67	85	soften	82.3317	25
67	95	soften	82.18891	26
67	83	soften	82.15941	27
67	5	soften	81.25552	28
67	12	soften	81.11647	29
67	78	soften	80.930756	30
67	45	soften	80.15569	31
67	868	soften	79.72	32
67	72	soften	79.48127	33
67	59	soften	79.306465	34
67	41	soften	79.271324	35
67	70	soften	78.83639	36
67	2	soften	78.7349	37
67	18	soften	78.65861	38
67	69	soften	78.30179	39
67	30	soften	77.99061	40
67	34	soften	77.971344	41
67	73	soften	77.67944	42
67	82	soften	77.584785	43
67	43	soften	77.517944	44
67	44	soften	77.51494	45
67	99	soften	76.11401	46
67	8	soften	75.89464	47
67	593	soften	75.60136	48
67	28	soften	75.168686	49
67	63	soften	73.465164	50
67	49	soften	72.69325	51
67	66	soften	72.08597	52
67	39	soften	71.69804	53
67	182	soften	71.157234	54
67	94	soften	70.73077	55
67	33	soften	70.58867	56
67	50	soften	70.39642	57
67	58	soften	70.02935	58
67	13	soften	69.64095	59
67	187	soften	69.22731	60
67	54	soften	68.72426	61
67	7	soften	68.5664	62
67	56	soften	67.71172	63
67	27	soften	67.319	64
67	230	soften	67.19513	65
67	455	soften	66.64654	66
67	89	soften	66.63101	67
67	61	soften	66.47036	68
67	640	soften	65.104004	69
67	92	soften	63.7226	70
67	31	soften	63.398922	71
67	10	soften	62.700726	72
67	285	soften	62.353134	73
67	222	soften	61.275536	74
67	86	soften	61.09672	75
67	98	soften	60.956665	76
67	176	soften	60.748135	77
67	47	soften	59.483074	78
67	84	soften	57.73095	79
67	51	soften	54.424553	80
68	48	enhance	100	1
68	75	enhance	99.66459	2
68	36	enhance	98.6038	3
68	40	enhance	98.33955	4
68	25	enhance	97.747444	5
68	71	enhance	97.309425	6
68	46	enhance	96.76469	7
68	87	enhance	96.62893	8
68	17	enhance	96.04894	9
68	882	enhance	95.14722	10
68	84	enhance	94.83374	11
68	155	enhance	94.39333	12
68	108	enhance	93.32192	13
68	1	enhance	93.1234	14
68	88	enhance	92.64551	15
68	785	enhance	92.04738	16
68	358	enhance	91.84882	17
68	647	enhance	89.43856	18
68	97	enhance	88.64867	19
68	6	enhance	88.62552	20
68	76	enhance	88.161545	21
68	285	enhance	87.79258	22
68	86	enhance	87.70008	23
68	10	enhance	87.317505	24
68	16	enhance	87.31041	25
68	15	enhance	86.247765	26
68	92	enhance	85.60233	27
68	52	enhance	84.8732	28
68	176	enhance	84.62452	29
68	38	enhance	84.34007	30
68	67	enhance	84.19743	31
68	29	enhance	83.99087	32
68	185	enhance	83.63435	33
68	42	enhance	82.750015	34
68	37	enhance	82.46276	35
68	98	enhance	82.3707	36
68	31	enhance	82.222855	37
68	89	enhance	80.635376	38
68	222	enhance	79.26438	39
68	39	enhance	78.80809	40
68	27	enhance	78.65745	41
68	24	enhance	78.519485	42
68	455	enhance	78.47863	43
68	51	enhance	77.33134	44
68	62	enhance	77.18949	45
68	7	enhance	76.36798	46
68	56	enhance	73.19686	47
68	26	enhance	72.93865	48
68	47	enhance	72.90907	49
68	100	enhance	72.10118	50
68	54	enhance	71.74871	51
68	94	enhance	71.67193	52
68	901	enhance	71.662384	53
68	81	enhance	70.164246	54
68	77	enhance	69.704994	55
68	187	enhance	69.67356	56
68	640	enhance	67.440155	57
68	19	enhance	66.60422	58
68	50	enhance	65.59325	59
68	61	enhance	64.606316	60
68	49	enhance	63.382244	61
68	921	enhance	63.081005	62
68	63	enhance	61.975685	63
68	13	enhance	61.451324	64
68	66	enhance	61.42394	65
68	230	enhance	61.02003	66
68	182	enhance	60.568268	67
68	53	enhance	60.214855	68
68	28	enhance	57.84257	69
68	593	enhance	55.9851	70
68	78	enhance	52.08127	71
68	44	enhance	51.713387	72
68	18	enhance	51.640984	73
68	43	enhance	49.1763	74
68	58	enhance	49.16416	75
68	33	enhance	49.13487	76
68	99	enhance	49.133312	77
68	30	enhance	48.693333	78
68	868	enhance	48.295635	79
68	65	enhance	47.968765	80
68	70	enhance	47.65039	81
68	34	enhance	47.46161	82
68	14	enhance	47.08907	83
68	32	enhance	45.002254	84
68	73	enhance	44.736416	85
68	59	enhance	42.82174	86
68	184	enhance	42.09431	87
68	72	enhance	41.739456	88
68	45	enhance	41.56537	89
68	93	enhance	38.937336	90
68	22	enhance	38.145645	91
68	57	enhance	37.86261	92
68	8	enhance	37.858574	93
68	82	enhance	36.662308	94
68	335	enhance	36.32728	95
68	83	enhance	35.813423	96
68	79	enhance	35.65841	97
68	2	enhance	35.217804	98
68	219	enhance	34.68778	99
68	126	enhance	34.46031	100
68	90	enhance	32.771576	101
68	5	enhance	32.287716	102
68	3	enhance	32.121365	103
68	41	enhance	31.660133	104
68	55	enhance	31.119846	105
68	12	enhance	30.658188	106
68	21	enhance	29.58734	107
68	4	enhance	28.927675	108
68	171	enhance	28.61558	109
68	69	enhance	28.520586	110
68	85	enhance	28.069569	111
68	96	enhance	27.889648	112
68	488	enhance	27.470596	113
68	60	enhance	27.143927	114
68	23	enhance	27.076263	115
68	35	enhance	27.032356	116
68	9	enhance	26.933073	117
68	91	enhance	25.132565	118
68	80	enhance	24.913986	119
68	64	enhance	24.806696	120
68	20	enhance	24.621035	121
68	11	enhance	24.285028	122
68	95	enhance	21.474026	123
68	74	enhance	18.75225	124
68	64	soften	100	1
68	11	soften	99.32633	2
68	74	soften	98.08204	3
68	60	soften	96.13747	4
68	80	soften	95.342674	5
68	91	soften	95.219345	6
68	55	soften	92.62185	7
68	90	soften	91.36456	8
68	3	soften	91.11782	9
68	126	soften	90.91705	10
68	83	soften	90.7331	11
68	72	soften	88.64432	12
68	96	soften	88.570045	13
68	23	soften	88.28651	14
68	4	soften	88.19924	15
68	93	soften	87.78236	16
68	79	soften	87.30147	17
68	171	soften	86.556694	18
68	21	soften	86.009735	19
68	20	soften	85.61645	20
68	70	soften	85.2434	21
68	184	soften	85.22211	22
68	9	soften	84.95656	23
68	335	soften	84.63663	24
68	45	soften	84.24971	25
68	219	soften	83.67893	26
68	5	soften	83.62196	27
68	35	soften	83.5269	28
68	95	soften	83.45376	29
68	2	soften	83.42293	30
68	82	soften	83.268845	31
68	85	soften	83.21925	32
68	12	soften	83.020645	33
68	22	soften	82.63902	34
68	34	soften	82.38726	35
68	868	soften	81.98038	36
68	59	soften	81.158554	37
68	43	soften	80.48926	38
68	99	soften	80.426796	39
68	41	soften	79.643654	40
68	78	soften	79.22571	41
68	69	soften	79.124435	42
68	33	soften	78.92911	43
68	30	soften	78.70123	44
68	73	soften	78.44392	45
68	182	soften	78.24421	46
68	13	soften	77.96515	47
68	18	soften	77.7428	48
68	49	soften	77.709526	49
68	44	soften	76.861496	50
68	8	soften	76.67549	51
68	593	soften	76.65939	52
68	63	soften	76.23452	53
68	28	soften	75.79286	54
68	50	soften	74.42309	55
68	94	soften	74.41312	56
68	488	soften	73.998665	57
68	61	soften	73.73361	58
68	230	soften	73.61365	59
68	66	soften	73.12337	60
68	640	soften	72.99164	61
68	187	soften	71.81218	62
68	39	soften	71.41554	63
68	58	soften	70.220505	64
68	222	soften	70.194885	65
68	7	soften	69.394646	66
68	56	soften	69.03621	67
68	14	soften	68.94202	68
68	92	soften	68.89482	69
68	54	soften	68.595406	70
68	47	soften	68.25414	71
68	31	soften	67.80277	72
68	19	soften	67.498695	73
68	176	soften	67.26647	74
68	89	soften	67.00468	75
68	285	soften	66.896225	76
68	65	soften	66.343315	77
68	98	soften	66.168015	78
68	27	soften	65.96023	79
68	455	soften	65.8441	80
68	51	soften	65.80329	81
68	10	soften	64.51197	82
68	26	soften	64.274734	83
68	24	soften	64.16069	84
68	921	soften	63.981705	85
68	901	soften	62.56215	86
68	52	soften	62.414455	87
68	108	soften	62.378704	88
68	86	soften	62.13955	89
68	62	soften	62.10446	90
68	647	soften	61.87568	91
68	1	soften	61.461994	92
68	77	soften	61.45768	93
68	185	soften	61.338043	94
68	88	soften	60.949226	95
68	100	soften	60.94606	96
68	67	soften	60.725212	97
68	84	soften	60.43882	98
68	785	soften	59.3733	99
68	6	soften	57.28673	100
68	36	soften	56.722748	101
68	17	soften	56.47899	102
68	71	soften	56.14066	103
68	87	soften	55.33934	104
68	97	soften	55.002907	105
68	40	soften	54.080357	106
68	48	soften	54.07031	107
68	25	soften	53.56163	108
68	155	soften	51.93859	109
68	882	soften	51.74368	110
69	85	enhance	100	1
69	9	enhance	99.67249	2
69	12	enhance	99.57783	3
69	21	enhance	99.5159	4
69	41	enhance	99.18203	5
69	35	enhance	98.66827	6
69	59	enhance	97.4239	7
69	5	enhance	96.9406	8
69	219	enhance	95.72255	9
69	23	enhance	95.51766	10
69	335	enhance	94.56898	11
69	4	enhance	93.508255	12
69	593	enhance	92.22738	13
69	8	enhance	91.54382	14
69	96	enhance	91.44784	15
69	20	enhance	91.1036	16
69	78	enhance	90.7442	17
69	74	enhance	90.3505	18
69	66	enhance	90.16072	19
69	91	enhance	89.31666	20
69	22	enhance	89.114006	21
69	65	enhance	88.83167	22
69	18	enhance	88.07357	23
69	184	enhance	87.05693	24
69	488	enhance	86.81383	25
69	44	enhance	86.184364	26
69	171	enhance	85.517586	27
69	58	enhance	85.13062	28
69	82	enhance	85.00397	29
69	79	enhance	83.245285	30
69	32	enhance	83.176895	31
69	55	enhance	83.12028	32
69	77	enhance	82.7307	33
69	3	enhance	82.35011	34
69	93	enhance	81.75386	35
69	60	enhance	81.407326	36
69	100	enhance	81.1722	37
69	64	enhance	81.04593	38
69	868	enhance	80.33078	39
69	54	enhance	79.86936	40
69	95	enhance	79.56477	41
69	11	enhance	79.31601	42
69	14	enhance	78.46723	43
69	28	enhance	77.530716	44
69	455	enhance	77.01008	45
69	27	enhance	76.4774	46
69	50	enhance	75.166306	47
69	94	enhance	70.91785	48
69	52	enhance	70.857956	49
69	53	enhance	70.14295	50
69	57	enhance	70.08168	51
69	70	enhance	69.70744	52
69	83	enhance	69.64724	53
69	10	enhance	69.271034	54
69	34	enhance	69.26937	55
69	72	enhance	68.55906	56
69	62	enhance	68.20645	57
69	921	enhance	67.702324	58
69	90	enhance	67.51657	59
69	19	enhance	65.59533	60
69	24	enhance	65.30514	61
69	7	enhance	65.16109	62
69	39	enhance	62.48525	63
69	81	enhance	62.07543	64
69	126	enhance	60.918133	65
69	182	enhance	60.674427	66
69	99	enhance	60.30653	67
69	2	enhance	59.603836	68
69	185	enhance	59.17824	69
69	42	enhance	58.890415	70
69	38	enhance	58.284718	71
69	80	enhance	57.531845	72
69	63	enhance	57.2794	73
69	43	enhance	54.399303	74
69	76	enhance	53.95481	75
69	49	enhance	52.552414	76
69	176	enhance	51.463013	77
69	92	enhance	51.425434	78
69	86	enhance	51.12458	79
69	37	enhance	49.2165	80
69	785	enhance	49.161404	81
69	187	enhance	49.13504	82
69	6	enhance	48.61163	83
69	29	enhance	48.427383	84
69	16	enhance	47.88695	85
69	73	enhance	47.43137	86
69	647	enhance	46.70408	87
69	45	enhance	46.53693	88
69	26	enhance	46.45298	89
69	15	enhance	45.770023	90
69	97	enhance	45.659027	91
69	108	enhance	45.2094	92
69	901	enhance	44.67	93
69	358	enhance	42.214046	94
69	285	enhance	41.356247	95
69	89	enhance	41.124504	96
69	17	enhance	37.956184	97
69	13	enhance	37.546947	98
69	56	enhance	36.38959	99
69	71	enhance	33.54979	100
69	30	enhance	33.45816	101
69	230	enhance	32.826843	102
69	84	enhance	31.275595	103
69	48	enhance	31.073736	104
69	222	enhance	30.995731	105
69	98	enhance	30.724657	106
69	31	enhance	30.431538	107
69	1	enhance	29.438667	108
69	68	enhance	29.03838	109
69	61	enhance	29.02844	110
69	87	enhance	28.854767	111
69	640	enhance	28.846184	112
69	36	enhance	27.617935	113
69	47	enhance	25.640762	114
69	88	enhance	25.358725	115
69	40	enhance	23.475628	116
69	33	enhance	22.652391	117
69	46	enhance	19.591618	118
69	25	enhance	19.303698	119
69	51	enhance	18.580212	120
69	155	enhance	17.684185	121
69	75	enhance	16.298363	122
69	882	enhance	15.75034	123
69	67	enhance	10.442352	124
69	126	soften	100	1
69	90	soften	99.312805	2
69	11	soften	97.39598	3
69	30	soften	96.73792	4
69	3	soften	94.08459	5
69	55	soften	93.07667	6
69	182	soften	92.54972	7
69	93	soften	91.897446	8
69	99	soften	91.23166	9
69	34	soften	89.55304	10
69	79	soften	88.48434	11
69	91	soften	88.09404	12
69	39	soften	87.99577	13
69	63	soften	86.65572	14
69	184	soften	86.51714	15
69	2	soften	85.9631	16
69	868	soften	84.36774	17
69	28	soften	83.93611	18
69	44	soften	83.24303	19
69	4	soften	83.03548	20
69	22	soften	81.668785	21
69	82	soften	81.54964	22
69	23	soften	80.528946	23
69	66	soften	80.26441	24
69	18	soften	80.06369	25
69	171	soften	78.8824	26
69	96	soften	78.27471	27
69	59	soften	78.26694	28
69	219	soften	76.687874	29
69	9	soften	76.46858	30
69	21	soften	74.942924	31
69	12	soften	72.146515	32
69	35	soften	71.06055	33
69	85	soften	70.34914	34
69	72	soften	70.1508	35
69	80	soften	70.00291	36
69	33	soften	69.1875	37
69	83	soften	68.98109	38
69	13	soften	68.8119	39
69	64	soften	67.369225	40
69	49	soften	66.908325	41
69	60	soften	66.74014	42
69	70	soften	66.69991	43
69	640	soften	66.23521	44
69	45	soften	66.12864	45
69	222	soften	66.00417	46
69	61	soften	65.81984	47
69	43	soften	64.1084	48
69	73	soften	63.721462	49
69	94	soften	62.064568	50
69	74	soften	58.585274	51
69	78	soften	57.74624	52
69	593	soften	55.984924	53
69	335	soften	54.90492	54
69	5	soften	54.59117	55
69	20	soften	51.507744	56
69	41	soften	50.22009	57
69	95	soften	48.929157	58
70	72	enhance	100	1
70	90	enhance	99.69545	2
70	126	enhance	98.814476	3
70	83	enhance	98.69688	4
70	93	enhance	97.26817	5
70	94	enhance	96.77544	6
70	3	enhance	96.50226	7
70	99	enhance	94.78517	8
70	182	enhance	93.7781	9
70	49	enhance	92.5207	10
70	13	enhance	90.99557	11
70	55	enhance	90.51038	12
70	50	enhance	90.49773	13
70	34	enhance	89.42081	14
70	82	enhance	88.44523	15
70	63	enhance	87.735435	16
70	80	enhance	87.49732	17
70	91	enhance	87.29471	18
70	43	enhance	86.38752	19
70	39	enhance	85.97087	20
70	593	enhance	85.558945	21
70	23	enhance	85.09724	22
70	60	enhance	84.59452	23
70	79	enhance	84.1403	24
70	74	enhance	83.78131	25
70	2	enhance	83.670845	26
70	5	enhance	83.31445	27
70	11	enhance	83.22938	28
70	184	enhance	83.07734	29
70	92	enhance	82.76335	30
70	44	enhance	82.18446	31
70	640	enhance	82.16271	32
70	4	enhance	82.08504	33
70	45	enhance	81.9422	34
70	64	enhance	81.92906	35
70	9	enhance	81.35398	36
70	59	enhance	81.05123	37
70	78	enhance	80.593	38
70	868	enhance	80.19312	39
70	61	enhance	80.028366	40
70	22	enhance	79.91965	41
70	96	enhance	79.89342	42
70	230	enhance	78.91246	43
70	285	enhance	78.36689	44
70	7	enhance	78.13593	45
70	222	enhance	77.62177	46
70	335	enhance	76.88119	47
70	66	enhance	76.791504	48
70	19	enhance	76.47514	49
70	21	enhance	76.3553	50
70	18	enhance	75.84646	51
70	33	enhance	75.51023	52
70	10	enhance	75.05865	53
70	176	enhance	74.73012	54
70	47	enhance	74.460884	55
70	219	enhance	73.55653	56
70	187	enhance	72.01667	57
70	41	enhance	71.72093	58
70	12	enhance	70.82637	59
70	85	enhance	70.28308	60
70	98	enhance	69.957535	61
70	69	enhance	69.77807	62
70	31	enhance	69.2657	63
70	27	enhance	69.236084	64
70	28	enhance	67.95988	65
70	86	enhance	67.3482	66
70	171	enhance	67.31911	67
70	54	enhance	66.43337	68
70	58	enhance	66.40925	69
70	20	enhance	66.29695	70
70	35	enhance	65.797905	71
70	30	enhance	65.133575	72
70	88	enhance	64.691444	73
70	108	enhance	64.440315	74
70	8	enhance	64.41914	75
70	73	enhance	63.513615	76
70	455	enhance	63.30596	77
70	56	enhance	62.174973	78
70	51	enhance	61.86303	79
70	52	enhance	61.51815	80
70	89	enhance	61.324062	81
70	1	enhance	56.803616	82
70	67	enhance	54.941402	83
70	95	enhance	54.661167	84
70	647	enhance	54.22168	85
70	24	enhance	53.566475	86
70	84	enhance	53.215668	87
70	36	enhance	52.778404	88
70	15	enhance	52.604618	89
70	77	enhance	51.79937	90
70	100	enhance	51.49576	91
70	62	enhance	49.075005	92
70	68	enhance	48.56464	93
70	65	enhance	47.462048	94
70	488	enhance	47.058834	95
70	185	enhance	47.024254	96
70	14	enhance	46.406574	97
70	40	enhance	45.011215	98
70	48	enhance	44.944855	99
70	71	enhance	44.847546	100
70	785	enhance	44.44857	101
70	32	enhance	43.571163	102
70	17	enhance	40.481457	103
70	26	enhance	40.292545	104
70	921	enhance	39.259197	105
70	6	enhance	38.88446	106
70	25	enhance	38.6045	107
70	87	enhance	38.596607	108
70	38	enhance	38.542778	109
70	37	enhance	38.47963	110
70	901	enhance	37.638737	111
70	75	enhance	36.980488	112
70	76	enhance	36.816208	113
70	97	enhance	36.382694	114
70	42	enhance	36.337193	115
70	57	enhance	34.97619	116
70	53	enhance	33.384125	117
70	16	enhance	32.9076	118
70	81	enhance	32.044804	119
70	358	enhance	31.832705	120
70	46	enhance	30.483553	121
70	155	enhance	28.825272	122
70	29	enhance	28.683891	123
70	882	enhance	27.741388	124
70	64	soften	100	1
70	11	soften	97.699394	2
70	60	soften	93.50731	3
70	74	soften	93.28627	4
70	91	soften	91.94571	5
70	55	soften	90.468605	6
70	184	soften	90.262985	7
70	3	soften	88.21479	8
70	80	soften	88.11363	9
70	96	soften	87.86097	10
70	83	soften	86.86318	11
70	72	soften	86.53297	12
70	93	soften	86.429214	13
70	90	soften	84.68133	14
70	126	soften	84.60545	15
71	17	enhance	100	1
71	48	enhance	99.887245	2
71	68	enhance	98.328804	3
71	785	enhance	98.20155	4
71	87	enhance	97.33418	5
71	25	enhance	97.18063	6
71	40	enhance	96.89329	7
71	36	enhance	96.3239	8
71	358	enhance	96.10629	9
71	75	enhance	96.01261	10
71	16	enhance	94.66519	11
71	1	enhance	94.44488	12
71	108	enhance	94.34528	13
71	155	enhance	93.68095	14
71	76	enhance	93.4413	15
71	46	enhance	93.354744	16
71	6	enhance	93.19479	17
71	882	enhance	93.023224	18
71	97	enhance	92.557175	19
71	38	enhance	92.34267	20
71	647	enhance	91.401634	21
71	42	enhance	91.36107	22
71	84	enhance	91.236275	23
71	185	enhance	90.81962	24
71	88	enhance	90.774445	25
71	29	enhance	89.88295	26
71	15	enhance	89.787994	27
71	285	enhance	88.361244	28
71	52	enhance	87.95485	29
71	176	enhance	87.29342	30
71	37	enhance	86.69613	31
71	24	enhance	85.68339	32
71	62	enhance	84.913055	33
71	92	enhance	84.27086	34
71	10	enhance	84.21238	35
71	86	enhance	84.189705	36
71	455	enhance	83.73943	37
71	98	enhance	83.3616	38
71	89	enhance	82.78782	39
71	31	enhance	80.312096	40
71	901	enhance	80.29598	41
71	100	enhance	79.57464	42
71	81	enhance	79.21846	43
71	67	enhance	78.94722	44
71	54	enhance	77.762314	45
71	77	enhance	77.502625	46
71	7	enhance	77.323006	47
71	26	enhance	77.262375	48
71	27	enhance	76.52729	49
71	222	enhance	74.61741	50
71	187	enhance	73.96899	51
71	51	enhance	73.68462	52
71	921	enhance	73.64909	53
71	39	enhance	73.207344	54
71	19	enhance	71.46572	55
71	56	enhance	71.05384	56
71	53	enhance	70.72035	57
71	94	enhance	70.48033	58
71	47	enhance	66.79767	59
71	50	enhance	65.0023	60
71	66	enhance	64.45215	61
71	28	enhance	63.228207	62
71	49	enhance	61.88355	63
71	182	enhance	61.16279	64
71	63	enhance	61.00964	65
71	640	enhance	59.936512	66
71	61	enhance	58.58552	67
71	32	enhance	58.418503	68
71	14	enhance	58.318993	69
71	593	enhance	58.23736	70
71	65	enhance	57.882805	71
71	13	enhance	56.66055	72
71	230	enhance	54.815155	73
71	18	enhance	54.60162	74
71	58	enhance	53.980667	75
71	78	enhance	51.268127	76
71	34	enhance	49.93746	77
71	868	enhance	49.062798	78
71	43	enhance	47.888245	79
71	44	enhance	47.160446	80
71	57	enhance	46.55505	81
71	99	enhance	46.011906	82
71	8	enhance	45.879936	83
71	30	enhance	45.599934	84
71	73	enhance	45.56641	85
71	59	enhance	45.406223	86
71	33	enhance	44.85814	87
71	70	enhance	44.464237	88
71	82	enhance	41.96697	89
71	45	enhance	41.04258	90
71	488	enhance	39.56113	91
71	72	enhance	39.277206	92
71	184	enhance	37.692642	93
71	219	enhance	37.6065	94
71	12	enhance	36.679417	95
71	171	enhance	36.329166	96
71	335	enhance	36.209267	97
71	5	enhance	36.20909	98
71	83	enhance	36.108845	99
71	79	enhance	35.889286	100
71	35	enhance	34.833588	101
71	2	enhance	34.209164	102
71	93	enhance	33.55329	103
71	85	enhance	33.522015	104
71	41	enhance	33.436672	105
71	69	enhance	33.296738	106
71	22	enhance	33.291153	107
71	21	enhance	32.58953	108
71	126	enhance	31.910316	109
71	20	enhance	31.607302	110
71	55	enhance	31.48347	111
71	95	enhance	30.577646	112
71	4	enhance	30.254938	113
71	3	enhance	29.746462	114
71	9	enhance	29.070555	115
71	90	enhance	28.083908	116
71	23	enhance	27.837788	117
71	60	enhance	27.011185	118
71	96	enhance	26.926947	119
71	91	enhance	22.71965	120
71	11	enhance	22.433647	121
71	64	enhance	21.266312	122
71	80	enhance	19.989952	123
71	74	enhance	17.065716	124
71	64	soften	100	1
71	11	soften	98.33482	2
71	74	soften	98.1398	3
71	80	soften	97.22212	4
71	91	soften	95.12025	5
71	60	soften	94.843735	6
71	90	soften	92.36979	7
71	126	soften	91.481	8
71	55	soften	91.23741	9
71	3	soften	90.970436	10
71	83	soften	89.76151	11
71	93	soften	88.99844	12
71	79	soften	88.73627	13
71	96	soften	88.62009	14
71	72	soften	88.57624	15
71	23	soften	88.19208	16
71	4	soften	87.01368	17
71	184	soften	86.069016	18
71	70	soften	86.03544	19
71	21	soften	85.89999	20
71	45	soften	84.99933	21
71	171	soften	84.665184	22
71	2	soften	84.63496	23
71	335	soften	84.621346	24
71	20	soften	84.05561	25
71	9	soften	83.99519	26
71	22	soften	83.35216	27
71	5	soften	83.083145	28
71	219	soften	82.85886	29
71	85	soften	82.590996	30
71	82	soften	82.52977	31
71	34	soften	82.01426	32
71	12	soften	82.01328	33
71	35	soften	81.94376	34
71	868	soften	81.55671	35
71	95	soften	81.545265	36
71	99	soften	81.4608	37
71	43	soften	81.23127	38
71	59	soften	81.070816	39
71	33	soften	80.82884	40
71	30	soften	80.14691	41
71	13	soften	79.64361	42
71	78	soften	79.58832	43
71	73	soften	79.539795	44
71	49	soften	79.076546	45
71	41	soften	78.83325	46
71	182	soften	78.648224	47
71	69	soften	78.49967	48
71	18	soften	78.306046	49
71	44	soften	77.84967	50
71	63	soften	77.15976	51
71	593	soften	76.87218	52
71	28	soften	76.15823	53
71	61	soften	75.859535	54
71	230	soften	75.7906	55
71	94	soften	75.33729	56
71	8	soften	75.32831	57
71	640	soften	75.1524	58
71	50	soften	74.82507	59
71	66	soften	73.52158	60
71	39	soften	73.316765	61
71	488	soften	72.55916	62
71	222	soften	71.667244	63
71	187	soften	71.1147	64
71	56	soften	69.68998	65
71	58	soften	69.58007	66
71	7	soften	69.500534	67
71	47	soften	69.38621	68
71	31	soften	69.32131	69
71	92	soften	69.19145	70
71	54	soften	68.78781	71
71	14	soften	67.672874	72
71	285	soften	67.63969	73
71	176	soften	67.60249	74
71	98	soften	67.5729	75
71	27	soften	67.53391	76
71	89	soften	67.17227	77
71	51	soften	66.75621	78
71	19	soften	66.606964	79
71	455	soften	66.03225	80
71	10	soften	65.41128	81
71	65	soften	65.24024	82
71	24	soften	64.301254	83
71	86	soften	63.83124	84
71	26	soften	63.69655	85
71	108	soften	63.412533	86
71	52	soften	63.035522	87
71	921	soften	62.99088	88
71	647	soften	62.69403	89
71	88	soften	62.513496	90
71	67	soften	62.28318	91
71	84	soften	62.201233	92
71	62	soften	61.87591	93
71	1	soften	61.808434	94
71	901	soften	61.30909	95
71	77	soften	61.257687	96
71	185	soften	61.050976	97
71	100	soften	60.82732	98
71	785	soften	59.40405	99
71	6	soften	58.07887	100
71	36	soften	58.073742	101
71	17	soften	57.01325	102
71	87	soften	56.416195	103
71	97	soften	56.27492	104
71	40	soften	55.942646	105
71	25	soften	55.038185	106
72	83	enhance	100	1
72	70	enhance	99.17258	2
72	90	enhance	96.25027	3
72	3	enhance	95.61735	4
72	93	enhance	94.15081	5
72	55	enhance	93.082436	6
72	126	enhance	93.06243	7
72	94	enhance	91.34033	8
72	182	enhance	91.004814	9
72	60	enhance	90.06857	10
72	91	enhance	89.12928	11
72	99	enhance	86.24067	12
72	50	enhance	85.78935	13
72	4	enhance	85.51792	14
72	11	enhance	85.440384	15
72	82	enhance	83.98685	16
72	13	enhance	83.310295	17
72	49	enhance	82.72472	18
72	23	enhance	82.52937	19
72	9	enhance	82.16118	20
72	64	enhance	81.809845	21
72	44	enhance	81.584885	22
72	34	enhance	81.47149	23
72	5	enhance	81.030365	24
72	22	enhance	81.009186	25
72	184	enhance	80.75425	26
72	92	enhance	80.44118	27
72	59	enhance	80.015305	28
72	74	enhance	79.78375	29
72	593	enhance	79.31297	30
72	868	enhance	78.22727	31
72	66	enhance	76.37376	32
72	78	enhance	76.23035	33
72	39	enhance	76.06925	34
72	80	enhance	75.99602	35
72	335	enhance	75.76392	36
72	96	enhance	75.41871	37
72	79	enhance	75.30941	38
72	19	enhance	75.11983	39
72	640	enhance	74.26378	40
72	43	enhance	74.01025	41
72	222	enhance	73.7671	42
72	21	enhance	73.421936	43
72	285	enhance	73.1361	44
72	63	enhance	73.074585	45
72	10	enhance	72.72406	46
72	41	enhance	71.939926	47
72	7	enhance	71.444244	48
72	12	enhance	70.29337	49
72	219	enhance	70.13055	50
72	176	enhance	69.869	51
72	47	enhance	69.062996	52
72	61	enhance	69.01837	53
72	2	enhance	68.87509	54
72	69	enhance	68.06067	55
72	85	enhance	68.05725	56
72	45	enhance	67.57127	57
72	187	enhance	67.358025	58
72	230	enhance	66.74997	59
72	18	enhance	66.127266	60
72	33	enhance	65.72643	61
72	27	enhance	65.02264	62
72	35	enhance	63.649532	63
72	51	enhance	63.215893	64
72	171	enhance	63.129337	65
72	8	enhance	62.140095	66
72	98	enhance	61.19242	67
72	54	enhance	60.80101	68
72	86	enhance	60.72781	69
72	28	enhance	60.299767	70
72	20	enhance	59.264202	71
72	58	enhance	57.60338	72
72	88	enhance	57.122498	73
72	31	enhance	56.80434	74
72	52	enhance	55.22745	75
72	455	enhance	54.25467	76
72	108	enhance	53.236908	77
72	67	enhance	51.8007	78
72	30	enhance	51.595036	79
72	56	enhance	51.587925	80
72	73	enhance	50.02408	81
72	15	enhance	49.353653	82
72	89	enhance	48.444614	83
72	1	enhance	48.083504	84
72	77	enhance	45.723576	85
72	100	enhance	45.463676	86
72	95	enhance	45.234272	87
72	84	enhance	43.871956	88
72	647	enhance	43.12052	89
72	24	enhance	42.813416	90
72	36	enhance	42.726048	91
72	65	enhance	42.62086	92
72	68	enhance	42.18831	93
72	488	enhance	39.45448	94
72	14	enhance	39.435238	95
72	71	enhance	39.288013	96
72	62	enhance	38.64518	97
72	785	enhance	38.42336	98
72	185	enhance	38.282326	99
72	48	enhance	38.042114	100
72	32	enhance	36.08313	101
72	17	enhance	35.240128	102
72	901	enhance	35.150932	103
72	40	enhance	35.11579	104
72	26	enhance	33.675106	105
72	37	enhance	32.78933	106
72	921	enhance	32.041492	107
72	87	enhance	31.335257	108
72	75	enhance	30.919909	109
72	76	enhance	30.297571	110
72	25	enhance	30.256521	111
72	38	enhance	30.239677	112
72	6	enhance	29.653124	113
72	57	enhance	29.25682	114
72	42	enhance	28.42364	115
72	81	enhance	27.539774	116
72	16	enhance	27.286303	117
72	97	enhance	27.27348	118
72	53	enhance	26.964941	119
72	46	enhance	26.859083	120
72	358	enhance	25.832994	121
72	155	enhance	23.82867	122
72	882	enhance	22.922083	123
72	29	enhance	22.646553	124
72	64	soften	100	1
72	11	soften	95.442856	2
72	74	soften	93.709435	3
72	91	soften	91.104904	4
72	60	soften	89.71423	5
72	80	soften	87.48746	6
72	55	soften	86.74102	7
73	30	enhance	100	1
73	45	enhance	95.80119	2
73	80	enhance	88.78981	3
73	56	enhance	88.23467	4
73	43	enhance	86.63722	5
73	34	enhance	86.109535	6
73	79	enhance	85.06018	7
73	49	enhance	84.554955	8
73	18	enhance	83.512314	9
73	89	enhance	80.26495	10
73	63	enhance	75.15669	11
73	126	enhance	75.1091	12
73	61	enhance	72.428185	13
73	54	enhance	71.911026	14
73	647	enhance	71.79647	15
73	28	enhance	70.9633	16
73	2	enhance	69.6463	17
73	230	enhance	69.216896	18
73	31	enhance	68.209885	19
73	47	enhance	68.20151	20
73	26	enhance	67.67673	21
73	187	enhance	67.1567	22
73	98	enhance	66.376495	23
73	39	enhance	66.25451	24
73	62	enhance	65.99662	25
73	50	enhance	65.7264	26
73	921	enhance	65.704384	27
73	455	enhance	65.66596	28
73	285	enhance	65.50783	29
73	108	enhance	65.18247	30
73	24	enhance	64.96819	31
73	70	enhance	64.28869	32
73	94	enhance	64.15653	33
73	185	enhance	63.9953	34
73	88	enhance	63.309967	35
73	13	enhance	63.232124	36
73	1	enhance	63.110985	37
73	83	enhance	63.060738	38
73	95	enhance	62.31082	39
73	78	enhance	61.693916	40
73	99	enhance	61.562252	41
73	20	enhance	61.407856	42
73	3	enhance	60.920864	43
73	182	enhance	60.865513	44
73	27	enhance	60.86275	45
73	6	enhance	60.365986	46
73	36	enhance	59.9203	47
73	58	enhance	59.81996	48
73	84	enhance	59.626827	49
73	19	enhance	59.24418	50
73	593	enhance	58.53677	51
73	74	enhance	58.497864	52
73	90	enhance	58.2027	53
73	171	enhance	57.63922	54
73	33	enhance	57.567936	55
73	52	enhance	57.21698	56
73	82	enhance	56.271313	57
73	640	enhance	56.0608	58
73	7	enhance	55.930866	59
73	97	enhance	55.79211	60
73	86	enhance	55.517635	61
73	488	enhance	55.297546	62
73	176	enhance	53.966263	63
73	8	enhance	52.38664	64
73	40	enhance	52.36226	65
73	219	enhance	52.32406	66
73	14	enhance	52.05941	67
73	21	enhance	51.78425	68
73	53	enhance	51.65968	69
73	32	enhance	51.406807	70
73	66	enhance	51.33331	71
73	93	enhance	51.265266	72
73	72	enhance	51.05699	73
73	5	enhance	51.04693	74
73	81	enhance	50.761826	75
73	35	enhance	50.299732	76
73	10	enhance	50.024597	77
73	785	enhance	49.541084	78
73	37	enhance	49.238934	79
73	100	enhance	49.061996	80
73	77	enhance	48.911045	81
73	65	enhance	48.83816	82
73	29	enhance	48.808434	83
73	85	enhance	48.229713	84
73	69	enhance	48.05883	85
73	42	enhance	47.992275	86
73	92	enhance	47.973648	87
73	16	enhance	47.78198	88
73	184	enhance	47.737885	89
73	17	enhance	47.723553	90
73	23	enhance	47.413258	91
73	76	enhance	47.398582	92
73	38	enhance	47.103653	93
73	96	enhance	47.08651	94
73	55	enhance	46.94039	95
73	71	enhance	46.52008	96
73	901	enhance	46.198612	97
73	68	enhance	46.151165	98
73	358	enhance	46.13819	99
73	59	enhance	45.078403	100
73	222	enhance	44.944767	101
73	9	enhance	44.912025	102
73	64	enhance	44.744076	103
73	48	enhance	44.226242	104
73	57	enhance	44.056183	105
73	12	enhance	43.34882	106
73	11	enhance	42.38612	107
73	87	enhance	40.453568	108
73	15	enhance	40.353912	109
73	91	enhance	40.00476	110
73	25	enhance	39.797497	111
73	44	enhance	38.622536	112
73	335	enhance	38.57156	113
73	4	enhance	38.085087	114
73	868	enhance	37.64412	115
73	41	enhance	37.467144	116
73	46	enhance	37.403347	117
73	75	enhance	37.23168	118
73	67	enhance	34.79027	119
73	22	enhance	33.50029	120
73	60	enhance	33.287155	121
73	882	enhance	33.205067	122
73	155	enhance	32.852703	123
73	51	enhance	31.727415	124
73	64	soften	100	1
73	11	soften	98.365715	2
73	60	soften	96.94486	3
73	91	soften	95.9341	4
73	74	soften	95.36569	5
73	55	soften	91.33105	6
73	72	soften	89.609634	7
73	184	soften	89.4032	8
73	96	soften	89.395195	9
73	83	soften	88.78113	10
73	868	soften	88.73623	11
73	335	soften	88.12061	12
73	22	soften	87.3144	13
73	93	soften	87.313644	14
73	4	soften	87.27384	15
73	3	soften	87.0036	16
73	80	soften	85.78157	17
73	21	soften	85.40955	18
73	70	soften	85.08626	19
73	90	soften	84.46901	20
73	171	soften	84.30471	21
73	59	soften	84.20579	22
73	126	soften	84.13867	23
73	23	soften	83.905525	24
73	219	soften	83.59923	25
73	9	soften	82.78852	26
73	12	soften	82.63962	27
73	79	soften	82.48008	28
73	44	soften	82.39127	29
73	20	soften	82.05933	30
73	85	soften	81.90391	31
73	78	soften	81.79093	32
73	35	soften	80.701546	33
73	5	soften	80.01977	34
73	45	soften	79.91386	35
73	94	soften	79.61752	36
73	82	soften	79.16031	37
73	13	soften	78.47388	38
73	34	soften	77.306206	39
73	49	soften	77.181404	40
73	182	soften	77.10471	41
73	2	soften	75.816925	42
73	99	soften	75.48936	43
73	43	soften	74.529305	44
73	30	soften	73.90533	45
74	96	enhance	100	1
74	91	enhance	98.78975	2
74	21	enhance	96.71782	3
74	23	enhance	96.714424	4
74	184	enhance	96.24056	5
74	9	enhance	96.14248	6
74	3	enhance	95.94209	7
74	335	enhance	95.311295	8
74	219	enhance	95.088234	9
74	93	enhance	94.966286	10
74	4	enhance	94.50496	11
74	64	enhance	93.93838	12
74	78	enhance	93.74594	13
74	22	enhance	93.410385	14
74	5	enhance	93.063705	15
74	59	enhance	92.877846	16
74	85	enhance	92.17834	17
74	55	enhance	91.50439	18
74	41	enhance	91.46873	19
74	69	enhance	91.2158	20
74	11	enhance	90.211685	21
74	20	enhance	89.97096	22
74	12	enhance	89.94317	23
74	79	enhance	89.9014	24
74	35	enhance	88.588524	25
74	593	enhance	87.89456	26
74	44	enhance	87.857025	27
74	18	enhance	87.284	28
74	60	enhance	86.33849	29
74	70	enhance	84.49808	30
74	868	enhance	83.86988	31
74	83	enhance	83.849464	32
74	82	enhance	82.934906	33
74	171	enhance	82.85212	34
74	90	enhance	82.14257	35
74	80	enhance	81.52172	36
74	72	enhance	81.13768	37
74	8	enhance	79.10862	38
74	66	enhance	78.95168	39
74	126	enhance	78.46357	40
74	95	enhance	78.318756	41
74	58	enhance	78.140274	42
74	94	enhance	76.69014	43
74	34	enhance	76.432976	44
74	50	enhance	71.95544	45
74	39	enhance	70.056244	46
74	488	enhance	69.03633	47
74	27	enhance	68.83983	48
74	99	enhance	68.73893	49
74	2	enhance	67.874344	50
74	43	enhance	66.64328	51
74	28	enhance	66.52116	52
74	455	enhance	66.50851	53
74	45	enhance	66.21005	54
74	54	enhance	65.81548	55
74	63	enhance	65.25462	56
74	65	enhance	64.38949	57
74	7	enhance	63.78792	58
74	10	enhance	63.037323	59
74	49	enhance	62.86216	60
74	182	enhance	60.844673	61
74	52	enhance	59.44774	62
74	14	enhance	59.360825	63
74	77	enhance	58.35745	64
74	73	enhance	58.287033	65
74	100	enhance	56.905453	66
74	32	enhance	56.196335	67
74	19	enhance	55.992954	68
74	24	enhance	52.975388	69
74	86	enhance	52.701294	70
74	92	enhance	52.0376	71
74	62	enhance	51.35066	72
74	30	enhance	50.33021	73
74	13	enhance	48.828682	74
74	176	enhance	48.257042	75
74	187	enhance	48.206783	76
74	921	enhance	46.260406	77
74	285	enhance	44.54937	78
74	89	enhance	43.28805	79
74	185	enhance	43.196747	80
74	53	enhance	42.720703	81
74	57	enhance	42.341213	82
74	56	enhance	41.98734	83
74	108	enhance	39.781887	84
74	230	enhance	39.22134	85
74	647	enhance	38.95353	86
74	61	enhance	38.111366	87
74	26	enhance	37.27151	88
74	640	enhance	36.215168	89
74	38	enhance	35.645847	90
74	222	enhance	34.590084	91
74	42	enhance	34.56713	92
74	47	enhance	34.386654	93
74	81	enhance	33.764797	94
74	6	enhance	33.08012	95
74	31	enhance	30.392288	96
74	33	enhance	30.375225	97
74	785	enhance	30.11738	98
74	1	enhance	29.468435	99
74	97	enhance	29.282236	100
74	76	enhance	29.149769	101
74	84	enhance	28.900461	102
74	901	enhance	28.67934	103
74	15	enhance	28.540901	104
74	98	enhance	26.305765	105
74	16	enhance	25.846436	106
74	29	enhance	24.47144	107
74	37	enhance	24.137724	108
74	36	enhance	23.957142	109
74	88	enhance	22.510725	110
74	358	enhance	20.74317	111
74	17	enhance	19.971472	112
74	48	enhance	19.506409	113
74	68	enhance	19.27555	114
74	51	enhance	18.361147	115
74	71	enhance	17.360092	116
74	87	enhance	15.902024	117
74	40	enhance	15.5901165	118
74	67	enhance	9.618094	119
74	25	enhance	9.421012	120
74	46	enhance	5.9596143	121
74	75	enhance	5.915959	122
74	155	enhance	5.0260115	123
74	882	enhance	4.1004696	124
74	11	soften	100	1
74	64	soften	97.14476	2
75	68	enhance	100	1
75	25	enhance	99.35318	2
75	48	enhance	98.914505	3
75	40	enhance	98.68017	4
75	36	enhance	97.54382	5
75	87	enhance	97.44234	6
75	46	enhance	97.121445	7
75	155	enhance	97.0027	8
75	882	enhance	96.80762	9
75	71	enhance	95.33702	10
75	84	enhance	94.467896	11
75	17	enhance	92.74841	12
75	88	enhance	90.58918	13
75	1	enhance	90.38043	14
75	358	enhance	89.30894	15
75	108	enhance	88.06539	16
75	785	enhance	87.71675	17
75	97	enhance	86.56237	18
75	67	enhance	86.43171	19
75	86	enhance	85.14242	20
75	6	enhance	84.77806	21
75	285	enhance	84.493126	22
75	76	enhance	84.45111	23
75	647	enhance	83.05125	24
75	176	enhance	82.432655	25
75	16	enhance	82.33266	26
75	15	enhance	81.63277	27
75	38	enhance	79.61138	28
75	92	enhance	79.2379	29
75	10	enhance	79.1721	30
75	29	enhance	79.02748	31
75	98	enhance	78.86579	32
75	52	enhance	78.43336	33
75	51	enhance	78.09355	34
75	42	enhance	77.41147	35
75	31	enhance	77.40287	36
75	222	enhance	77.0044	37
75	37	enhance	76.59844	38
75	185	enhance	76.006714	39
75	24	enhance	74.49714	40
75	89	enhance	71.9468	41
75	27	enhance	70.06074	42
75	455	enhance	70.0199	43
75	62	enhance	69.23466	44
75	39	enhance	69.06405	45
75	47	enhance	68.90957	46
75	7	enhance	65.20331	47
75	100	enhance	64.09658	48
75	94	enhance	63.23636	49
75	56	enhance	63.1349	50
75	901	enhance	62.343437	51
75	26	enhance	62.065037	52
75	54	enhance	61.476307	53
75	77	enhance	61.412357	54
75	640	enhance	61.352085	55
75	81	enhance	60.861065	56
75	61	enhance	58.454765	57
75	187	enhance	57.79598	58
75	19	enhance	56.36031	59
75	49	enhance	55.087685	60
75	13	enhance	54.582737	61
75	230	enhance	53.406	62
75	53	enhance	53.23952	63
75	921	enhance	52.156197	64
75	50	enhance	52.128803	65
75	66	enhance	50.830296	66
75	63	enhance	50.567318	67
75	182	enhance	49.70281	68
75	28	enhance	47.871746	69
75	593	enhance	42.746037	70
75	33	enhance	41.352993	71
75	44	enhance	39.924553	72
75	30	enhance	39.166115	73
75	18	enhance	39.02157	74
75	78	enhance	37.999294	75
75	868	enhance	37.80512	76
75	58	enhance	36.916454	77
75	70	enhance	36.406425	78
75	73	enhance	36.21182	79
75	43	enhance	36.059124	80
75	32	enhance	35.99823	81
75	99	enhance	35.82267	82
75	65	enhance	35.72242	83
75	14	enhance	35.003418	84
75	34	enhance	32.745514	85
75	45	enhance	31.928078	86
75	59	enhance	30.742054	87
75	72	enhance	30.693895	88
75	184	enhance	28.948793	89
75	57	enhance	26.48853	90
75	93	enhance	26.060984	91
75	22	enhance	25.60592	92
75	79	enhance	24.76931	93
75	83	enhance	23.33708	94
75	335	enhance	23.202696	95
75	8	enhance	22.52742	96
75	2	enhance	22.368677	97
75	82	enhance	21.967308	98
75	126	enhance	21.871824	99
75	219	enhance	19.845015	100
75	90	enhance	19.376299	101
75	12	enhance	18.435991	102
75	5	enhance	17.964535	103
75	41	enhance	17.720278	104
75	3	enhance	17.383413	105
75	21	enhance	17.286985	106
75	55	enhance	16.607058	107
75	69	enhance	16.061613	108
75	488	enhance	16.03465	109
75	85	enhance	15.82717	110
75	60	enhance	14.815269	111
75	4	enhance	14.782396	112
75	171	enhance	14.710545	113
75	96	enhance	14.315014	114
75	80	enhance	13.764301	115
75	35	enhance	13.61571	116
75	9	enhance	12.977949	117
75	91	enhance	12.865079	118
75	23	enhance	12.355895	119
75	64	enhance	12.073763	120
75	11	enhance	11.156332	121
75	20	enhance	9.976118	122
75	95	enhance	8.268431	123
75	74	enhance	5.774719	124
75	64	soften	100	1
75	11	soften	99.93546	2
75	74	soften	98.710365	3
75	80	soften	96.61022	4
75	60	soften	96.33948	5
75	91	soften	94.85866	6
75	55	soften	93.435745	7
75	90	soften	92.3665	8
75	3	soften	92.07009	9
75	126	soften	91.96662	10
75	83	soften	91.182365	11
75	23	soften	89.57829	12
75	4	soften	88.978294	13
75	96	soften	88.57686	14
75	171	soften	88.09533	15
75	72	soften	87.90582	16
75	79	soften	87.78919	17
75	20	soften	87.43906	18
75	93	soften	87.2232	19
75	21	soften	86.37196	20
75	9	soften	85.927	21
75	95	soften	85.38185	22
75	35	soften	85.13237	23
75	5	soften	84.78799	24
75	2	soften	84.760925	25
75	45	soften	84.60558	26
75	82	soften	84.58041	27
75	70	soften	84.4903	28
75	219	soften	84.408936	29
75	184	soften	84.15107	30
75	335	soften	84.10408	31
75	85	soften	83.997086	32
75	34	soften	83.68745	33
75	12	soften	83.64193	34
75	43	soften	81.48177	35
75	22	soften	81.43861	36
75	99	soften	81.05999	37
75	59	soften	80.51328	38
75	41	soften	80.2097	39
75	868	soften	80.16557	40
75	69	soften	80.02129	41
75	30	soften	79.30141	42
75	33	soften	79.12394	43
75	73	soften	79.07249	44
75	78	soften	78.761086	45
75	8	soften	78.40936	46
75	182	soften	78.03509	47
75	18	soften	77.83969	48
75	49	soften	76.67907	49
75	13	soften	76.526764	50
75	593	soften	76.40613	51
75	63	soften	76.00049	52
75	488	soften	75.768	53
75	28	soften	75.56501	54
75	44	soften	75.098595	55
75	50	soften	74.50355	56
75	230	soften	73.15975	57
75	61	soften	72.61511	58
75	94	soften	72.18993	59
75	187	soften	71.98473	60
75	66	soften	71.900406	61
75	640	soften	71.45719	62
75	58	soften	70.16834	63
75	14	soften	69.883194	64
75	39	soften	69.32234	65
75	56	soften	68.8241	66
75	7	soften	68.39601	67
75	54	soften	67.90893	68
75	65	soften	67.118095	69
75	19	soften	67.00875	70
75	222	soften	66.617226	71
75	47	soften	66.23163	72
75	92	soften	66.217415	73
75	89	soften	66.05754	74
75	31	soften	65.94762	75
75	32	soften	65.18745	76
75	921	soften	64.516495	77
75	26	soften	64.291824	78
75	98	soften	64.11943	79
75	455	soften	64.11555	80
75	176	soften	63.66911	81
75	27	soften	63.65918	82
75	285	soften	63.528008	83
75	901	soften	62.461693	84
75	10	soften	62.083755	85
75	24	soften	61.607536	86
75	51	soften	61.333405	87
75	62	soften	60.951866	88
75	77	soften	60.281605	89
75	53	soften	60.160027	90
75	185	soften	60.133366	91
75	647	soften	60.10479	92
75	108	soften	60.089264	93
75	52	soften	59.73908	94
75	100	soften	59.629215	95
75	1	soften	58.45512	96
75	88	soften	58.064034	97
75	86	soften	57.61839	98
75	785	soften	57.08005	99
75	84	soften	56.329277	100
75	67	soften	56.21855	101
75	6	soften	54.655357	102
75	38	soften	54.51608	103
75	42	soften	54.224022	104
75	17	soften	53.83248	105
75	15	soften	53.731342	106
75	36	soften	53.303852	107
75	16	soften	53.261402	108
75	71	soften	53.251896	109
75	76	soften	52.852615	110
75	29	soften	52.702835	111
75	358	soften	51.797203	112
75	97	soften	51.67712	113
75	87	soften	51.17921	114
75	68	soften	51.01762	115
75	48	soften	50.413597	116
75	40	soften	50.06069	117
75	25	soften	49.084534	118
75	46	soften	47.64841	119
75	882	soften	47.07251	120
75	155	soften	47.049732	121
76	358	enhance	100	1
76	785	enhance	99.724335	2
76	38	enhance	99.554855	3
76	42	enhance	99.45359	4
76	16	enhance	97.193436	5
76	17	enhance	97.18129	6
76	29	enhance	97.05687	7
76	6	enhance	96.806335	8
76	37	enhance	96.23674	9
76	185	enhance	96.02736	10
76	97	enhance	95.23298	11
76	62	enhance	95.1146	12
76	100	enhance	93.9791	13
76	81	enhance	93.309456	14
76	87	enhance	93.11884	15
76	71	enhance	93.1051	16
76	77	enhance	92.72585	17
76	24	enhance	92.66697	18
76	647	enhance	90.76103	19
76	455	enhance	90.729546	20
76	52	enhance	90.540405	21
76	48	enhance	90.3792	22
76	46	enhance	90.26309	23
76	155	enhance	89.08013	24
76	882	enhance	89.04392	25
76	68	enhance	88.764565	26
76	921	enhance	87.898705	27
76	84	enhance	86.70156	28
76	25	enhance	86.53349	29
76	53	enhance	86.49702	30
76	15	enhance	86.25418	31
76	54	enhance	85.69519	32
76	40	enhance	85.23195	33
76	108	enhance	85.120415	34
76	36	enhance	84.88641	35
76	75	enhance	84.74356	36
76	10	enhance	84.22728	37
76	26	enhance	83.3652	38
76	27	enhance	83.24708	39
76	1	enhance	81.8236	40
76	901	enhance	80.45242	41
76	65	enhance	79.75216	42
76	176	enhance	78.65471	43
76	86	enhance	78.31697	44
76	32	enhance	76.67487	45
76	89	enhance	76.43128	46
76	14	enhance	76.10658	47
76	88	enhance	73.46483	48
76	7	enhance	72.36211	49
76	66	enhance	72.28233	50
76	285	enhance	71.70454	51
76	92	enhance	70.99377	52
76	19	enhance	70.41654	53
76	28	enhance	70.13484	54
76	58	enhance	69.35207	55
76	57	enhance	68.62428	56
76	39	enhance	68.40438	57
76	18	enhance	67.17124	58
76	56	enhance	67.05923	59
76	31	enhance	66.86345	60
76	98	enhance	66.46112	61
76	187	enhance	65.29533	62
76	593	enhance	64.99518	63
76	50	enhance	63.942406	64
76	67	enhance	62.716408	65
76	78	enhance	62.566498	66
76	488	enhance	61.88115	67
76	94	enhance	61.52659	68
76	8	enhance	61.498276	69
76	222	enhance	58.986763	70
76	51	enhance	58.590046	71
76	59	enhance	57.037468	72
76	44	enhance	54.153984	73
76	63	enhance	53.93463	74
76	219	enhance	53.55582	75
76	69	enhance	53.355194	76
76	35	enhance	52.709667	77
76	12	enhance	52.368465	78
76	47	enhance	52.13742	79
76	868	enhance	51.739403	80
76	41	enhance	51.61086	81
76	182	enhance	50.80102	82
76	85	enhance	50.71886	83
76	335	enhance	50.01401	84
76	171	enhance	49.704914	85
76	20	enhance	49.509296	86
76	95	enhance	49.254414	87
76	49	enhance	49.081257	88
76	34	enhance	48.462345	89
76	21	enhance	48.12992	90
76	5	enhance	47.106106	91
76	184	enhance	46.895367	92
76	82	enhance	46.644077	93
76	73	enhance	46.259865	94
76	22	enhance	43.844707	95
76	61	enhance	43.73123	96
76	640	enhance	43.168545	97
76	9	enhance	42.98465	98
76	79	enhance	42.97984	99
76	230	enhance	42.527523	100
76	43	enhance	41.795628	101
76	30	enhance	40.969788	102
76	96	enhance	40.886913	103
76	13	enhance	39.463646	104
76	4	enhance	39.06117	105
76	23	enhance	38.534523	106
76	99	enhance	37.53242	107
76	70	enhance	36.37021	108
76	2	enhance	34.74741	109
76	45	enhance	34.281754	110
76	93	enhance	33.85005	111
76	55	enhance	33.183704	112
76	3	enhance	30.49569	113
76	72	enhance	30.18026	114
76	91	enhance	28.858479	115
76	83	enhance	28.773027	116
76	74	enhance	28.55237	117
76	60	enhance	28.48508	118
76	33	enhance	28.241165	119
76	64	enhance	27.240456	120
76	11	enhance	25.698734	121
76	126	enhance	23.666212	122
76	90	enhance	21.558136	123
76	80	enhance	18.03627	124
76	80	soften	100	1
76	11	soften	99.11473	2
76	90	soften	96.67827	3
76	60	soften	96.58567	4
76	126	soften	96.22111	5
76	83	soften	94.240234	6
76	91	soften	94.21827	7
76	72	soften	93.39988	8
76	3	soften	92.803955	9
76	55	soften	92.68477	10
76	93	soften	90.21339	11
76	70	soften	89.695755	12
76	79	soften	89.53827	13
76	45	soften	88.672455	14
76	33	soften	87.3892	15
76	23	soften	87.04762	16
76	4	soften	86.25501	17
76	2	soften	86.20619	18
76	13	soften	85.51845	19
76	99	soften	85.27829	20
76	34	soften	84.753555	21
76	43	soften	84.69876	22
76	96	soften	84.69862	23
76	184	soften	84.16353	24
76	82	soften	83.59859	25
76	30	soften	83.5874	26
76	182	soften	83.49513	27
76	171	soften	83.17907	28
76	21	soften	82.89872	29
76	5	soften	82.725975	30
76	9	soften	82.58802	31
76	73	soften	82.09844	32
76	335	soften	81.313225	33
76	868	soften	81.24085	34
76	20	soften	81.09788	35
76	22	soften	81.006035	36
76	640	soften	80.78124	37
76	230	soften	80.779594	38
76	219	soften	80.07181	39
76	63	soften	79.917725	40
76	59	soften	79.50127	41
76	85	soften	79.44518	42
76	12	soften	79.39061	43
76	35	soften	79.202995	44
76	78	soften	78.21608	45
76	50	soften	77.53682	46
76	28	soften	77.45479	47
76	18	soften	77.427246	48
76	44	soften	77.19089	49
76	593	soften	77.17036	50
76	41	soften	75.96899	51
76	69	soften	75.56022	52
76	39	soften	75.18513	53
76	187	soften	74.722046	54
76	8	soften	74.35698	55
76	66	soften	73.82542	56
76	98	soften	73.35391	57
76	285	soften	72.45872	58
76	7	soften	71.64335	59
76	176	soften	70.42101	60
76	89	soften	69.7438	61
76	19	soften	69.7141	62
76	54	soften	69.664345	63
76	488	soften	69.5769	64
76	64	soften	69.36837	65
76	58	soften	68.35997	66
76	27	soften	67.87068	67
76	10	soften	66.78562	68
76	74	soften	66.41012	69
76	108	soften	66.27414	70
76	14	soften	66.1263	71
76	455	soften	65.97925	72
76	86	soften	65.73572	73
76	26	soften	64.621506	74
76	647	soften	64.18872	75
76	24	soften	64.10396	76
76	52	soften	63.849644	77
76	65	soften	63.413986	78
76	901	soften	63.244038	79
76	32	soften	62.24597	80
76	185	soften	61.73512	81
76	785	soften	60.5732	82
76	53	soften	59.47397	83
76	17	soften	59.035847	84
76	49	soften	58.98408	85
76	6	soften	58.723675	86
76	15	soften	58.48318	87
76	87	soften	58.12292	88
76	48	soften	58.06501	89
76	97	soften	56.986214	90
76	61	soften	56.980038	91
76	38	soften	56.581306	92
76	358	soften	56.045643	93
76	94	soften	55.11847	94
76	155	soften	55.08077	95
76	95	soften	54.61026	96
76	222	soften	53.510742	97
76	47	soften	52.1137	98
76	31	soften	51.5908	99
76	92	soften	51.077316	100
76	56	soften	50.742214	101
76	51	soften	50.286526	102
76	88	soften	47.398735	103
76	67	soften	46.97354	104
76	1	soften	45.576977	105
76	84	soften	44.963387	106
76	921	soften	44.00251	107
76	62	soften	43.293434	108
76	36	soften	42.879856	109
76	77	soften	42.255924	110
76	100	soften	42.04877	111
76	71	soften	41.68988	112
76	40	soften	41.57423	113
76	68	soften	41.148495	114
76	25	soften	40.580402	115
76	46	soften	38.66891	116
76	882	soften	38.500538	117
77	100	enhance	100	1
77	62	enhance	94.49285	2
77	65	enhance	94.17168	3
77	42	enhance	93.88755	4
77	38	enhance	93.62377	5
77	455	enhance	93.45261	6
77	76	enhance	90.652885	7
77	81	enhance	90.04847	8
77	185	enhance	89.95393	9
77	32	enhance	89.88326	10
77	24	enhance	89.24322	11
77	52	enhance	88.85227	12
77	54	enhance	88.660164	13
77	921	enhance	88.46619	14
77	53	enhance	88.08845	15
77	14	enhance	87.28934	16
77	785	enhance	86.66625	17
77	58	enhance	86.02078	18
77	16	enhance	85.06715	19
77	6	enhance	85.01861	20
77	29	enhance	84.86406	21
77	27	enhance	84.25076	22
77	66	enhance	84.00713	23
77	37	enhance	83.54035	24
77	358	enhance	82.848206	25
77	10	enhance	82.77948	26
77	97	enhance	82.499	27
77	488	enhance	81.932274	28
77	593	enhance	81.330414	29
77	18	enhance	80.52392	30
77	8	enhance	80.41045	31
77	69	enhance	79.98232	32
77	17	enhance	79.891136	33
77	57	enhance	79.69419	34
77	647	enhance	79.257355	35
77	78	enhance	78.666916	36
77	59	enhance	78.4154	37
77	15	enhance	77.62267	38
77	41	enhance	77.579124	39
77	35	enhance	77.28119	40
77	12	enhance	77.15992	41
77	219	enhance	76.742935	42
77	28	enhance	76.60531	43
77	85	enhance	76.01975	44
77	71	enhance	75.49737	45
77	7	enhance	74.8019	46
77	26	enhance	74.56105	47
77	19	enhance	74.09667	48
77	108	enhance	74.02603	49
77	335	enhance	73.79206	50
77	20	enhance	73.604416	51
77	21	enhance	73.47121	52
77	901	enhance	72.836334	53
77	48	enhance	71.71204	54
77	87	enhance	71.259476	55
77	44	enhance	71.24052	56
77	5	enhance	71.05218	57
77	95	enhance	70.973206	58
77	50	enhance	70.821144	59
77	171	enhance	70.6625	60
77	176	enhance	70.62019	61
77	9	enhance	70.45103	62
77	86	enhance	69.53549	63
77	39	enhance	69.43697	64
77	868	enhance	69.23654	65
77	68	enhance	68.6128	66
77	82	enhance	67.62885	67
77	94	enhance	67.619385	68
77	89	enhance	67.321884	69
77	96	enhance	67.30536	70
77	184	enhance	66.34606	71
77	92	enhance	65.86639	72
77	22	enhance	65.6178	73
77	36	enhance	65.49206	74
77	84	enhance	65.428825	75
77	1	enhance	65.18912	76
77	23	enhance	64.88415	77
77	40	enhance	64.43716	78
77	4	enhance	63.764946	79
77	46	enhance	63.742435	80
77	25	enhance	63.271915	81
77	187	enhance	62.52225	82
77	155	enhance	62.3605	83
77	285	enhance	61.665962	84
77	882	enhance	61.64201	85
77	75	enhance	60.24734	86
77	79	enhance	59.589123	87
77	34	enhance	59.310005	88
77	63	enhance	59.18967	89
77	56	enhance	56.19655	90
77	74	enhance	55.88357	91
77	88	enhance	55.802925	92
77	182	enhance	55.41702	93
77	55	enhance	55.076794	94
77	91	enhance	54.428493	95
77	93	enhance	54.010895	96
77	31	enhance	53.187874	97
77	98	enhance	53.131657	98
77	3	enhance	51.444298	99
77	60	enhance	50.480648	100
77	49	enhance	50.36834	101
77	70	enhance	50.02787	102
77	64	enhance	49.615063	103
77	2	enhance	48.62448	104
77	43	enhance	47.9199	105
77	11	enhance	47.57151	106
77	99	enhance	47.347893	107
77	73	enhance	46.668808	108
77	222	enhance	45.564137	109
77	83	enhance	44.830738	110
77	72	enhance	44.5283	111
77	45	enhance	39.89718	112
77	67	enhance	39.511307	113
77	51	enhance	39.47728	114
77	47	enhance	39.05744	115
77	90	enhance	38.607765	116
77	126	enhance	37.539192	117
77	30	enhance	37.17464	118
77	230	enhance	37.156883	119
77	13	enhance	36.62686	120
77	61	enhance	35.864876	121
77	640	enhance	35.202595	122
77	80	enhance	32.44277	123
77	33	enhance	24.523697	124
77	80	soften	100	1
77	90	soften	97.60762	2
77	126	soften	97.555405	3
77	11	soften	96.89286	4
77	64	soften	96.281845	5
77	72	soften	95.27105	6
77	83	soften	95.13099	7
77	60	soften	94.72194	8
77	3	soften	92.39854	9
77	33	soften	92.25478	10
77	55	soften	91.55864	11
77	70	soften	91.21037	12
77	91	soften	90.49375	13
77	45	soften	90.39831	14
77	13	soften	90.28688	15
77	93	soften	89.96022	16
77	74	soften	89.2703	17
77	79	soften	88.5713	18
77	49	soften	88.15822	19
77	30	soften	88.100555	20
77	99	soften	87.34386	21
77	43	soften	86.945045	22
77	182	soften	86.626076	23
77	61	soften	86.34647	24
77	2	soften	86.16013	25
77	640	soften	86.15165	26
77	34	soften	86.02978	27
77	230	soften	84.98976	28
77	73	soften	84.958305	29
77	23	soften	83.69201	30
77	4	soften	83.57028	31
77	184	soften	83.29556	32
77	222	soften	82.615555	33
77	82	soften	82.235634	34
77	63	soften	81.91931	35
77	94	soften	81.44968	36
77	96	soften	80.731964	37
77	868	soften	80.536514	38
77	171	soften	80.05909	39
77	5	soften	80.00874	40
77	22	soften	79.60751	41
77	50	soften	79.50459	42
77	47	soften	79.46359	43
77	98	soften	79.32852	44
77	9	soften	79.09555	45
77	51	soften	79.0552	46
77	31	soften	79.00925	47
77	39	soften	78.950096	48
77	28	soften	78.88347	49
77	21	soften	78.55854	50
77	335	soften	78.477745	51
77	78	soften	78.25234	52
77	187	soften	78.22853	53
77	285	soften	77.95411	54
77	44	soften	77.91426	55
77	59	soften	77.61626	56
77	18	soften	77.264854	57
77	219	soften	77.16343	58
77	593	soften	77.14813	59
77	92	soften	77.14577	60
77	56	soften	77.03869	61
77	20	soften	76.80575	62
77	12	soften	75.26296	63
77	66	soften	74.97619	64
77	35	soften	74.715546	65
77	85	soften	74.67767	66
77	7	soften	74.31639	67
77	176	soften	74.24219	68
77	67	soften	74.175766	69
77	88	soften	74.029854	70
77	95	soften	73.51725	71
77	89	soften	73.48397	72
77	41	soften	72.91987	73
77	8	soften	72.784775	74
77	19	soften	72.39477	75
77	54	soften	71.844185	76
77	69	soften	71.4413	77
77	27	soften	71.15231	78
77	86	soften	70.84057	79
77	108	soften	70.83652	80
77	84	soften	70.23654	81
77	1	soften	70.139435	82
77	10	soften	70.10049	83
77	647	soften	68.38619	84
77	26	soften	67.98269	85
77	455	soften	67.63468	86
77	58	soften	67.51962	87
77	52	soften	66.91416	88
77	36	soften	66.68167	89
77	901	soften	66.66159	90
77	24	soften	65.9767	91
77	40	soften	65.84703	92
77	488	soften	65.64009	93
77	14	soften	65.01326	94
77	25	soften	64.55101	95
77	785	soften	64.42378	96
77	921	soften	64.25007	97
77	185	soften	64.19736	98
77	87	soften	63.902954	99
77	62	soften	63.55677	100
77	6	soften	63.047657	101
77	65	soften	62.281033	102
77	97	soften	61.763638	103
78	184	enhance	100	1
78	219	enhance	99.16115	2
78	335	enhance	98.54167	3
78	593	enhance	97.056206	4
78	59	enhance	96.92846	5
78	96	enhance	96.865486	6
78	44	enhance	96.356606	7
78	22	enhance	96.326996	8
78	18	enhance	95.94718	9
78	41	enhance	94.99656	10
78	21	enhance	94.480644	11
78	66	enhance	93.619125	12
78	4	enhance	93.61783	13
78	74	enhance	93.50051	14
78	9	enhance	93.47254	15
78	23	enhance	93.38353	16
78	5	enhance	92.87087	17
78	27	enhance	91.86982	18
78	85	enhance	91.553276	19
78	93	enhance	91.49303	20
78	69	enhance	91.37342	21
78	91	enhance	91.30141	22
78	3	enhance	90.988	23
78	12	enhance	90.93432	24
78	35	enhance	90.024826	25
78	20	enhance	89.81668	26
78	8	enhance	89.23234	27
78	455	enhance	89.11995	28
78	55	enhance	88.72672	29
78	64	enhance	88.52136	30
78	868	enhance	88.13412	31
78	58	enhance	88.06578	32
78	54	enhance	87.951546	33
78	39	enhance	87.82628	34
78	10	enhance	87.32388	35
78	50	enhance	85.19212	36
78	11	enhance	84.93957	37
78	52	enhance	84.927155	38
78	94	enhance	84.8391	39
78	79	enhance	84.810936	40
78	171	enhance	84.53342	41
78	7	enhance	83.69338	42
78	82	enhance	83.40053	43
78	65	enhance	82.83192	44
78	60	enhance	82.3811	45
78	77	enhance	81.93432	46
78	100	enhance	81.62369	47
78	70	enhance	81.06969	48
78	34	enhance	80.18521	49
78	28	enhance	79.51595	50
78	95	enhance	78.458565	51
78	83	enhance	78.01312	52
78	62	enhance	77.91254	53
78	72	enhance	77.32101	54
78	14	enhance	76.746826	55
78	90	enhance	75.60851	56
78	488	enhance	74.4336	57
78	921	enhance	73.60923	58
78	185	enhance	73.50063	59
78	24	enhance	73.40977	60
78	63	enhance	73.250175	61
78	86	enhance	73.01314	62
78	99	enhance	72.224686	63
78	19	enhance	72.07047	64
78	126	enhance	70.8866	65
78	92	enhance	70.629875	66
78	43	enhance	70.29924	67
78	32	enhance	69.77004	68
78	647	enhance	69.25662	69
78	182	enhance	69.20224	70
78	26	enhance	69.15084	71
78	80	enhance	68.89803	72
78	187	enhance	68.12527	73
78	53	enhance	67.74629	74
78	38	enhance	67.46934	75
78	42	enhance	67.2591	76
78	49	enhance	67.15674	77
78	89	enhance	67.04708	78
78	108	enhance	66.851	79
78	81	enhance	66.46518	80
78	6	enhance	66.39432	81
78	2	enhance	65.860535	82
78	785	enhance	64.35158	83
78	176	enhance	64.11254	84
78	56	enhance	63.718826	85
78	76	enhance	63.708344	86
78	16	enhance	62.44339	87
78	285	enhance	62.43469	88
78	29	enhance	62.34378	89
78	45	enhance	62.16123	90
78	97	enhance	62.003666	91
78	73	enhance	61.31063	92
78	901	enhance	60.333412	93
78	57	enhance	59.976234	94
78	358	enhance	58.247417	95
78	37	enhance	58.19997	96
78	15	enhance	57.831528	97
78	17	enhance	57.830322	98
78	30	enhance	57.051983	99
78	84	enhance	55.947826	100
78	1	enhance	55.745697	101
78	48	enhance	53.527824	102
78	68	enhance	53.394497	103
78	13	enhance	52.894707	104
78	36	enhance	52.33429	105
78	71	enhance	52.01595	106
78	31	enhance	49.65966	107
78	87	enhance	48.87366	108
78	222	enhance	48.73108	109
78	230	enhance	46.915775	110
78	40	enhance	46.83636	111
78	88	enhance	46.64066	112
78	640	enhance	45.865063	113
78	98	enhance	45.51812	114
78	61	enhance	45.514557	115
78	47	enhance	44.593273	116
78	46	enhance	43.86749	117
78	25	enhance	42.066566	118
78	882	enhance	41.050198	119
78	155	enhance	39.379215	120
78	75	enhance	38.826775	121
78	33	enhance	35.389946	122
78	51	enhance	34.896038	123
78	67	enhance	28.958134	124
78	11	soften	100	1
78	64	soften	98.6527	2
78	60	soften	98.58064	3
78	80	soften	97.96693	4
78	72	soften	97.948105	5
78	83	soften	97.431755	6
78	126	soften	97.0267	7
78	90	soften	96.381805	8
78	55	soften	94.53721	9
78	3	soften	93.229774	10
78	91	soften	92.493324	11
78	70	soften	92.087296	12
78	93	soften	90.21646	13
78	74	soften	90.139725	14
78	45	soften	89.87854	15
78	79	soften	86.95572	16
78	4	soften	85.80273	17
78	184	soften	85.38937	18
78	868	soften	84.776566	19
78	23	soften	83.41123	20
78	171	soften	82.41592	21
78	96	soften	82.39126	22
78	22	soften	81.73846	23
78	335	soften	80.87249	24
78	9	soften	80.09985	25
78	59	soften	79.53086	26
78	21	soften	79.311264	27
78	219	soften	79.00802	28
79	18	enhance	100	1
79	21	enhance	94.204315	2
79	80	enhance	94.2036	3
79	74	enhance	93.438225	4
79	5	enhance	91.807495	5
79	593	enhance	90.902214	6
79	85	enhance	90.33369	7
79	34	enhance	90.2382	8
79	23	enhance	90.11975	9
79	3	enhance	90.03705	10
79	28	enhance	89.39617	11
79	126	enhance	88.89978	12
79	49	enhance	88.47778	13
79	78	enhance	88.378876	14
79	70	enhance	88.19863	15
79	73	enhance	88.08792	16
79	93	enhance	87.97656	17
79	59	enhance	87.72787	18
79	69	enhance	87.348854	19
79	35	enhance	87.02235	20
79	12	enhance	86.94749	21
79	66	enhance	86.641655	22
79	54	enhance	86.48848	23
79	94	enhance	86.224495	24
79	45	enhance	85.96384	25
79	90	enhance	85.78392	26
79	50	enhance	85.702934	27
79	82	enhance	85.14663	28
79	91	enhance	85.02053	29
79	9	enhance	84.79247	30
79	20	enhance	84.40192	31
79	83	enhance	84.140785	32
79	219	enhance	84.05285	33
79	43	enhance	83.6678	34
79	96	enhance	82.68476	35
79	184	enhance	82.458595	36
79	27	enhance	81.36604	37
79	2	enhance	80.940025	38
79	4	enhance	80.784874	39
79	64	enhance	80.65351	40
79	335	enhance	80.002174	41
79	55	enhance	79.743286	42
79	72	enhance	79.60043	43
79	171	enhance	79.17193	44
79	63	enhance	79.12395	45
79	99	enhance	78.86241	46
79	182	enhance	78.777855	47
79	8	enhance	77.495094	48
79	39	enhance	77.42785	49
79	11	enhance	77.355194	50
79	455	enhance	76.89685	51
79	41	enhance	75.500084	52
79	30	enhance	75.21826	53
79	488	enhance	74.92011	54
79	22	enhance	74.69187	55
79	60	enhance	74.586266	56
79	44	enhance	74.16855	57
79	95	enhance	73.45142	58
79	52	enhance	71.24576	59
79	58	enhance	70.27165	60
79	32	enhance	69.68508	61
79	868	enhance	69.54912	62
79	24	enhance	68.70123	63
79	13	enhance	68.39235	64
79	10	enhance	68.00956	65
79	230	enhance	67.69879	66
79	61	enhance	66.80082	67
79	65	enhance	66.425064	68
79	53	enhance	65.552536	69
79	7	enhance	64.853676	70
79	77	enhance	64.675125	71
79	14	enhance	64.19064	72
79	62	enhance	64.084465	73
79	100	enhance	64.036896	74
79	285	enhance	63.294216	75
79	56	enhance	62.97908	76
79	921	enhance	62.266037	77
79	86	enhance	61.943096	78
79	98	enhance	61.41332	79
79	176	enhance	60.536213	80
79	19	enhance	60.283745	81
79	647	enhance	60.167057	82
79	108	enhance	59.738373	83
79	89	enhance	59.654003	84
79	31	enhance	58.639565	85
79	185	enhance	58.45467	86
79	187	enhance	58.153458	87
79	640	enhance	57.96394	88
79	92	enhance	57.093895	89
79	47	enhance	55.884415	90
79	33	enhance	55.33632	91
79	6	enhance	54.72016	92
79	97	enhance	52.948906	93
79	88	enhance	52.76288	94
79	222	enhance	48.829483	95
79	84	enhance	48.712803	96
79	26	enhance	48.60374	97
79	42	enhance	47.708626	98
79	38	enhance	47.35394	99
79	81	enhance	47.340176	100
79	29	enhance	46.527473	101
79	785	enhance	46.13337	102
79	76	enhance	45.60536	103
79	36	enhance	45.230133	104
79	57	enhance	45.02157	105
79	1	enhance	44.433792	106
79	16	enhance	42.660206	107
79	358	enhance	40.932842	108
79	40	enhance	40.715637	109
79	17	enhance	40.320293	110
79	37	enhance	38.953804	111
79	68	enhance	38.09548	112
79	71	enhance	37.944645	113
79	48	enhance	37.206615	114
79	901	enhance	34.859745	115
79	15	enhance	34.070084	116
79	87	enhance	32.119976	117
79	51	enhance	30.425768	118
79	25	enhance	28.152517	119
79	67	enhance	26.399487	120
79	75	enhance	26.373411	121
79	46	enhance	24.672508	122
79	155	enhance	20.395714	123
79	882	enhance	18.828716	124
79	11	soften	100	1
79	60	soften	98.53666	2
79	55	soften	95.06982	3
79	72	soften	94.64692	4
79	83	soften	94.52581	5
79	91	soften	92.03595	6
79	3	soften	90.99304	7
79	126	soften	90.033485	8
79	184	soften	89.263054	9
79	80	soften	89.10095	10
79	90	soften	88.93375	11
79	70	soften	88.476654	12
79	93	soften	87.76108	13
79	96	soften	85.769264	14
79	64	soften	69.276505	15
79	74	soften	62.86941	16
80	45	enhance	100	1
80	126	enhance	98.18951	2
80	43	enhance	94.43002	3
80	34	enhance	92.37708	4
80	79	enhance	92.10447	5
80	49	enhance	90.56448	6
80	73	enhance	89.90139	7
80	30	enhance	89.69339	8
80	70	enhance	89.67384	9
80	90	enhance	89.39143	10
80	2	enhance	87.99096	11
80	3	enhance	86.45718	12
80	83	enhance	85.59676	13
80	63	enhance	84.95466	14
80	99	enhance	83.47089	15
80	74	enhance	82.84087	16
80	93	enhance	81.58786	17
80	18	enhance	79.68121	18
80	13	enhance	79.19231	19
80	72	enhance	78.53627	20
80	61	enhance	78.52767	21
80	230	enhance	77.33073	22
80	94	enhance	75.84617	23
80	82	enhance	74.15732	24
80	182	enhance	73.609825	25
80	50	enhance	73.41965	26
80	39	enhance	72.71505	27
80	55	enhance	72.36071	28
80	23	enhance	71.81804	29
80	33	enhance	71.59539	30
80	64	enhance	70.85148	31
80	96	enhance	70.3684	32
80	56	enhance	70.28774	33
80	78	enhance	70.19669	34
80	91	enhance	69.721794	35
80	593	enhance	69.23762	36
80	640	enhance	68.805374	37
80	11	enhance	68.670944	38
80	184	enhance	68.433754	39
80	5	enhance	68.40952	40
80	20	enhance	67.73754	41
80	47	enhance	66.37514	42
80	21	enhance	66.173134	43
80	9	enhance	66.028625	44
80	219	enhance	64.22626	45
80	171	enhance	63.215538	46
80	28	enhance	62.54011	47
80	89	enhance	62.471806	48
80	95	enhance	62.353447	49
80	31	enhance	62.225044	50
80	58	enhance	61.09401	51
80	4	enhance	60.91349	52
80	60	enhance	60.705482	53
80	59	enhance	60.212013	54
80	187	enhance	59.612038	55
80	85	enhance	59.191692	56
80	44	enhance	59.04657	57
80	69	enhance	59.022705	58
80	285	enhance	58.909824	59
80	335	enhance	58.276894	60
80	22	enhance	58.27038	61
80	7	enhance	58.061295	62
80	19	enhance	57.403275	63
80	98	enhance	56.982	64
80	35	enhance	56.82547	65
80	868	enhance	56.78793	66
80	54	enhance	55.75785	67
80	12	enhance	54.796707	68
80	41	enhance	54.52537	69
80	66	enhance	53.448376	70
80	8	enhance	53.308083	71
80	92	enhance	52.601868	72
80	27	enhance	52.59918	73
80	222	enhance	52.127747	74
80	455	enhance	51.178883	75
80	108	enhance	50.38628	76
80	176	enhance	49.676315	77
80	88	enhance	49.240597	78
80	86	enhance	49.056652	79
80	647	enhance	48.27956	80
80	488	enhance	47.562656	81
80	10	enhance	47.267464	82
80	24	enhance	44.35519	83
80	1	enhance	43.90888	84
80	52	enhance	42.756306	85
80	62	enhance	42.08265	86
80	84	enhance	40.494217	87
80	36	enhance	39.3835	88
80	14	enhance	39.03543	89
80	26	enhance	38.842384	90
80	65	enhance	37.15419	91
80	921	enhance	37.10631	92
80	185	enhance	37.054638	93
80	32	enhance	36.417118	94
80	77	enhance	34.427177	95
80	100	enhance	33.612392	96
80	51	enhance	31.44318	97
80	57	enhance	30.78148	98
80	40	enhance	29.702347	99
80	67	enhance	29.585665	100
80	6	enhance	29.073685	101
80	15	enhance	26.47584	102
80	68	enhance	26.023636	103
80	97	enhance	24.973587	104
80	53	enhance	24.62162	105
80	37	enhance	23.427198	106
80	785	enhance	23.246231	107
80	48	enhance	22.436626	108
80	38	enhance	21.117302	109
80	901	enhance	20.966911	110
80	71	enhance	20.66382	111
80	81	enhance	20.632484	112
80	42	enhance	20.096926	113
80	17	enhance	18.83849	114
80	76	enhance	18.711605	115
80	25	enhance	17.738794	116
80	87	enhance	16.64098	117
80	16	enhance	15.433173	118
80	29	enhance	14.792683	119
80	75	enhance	14.329129	120
80	358	enhance	13.677716	121
80	46	enhance	9.297184	122
80	155	enhance	6.4456973	123
80	882	enhance	6.202682	124
80	64	soften	100	1
80	11	soften	98.78195	2
80	60	soften	96.49535	3
80	91	soften	92.82194	4
80	74	soften	91.59918	5
81	921	enhance	100	1
81	185	enhance	96.23908	2
81	42	enhance	95.93541	3
81	62	enhance	95.22695	4
81	76	enhance	94.10672	5
81	16	enhance	93.83751	6
81	38	enhance	93.680786	7
81	37	enhance	93.41724	8
81	29	enhance	93.22641	9
81	26	enhance	93.19969	10
81	100	enhance	93.19707	11
81	77	enhance	92.894615	12
81	65	enhance	92.71278	13
81	785	enhance	91.50352	14
81	53	enhance	90.60301	15
81	14	enhance	90.26377	16
81	901	enhance	89.84565	17
81	358	enhance	89.64295	18
81	6	enhance	87.56179	19
81	54	enhance	87.31911	20
81	455	enhance	86.81089	21
81	32	enhance	86.540016	22
81	17	enhance	86.36329	23
81	57	enhance	85.11169	24
81	24	enhance	83.46345	25
81	647	enhance	83.341	26
81	97	enhance	82.212265	27
81	52	enhance	81.020134	28
81	71	enhance	79.607864	29
81	8	enhance	79.12164	30
81	488	enhance	77.57233	31
81	15	enhance	76.97925	32
81	27	enhance	75.886734	33
81	58	enhance	75.84782	34
81	10	enhance	75.16355	35
81	89	enhance	74.85007	36
81	187	enhance	72.67043	37
81	28	enhance	72.60031	38
81	108	enhance	72.432335	39
81	19	enhance	72.41005	40
81	87	enhance	72.3763	41
81	46	enhance	72.30619	42
81	48	enhance	72.17025	43
81	18	enhance	71.9678	44
81	68	enhance	71.24778	45
81	66	enhance	71.057686	46
81	7	enhance	70.635475	47
81	56	enhance	70.1251	48
81	882	enhance	67.6538	49
81	50	enhance	67.59783	50
81	1	enhance	67.41835	51
81	593	enhance	67.31271	52
81	155	enhance	66.566025	53
81	36	enhance	66.40946	54
81	95	enhance	65.84863	55
81	78	enhance	65.83164	56
81	35	enhance	65.82659	57
81	84	enhance	64.95452	58
81	20	enhance	64.88824	59
81	171	enhance	64.09686	60
81	40	enhance	63.91462	61
81	219	enhance	63.83649	62
81	25	enhance	63.39978	63
81	69	enhance	61.91006	64
81	75	enhance	61.593643	65
81	12	enhance	60.3285	66
81	176	enhance	60.292603	67
81	41	enhance	60.228992	68
81	59	enhance	58.927696	69
81	85	enhance	58.75562	70
81	34	enhance	58.487637	71
81	92	enhance	58.13581	72
81	86	enhance	57.02301	73
81	82	enhance	56.952988	74
81	39	enhance	56.874527	75
81	88	enhance	56.483444	76
81	5	enhance	56.13464	77
81	285	enhance	54.280693	78
81	31	enhance	53.770313	79
81	21	enhance	53.761745	80
81	335	enhance	53.39857	81
81	98	enhance	52.761993	82
81	63	enhance	51.8621	83
81	9	enhance	51.47642	84
81	94	enhance	50.249516	85
81	44	enhance	50.16927	86
81	73	enhance	49.96561	87
81	182	enhance	49.358635	88
81	868	enhance	49.12272	89
81	4	enhance	47.16837	90
81	43	enhance	47.06585	91
81	184	enhance	46.87112	92
81	23	enhance	46.568634	93
81	96	enhance	45.441566	94
81	79	enhance	44.99599	95
81	30	enhance	43.84524	96
81	22	enhance	43.749767	97
81	47	enhance	41.787724	98
81	49	enhance	41.560627	99
81	55	enhance	40.76681	100
81	2	enhance	39.59325	101
81	99	enhance	39.00399	102
81	67	enhance	38.877495	103
81	222	enhance	38.092663	104
81	51	enhance	37.31371	105
81	3	enhance	36.44482	106
81	230	enhance	36.060246	107
81	45	enhance	34.95089	108
81	61	enhance	34.050465	109
81	74	enhance	33.3554	110
81	60	enhance	32.595455	111
81	83	enhance	32.36913	112
81	70	enhance	31.92709	113
81	93	enhance	31.796642	114
81	11	enhance	31.01138	115
81	640	enhance	30.948027	116
81	91	enhance	30.323515	117
81	64	enhance	30.176231	118
81	13	enhance	27.964281	119
81	72	enhance	27.667538	120
81	126	enhance	26.440468	121
81	33	enhance	23.64555	122
81	90	enhance	23.435368	123
81	80	enhance	20.05775	124
81	11	soften	100	1
81	91	soften	98.49393	2
81	90	soften	97.693184	3
81	126	soften	96.49733	4
81	93	soften	94.71726	5
81	3	soften	93.16212	6
81	79	soften	92.44029	7
81	55	soften	92.400406	8
81	184	soften	89.10353	9
81	96	soften	88.16566	10
81	23	soften	87.76993	11
81	2	soften	86.90664	12
81	4	soften	86.62119	13
81	99	soften	86.47323	14
81	868	soften	86.29257	15
81	22	soften	86.24153	16
81	21	soften	85.64328	17
81	182	soften	85.18475	18
81	30	soften	83.767075	19
81	34	soften	83.48405	20
81	59	soften	83.2828	21
81	9	soften	83.15685	22
81	82	soften	83.046776	23
81	44	soften	83.04606	24
81	63	soften	82.49352	25
81	171	soften	81.4291	26
81	39	soften	81.33306	27
81	85	soften	80.87949	28
81	12	soften	80.7461	29
81	219	soften	80.68651	30
81	28	soften	79.592476	31
81	18	soften	79.56398	32
81	285	soften	79.380615	33
81	50	soften	78.767494	34
81	35	soften	78.21447	35
81	66	soften	77.95392	36
81	176	soften	77.789894	37
81	69	soften	76.71355	38
81	7	soften	74.33622	39
81	27	soften	73.90561	40
81	10	soften	72.34729	41
81	54	soften	72.22819	42
81	8	soften	71.99948	43
81	64	soften	71.64287	44
81	80	soften	70.93166	45
81	455	soften	70.56895	46
81	58	soften	70.19431	47
81	52	soften	70.08494	48
81	74	soften	68.56383	49
81	647	soften	68.46476	50
81	60	soften	68.38046	51
81	488	soften	68.15011	52
81	72	soften	67.358795	53
81	83	soften	66.17706	54
81	70	soften	65.489204	55
81	14	soften	65.4677	56
81	6	soften	64.57359	57
81	97	soften	64.38748	58
81	17	soften	64.244965	59
81	45	soften	63.1382	60
81	13	soften	63.00213	61
81	15	soften	62.810318	62
81	32	soften	62.64467	63
81	901	soften	62.640198	64
81	33	soften	62.22207	65
81	53	soften	61.730515	66
81	49	soften	61.70902	67
81	76	soften	60.8268	68
81	37	soften	60.135933	69
81	640	soften	59.657894	70
81	61	soften	59.58977	71
81	335	soften	59.58889	72
81	94	soften	59.40593	73
81	43	soften	59.14	74
81	222	soften	58.763737	75
81	230	soften	58.55005	76
81	5	soften	58.16697	77
81	73	soften	57.801617	78
81	78	soften	56.864628	79
81	593	soften	55.950558	80
81	51	soften	55.91885	81
81	20	soften	55.77896	82
81	47	soften	54.93206	83
81	31	soften	54.8559	84
81	92	soften	54.833794	85
81	98	soften	54.82747	86
81	41	soften	54.0196	87
81	95	soften	53.318176	88
81	86	soften	52.916798	89
81	67	soften	52.90329	90
81	187	soften	51.911545	91
81	88	soften	51.648952	92
81	56	soften	51.222157	93
81	84	soften	50.929123	94
81	89	soften	50.416744	95
81	108	soften	50.11405	96
81	19	soften	49.69483	97
81	1	soften	49.563774	98
81	24	soften	49.05241	99
81	36	soften	47.758327	100
81	40	soften	47.41631	101
81	25	soften	46.771103	102
81	87	soften	46.42789	103
81	68	soften	45.851883	104
81	48	soften	45.711845	105
81	785	soften	45.6006	106
81	62	soften	45.530754	107
81	71	soften	45.516796	108
81	185	soften	45.101627	109
81	26	soften	45.05448	110
81	155	soften	44.93675	111
81	77	soften	44.75049	112
81	100	soften	44.70251	113
81	882	soften	44.628918	114
81	65	soften	44.273716	115
81	75	soften	44.143227	116
81	46	soften	43.859547	117
81	921	soften	43.643383	118
81	358	soften	43.101585	119
81	38	soften	42.84922	120
81	42	soften	41.921383	121
81	16	soften	41.727177	122
81	29	soften	41.680447	123
82	5	enhance	100	1
82	23	enhance	97.552765	2
82	50	enhance	97.508446	3
82	593	enhance	95.94421	4
82	34	enhance	94.74222	5
82	59	enhance	93.520775	6
82	8	enhance	93.21683	7
82	55	enhance	92.814705	8
82	12	enhance	92.34579	9
82	2	enhance	92.34102	10
82	9	enhance	92.31093	11
82	182	enhance	92.23509	12
82	35	enhance	92.228195	13
82	20	enhance	92.03935	14
82	3	enhance	91.900986	15
82	70	enhance	91.844826	16
82	21	enhance	91.46034	17
82	85	enhance	91.36391	18
82	219	enhance	91.25979	19
82	83	enhance	91.18335	20
82	90	enhance	91.12342	21
82	99	enhance	90.83122	22
82	171	enhance	90.78958	23
82	4	enhance	90.71884	24
82	126	enhance	89.552	25
82	93	enhance	89.2437	26
82	96	enhance	89.19863	27
82	69	enhance	88.360725	28
82	335	enhance	87.98749	29
82	72	enhance	87.94274	30
82	18	enhance	86.77116	31
82	41	enhance	86.74296	32
82	66	enhance	86.12799	33
82	78	enhance	86.096985	34
82	74	enhance	85.392166	35
82	91	enhance	85.30786	36
82	63	enhance	85.27234	37
82	95	enhance	85.11984	38
82	60	enhance	85.11883	39
82	488	enhance	84.905235	40
82	94	enhance	84.46574	41
82	79	enhance	84.35095	42
82	14	enhance	83.47156	43
82	868	enhance	82.60714	44
82	43	enhance	82.42175	45
82	184	enhance	81.805595	46
82	11	enhance	80.95986	47
82	58	enhance	80.82248	48
82	28	enhance	80.253174	49
82	65	enhance	80.206	50
82	22	enhance	79.536354	51
82	32	enhance	79.400894	52
82	54	enhance	79.306244	53
82	64	enhance	77.92307	54
82	49	enhance	77.56167	55
82	44	enhance	77.28368	56
82	7	enhance	77.00237	57
82	19	enhance	76.87343	58
82	80	enhance	75.13864	59
82	187	enhance	74.17116	60
82	13	enhance	73.41462	61
82	10	enhance	73.27091	62
82	455	enhance	73.19237	63
82	77	enhance	72.71514	64
82	39	enhance	72.262215	65
82	45	enhance	72.10205	66
82	92	enhance	71.70679	67
82	100	enhance	71.06868	68
82	230	enhance	69.97236	69
82	27	enhance	68.98747	70
82	176	enhance	67.36459	71
82	921	enhance	66.612724	72
82	640	enhance	66.30585	73
82	33	enhance	66.059204	74
82	61	enhance	65.8137	75
82	62	enhance	64.98826	76
82	24	enhance	64.41006	77
82	57	enhance	63.58658	78
82	185	enhance	62.73396	79
82	52	enhance	62.596634	80
82	53	enhance	62.11681	81
82	285	enhance	59.463787	82
82	81	enhance	59.36017	83
82	47	enhance	59.17638	84
82	222	enhance	59.06384	85
82	31	enhance	58.672222	86
82	98	enhance	58.63273	87
82	89	enhance	58.32895	88
82	73	enhance	57.729744	89
82	56	enhance	57.529335	90
82	108	enhance	56.397446	91
82	647	enhance	55.52035	92
82	785	enhance	55.122746	93
82	26	enhance	54.09204	94
82	38	enhance	53.75316	95
82	42	enhance	53.446438	96
82	30	enhance	52.479614	97
82	901	enhance	52.109337	98
82	37	enhance	50.169476	99
82	76	enhance	49.03093	100
82	15	enhance	48.91587	101
82	88	enhance	48.888885	102
82	86	enhance	48.6701	103
82	51	enhance	45.00477	104
82	1	enhance	44.792885	105
82	16	enhance	44.23296	106
82	6	enhance	44.01688	107
82	71	enhance	43.955765	108
82	17	enhance	43.92781	109
82	29	enhance	42.98805	110
82	84	enhance	39.979286	111
82	358	enhance	39.866135	112
82	36	enhance	39.225674	113
82	97	enhance	38.842552	114
82	68	enhance	38.80198	115
82	67	enhance	36.7678	116
82	48	enhance	36.124878	117
82	87	enhance	33.38588	118
82	40	enhance	30.89968	119
82	25	enhance	26.338089	120
82	46	enhance	23.939787	121
82	75	enhance	23.171373	122
82	155	enhance	19.896055	123
82	882	enhance	18.074911	124
82	11	soften	100	1
82	91	soften	95.46153	2
82	184	soften	95.0611	3
82	93	soften	93.62964	4
82	3	soften	92.45715	5
82	55	soften	92.18438	6
82	90	soften	92.11324	7
82	126	soften	91.53652	8
82	868	soften	90.61675	9
82	22	soften	90.59913	10
82	79	soften	90.37212	11
82	30	soften	90.274666	12
82	44	soften	89.415375	13
82	96	soften	89.09704	14
82	4	soften	87.31556	15
82	99	soften	85.04387	16
82	59	soften	84.92671	17
82	23	soften	84.86338	18
82	219	soften	84.524124	19
82	21	soften	84.48939	20
82	34	soften	84.256775	21
82	171	soften	83.25787	22
82	2	soften	82.576836	23
82	9	soften	81.750916	24
82	12	soften	80.0527	25
82	85	soften	79.67988	26
82	64	soften	72.62101	27
82	80	soften	67.129105	28
82	60	soften	66.89152	29
82	74	soften	66.3839	30
82	72	soften	65.42985	31
82	83	soften	64.10621	32
82	70	soften	63.95114	33
82	45	soften	62.760056	34
82	49	soften	62.198902	35
82	13	soften	62.129322	36
82	335	soften	62.055603	37
82	78	soften	61.921867	38
82	94	soften	61.342182	39
82	43	soften	59.959927	40
82	5	soften	56.839996	41
82	20	soften	56.56021	42
83	72	enhance	100	1
83	70	enhance	97.880226	2
83	3	enhance	96.44141	3
83	126	enhance	96.23295	4
83	90	enhance	94.344864	5
83	55	enhance	93.400604	6
83	93	enhance	90.19695	7
83	182	enhance	88.98559	8
83	34	enhance	88.747375	9
83	94	enhance	87.52373	10
83	82	enhance	87.08168	11
83	60	enhance	86.838875	12
83	91	enhance	85.91396	13
83	50	enhance	85.373695	14
83	11	enhance	84.60917	15
83	99	enhance	84.4793	16
83	4	enhance	83.72932	17
83	49	enhance	83.504166	18
83	80	enhance	82.82814	19
83	74	enhance	82.45029	20
83	9	enhance	82.365135	21
83	23	enhance	81.5924	22
83	5	enhance	81.58122	23
83	64	enhance	80.5718	24
83	13	enhance	79.78151	25
83	79	enhance	79.605	26
83	43	enhance	79.18463	27
83	184	enhance	78.40886	28
83	19	enhance	77.87102	29
83	59	enhance	77.79469	30
83	593	enhance	77.53464	31
83	45	enhance	77.117584	32
83	78	enhance	76.9127	33
83	96	enhance	76.53682	34
83	22	enhance	76.01326	35
83	44	enhance	75.16675	36
83	868	enhance	75.037506	37
83	92	enhance	75.01452	38
83	63	enhance	74.39899	39
83	21	enhance	74.06357	40
83	335	enhance	73.63685	41
83	219	enhance	73.10049	42
83	66	enhance	72.86779	43
83	2	enhance	72.47988	44
83	18	enhance	71.82805	45
83	39	enhance	71.585075	46
83	187	enhance	71.4169	47
83	41	enhance	71.37792	48
83	285	enhance	70.79054	49
83	171	enhance	70.787796	50
83	47	enhance	70.59595	51
83	12	enhance	70.448265	52
83	85	enhance	69.287056	53
83	69	enhance	69.14094	54
83	640	enhance	68.78069	55
83	7	enhance	68.77631	56
83	61	enhance	67.88846	57
83	20	enhance	67.88102	58
83	10	enhance	67.61705	59
83	35	enhance	67.36341	60
83	176	enhance	66.65449	61
83	8	enhance	66.55381	62
83	222	enhance	66.065674	63
83	230	enhance	65.191086	64
83	33	enhance	63.43418	65
83	58	enhance	63.014267	66
83	54	enhance	62.863914	67
83	28	enhance	62.103798	68
83	30	enhance	61.878925	69
83	73	enhance	61.784973	70
83	27	enhance	61.298656	71
83	56	enhance	59.051765	72
83	98	enhance	57.942924	73
83	95	enhance	57.46859	74
83	51	enhance	56.685905	75
83	455	enhance	55.142998	76
83	86	enhance	54.456245	77
83	89	enhance	53.780136	78
83	31	enhance	53.73078	79
83	88	enhance	53.65611	80
83	52	enhance	51.755726	81
83	108	enhance	50.16612	82
83	1	enhance	48.79331	83
83	488	enhance	48.30052	84
83	65	enhance	47.543545	85
83	14	enhance	46.477566	86
83	15	enhance	46.474045	87
83	77	enhance	46.03413	88
83	100	enhance	45.35148	89
83	24	enhance	44.931976	90
83	67	enhance	44.919453	91
83	647	enhance	44.563248	92
83	62	enhance	43.218555	93
83	185	enhance	42.135456	94
83	26	enhance	41.715103	95
83	32	enhance	41.163128	96
83	84	enhance	40.65694	97
83	36	enhance	39.896275	98
83	921	enhance	39.888847	99
83	901	enhance	38.69889	100
83	785	enhance	37.501064	101
83	68	enhance	36.198547	102
83	71	enhance	36.11878	103
83	57	enhance	35.76146	104
83	37	enhance	32.9292	105
83	17	enhance	32.68488	106
83	81	enhance	32.21965	107
83	48	enhance	31.760195	108
83	38	enhance	29.999842	109
83	6	enhance	29.756708	110
83	53	enhance	29.453648	111
83	40	enhance	29.398031	112
83	76	enhance	28.884869	113
83	42	enhance	28.831656	114
83	16	enhance	26.666168	115
83	87	enhance	25.749222	116
83	97	enhance	25.407585	117
83	75	enhance	23.508919	118
83	358	enhance	23.366613	119
83	25	enhance	23.28653	120
83	29	enhance	22.02991	121
83	46	enhance	21.403244	122
83	155	enhance	17.48734	123
83	882	enhance	16.678177	124
83	64	soften	100	1
83	11	soften	94.56879	2
83	74	soften	93.5692	3
83	91	soften	91.50607	4
83	60	soften	88.93569	5
83	80	soften	87.81546	6
83	55	soften	85.52851	7
83	72	soften	82.731415	8
84	36	enhance	100	1
84	87	enhance	99.50565	2
84	155	enhance	97.97173	3
84	25	enhance	97.73154	4
84	68	enhance	97.55367	5
84	882	enhance	97.47286	6
84	40	enhance	96.86588	7
84	75	enhance	96.85138	8
84	1	enhance	96.804504	9
84	46	enhance	96.60566	10
84	48	enhance	95.70234	11
84	71	enhance	92.88004	12
84	86	enhance	92.86602	13
84	108	enhance	92.73384	14
84	176	enhance	92.54052	15
84	17	enhance	91.9285	16
84	88	enhance	91.92453	17
84	647	enhance	91.73548	18
84	785	enhance	91.53698	19
84	285	enhance	91.09541	20
84	358	enhance	90.561966	21
84	67	enhance	90.06575	22
84	76	enhance	88.58235	23
84	6	enhance	88.44802	24
84	97	enhance	88.078415	25
84	24	enhance	87.03347	26
84	31	enhance	86.146194	27
84	222	enhance	85.80523	28
84	89	enhance	84.793465	29
84	92	enhance	84.76682	30
84	10	enhance	84.486115	31
84	51	enhance	83.94925	32
84	52	enhance	83.907	33
84	37	enhance	83.79988	34
84	185	enhance	83.54433	35
84	98	enhance	82.5961	36
84	38	enhance	82.4468	37
84	15	enhance	82.412	38
84	16	enhance	81.79151	39
84	39	enhance	80.99452	40
84	47	enhance	80.84418	41
84	455	enhance	80.62967	42
84	42	enhance	79.68305	43
84	62	enhance	79.6727	44
84	29	enhance	79.54002	45
84	56	enhance	79.355515	46
84	27	enhance	78.78907	47
84	94	enhance	74.62443	48
84	7	enhance	73.46157	49
84	26	enhance	73.20126	50
84	54	enhance	72.933426	51
84	61	enhance	70.90491	52
84	100	enhance	70.45141	53
84	49	enhance	70.01306	54
84	640	enhance	69.909355	55
84	77	enhance	68.37677	56
84	187	enhance	67.91463	57
84	19	enhance	67.63895	58
84	13	enhance	67.0865	59
84	63	enhance	66.63614	60
84	81	enhance	65.80134	61
84	230	enhance	65.23241	62
84	901	enhance	65.0585	63
84	50	enhance	64.84181	64
84	921	enhance	63.258327	65
84	30	enhance	61.314255	66
84	28	enhance	61.093952	67
84	18	enhance	60.398792	68
84	182	enhance	60.26395	69
84	66	enhance	59.866394	70
84	73	enhance	59.456722	71
84	53	enhance	58.906776	72
84	593	enhance	56.538708	73
84	45	enhance	56.464836	74
84	43	enhance	56.177696	75
84	78	enhance	56.13698	76
84	58	enhance	54.825386	77
84	34	enhance	53.920235	78
84	70	enhance	53.711407	79
84	44	enhance	51.036457	80
84	33	enhance	50.878654	81
84	99	enhance	49.93221	82
84	868	enhance	49.269234	83
84	14	enhance	48.508923	84
84	65	enhance	47.574028	85
84	79	enhance	46.904263	86
84	184	enhance	45.98278	87
84	32	enhance	45.91531	88
84	59	enhance	44.922626	89
84	72	enhance	44.6501	90
84	93	enhance	42.46848	91
84	2	enhance	42.364574	92
84	126	enhance	42.27416	93
84	83	enhance	41.378063	94
84	80	enhance	39.879433	95
84	82	enhance	38.858112	96
84	219	enhance	38.731853	97
84	22	enhance	38.703358	98
84	335	enhance	38.178974	99
84	8	enhance	37.179195	100
84	3	enhance	36.86704	101
84	57	enhance	36.789257	102
84	90	enhance	36.035378	103
84	171	enhance	34.482445	104
84	21	enhance	34.472942	105
84	5	enhance	34.45692	106
84	96	enhance	34.360023	107
84	55	enhance	32.965824	108
84	488	enhance	32.715816	109
84	20	enhance	32.617496	110
84	41	enhance	32.283737	111
84	12	enhance	32.068638	112
84	85	enhance	31.713068	113
84	69	enhance	31.598928	114
84	95	enhance	31.554594	115
84	35	enhance	29.9964	116
84	64	enhance	29.625357	117
84	9	enhance	29.530468	118
84	23	enhance	29.343464	119
84	74	enhance	28.92225	120
84	4	enhance	28.791372	121
84	91	enhance	28.531857	122
84	11	enhance	27.377115	123
84	60	enhance	26.742735	124
84	11	soften	100	1
84	64	soften	99.87977	2
84	60	soften	96.56651	3
84	74	soften	96.37492	4
84	80	soften	95.82863	5
84	91	soften	93.90508	6
84	55	soften	93.169	7
84	90	soften	92.127235	8
84	126	soften	91.93166	9
84	3	soften	91.75265	10
84	83	soften	91.69891	11
84	72	soften	89.15183	12
84	4	soften	87.97566	13
84	23	soften	87.51929	14
84	93	soften	87.25796	15
84	79	soften	87.0354	16
84	171	soften	86.54141	17
84	96	soften	86.51253	18
84	70	soften	85.24436	19
84	45	soften	85.08393	20
84	20	soften	84.90773	21
84	184	soften	84.47445	22
84	21	soften	84.30947	23
84	9	soften	84.04858	24
84	34	soften	83.36314	25
84	5	soften	83.172646	26
84	335	soften	83.07281	27
84	219	soften	83.04063	28
84	2	soften	83.01698	29
84	82	soften	82.97287	30
84	35	soften	82.64473	31
84	95	soften	82.26027	32
84	43	soften	81.78515	33
84	85	soften	81.67398	34
84	12	soften	81.49415	35
84	22	soften	81.238686	36
84	99	soften	81.185165	37
84	868	soften	81.07935	38
84	30	soften	80.623825	39
84	33	soften	80.05573	40
84	59	soften	79.766495	41
84	73	soften	79.75169	42
84	182	soften	79.02974	43
84	78	soften	78.956154	44
84	49	soften	78.496216	45
84	13	soften	78.3695	46
84	41	soften	78.3362	47
84	18	soften	77.53273	48
84	69	soften	77.47138	49
84	8	soften	76.846016	50
84	63	soften	76.51742	51
84	593	soften	76.18845	52
84	28	soften	76.16965	53
84	44	soften	76.00478	54
84	50	soften	74.95747	55
84	61	soften	74.369835	56
84	94	soften	74.34037	57
84	230	soften	74.19776	58
84	187	soften	73.44008	59
84	640	soften	73.42235	60
84	66	soften	72.668274	61
84	39	soften	71.468666	62
84	56	soften	70.40867	63
84	7	soften	69.93657	64
84	222	soften	69.58737	65
84	92	soften	69.07897	66
84	54	soften	68.792145	67
84	47	soften	68.67118	68
84	31	soften	68.12276	69
84	89	soften	67.92431	70
84	285	soften	67.24337	71
84	98	soften	66.81186	72
84	176	soften	66.235275	73
84	27	soften	65.731514	74
84	455	soften	65.29859	75
84	51	soften	65.01322	76
84	10	soften	64.19813	77
84	86	soften	61.219646	78
85	12	enhance	100	1
85	21	enhance	99.74329	2
85	35	enhance	99.03721	3
85	69	enhance	97.19191	4
85	59	enhance	97.09853	5
85	5	enhance	97.03466	6
85	23	enhance	94.62954	7
85	219	enhance	94.16182	8
85	335	enhance	93.11211	9
85	9	enhance	92.96401	10
85	4	enhance	91.436455	11
85	41	enhance	91.185646	12
85	593	enhance	91.13933	13
85	20	enhance	90.86173	14
85	8	enhance	90.56487	15
85	66	enhance	90.06994	16
85	96	enhance	89.71459	17
85	74	enhance	88.74002	18
85	78	enhance	88.36963	19
85	18	enhance	87.686035	20
85	91	enhance	87.45482	21
85	488	enhance	86.724045	22
85	82	enhance	85.424934	23
85	171	enhance	85.35069	24
85	184	enhance	84.529976	25
85	22	enhance	84.152756	26
85	79	enhance	83.67242	27
85	65	enhance	83.05526	28
85	32	enhance	82.055405	29
85	55	enhance	80.633575	30
85	54	enhance	80.04534	31
85	95	enhance	79.78864	32
85	60	enhance	79.64963	33
85	93	enhance	79.52694	34
85	3	enhance	79.40987	35
85	44	enhance	79.11603	36
85	14	enhance	79.107796	37
85	64	enhance	78.738304	38
85	28	enhance	78.434746	39
85	868	enhance	78.201126	40
85	11	enhance	76.90633	41
85	77	enhance	76.42391	42
85	455	enhance	76.05057	43
85	27	enhance	75.55467	44
85	50	enhance	75.02745	45
85	58	enhance	75.0089	46
85	100	enhance	74.994606	47
85	53	enhance	72.44208	48
85	94	enhance	69.79528	49
85	52	enhance	69.38691	50
85	70	enhance	68.240326	51
85	83	enhance	67.83454	52
85	10	enhance	67.818985	53
85	34	enhance	67.61953	54
85	72	enhance	66.630516	55
85	90	enhance	65.95961	56
85	24	enhance	65.75482	57
85	921	enhance	65.21306	58
85	62	enhance	63.92928	59
85	7	enhance	61.415806	60
85	182	enhance	60.86515	61
85	2	enhance	60.027054	62
85	126	enhance	59.669846	63
85	39	enhance	59.584908	64
85	99	enhance	58.78853	65
85	185	enhance	58.36317	66
85	81	enhance	57.258247	67
85	80	enhance	56.076393	68
85	57	enhance	55.981632	69
85	63	enhance	55.82969	70
85	42	enhance	55.53464	71
85	38	enhance	55.100567	72
85	19	enhance	53.599506	73
85	43	enhance	52.2498	74
85	49	enhance	51.790405	75
85	176	enhance	51.28591	76
85	76	enhance	49.848614	77
85	92	enhance	49.391922	78
85	785	enhance	48.767876	79
85	29	enhance	48.57776	80
85	86	enhance	48.516594	81
85	6	enhance	48.084713	82
85	16	enhance	46.54188	83
85	73	enhance	46.263367	84
85	187	enhance	45.884403	85
85	97	enhance	45.658558	86
85	45	enhance	45.5944	87
85	647	enhance	45.168495	88
85	26	enhance	43.880657	89
85	108	enhance	42.97839	90
85	358	enhance	41.861816	91
85	901	enhance	41.483543	92
85	285	enhance	39.99585	93
85	37	enhance	39.995014	94
85	89	enhance	38.214424	95
85	17	enhance	37.298634	96
85	13	enhance	36.782707	97
85	15	enhance	33.94205	98
85	56	enhance	33.463593	99
85	230	enhance	33.226555	100
85	71	enhance	32.828297	101
85	98	enhance	31.090448	102
85	30	enhance	30.788858	103
85	84	enhance	30.507147	104
85	222	enhance	30.008377	105
85	31	enhance	29.553385	106
85	48	enhance	29.471088	107
85	61	enhance	29.166187	108
85	640	enhance	28.371529	109
85	87	enhance	27.881153	110
85	68	enhance	27.776646	111
85	1	enhance	27.263168	112
85	36	enhance	26.218445	113
85	47	enhance	25.41369	114
85	88	enhance	25.06817	115
85	33	enhance	22.607626	116
85	40	enhance	22.487478	117
85	46	enhance	18.714186	118
85	51	enhance	18.258108	119
85	25	enhance	17.983925	120
85	155	enhance	16.405048	121
85	75	enhance	15.609472	122
85	882	enhance	14.131646	123
85	67	enhance	10.255915	124
85	126	soften	100	1
85	90	soften	99.162544	2
85	30	soften	97.644646	3
85	11	soften	96.98847	4
85	3	soften	93.96489	5
85	55	soften	92.751396	6
85	93	soften	91.2929	7
85	79	soften	87.91269	8
85	91	soften	86.838196	9
85	184	soften	85.96547	10
85	868	soften	83.50884	11
85	44	soften	82.630516	12
85	4	soften	82.278534	13
85	22	soften	80.80178	14
85	23	soften	79.533676	15
85	171	soften	78.21186	16
85	96	soften	77.21346	17
85	59	soften	77.17491	18
85	219	soften	75.92503	19
85	9	soften	75.347015	20
85	21	soften	73.56957	21
85	12	soften	70.79656	22
85	80	soften	70.036385	23
85	72	soften	69.92861	24
85	83	soften	68.83492	25
85	13	soften	68.73639	26
85	64	soften	67.0037	27
85	49	soften	66.83589	28
85	70	soften	66.39631	29
85	60	soften	66.23391	30
85	45	soften	66.111244	31
85	74	soften	57.702557	32
85	78	soften	57.49764	33
85	335	soften	54.19781	34
85	5	soften	53.86755	35
85	20	soften	50.887886	36
86	52	enhance	100	1
86	108	enhance	99.63454	2
86	84	enhance	99.26016	3
86	36	enhance	98.69279	4
86	48	enhance	98.52232	5
86	285	enhance	98.18525	6
86	39	enhance	97.69043	7
86	10	enhance	97.22008	8
86	40	enhance	96.91294	9
86	176	enhance	96.80881	10
86	68	enhance	96.42705	11
86	25	enhance	96.15347	12
86	1	enhance	95.99849	13
86	87	enhance	95.95021	14
86	92	enhance	95.40217	15
86	647	enhance	94.736725	16
86	94	enhance	94.09311	17
86	27	enhance	93.53925	18
86	75	enhance	93.30088	19
86	455	enhance	92.838036	20
86	71	enhance	91.607704	21
86	155	enhance	91.557686	22
86	7	enhance	90.36485	23
86	882	enhance	90.2083	24
86	24	enhance	90.0353	25
86	97	enhance	89.94732	26
86	6	enhance	89.52165	27
86	88	enhance	88.70514	28
86	17	enhance	88.58945	29
86	785	enhance	88.57962	30
86	46	enhance	87.19177	31
86	15	enhance	86.84397	32
86	358	enhance	86.67945	33
86	222	enhance	86.47082	34
86	76	enhance	85.52523	35
86	38	enhance	85.00764	36
86	89	enhance	84.755035	37
86	16	enhance	83.73961	38
86	185	enhance	83.33754	39
86	31	enhance	83.01652	40
86	62	enhance	82.40922	41
86	42	enhance	81.866776	42
86	54	enhance	81.3525	43
86	44	enhance	80.980644	44
86	67	enhance	80.66409	45
86	98	enhance	80.262886	46
86	100	enhance	79.707184	47
86	66	enhance	79.62148	48
86	49	enhance	78.67202	49
86	78	enhance	78.30419	50
86	593	enhance	78.27445	51
86	77	enhance	77.67194	52
86	51	enhance	77.36282	53
86	29	enhance	77.038055	54
86	37	enhance	76.142654	55
86	868	enhance	74.79085	56
86	19	enhance	74.72884	57
86	63	enhance	74.513176	58
86	184	enhance	73.21426	59
86	18	enhance	73.15157	60
86	50	enhance	72.9575	61
86	56	enhance	72.758194	62
86	70	enhance	72.655945	63
86	47	enhance	71.77739	64
86	187	enhance	71.71732	65
86	13	enhance	71.08323	66
86	93	enhance	70.421745	67
86	28	enhance	70.40621	68
86	59	enhance	69.1639	69
86	22	enhance	69.06562	70
86	640	enhance	68.64747	71
86	58	enhance	68.3801	72
86	26	enhance	67.38897	73
86	182	enhance	67.158745	74
86	901	enhance	66.542564	75
86	72	enhance	66.0604	76
86	61	enhance	65.95915	77
86	335	enhance	64.66796	78
86	79	enhance	63.75001	79
86	3	enhance	62.33871	80
86	99	enhance	62.278572	81
86	43	enhance	62.032124	82
86	81	enhance	61.74383	83
86	921	enhance	61.385246	84
86	34	enhance	60.790607	85
86	91	enhance	60.662773	86
86	230	enhance	60.641605	87
86	219	enhance	60.328224	88
86	53	enhance	59.519543	89
86	83	enhance	59.23812	90
86	96	enhance	59.236336	91
86	73	enhance	59.170925	92
86	45	enhance	59.06126	93
86	30	enhance	58.81543	94
86	21	enhance	58.74727	95
86	64	enhance	58.335556	96
86	41	enhance	57.937885	97
86	4	enhance	57.72639	98
86	55	enhance	57.608414	99
86	74	enhance	56.372425	100
86	9	enhance	56.197083	101
86	5	enhance	56.011852	102
86	90	enhance	55.404644	103
86	69	enhance	55.20961	104
86	12	enhance	55.016125	105
86	65	enhance	54.81027	106
86	23	enhance	54.80151	107
86	11	enhance	54.715668	108
86	126	enhance	54.65547	109
86	60	enhance	54.37714	110
86	85	enhance	53.906994	111
86	80	enhance	51.638313	112
86	14	enhance	51.486477	113
86	8	enhance	51.00095	114
86	82	enhance	50.562332	115
86	32	enhance	49.82826	116
86	35	enhance	49.263252	117
86	33	enhance	46.60111	118
86	171	enhance	46.454353	119
86	20	enhance	46.261623	120
86	2	enhance	45.040367	121
86	488	enhance	37.003353	122
86	95	enhance	36.869354	123
86	57	enhance	36.09036	124
86	11	soften	100	1
86	64	soften	98.12414	2
86	60	soften	97.38498	3
86	80	soften	96.75283	4
86	55	soften	94.6121	5
86	126	soften	94.31458	6
86	83	soften	94.1286	7
86	90	soften	93.94293	8
86	74	soften	93.83597	9
86	3	soften	92.77312	10
86	91	soften	91.96917	11
86	72	soften	91.181046	12
86	4	soften	87.96049	13
86	23	soften	87.20396	14
86	171	soften	87.19227	15
86	93	soften	86.610214	16
86	79	soften	86.33456	17
86	45	soften	86.22121	18
86	70	soften	86.11083	19
86	34	soften	85.767586	20
86	96	soften	84.85124	21
86	20	soften	84.69088	22
86	82	soften	84.564545	23
86	2	soften	84.458725	24
86	9	soften	83.70128	25
86	43	soften	83.64583	26
86	33	soften	83.55314	27
86	5	soften	83.03821	28
86	30	soften	83.02808	29
86	184	soften	82.95018	30
86	99	soften	82.819595	31
86	21	soften	82.61907	32
86	219	soften	82.55871	33
86	95	soften	82.41671	34
86	35	soften	82.26011	35
86	335	soften	81.62132	36
86	182	soften	81.55036	37
86	73	soften	81.26929	38
86	13	soften	80.696655	39
86	12	soften	80.595604	40
86	85	soften	80.29973	41
86	868	soften	79.85232	42
86	22	soften	79.75106	43
86	49	soften	79.65717	44
86	59	soften	78.90253	45
86	78	soften	78.411644	46
86	8	soften	77.88851	47
86	41	soften	77.68878	48
86	18	soften	77.29465	49
86	63	soften	77.14393	50
86	61	soften	76.96139	51
86	50	soften	76.73262	52
86	230	soften	76.67383	53
86	28	soften	76.487625	54
86	69	soften	76.34697	55
86	640	soften	76.13392	56
86	593	soften	75.81376	57
86	187	soften	75.68577	58
86	44	soften	74.68533	59
86	94	soften	74.00617	60
86	66	soften	72.5457	61
86	222	soften	71.81897	62
86	39	soften	71.08261	63
86	92	soften	70.11611	64
86	51	soften	68.30525	65
86	285	soften	67.8245	66
86	176	soften	66.8448	67
86	27	soften	65.32686	68
87	155	enhance	100	1
87	25	enhance	99.31719	2
87	882	enhance	98.562706	3
87	48	enhance	97.7744	4
87	75	enhance	96.88426	5
87	84	enhance	96.50097	6
87	68	enhance	96.39885	7
87	71	enhance	96.09575	8
87	46	enhance	96.03319	9
87	36	enhance	95.24672	10
87	40	enhance	95.1732	11
87	785	enhance	94.78335	12
87	358	enhance	94.53354	13
87	17	enhance	94.46797	14
87	76	enhance	92.266014	15
87	1	enhance	91.3334	16
87	108	enhance	90.05381	17
87	97	enhance	89.18421	18
87	6	enhance	89.0883	19
87	38	enhance	88.73141	20
87	16	enhance	88.66903	21
87	647	enhance	87.16591	22
87	86	enhance	87.0586	23
87	176	enhance	86.77352	24
87	42	enhance	86.36946	25
87	37	enhance	85.63876	26
87	24	enhance	85.62549	27
87	185	enhance	84.6936	28
87	15	enhance	84.40361	29
87	52	enhance	84.17376	30
87	29	enhance	83.75832	31
87	88	enhance	83.47112	32
87	67	enhance	83.05533	33
87	285	enhance	81.529724	34
87	10	enhance	80.456345	35
87	92	enhance	79.70032	36
87	62	enhance	79.69029	37
87	455	enhance	79.362885	38
87	31	enhance	77.40137	39
87	89	enhance	77.041664	40
87	222	enhance	76.41927	41
87	51	enhance	76.16233	42
87	100	enhance	74.361786	43
87	98	enhance	74.35416	44
87	27	enhance	72.70265	45
87	77	enhance	72.22143	46
87	7	enhance	71.87287	47
87	901	enhance	71.25546	48
87	81	enhance	71.10589	49
87	39	enhance	70.472305	50
87	26	enhance	70.18509	51
87	54	enhance	68.422905	52
87	56	enhance	65.04262	53
87	921	enhance	64.72723	54
87	94	enhance	63.88996	55
87	47	enhance	63.541565	56
87	53	enhance	62.974545	57
87	187	enhance	62.73563	58
87	19	enhance	61.4764	59
87	66	enhance	56.719902	60
87	640	enhance	56.288254	61
87	28	enhance	55.34301	62
87	50	enhance	55.233486	63
87	63	enhance	55.10193	64
87	61	enhance	53.806725	65
87	49	enhance	53.052147	66
87	593	enhance	52.397476	67
87	13	enhance	51.624825	68
87	14	enhance	51.337334	69
87	65	enhance	50.84672	70
87	58	enhance	50.763565	71
87	32	enhance	50.342262	72
87	230	enhance	49.817924	73
87	182	enhance	49.216858	74
87	18	enhance	48.682415	75
87	78	enhance	47.558113	76
87	868	enhance	46.250698	77
87	44	enhance	45.776043	78
87	59	enhance	40.7624	79
87	43	enhance	39.822296	80
87	30	enhance	39.716908	81
87	57	enhance	39.332466	82
87	34	enhance	39.184242	83
87	73	enhance	39.120106	84
87	99	enhance	37.90323	85
87	70	enhance	37.77984	86
87	33	enhance	37.410656	87
87	8	enhance	37.14187	88
87	184	enhance	36.493336	89
87	45	enhance	34.531616	90
87	335	enhance	33.85351	91
87	219	enhance	33.585464	92
87	22	enhance	32.65911	93
87	488	enhance	32.365044	94
87	82	enhance	31.46976	95
87	72	enhance	30.928055	96
87	12	enhance	30.489029	97
87	93	enhance	30.167227	98
87	79	enhance	29.993584	99
87	41	enhance	29.921095	100
87	171	enhance	28.738113	101
87	5	enhance	28.58471	102
87	2	enhance	28.337282	103
87	69	enhance	28.272764	104
87	21	enhance	28.253109	105
87	85	enhance	28.10809	106
87	35	enhance	28.01426	107
87	20	enhance	26.274967	108
87	96	enhance	25.908838	109
87	95	enhance	25.589499	110
87	83	enhance	25.41461	111
87	4	enhance	24.23004	112
87	55	enhance	23.805784	113
87	9	enhance	23.465714	114
87	3	enhance	23.057976	115
87	23	enhance	22.63129	116
87	126	enhance	22.609003	117
87	90	enhance	20.398615	118
87	60	enhance	19.982538	119
87	91	enhance	19.468664	120
87	64	enhance	18.76295	121
87	11	enhance	17.556583	122
87	80	enhance	15.893473	123
87	74	enhance	15.433474	124
87	11	soften	100	1
87	64	soften	99.93009	2
87	80	soften	98.998795	3
87	74	soften	96.78786	4
87	60	soften	96.5494	5
87	90	soften	94.865944	6
87	126	soften	94.41489	7
87	91	soften	94.19039	8
87	55	soften	93.16961	9
87	3	soften	92.78665	10
87	83	soften	92.68009	11
87	72	soften	90.240524	12
87	79	soften	89.03855	13
87	93	soften	88.56793	14
87	23	soften	88.479065	15
87	4	soften	87.6374	16
87	45	soften	86.844215	17
87	70	soften	86.716415	18
87	96	soften	86.2023	19
87	171	soften	85.86945	20
87	2	soften	85.51542	21
87	34	soften	84.47415	22
87	20	soften	84.449165	23
87	21	soften	84.431335	24
87	9	soften	84.15645	25
87	184	soften	84.11538	26
87	82	soften	83.95423	27
87	5	soften	83.89187	28
87	43	soften	83.51347	29
87	99	soften	83.33906	30
87	33	soften	83.205025	31
87	219	soften	82.36063	32
87	335	soften	82.33508	33
87	30	soften	82.24077	34
87	35	soften	82.22696	35
87	85	soften	81.60645	36
87	95	soften	81.55802	37
87	73	soften	81.22954	38
87	12	soften	81.141685	39
87	22	soften	80.82507	40
87	182	soften	80.54994	41
87	13	soften	80.40009	42
87	49	soften	80.223465	43
87	868	soften	79.88195	44
87	59	soften	79.457634	45
87	78	soften	78.540245	46
87	18	soften	77.8417	47
87	63	soften	77.808044	48
87	41	soften	77.79423	49
87	69	soften	77.517395	50
87	230	soften	76.869125	51
87	61	soften	76.70312	52
87	28	soften	76.553314	53
87	8	soften	76.54204	54
87	593	soften	76.473015	55
87	50	soften	76.04805	56
87	44	soften	75.637276	57
87	640	soften	75.589935	58
87	94	soften	74.78488	59
87	187	soften	73.30084	60
87	66	soften	72.454796	61
87	488	soften	72.366264	62
87	39	soften	71.91235	63
87	56	soften	70.85819	64
87	222	soften	69.91456	65
87	47	soften	69.7028	66
87	7	soften	69.63234	67
87	31	soften	69.07489	68
87	58	soften	68.64198	69
87	92	soften	68.634766	70
87	54	soften	68.622314	71
87	98	soften	67.9788	72
87	19	soften	67.71462	73
87	89	soften	67.68024	74
87	14	soften	67.53099	75
87	285	soften	66.93487	76
87	27	soften	65.44188	77
87	176	soften	65.36651	78
87	51	soften	64.56755	79
87	26	soften	64.51096	80
87	455	soften	64.37382	81
87	10	soften	63.754673	82
87	108	soften	62.482246	83
87	88	soften	62.12672	84
87	24	soften	61.505394	85
87	647	soften	61.490818	86
87	52	soften	61.013557	87
87	1	soften	60.846985	88
87	62	soften	60.725758	89
87	185	soften	60.35957	90
87	86	soften	60.220554	91
87	67	soften	59.82276	92
87	84	soften	58.897762	93
87	785	soften	57.759525	94
87	36	soften	56.328526	95
88	98	enhance	100	1
88	285	enhance	97.7055	2
88	36	enhance	96.186424	3
88	40	enhance	95.56147	4
88	68	enhance	94.646225	5
88	31	enhance	94.41892	6
88	108	enhance	92.41366	7
88	75	enhance	92.235085	8
88	1	enhance	91.85365	9
88	71	enhance	91.77337	10
88	84	enhance	91.29134	11
88	48	enhance	91.23706	12
88	25	enhance	89.826614	13
88	222	enhance	89.57256	14
88	47	enhance	89.44719	15
88	67	enhance	89.424805	16
88	176	enhance	87.92296	17
88	61	enhance	87.817085	18
88	92	enhance	87.62248	19
88	17	enhance	87.25665	20
88	640	enhance	86.9	21
88	647	enhance	86.257	22
88	49	enhance	86.15926	23
88	87	enhance	85.47726	24
88	46	enhance	85.01115	25
88	51	enhance	84.24781	26
88	13	enhance	84.21935	27
88	230	enhance	82.7481	28
88	86	enhance	82.41928	29
88	89	enhance	81.72746	30
88	882	enhance	81.57702	31
88	155	enhance	81.45846	32
88	785	enhance	81.26569	33
88	94	enhance	81.065346	34
88	39	enhance	80.45638	35
88	56	enhance	79.97766	36
88	10	enhance	79.818115	37
88	182	enhance	79.557236	38
88	15	enhance	79.421585	39
88	97	enhance	79.39799	40
88	6	enhance	78.78662	41
88	358	enhance	78.25084	42
88	33	enhance	74.964325	43
88	187	enhance	74.89242	44
88	52	enhance	74.82228	45
88	63	enhance	74.59919	46
88	76	enhance	74.54147	47
88	50	enhance	74.13745	48
88	185	enhance	73.496376	49
88	16	enhance	72.72928	50
88	27	enhance	72.26405	51
88	37	enhance	72.182556	52
88	7	enhance	72.14353	53
88	24	enhance	71.72794	54
88	19	enhance	71.63774	55
88	29	enhance	70.88246	56
88	54	enhance	70.85788	57
88	38	enhance	69.75558	58
88	455	enhance	69.74024	59
88	42	enhance	68.242485	60
88	43	enhance	67.58913	61
88	62	enhance	67.40191	62
88	30	enhance	66.750244	63
88	99	enhance	65.47371	64
88	70	enhance	64.844345	65
88	45	enhance	64.72041	66
88	34	enhance	63.95941	67
88	26	enhance	63.20489	68
88	73	enhance	62.694515	69
88	28	enhance	62.421062	70
88	100	enhance	60.098087	71
88	901	enhance	59.764812	72
88	66	enhance	59.29884	73
88	126	enhance	59.292587	74
88	77	enhance	57.91548	75
88	72	enhance	57.735218	76
88	81	enhance	56.825687	77
88	593	enhance	55.262432	78
88	18	enhance	54.401157	79
88	921	enhance	54.25022	80
88	83	enhance	54.23165	81
88	2	enhance	53.883583	82
88	90	enhance	51.96527	83
88	53	enhance	51.885464	84
88	79	enhance	50.454037	85
88	80	enhance	48.159004	86
88	82	enhance	47.190548	87
88	78	enhance	46.475994	88
88	93	enhance	45.727863	89
88	44	enhance	44.521713	90
88	868	enhance	43.510445	91
88	58	enhance	42.31957	92
88	3	enhance	41.888283	93
88	32	enhance	40.136925	94
88	59	enhance	39.9287	95
88	14	enhance	38.476078	96
88	184	enhance	36.89325	97
88	55	enhance	36.539143	98
88	65	enhance	36.476303	99
88	5	enhance	35.067616	100
88	8	enhance	32.58681	101
88	60	enhance	31.29721	102
88	57	enhance	30.988096	103
88	22	enhance	30.380062	104
88	23	enhance	29.230078	105
88	21	enhance	28.960297	106
88	335	enhance	28.768675	107
88	171	enhance	28.713017	108
88	219	enhance	27.791191	109
88	12	enhance	27.77787	110
88	11	enhance	27.51428	111
88	91	enhance	27.248272	112
88	4	enhance	26.9566	113
88	9	enhance	26.50165	114
88	64	enhance	25.999546	115
88	85	enhance	25.879597	116
88	69	enhance	25.44441	117
88	488	enhance	24.576107	118
88	96	enhance	24.319712	119
88	35	enhance	23.621685	120
88	41	enhance	23.165077	121
88	74	enhance	22.372526	122
88	20	enhance	22.28608	123
88	95	enhance	19.643171	124
88	64	soften	100	1
88	74	soften	98.815735	2
88	11	soften	97.64574	3
88	91	soften	94.93676	4
88	60	soften	93.82307	5
88	96	soften	90.99583	6
88	55	soften	90.25623	7
88	80	soften	88.92124	8
88	4	soften	88.08652	9
88	3	soften	87.70431	10
88	335	soften	87.68658	11
88	184	soften	87.56716	12
88	21	soften	87.52576	13
88	23	soften	87.10851	14
88	171	soften	86.93989	15
88	20	soften	86.81869	16
88	219	soften	85.774895	17
88	93	soften	85.61366	18
88	83	soften	85.43759	19
88	22	soften	85.24895	20
88	95	soften	85.01249	21
88	9	soften	84.926315	22
88	85	soften	84.894005	23
88	35	soften	84.74829	24
88	79	soften	84.53732	25
88	90	soften	84.52465	26
88	12	soften	84.47254	27
88	126	soften	83.84677	28
88	868	soften	83.71076	29
88	72	soften	83.57723	30
88	59	soften	82.63077	31
88	5	soften	82.457146	32
88	41	soften	81.712585	33
88	78	soften	81.15088	34
88	70	soften	81.03555	35
88	69	soften	80.55172	36
88	82	soften	80.34216	37
88	45	soften	79.480255	38
88	44	soften	78.78932	39
88	2	soften	78.76029	40
88	18	soften	78.39575	41
88	34	soften	78.343025	42
88	8	soften	76.64595	43
88	593	soften	76.35916	44
88	43	soften	75.75732	45
88	99	soften	75.28838	46
88	488	soften	75.21756	47
88	73	soften	75.13174	48
88	28	soften	74.91953	49
88	30	soften	74.678795	50
88	66	soften	74.106415	51
88	182	soften	73.238815	52
88	63	soften	73.18976	53
88	49	soften	72.8452	54
88	94	soften	72.83451	55
88	13	soften	72.04231	56
88	50	soften	71.65158	57
88	58	soften	71.63606	58
88	39	soften	71.30026	59
88	33	soften	70.75961	60
88	187	soften	69.309654	61
88	54	soften	69.16965	62
88	7	soften	68.88612	63
88	455	soften	68.14394	64
88	27	soften	68.09462	65
88	61	soften	68.00813	66
88	92	soften	67.9219	67
88	230	soften	67.78463	68
88	222	soften	67.50137	69
88	640	soften	67.47186	70
88	176	soften	67.40461	71
88	56	soften	67.16262	72
88	24	soften	66.732	73
88	89	soften	66.39407	74
88	10	soften	65.73161	75
88	19	soften	65.726105	76
88	285	soften	65.67522	77
88	52	soften	64.98086	78
88	31	soften	64.74185	79
88	47	soften	64.54225	80
88	86	soften	64.32677	81
88	51	soften	63.921062	82
88	98	soften	62.27663	83
88	108	soften	62.255432	84
88	1	soften	61.971123	85
88	84	soften	61.9367	86
88	67	soften	59.20759	87
89	56	enhance	100	1
89	1	enhance	97.353455	2
89	108	enhance	97.22658	3
89	647	enhance	96.13362	4
89	187	enhance	93.96298	5
89	26	enhance	93.47542	6
89	36	enhance	92.42024	7
89	185	enhance	92.3394	8
89	7	enhance	91.09712	9
89	62	enhance	89.773636	10
89	31	enhance	89.7367	11
89	63	enhance	88.68155	12
89	30	enhance	87.04445	13
89	39	enhance	86.52534	14
89	455	enhance	86.43024	15
89	84	enhance	86.362946	16
89	43	enhance	86.26988	17
89	71	enhance	85.83934	18
89	901	enhance	85.79806	19
89	785	enhance	85.4665	20
89	48	enhance	85.23781	21
89	285	enhance	85.17517	22
89	40	enhance	85.10456	23
89	6	enhance	84.59831	24
89	68	enhance	84.4834	25
89	16	enhance	83.92824	26
89	88	enhance	83.81753	27
89	24	enhance	83.7243	28
89	37	enhance	83.25309	29
89	15	enhance	83.16833	30
89	17	enhance	83.04717	31
89	38	enhance	82.46199	32
89	34	enhance	82.412224	33
89	921	enhance	81.91622	34
89	52	enhance	81.826645	35
89	42	enhance	81.80217	36
89	25	enhance	81.76093	37
89	73	enhance	81.517395	38
89	92	enhance	81.50561	39
89	19	enhance	81.33776	40
89	45	enhance	81.30695	41
89	87	enhance	80.91085	42
89	86	enhance	80.76299	43
89	49	enhance	80.37371	44
89	98	enhance	79.953285	45
89	76	enhance	79.53467	46
89	358	enhance	79.00474	47
89	176	enhance	78.593506	48
89	97	enhance	78.4145	49
89	54	enhance	77.82764	50
89	81	enhance	77.22938	51
89	58	enhance	76.87523	52
89	10	enhance	76.721375	53
89	47	enhance	76.129524	54
89	50	enhance	75.50012	55
89	94	enhance	75.34001	56
89	18	enhance	75.264015	57
89	61	enhance	75.18471	58
89	75	enhance	75.127365	59
89	29	enhance	75.07692	60
89	882	enhance	74.62735	61
89	155	enhance	74.03269	62
89	46	enhance	73.510864	63
89	230	enhance	72.77928	64
89	100	enhance	72.73149	65
89	27	enhance	72.083084	66
89	77	enhance	71.657364	67
89	13	enhance	70.08512	68
89	222	enhance	69.864395	69
89	99	enhance	69.803764	70
89	28	enhance	69.3532	71
89	593	enhance	69.28396	72
89	640	enhance	69.014084	73
89	78	enhance	68.51896	74
89	14	enhance	66.58701	75
89	182	enhance	66.56813	76
89	2	enhance	65.65119	77
89	67	enhance	64.85586	78
89	65	enhance	63.20233	79
89	70	enhance	63.04099	80
89	33	enhance	62.73236	81
89	80	enhance	62.66212	82
89	126	enhance	62.00204	83
89	8	enhance	60.838886	84
89	57	enhance	60.05462	85
89	95	enhance	59.307434	86
89	53	enhance	58.978134	87
89	79	enhance	58.502426	88
89	20	enhance	58.052097	89
89	32	enhance	57.78762	90
89	82	enhance	57.742546	91
89	51	enhance	57.620834	92
89	66	enhance	57.24336	93
89	171	enhance	57.048046	94
89	219	enhance	56.728813	95
89	868	enhance	56.70092	96
89	3	enhance	55.793137	97
89	83	enhance	55.747116	98
89	44	enhance	54.94234	99
89	184	enhance	53.837067	100
89	93	enhance	52.021404	101
89	90	enhance	51.94923	102
89	488	enhance	51.20896	103
89	72	enhance	50.21645	104
89	55	enhance	49.3749	105
89	5	enhance	48.219475	106
89	59	enhance	48.0296	107
89	96	enhance	47.718857	108
89	35	enhance	45.387413	109
89	335	enhance	45.26666	110
89	41	enhance	45.124928	111
89	23	enhance	44.51601	112
89	74	enhance	44.122536	113
89	9	enhance	43.16159	114
89	22	enhance	42.665424	115
89	69	enhance	42.318718	116
89	21	enhance	42.30209	117
89	64	enhance	41.256878	118
89	4	enhance	40.923244	119
89	11	enhance	40.765743	120
89	85	enhance	40.460297	121
89	12	enhance	39.629677	122
89	91	enhance	35.32319	123
89	60	enhance	34.056686	124
89	64	soften	100	1
89	11	soften	98.27845	2
89	74	soften	96.68196	3
89	60	soften	96.14428	4
89	91	soften	95.846344	5
89	80	soften	92.735825	6
89	55	soften	91.24097	7
89	72	soften	90.304436	8
89	83	soften	90.140236	9
89	90	soften	89.55747	10
89	3	soften	89.239365	11
89	93	soften	88.96031	12
89	126	soften	88.925354	13
89	96	soften	88.771614	14
89	184	soften	87.730576	15
89	70	soften	86.74749	16
89	4	soften	86.633484	17
89	79	soften	86.38648	18
89	335	soften	86.048134	19
89	23	soften	85.96378	20
89	21	soften	85.5018	21
89	22	soften	85.42856	22
89	868	soften	85.02013	23
89	171	soften	83.61426	24
89	45	soften	83.16787	25
89	9	soften	83.13129	26
89	59	soften	82.68919	27
89	219	soften	82.46761	28
89	20	soften	82.07711	29
89	12	soften	81.88547	30
89	85	soften	81.82516	31
89	5	soften	81.447525	32
89	82	soften	81.00587	33
89	2	soften	80.88405	34
89	13	soften	80.633965	35
89	35	soften	80.44417	36
89	78	soften	80.42555	37
89	44	soften	80.26647	38
89	34	soften	79.74805	39
89	95	soften	79.69489	40
89	49	soften	79.24247	41
89	99	soften	79.139984	42
89	182	soften	78.85861	43
89	41	soften	78.63872	44
89	33	soften	78.423134	45
89	94	soften	78.42302	46
89	43	soften	78.00903	47
89	18	soften	77.78504	48
89	30	soften	77.4161	49
89	69	soften	77.32218	50
89	222	soften	77.00341	51
89	73	soften	76.9646	52
89	593	soften	76.81896	53
89	63	soften	76.177895	54
89	640	soften	76.05875	55
89	28	soften	75.99831	56
89	61	soften	75.89097	57
89	66	soften	75.805435	58
89	39	soften	75.30507	59
89	51	soften	74.84012	60
89	50	soften	74.587395	61
89	230	soften	74.56533	62
89	176	soften	73.81287	63
89	92	soften	73.71634	64
89	285	soften	72.93285	65
89	8	soften	72.8965	66
89	47	soften	72.572815	67
89	27	soften	70.72541	68
89	31	soften	70.6998	69
89	187	soften	70.62906	70
89	7	soften	70.33491	71
89	86	soften	70.150536	72
89	54	soften	69.97177	73
89	98	soften	69.578926	74
89	56	soften	69.325096	75
90	70	enhance	100	1
90	126	enhance	99.73011	2
90	99	enhance	98.073494	3
90	72	enhance	97.3498	4
90	3	enhance	97.0127	5
90	93	enhance	96.78331	6
90	83	enhance	95.42262	7
90	182	enhance	92.18245	8
90	55	enhance	89.89337	9
90	50	enhance	88.97154	10
90	34	enhance	88.561806	11
90	13	enhance	88.14353	12
90	82	enhance	88.01858	13
90	80	enhance	87.48821	14
90	49	enhance	87.46682	15
90	23	enhance	87.456665	16
90	43	enhance	87.28507	17
90	94	enhance	87.19169	18
90	2	enhance	86.37924	19
90	91	enhance	86.36007	20
90	63	enhance	84.84947	21
90	60	enhance	84.63101	22
90	5	enhance	83.8033	23
90	11	enhance	83.54997	24
90	593	enhance	82.73919	25
90	79	enhance	82.08669	26
90	4	enhance	82.05594	27
90	74	enhance	81.69458	28
90	64	enhance	81.496506	29
90	640	enhance	80.658585	30
90	9	enhance	80.45068	31
90	230	enhance	79.80876	32
90	33	enhance	79.49092	33
90	184	enhance	79.14086	34
90	39	enhance	78.08741	35
90	44	enhance	77.897224	36
90	61	enhance	77.76857	37
90	22	enhance	77.06312	38
90	45	enhance	76.83936	39
90	59	enhance	76.5039	40
90	96	enhance	75.86827	41
90	78	enhance	75.39354	42
90	21	enhance	73.87112	43
90	335	enhance	73.146935	44
90	868	enhance	72.698006	45
90	7	enhance	71.55235	46
90	92	enhance	70.68472	47
90	219	enhance	70.631424	48
90	66	enhance	70.572624	49
90	18	enhance	69.82889	50
90	41	enhance	69.74746	51
90	12	enhance	68.54459	52
90	85	enhance	68.14162	53
90	69	enhance	67.79144	54
90	222	enhance	67.6736	55
90	19	enhance	66.88516	56
90	187	enhance	66.44427	57
90	35	enhance	64.493225	58
90	28	enhance	64.20151	59
90	8	enhance	64.13414	60
90	47	enhance	64.06895	61
90	171	enhance	63.783985	62
90	20	enhance	63.258224	63
90	31	enhance	63.250565	64
90	10	enhance	62.95929	65
90	285	enhance	62.16908	66
90	98	enhance	62.122463	67
90	30	enhance	60.994896	68
90	27	enhance	59.606163	69
90	54	enhance	58.159924	70
90	73	enhance	57.67665	71
90	58	enhance	57.503544	72
90	176	enhance	57.082424	73
90	56	enhance	55.07843	74
90	108	enhance	52.373966	75
90	88	enhance	52.001114	76
90	86	enhance	51.514053	77
90	89	enhance	50.688766	78
90	455	enhance	50.302074	79
90	95	enhance	48.94786	80
90	52	enhance	48.48524	81
90	51	enhance	47.934017	82
90	488	enhance	42.544743	83
90	65	enhance	41.772854	84
90	647	enhance	41.204697	85
90	14	enhance	40.580845	86
90	67	enhance	40.55713	87
90	77	enhance	40.096992	88
90	100	enhance	39.47377	89
90	1	enhance	38.603027	90
90	15	enhance	38.066395	91
90	32	enhance	37.293945	92
90	24	enhance	36.537853	93
90	36	enhance	35.975636	94
90	84	enhance	35.811848	95
90	62	enhance	35.136864	96
90	68	enhance	33.502384	97
90	185	enhance	33.453056	98
90	57	enhance	32.394222	99
90	921	enhance	31.73948	100
90	26	enhance	31.18118	101
90	40	enhance	29.464994	102
90	901	enhance	29.307661	103
90	48	enhance	29.235014	104
90	785	enhance	28.77525	105
90	71	enhance	28.412542	106
90	37	enhance	27.895126	107
90	53	enhance	25.525	108
90	17	enhance	25.097721	109
90	81	enhance	23.593628	110
90	6	enhance	23.324476	111
90	38	enhance	23.072165	112
90	42	enhance	21.948654	113
90	25	enhance	21.906519	114
90	76	enhance	21.889162	115
90	87	enhance	20.90328	116
90	97	enhance	20.400213	117
90	16	enhance	19.936249	118
90	75	enhance	19.741953	119
90	358	enhance	16.91115	120
90	29	enhance	16.906204	121
90	46	enhance	14.714751	122
90	155	enhance	10.963264	123
90	882	enhance	10.621755	124
90	11	soften	100	1
90	60	soften	96.20689	2
90	91	soften	95.748856	3
90	55	soften	92.17428	4
90	3	soften	88.29213	5
90	72	soften	87.77698	6
90	83	soften	87.32115	7
90	80	soften	85.25075	8
90	64	soften	72.36188	9
90	74	soften	67.53874	10
91	4	enhance	100	1
91	93	enhance	98.60823	2
91	22	enhance	98.4547	3
91	74	enhance	97.60947	4
91	23	enhance	97.4498	5
91	9	enhance	97.31448	6
91	3	enhance	96.87963	7
91	184	enhance	96.47449	8
91	335	enhance	96.194	9
91	55	enhance	95.582375	10
91	59	enhance	95.570625	11
91	60	enhance	95.37787	12
91	64	enhance	94.99662	13
91	96	enhance	94.776215	14
91	21	enhance	94.160995	15
91	44	enhance	94.03376	16
91	5	enhance	93.80588	17
91	11	enhance	93.73737	18
91	41	enhance	92.21289	19
91	78	enhance	90.44738	20
91	12	enhance	90.41718	21
91	219	enhance	90.04896	22
91	85	enhance	89.757996	23
91	72	enhance	89.55886	24
91	69	enhance	89.09472	25
91	593	enhance	88.78675	26
91	868	enhance	87.33562	27
91	70	enhance	86.989655	28
91	83	enhance	86.32805	29
91	90	enhance	85.796196	30
91	66	enhance	84.73002	31
91	35	enhance	84.609634	32
91	82	enhance	81.86315	33
91	94	enhance	81.62889	34
91	79	enhance	80.825005	35
91	20	enhance	77.5148	36
91	8	enhance	76.06069	37
91	18	enhance	76.00162	38
91	126	enhance	75.631874	39
91	50	enhance	75.3294	40
91	171	enhance	74.44737	41
91	99	enhance	71.38429	42
91	27	enhance	71.092316	43
91	39	enhance	70.60906	44
91	10	enhance	69.98896	45
91	34	enhance	68.57091	46
91	58	enhance	68.27778	47
91	182	enhance	68.18452	48
91	80	enhance	67.79182	49
91	7	enhance	67.149155	50
91	54	enhance	63.638752	51
91	28	enhance	63.430725	52
91	455	enhance	62.06786	53
91	92	enhance	61.621693	54
91	52	enhance	61.34927	55
91	49	enhance	60.6635	56
91	95	enhance	60.352627	57
91	63	enhance	59.741802	58
91	2	enhance	58.63876	59
91	65	enhance	58.45284	60
91	19	enhance	58.43744	61
91	43	enhance	57.847332	62
91	488	enhance	56.638817	63
91	77	enhance	56.158894	64
91	86	enhance	56.03467	65
91	100	enhance	55.21999	66
91	13	enhance	53.157307	67
91	176	enhance	52.673542	68
91	14	enhance	50.75242	69
91	45	enhance	50.387238	70
91	32	enhance	49.060497	71
91	285	enhance	48.941017	72
91	187	enhance	48.508167	73
91	24	enhance	45.803234	74
91	222	enhance	44.634663	75
91	62	enhance	42.949734	76
91	640	enhance	42.31025	77
91	108	enhance	40.626064	78
91	73	enhance	39.38435	79
91	53	enhance	38.655834	80
91	230	enhance	38.52014	81
91	185	enhance	37.511047	82
91	921	enhance	37.323223	83
91	61	enhance	37.177505	84
91	57	enhance	35.266415	85
91	15	enhance	34.628185	86
91	47	enhance	34.580666	87
91	89	enhance	34.24109	88
91	38	enhance	33.61746	89
91	647	enhance	33.481842	90
91	30	enhance	33.344864	91
91	33	enhance	32.526283	92
91	42	enhance	32.353527	93
91	56	enhance	31.657907	94
91	785	enhance	31.419373	95
91	98	enhance	30.829475	96
91	51	enhance	30.721449	97
91	31	enhance	30.59781	98
91	81	enhance	30.328962	99
91	901	enhance	29.859728	100
91	6	enhance	29.405317	101
91	76	enhance	29.110283	102
91	26	enhance	28.838696	103
91	84	enhance	28.169733	104
91	1	enhance	27.818243	105
91	97	enhance	27.290617	106
91	16	enhance	27.113752	107
91	88	enhance	27.089031	108
91	68	enhance	25.525263	109
91	48	enhance	25.372597	110
91	36	enhance	24.389084	111
91	29	enhance	24.126062	112
91	37	enhance	23.98313	113
91	17	enhance	23.73836	114
91	71	enhance	22.835432	115
91	358	enhance	22.316149	116
91	87	enhance	19.820059	117
91	67	enhance	19.256907	118
91	40	enhance	18.62236	119
91	25	enhance	14.570681	120
91	75	enhance	13.022272	121
91	46	enhance	11.729774	122
91	155	enhance	10.57877	123
91	882	enhance	9.423512	124
91	11	soften	100	1
91	60	soften	96.663414	2
91	64	soften	69.23757	3
91	74	soften	60.24581	4
92	176	enhance	100	1
92	285	enhance	99.43336	2
92	222	enhance	98.13107	3
92	94	enhance	97.79295	4
92	10	enhance	96.54113	5
92	7	enhance	95.14727	6
92	1	enhance	92.75426	7
92	108	enhance	92.74154	8
92	39	enhance	92.164055	9
92	86	enhance	92.15958	10
92	51	enhance	91.5326	11
92	88	enhance	91.09986	12
92	68	enhance	90.921524	13
92	36	enhance	90.449646	14
92	67	enhance	90.00739	15
92	15	enhance	89.875946	16
92	19	enhance	89.52338	17
92	182	enhance	89.43321	18
92	50	enhance	89.07878	19
92	48	enhance	88.878075	20
92	71	enhance	88.57939	21
92	13	enhance	87.91049	22
92	84	enhance	87.52382	23
92	187	enhance	87.48506	24
92	31	enhance	87.42493	25
92	47	enhance	87.33352	26
92	98	enhance	86.49115	27
92	640	enhance	86.405815	28
92	70	enhance	86.25125	29
92	52	enhance	85.087746	30
92	25	enhance	84.87916	31
92	87	enhance	84.85481	32
92	63	enhance	84.84216	33
92	72	enhance	84.53065	34
92	49	enhance	84.40815	35
92	785	enhance	84.105774	36
92	40	enhance	83.96007	37
92	75	enhance	83.87932	38
92	868	enhance	83.65232	39
92	89	enhance	82.62715	40
92	17	enhance	81.8509	41
92	455	enhance	81.10186	42
92	99	enhance	81.02407	43
92	647	enhance	80.91132	44
92	27	enhance	80.5975	45
92	593	enhance	80.31362	46
92	61	enhance	79.446266	47
92	155	enhance	79.053825	48
92	83	enhance	78.82812	49
92	44	enhance	78.49111	50
92	46	enhance	77.696846	51
92	66	enhance	77.61412	52
92	882	enhance	77.319534	53
92	185	enhance	77.26522	54
92	24	enhance	77.07125	55
92	93	enhance	76.56355	56
92	55	enhance	75.81658	57
92	230	enhance	75.72278	58
92	34	enhance	75.25184	59
92	76	enhance	74.89294	60
92	54	enhance	74.88172	61
92	38	enhance	74.53238	62
92	56	enhance	74.39726	63
92	37	enhance	74.35926	64
92	358	enhance	73.49859	65
92	90	enhance	73.43925	66
92	78	enhance	73.17363	67
92	16	enhance	73.03727	68
92	3	enhance	72.858406	69
92	43	enhance	72.65712	70
92	62	enhance	72.613365	71
92	100	enhance	72.27426	72
92	126	enhance	72.270966	73
92	82	enhance	71.96268	74
92	184	enhance	71.816376	75
92	60	enhance	71.632454	76
92	901	enhance	71.52676	77
92	42	enhance	71.51291	78
92	77	enhance	71.07284	79
92	6	enhance	71.040634	80
92	28	enhance	70.79847	81
92	59	enhance	70.632164	82
92	33	enhance	69.07655	83
92	97	enhance	68.79733	84
92	22	enhance	68.68358	85
92	58	enhance	67.77682	86
92	11	enhance	67.62187	87
92	4	enhance	66.26126	88
92	26	enhance	66.06355	89
92	335	enhance	65.692604	90
92	5	enhance	64.72759	91
92	91	enhance	64.44382	92
92	18	enhance	64.31168	93
92	64	enhance	64.30152	94
92	29	enhance	63.189613	95
92	45	enhance	62.84665	96
92	9	enhance	62.657463	97
92	219	enhance	62.56602	98
92	23	enhance	62.293217	99
92	2	enhance	60.894314	100
92	81	enhance	60.809216	101
92	41	enhance	60.75193	102
92	96	enhance	59.587463	103
92	8	enhance	59.56688	104
92	171	enhance	59.070656	105
92	921	enhance	57.45525	106
92	12	enhance	56.79106	107
92	79	enhance	56.762203	108
92	21	enhance	56.26265	109
92	65	enhance	54.94666	110
92	30	enhance	54.551266	111
92	14	enhance	54.303223	112
92	74	enhance	53.77061	113
92	69	enhance	53.646957	114
92	80	enhance	53.48814	115
92	85	enhance	53.014294	116
92	35	enhance	51.870964	117
92	20	enhance	50.609917	118
92	32	enhance	49.465725	119
92	73	enhance	49.39265	120
92	53	enhance	48.73155	121
92	57	enhance	42.071243	122
92	95	enhance	40.78436	123
92	488	enhance	38.866684	124
92	64	soften	100	1
92	11	soften	97.23149	2
92	74	soften	96.044525	3
92	80	soften	93.72961	4
92	91	soften	92.98424	5
92	60	soften	92.458626	6
92	55	soften	89.48875	7
92	3	soften	89.317696	8
92	90	soften	88.7031	9
92	96	soften	87.96058	10
92	184	soften	87.90976	11
92	126	soften	87.77636	12
92	93	soften	87.70422	13
92	79	soften	86.97662	14
92	83	soften	86.71515	15
92	4	soften	85.841896	16
92	72	soften	85.73331	17
92	23	soften	85.68997	18
92	335	soften	85.06286	19
92	22	soften	84.335106	20
92	21	soften	84.28545	21
92	70	soften	83.80277	22
92	171	soften	83.56359	23
92	45	soften	83.35376	24
92	219	soften	83.05562	25
92	20	soften	82.82683	26
92	868	soften	82.06159	27
92	9	soften	81.84583	28
92	78	soften	81.63745	29
92	30	soften	81.439606	30
92	2	soften	81.26355	31
92	5	soften	80.85077	32
92	85	soften	80.65143	33
92	59	soften	80.541565	34
92	34	soften	80.44005	35
92	35	soften	80.251465	36
92	12	soften	80.18562	37
92	43	soften	80.13265	38
92	73	soften	80.01175	39
92	95	soften	79.92887	40
92	44	soften	79.72015	41
92	99	soften	79.54765	42
92	82	soften	79.31875	43
92	18	soften	79.14478	44
92	41	soften	78.306145	45
92	49	soften	78.06904	46
92	33	soften	77.66799	47
92	13	soften	77.529625	48
92	28	soften	76.8748	49
92	593	soften	76.75698	50
92	69	soften	76.63395	51
92	182	soften	76.624535	52
92	63	soften	76.401474	53
92	39	soften	75.68903	54
92	94	soften	75.44935	55
92	66	soften	74.60672	56
92	61	soften	73.87214	57
92	230	soften	73.47912	58
92	640	soften	73.30924	59
92	222	soften	71.39111	60
92	285	soften	69.20391	61
93	3	enhance	100	1
93	91	enhance	99.019844	2
93	70	enhance	97.33287	3
93	90	enhance	96.55274	4
93	184	enhance	96.125114	5
93	23	enhance	95.982544	6
93	22	enhance	95.57844	7
93	44	enhance	95.21876	8
93	55	enhance	95.01318	9
93	72	enhance	94.9995	10
93	4	enhance	94.297424	11
93	74	enhance	94.22336	12
93	64	enhance	93.10244	13
93	593	enhance	92.313675	14
93	96	enhance	92.19808	15
93	9	enhance	92.15415	16
93	60	enhance	91.78	17
93	11	enhance	91.70131	18
93	335	enhance	91.570366	19
93	94	enhance	91.43827	20
93	5	enhance	91.37876	21
93	59	enhance	91.33036	22
93	78	enhance	91.01555	23
93	83	enhance	91.009995	24
93	99	enhance	88.49572	25
93	126	enhance	88.07624	26
93	21	enhance	87.9524	27
93	868	enhance	87.52231	28
93	41	enhance	86.44069	29
93	82	enhance	85.99754	30
93	219	enhance	85.91975	31
93	50	enhance	85.580444	32
93	39	enhance	85.55801	33
93	79	enhance	83.984276	34
93	66	enhance	83.11127	35
93	12	enhance	82.290245	36
93	85	enhance	81.962036	37
93	69	enhance	81.89112	38
93	182	enhance	81.19174	39
93	34	enhance	79.82523	40
93	80	enhance	79.66055	41
93	63	enhance	78.82168	42
93	18	enhance	78.6079	43
93	7	enhance	78.34984	44
93	49	enhance	77.48679	45
93	35	enhance	76.57218	46
93	10	enhance	75.87705	47
93	43	enhance	75.688934	48
93	2	enhance	75.348915	49
93	27	enhance	74.44927	50
93	13	enhance	73.670105	51
93	20	enhance	73.64187	52
93	92	enhance	73.51628	53
93	8	enhance	72.46625	54
93	171	enhance	71.07522	55
93	58	enhance	70.660095	56
93	28	enhance	67.36588	57
93	19	enhance	66.46468	58
93	54	enhance	66.26501	59
93	45	enhance	66.19479	60
93	455	enhance	65.67783	61
93	86	enhance	65.32064	62
93	52	enhance	65.15382	63
93	640	enhance	65.01086	64
93	285	enhance	62.450283	65
93	230	enhance	61.798664	66
93	222	enhance	61.683548	67
93	176	enhance	61.663883	68
93	187	enhance	61.26794	69
93	61	enhance	60.058372	70
93	95	enhance	57.41659	71
93	33	enhance	56.642147	72
93	108	enhance	56.63172	73
93	77	enhance	55.960636	74
93	100	enhance	55.459843	75
93	65	enhance	54.701626	76
93	31	enhance	52.97535	77
93	47	enhance	51.647957	78
93	488	enhance	51.002655	79
93	73	enhance	50.680893	80
93	89	enhance	50.638264	81
93	30	enhance	50.613777	82
93	98	enhance	50.29647	83
93	24	enhance	49.54405	84
93	14	enhance	49.150734	85
93	56	enhance	48.739388	86
93	62	enhance	47.652153	87
93	647	enhance	46.53504	88
93	88	enhance	45.65039	89
93	32	enhance	45.621197	90
93	15	enhance	44.84929	91
93	185	enhance	43.354538	92
93	51	enhance	43.065662	93
93	1	enhance	42.37802	94
93	84	enhance	42.104496	95
93	36	enhance	40.29997	96
93	68	enhance	39.71081	97
93	921	enhance	38.969326	98
93	785	enhance	38.381763	99
93	48	enhance	38.024845	100
93	38	enhance	37.90606	101
93	57	enhance	36.815933	102
93	53	enhance	36.35098	103
93	26	enhance	36.276745	104
93	6	enhance	36.16203	105
93	42	enhance	36.138283	106
93	67	enhance	35.407658	107
93	901	enhance	35.031776	108
93	40	enhance	34.510292	109
93	76	enhance	34.28794	110
93	97	enhance	33.86977	111
93	71	enhance	33.865055	112
93	17	enhance	33.097237	113
93	37	enhance	32.87968	114
93	16	enhance	31.989397	115
93	81	enhance	31.935102	116
93	87	enhance	30.83992	117
93	25	enhance	29.12821	118
93	358	enhance	28.593435	119
93	29	enhance	28.534298	120
93	75	enhance	26.489527	121
93	46	enhance	22.50598	122
93	155	enhance	20.84971	123
93	882	enhance	20.610828	124
93	11	soften	100	1
93	55	soften	94.32737	2
93	91	soften	91.427864	3
93	3	soften	91.322075	4
93	90	soften	89.55729	5
93	64	soften	69.63057	6
93	60	soften	68.16946	7
93	83	soften	65.456764	8
93	72	soften	65.12799	9
93	80	soften	63.853474	10
93	74	soften	63.32221	11
94	70	enhance	100	1
94	39	enhance	98.10094	2
94	92	enhance	96.965004	3
94	49	enhance	96.02186	4
94	285	enhance	95.85157	5
94	72	enhance	95.171265	6
94	182	enhance	94.73216	7
94	50	enhance	94.726006	8
94	93	enhance	94.42219	9
94	10	enhance	94.03334	10
94	593	enhance	93.53947	11
94	176	enhance	92.656235	12
94	83	enhance	91.19459	13
94	7	enhance	91.17551	14
94	66	enhance	90.5658	15
94	99	enhance	90.37271	16
94	13	enhance	90.30953	17
94	86	enhance	90.12546	18
94	63	enhance	89.98692	19
94	3	enhance	89.854774	20
94	90	enhance	89.82252	21
94	27	enhance	89.059525	22
94	44	enhance	88.922035	23
94	126	enhance	88.129845	24
94	52	enhance	87.38941	25
94	222	enhance	87.33485	26
94	78	enhance	87.15047	27
94	59	enhance	87.079796	28
94	108	enhance	87.06945	29
94	868	enhance	86.27509	30
94	184	enhance	85.71712	31
94	55	enhance	85.12846	32
94	34	enhance	85.10861	33
94	455	enhance	85.06198	34
94	79	enhance	84.997795	35
94	91	enhance	84.64455	36
94	98	enhance	84.47023	37
94	54	enhance	84.2001	38
94	82	enhance	84.0495	39
94	19	enhance	83.86337	40
94	88	enhance	83.56893	41
94	5	enhance	83.549934	42
94	640	enhance	83.37115	43
94	18	enhance	83.341446	44
94	22	enhance	82.2372	45
94	23	enhance	82.18585	46
94	43	enhance	82.126595	47
94	60	enhance	81.397934	48
94	31	enhance	81.37447	49
94	4	enhance	81.224976	50
94	61	enhance	80.66559	51
94	28	enhance	80.32755	52
94	335	enhance	80.106224	53
94	9	enhance	79.782715	54
94	21	enhance	79.33027	55
94	187	enhance	79.177	56
94	47	enhance	78.69372	57
94	74	enhance	78.57324	58
94	64	enhance	78.55862	59
94	1	enhance	78.51995	60
94	11	enhance	78.5147	61
94	230	enhance	78.36928	62
94	36	enhance	77.92116	63
94	96	enhance	77.658226	64
94	45	enhance	77.147224	65
94	24	enhance	76.84001	66
94	80	enhance	76.47112	67
94	84	enhance	76.39921	68
94	89	enhance	75.730095	69
94	219	enhance	75.675735	70
94	12	enhance	75.5617	71
94	647	enhance	75.52806	72
94	68	enhance	75.480995	73
94	2	enhance	74.84748	74
94	48	enhance	74.44755	75
94	85	enhance	74.27977	76
94	15	enhance	73.72647	77
94	41	enhance	73.61534	78
94	71	enhance	73.45657	79
94	40	enhance	73.422806	80
94	51	enhance	73.363976	81
94	69	enhance	73.35507	82
94	100	enhance	73.00362	83
94	58	enhance	72.924934	84
94	77	enhance	72.34667	85
94	785	enhance	70.939766	86
94	62	enhance	70.918945	87
94	185	enhance	70.15183	88
94	67	enhance	69.94507	89
94	33	enhance	69.93885	90
94	56	enhance	69.41444	91
94	35	enhance	69.25588	92
94	17	enhance	68.73628	93
94	8	enhance	68.280945	94
94	25	enhance	67.76505	95
94	6	enhance	67.69317	96
94	87	enhance	67.44605	97
94	97	enhance	66.899506	98
94	171	enhance	66.88215	99
94	75	enhance	66.37374	100
94	38	enhance	66.19186	101
94	73	enhance	65.49498	102
94	20	enhance	65.263435	103
94	76	enhance	64.356285	104
94	30	enhance	63.88257	105
94	42	enhance	63.857285	106
94	16	enhance	62.269695	107
94	358	enhance	61.73051	108
94	65	enhance	59.394714	109
94	37	enhance	58.812626	110
94	46	enhance	58.046383	111
94	155	enhance	57.9915	112
94	29	enhance	57.339615	113
94	32	enhance	57.309414	114
94	882	enhance	56.31022	115
94	14	enhance	56.191395	116
94	921	enhance	56.14217	117
94	901	enhance	55.97577	118
94	26	enhance	55.540695	119
94	53	enhance	55.477436	120
94	95	enhance	52.74396	121
94	488	enhance	52.138966	122
94	81	enhance	52.115273	123
94	57	enhance	41.03366	124
94	64	soften	100	1
94	11	soften	99.29962	2
94	60	soften	95.746895	3
94	74	soften	94.599266	4
94	55	soften	93.13631	5
94	80	soften	93.058914	6
94	91	soften	92.82598	7
94	3	soften	91.203766	8
94	83	soften	90.74852	9
94	126	soften	89.77831	10
94	90	soften	89.655594	11
94	72	soften	89.461426	12
94	184	soften	88.50379	13
94	4	soften	88.13964	14
94	96	soften	88.11819	15
94	93	soften	87.67976	16
94	171	soften	86.79512	17
94	335	soften	86.069725	18
94	23	soften	85.94459	19
94	79	soften	85.92909	20
94	70	soften	85.62441	21
94	22	soften	85.0827	22
94	45	soften	84.92561	23
94	219	soften	84.91359	24
94	868	soften	84.72902	25
94	20	soften	84.643974	26
94	21	soften	84.13491	27
94	30	soften	83.99964	28
94	34	soften	83.753624	29
94	9	soften	83.275116	30
94	78	soften	83.2272	31
94	59	soften	81.97633	32
94	5	soften	81.81049	33
94	2	soften	81.71113	34
94	12	soften	81.49413	35
94	85	soften	81.085106	36
94	99	soften	80.910904	37
94	44	soften	80.833466	38
94	13	soften	80.50015	39
94	49	soften	80.0827	40
95	20	enhance	100	1
95	488	enhance	96.533775	2
95	14	enhance	92.24845	3
95	171	enhance	91.62369	4
95	219	enhance	89.06336	5
95	58	enhance	88.18675	6
95	35	enhance	88.0279	7
95	8	enhance	87.86294	8
95	65	enhance	87.211205	9
95	18	enhance	86.27131	10
95	32	enhance	84.29215	11
95	96	enhance	83.94076	12
95	85	enhance	82.769295	13
95	82	enhance	82.55987	14
95	21	enhance	80.75675	15
95	69	enhance	80.219345	16
95	12	enhance	80.12442	17
95	5	enhance	79.00587	18
95	78	enhance	78.559326	19
95	921	enhance	78.30415	20
95	74	enhance	78.21403	21
95	41	enhance	77.37156	22
95	335	enhance	76.490166	23
95	34	enhance	76.29789	24
95	23	enhance	75.714905	25
95	9	enhance	75.5889	26
95	59	enhance	75.46004	27
95	593	enhance	75.4496	28
95	62	enhance	75.275375	29
95	77	enhance	74.01597	30
95	455	enhance	73.68551	31
95	100	enhance	71.780334	32
95	24	enhance	70.62549	33
95	79	enhance	70.576645	34
95	57	enhance	70.46271	35
95	2	enhance	69.73856	36
95	54	enhance	69.73649	37
95	185	enhance	69.08753	38
95	4	enhance	68.497444	39
95	184	enhance	68.09613	40
95	55	enhance	66.58187	41
95	81	enhance	66.56771	42
95	28	enhance	66.21605	43
95	53	enhance	66.143456	44
95	868	enhance	66.00389	45
95	26	enhance	65.43918	46
95	3	enhance	64.910065	47
95	50	enhance	64.27522	48
95	45	enhance	63.658863	49
95	66	enhance	63.458908	50
95	63	enhance	62.198048	51
95	73	enhance	62.003223	52
95	43	enhance	61.76895	53
95	80	enhance	61.27848	54
95	91	enhance	61.000725	55
95	22	enhance	60.951687	56
95	64	enhance	59.968372	57
95	42	enhance	59.653522	58
95	38	enhance	59.38731	59
95	83	enhance	58.365673	60
95	11	enhance	58.17336	61
95	89	enhance	58.107956	62
95	93	enhance	57.791924	63
95	7	enhance	57.203846	64
95	19	enhance	57.156075	65
95	126	enhance	55.88162	66
95	187	enhance	55.85457	67
95	44	enhance	55.626762	68
95	70	enhance	55.055084	69
95	27	enhance	54.81977	70
95	52	enhance	54.703365	71
95	56	enhance	54.122124	72
95	647	enhance	53.64389	73
95	60	enhance	53.411396	74
95	901	enhance	52.10751	75
95	10	enhance	51.95453	76
95	30	enhance	51.71609	77
95	785	enhance	51.598747	78
95	94	enhance	51.411045	79
95	99	enhance	50.362827	80
95	76	enhance	50.217716	81
95	39	enhance	49.661964	82
95	90	enhance	49.15046	83
95	6	enhance	48.81182	84
95	37	enhance	47.51424	85
95	182	enhance	46.651264	86
95	72	enhance	45.940376	87
95	16	enhance	45.838898	88
95	176	enhance	45.614254	89
95	29	enhance	45.32881	90
95	49	enhance	45.272728	91
95	97	enhance	40.972588	92
95	108	enhance	40.586502	93
95	358	enhance	39.456154	94
95	92	enhance	39.41711	95
95	1	enhance	38.62834	96
95	17	enhance	35.86425	97
95	15	enhance	35.176132	98
95	86	enhance	34.422222	99
95	285	enhance	33.088314	100
95	230	enhance	32.064556	101
95	84	enhance	31.488655	102
95	47	enhance	31.459017	103
95	71	enhance	31.063505	104
95	31	enhance	30.563274	105
95	61	enhance	29.276445	106
95	13	enhance	28.865816	107
95	36	enhance	28.545347	108
95	87	enhance	26.331123	109
95	48	enhance	23.078459	110
95	98	enhance	22.749767	111
95	33	enhance	22.203981	112
95	68	enhance	22.04376	113
95	640	enhance	20.42108	114
95	88	enhance	19.738081	115
95	222	enhance	18.68822	116
95	40	enhance	17.337173	117
95	46	enhance	15.199077	118
95	25	enhance	14.618026	119
95	155	enhance	13.938697	120
95	882	enhance	12.574498	121
95	51	enhance	9.490189	122
95	75	enhance	8.459335	123
95	67	enhance	5.825808	124
95	80	soften	100	1
95	90	soften	98.08262	2
95	72	soften	98.02553	3
95	126	soften	97.75551	4
95	13	soften	97.52785	5
95	33	soften	97.01165	6
95	64	soften	96.27528	7
95	11	soften	95.174644	8
95	49	soften	95.079605	9
95	83	soften	94.77554	10
95	70	soften	94.62313	11
95	30	soften	94.24873	12
95	45	soften	92.988266	13
95	93	soften	92.55913	14
95	60	soften	92.45652	15
95	3	soften	91.64938	16
95	182	soften	89.87873	17
95	99	soften	89.67079	18
95	79	soften	89.06233	19
95	43	soften	89.05963	20
95	55	soften	89.04546	21
95	94	soften	88.9303	22
95	73	soften	88.86515	23
95	91	soften	88.314896	24
95	184	soften	86.82071	25
95	34	soften	85.36515	26
95	2	soften	84.2995	27
95	74	soften	83.89631	28
95	44	soften	83.56744	29
95	868	soften	83.34796	30
95	22	soften	81.73231	31
95	78	soften	81.15645	32
95	4	soften	79.92889	33
95	23	soften	78.84857	34
95	18	soften	78.650375	35
95	82	soften	77.776535	36
95	335	soften	77.465546	37
95	96	soften	77.40854	38
95	59	soften	77.08287	39
95	5	soften	75.73955	40
95	21	soften	74.16196	41
95	171	soften	74.098495	42
95	219	soften	73.81407	43
95	9	soften	73.78044	44
95	12	soften	69.66559	45
95	20	soften	69.54073	46
95	85	soften	68.6289	47
95	35	soften	67.298584	48
96	335	enhance	100	1
96	74	enhance	98.81944	2
96	219	enhance	98.193184	3
96	184	enhance	97.59373	4
96	22	enhance	96.231606	5
96	78	enhance	95.9732	6
96	41	enhance	95.742325	7
96	23	enhance	95.73323	8
96	59	enhance	95.45589	9
96	21	enhance	95.36071	10
96	9	enhance	95.3339	11
96	91	enhance	94.78983	12
96	4	enhance	94.04902	13
96	5	enhance	92.37249	14
96	85	enhance	92.090515	15
96	20	enhance	91.84804	16
96	93	enhance	91.82801	17
96	44	enhance	91.24137	18
96	69	enhance	91.2337	19
96	12	enhance	91.21546	20
96	593	enhance	90.11841	21
96	3	enhance	89.934746	22
96	64	enhance	89.527626	23
96	55	enhance	89.45879	24
96	35	enhance	89.15697	25
96	868	enhance	88.65749	26
96	11	enhance	85.659775	27
96	82	enhance	85.60911	28
96	18	enhance	85.32467	29
96	58	enhance	85.12936	30
96	171	enhance	84.67435	31
96	8	enhance	83.79408	32
96	60	enhance	83.503784	33
96	95	enhance	83.06086	34
96	66	enhance	81.56403	35
96	70	enhance	79.62566	36
96	79	enhance	78.61579	37
96	83	enhance	76.916756	38
96	72	enhance	75.79309	39
96	90	enhance	75.38373	40
96	94	enhance	74.90223	41
96	488	enhance	74.48127	42
96	65	enhance	74.12516	43
96	50	enhance	73.32216	44
96	39	enhance	72.95508	45
96	455	enhance	72.761795	46
96	34	enhance	72.173645	47
96	27	enhance	72.06433	48
96	10	enhance	70.73528	49
96	14	enhance	70.13826	50
96	126	enhance	69.506516	51
96	7	enhance	69.48577	52
96	77	enhance	69.45512	53
96	80	enhance	68.43034	54
96	2	enhance	68.28438	55
96	100	enhance	68.02635	56
96	54	enhance	67.91623	57
96	99	enhance	67.018394	58
96	63	enhance	65.657394	59
96	52	enhance	64.36612	60
96	28	enhance	64.34745	61
96	32	enhance	63.16516	62
96	43	enhance	61.060677	63
96	62	enhance	60.220604	64
96	182	enhance	59.55813	65
96	19	enhance	59.48042	66
96	24	enhance	59.127045	67
96	92	enhance	56.98619	68
96	45	enhance	56.355904	69
96	49	enhance	54.896564	70
96	86	enhance	54.72492	71
96	921	enhance	53.783722	72
96	185	enhance	52.61095	73
96	57	enhance	52.244976	74
96	176	enhance	52.142246	75
96	187	enhance	51.24333	76
96	53	enhance	49.857254	77
96	38	enhance	48.66145	78
96	42	enhance	47.2672	79
96	73	enhance	46.362926	80
96	89	enhance	46.263664	81
96	647	enhance	46.002663	82
96	81	enhance	45.456257	83
96	26	enhance	45.43165	84
96	13	enhance	44.68564	85
96	108	enhance	44.5429	86
96	285	enhance	44.457817	87
96	785	enhance	42.186493	88
96	56	enhance	41.79887	89
96	6	enhance	41.423023	90
96	76	enhance	41.249596	91
96	30	enhance	41.116123	92
96	15	enhance	38.9296	93
96	901	enhance	38.593353	94
96	97	enhance	37.167053	95
96	222	enhance	36.53132	96
96	16	enhance	36.218098	97
96	230	enhance	36.019215	98
96	37	enhance	35.677967	99
96	29	enhance	35.20559	100
96	640	enhance	35.115974	101
96	1	enhance	34.621826	102
96	84	enhance	33.928802	103
96	61	enhance	33.659283	104
96	358	enhance	32.07555	105
96	47	enhance	31.705017	106
96	17	enhance	31.567707	107
96	31	enhance	31.07435	108
96	36	enhance	29.128283	109
96	48	enhance	28.472355	110
96	68	enhance	28.329498	111
96	33	enhance	27.725683	112
96	71	enhance	27.068058	113
96	87	enhance	26.380262	114
96	98	enhance	25.335276	115
96	88	enhance	24.181059	116
96	51	enhance	22.276308	117
96	40	enhance	21.494032	118
96	25	enhance	18.299526	119
96	46	enhance	16.700006	120
96	882	enhance	15.334056	121
96	155	enhance	15.174552	122
96	75	enhance	14.492004	123
96	67	enhance	14.265516	124
96	126	soften	100	1
96	90	soften	98.77206	2
96	11	soften	98.70985	3
96	55	soften	94.18284	4
96	3	soften	94.16773	5
96	93	soften	89.81546	6
96	91	soften	86.99572	7
96	184	soften	84.332	8
96	72	soften	70.11983	9
96	83	soften	69.61097	10
96	80	soften	69.48546	11
96	60	soften	67.75049	12
96	64	soften	67.22893	13
96	74	soften	57.760117	14
97	6	enhance	100	1
97	358	enhance	96.63513	2
97	29	enhance	96.254364	3
97	17	enhance	95.21079	4
97	76	enhance	93.78491	5
97	16	enhance	93.56801	6
97	42	enhance	93.11691	7
97	38	enhance	93.049934	8
97	785	enhance	92.520515	9
97	52	enhance	91.78354	10
97	647	enhance	90.93594	11
97	48	enhance	90.83914	12
97	71	enhance	90.82184	13
97	40	enhance	90.33635	14
97	185	enhance	90.255135	15
97	455	enhance	89.27753	16
97	24	enhance	89.20441	17
97	62	enhance	88.95272	18
97	87	enhance	88.63992	19
97	68	enhance	87.89785	20
97	46	enhance	86.390755	21
97	25	enhance	86.24536	22
97	108	enhance	86.18353	23
97	36	enhance	85.99488	24
97	27	enhance	85.72073	25
97	75	enhance	85.54135	26
97	54	enhance	85.114845	27
97	100	enhance	85.07038	28
97	882	enhance	84.90791	29
97	84	enhance	84.89749	30
97	53	enhance	84.27905	31
97	155	enhance	83.978455	32
97	77	enhance	83.10239	33
97	86	enhance	81.11392	34
97	10	enhance	80.331635	35
97	81	enhance	80.276276	36
97	1	enhance	79.95627	37
97	37	enhance	79.901855	38
97	921	enhance	79.010635	39
97	88	enhance	77.061356	40
97	26	enhance	75.265305	41
97	285	enhance	74.42049	42
97	89	enhance	74.20901	43
97	15	enhance	73.59454	44
97	176	enhance	72.39001	45
97	39	enhance	71.513466	46
97	66	enhance	70.64689	47
97	98	enhance	69.879166	48
97	28	enhance	69.816605	49
97	901	enhance	69.11441	50
97	18	enhance	68.011475	51
97	32	enhance	66.13059	52
97	31	enhance	65.969444	53
97	7	enhance	65.61235	54
97	65	enhance	65.246544	55
97	56	enhance	64.521996	56
97	92	enhance	64.22388	57
97	94	enhance	62.98547	58
97	14	enhance	62.84167	59
97	593	enhance	60.648308	60
97	78	enhance	59.966473	61
97	50	enhance	56.845688	62
97	187	enhance	56.31449	63
97	58	enhance	56.217262	64
97	19	enhance	55.00642	65
97	67	enhance	54.713524	66
97	49	enhance	54.43895	67
97	73	enhance	53.623775	68
97	222	enhance	52.23072	69
97	59	enhance	51.993748	70
97	63	enhance	51.752823	71
97	488	enhance	51.281834	72
97	44	enhance	49.489227	73
97	79	enhance	49.141853	74
97	8	enhance	49.095425	75
97	51	enhance	48.392994	76
97	57	enhance	47.860153	77
97	30	enhance	46.94821	78
97	47	enhance	46.891533	79
97	12	enhance	46.392708	80
97	182	enhance	46.19149	81
97	85	enhance	45.74927	82
97	219	enhance	45.677105	83
97	868	enhance	45.669487	84
97	21	enhance	45.482082	85
97	35	enhance	44.941326	86
97	184	enhance	44.882248	87
97	335	enhance	44.585636	88
97	69	enhance	44.46505	89
97	61	enhance	44.022648	90
97	34	enhance	43.694542	91
97	230	enhance	41.52044	92
97	20	enhance	40.722897	93
97	43	enhance	40.486626	94
97	640	enhance	40.46068	95
97	5	enhance	39.99533	96
97	171	enhance	39.92341	97
97	95	enhance	39.575573	98
97	41	enhance	39.3291	99
97	22	enhance	38.467255	100
97	45	enhance	38.366695	101
97	13	enhance	38.256607	102
97	82	enhance	36.38981	103
97	96	enhance	36.28009	104
97	70	enhance	35.39543	105
97	99	enhance	33.532764	106
97	93	enhance	32.92879	107
97	9	enhance	32.698727	108
97	23	enhance	32.465973	109
97	4	enhance	31.416061	110
97	2	enhance	31.00926	111
97	74	enhance	28.245996	112
97	3	enhance	27.026054	113
97	72	enhance	26.754776	114
97	91	enhance	26.643175	115
97	33	enhance	26.520712	116
97	64	enhance	25.641232	117
97	55	enhance	25.42621	118
97	83	enhance	24.92437	119
97	80	enhance	23.706215	120
97	126	enhance	23.330513	121
97	60	enhance	22.261833	122
97	11	enhance	21.242817	123
97	90	enhance	19.7862	124
97	11	soften	100	1
97	60	soften	99.01867	2
97	80	soften	98.72187	3
97	126	soften	96.95604	4
97	83	soften	96.62432	5
97	90	soften	96.51778	6
97	55	soften	95.10464	7
97	72	soften	94.61312	8
97	91	soften	93.65893	9
97	3	soften	93.17372	10
97	70	soften	88.85824	11
97	93	soften	87.9436	12
97	4	soften	87.67631	13
97	23	soften	87.59357	14
97	45	soften	87.483154	15
97	79	soften	87.101875	16
97	33	soften	86.75062	17
97	2	soften	86.0507	18
97	171	soften	86.01852	19
97	82	soften	85.93575	20
97	34	soften	85.935005	21
97	13	soften	84.2708	22
97	96	soften	84.26745	23
97	9	soften	84.05576	24
97	99	soften	84.04763	25
97	43	soften	83.80241	26
97	182	soften	83.75399	27
97	5	soften	83.45308	28
97	20	soften	83.16465	29
97	21	soften	82.73133	30
97	35	soften	81.39432	31
97	184	soften	81.270676	32
97	30	soften	81.20126	33
97	12	soften	80.75118	34
97	219	soften	80.64562	35
97	335	soften	80.52804	36
97	868	soften	80.45256	37
97	85	soften	80.32167	38
97	73	soften	80.08822	39
97	640	soften	79.40025	40
97	230	soften	79.32049	41
97	59	soften	79.09611	42
97	22	soften	78.88399	43
97	63	soften	77.961	44
97	50	soften	77.363846	45
97	41	soften	76.62274	46
97	69	soften	76.26596	47
97	8	soften	76.21107	48
97	78	soften	76.04258	49
97	28	soften	75.654884	50
97	593	soften	75.64411	51
97	18	soften	75.62027	52
97	187	soften	74.73311	53
97	44	soften	73.81174	54
97	66	soften	71.98521	55
97	488	soften	71.972725	56
97	98	soften	70.5074	57
97	39	soften	70.39313	58
97	19	soften	70.01878	59
97	7	soften	69.62246	60
97	176	soften	69.542015	61
97	285	soften	69.541534	62
97	64	soften	68.247536	63
97	58	soften	67.79486	64
97	14	soften	67.69599	65
97	54	soften	67.643845	66
97	89	soften	67.47835	67
97	74	soften	65.975586	68
97	10	soften	64.453384	69
97	65	soften	64.04494	70
97	26	soften	63.858555	71
97	27	soften	63.673634	72
97	455	soften	63.249268	73
97	901	soften	62.78117	74
97	108	soften	62.383984	75
97	24	soften	62.24885	76
97	647	soften	61.214275	77
97	86	soften	60.62283	78
97	185	soften	60.338608	79
97	52	soften	59.692417	80
97	785	soften	58.96656	81
97	49	soften	57.268394	82
97	95	soften	56.75116	83
97	61	soften	55.996544	84
97	87	soften	54.799805	85
97	6	soften	54.370575	86
97	94	soften	53.100628	87
97	222	soften	52.75708	88
97	47	soften	52.48082	89
97	51	soften	50.69171	90
97	92	soften	50.252316	91
97	56	soften	49.82766	92
97	31	soften	49.81461	93
97	67	soften	46.388325	94
97	88	soften	45.147465	95
97	921	soften	43.816463	96
97	1	soften	43.780933	97
97	84	soften	42.460712	98
97	62	soften	41.89628	99
97	36	soften	40.277138	100
97	40	soften	37.79018	101
97	25	soften	37.357067	102
98	88	enhance	100	1
98	31	enhance	98.14098	2
98	61	enhance	93.80401	3
98	285	enhance	92.58827	4
98	49	enhance	92.34483	5
98	640	enhance	92.22174	6
98	230	enhance	91.128586	7
98	13	enhance	90.91398	8
98	108	enhance	89.443405	9
98	222	enhance	89.041306	10
98	40	enhance	87.728424	11
98	182	enhance	87.29914	12
98	36	enhance	86.7294	13
98	33	enhance	86.27585	14
98	47	enhance	85.59546	15
98	71	enhance	84.27896	16
98	68	enhance	84.14952	17
98	176	enhance	83.729065	18
98	92	enhance	83.18969	19
98	67	enhance	82.75172	20
98	84	enhance	82.027176	21
98	1	enhance	81.98972	22
98	48	enhance	81.96225	23
98	94	enhance	81.939644	24
98	63	enhance	81.28717	25
98	25	enhance	80.88954	26
98	647	enhance	80.83377	27
98	75	enhance	80.2987	28
98	50	enhance	79.13954	29
98	17	enhance	78.702805	30
98	51	enhance	78.32539	31
98	39	enhance	78.24499	32
98	89	enhance	77.95957	33
98	56	enhance	76.27182	34
98	87	enhance	76.141174	35
98	43	enhance	75.89351	36
98	99	enhance	75.70832	37
98	187	enhance	75.25473	38
98	86	enhance	74.57527	39
98	785	enhance	74.33126	40
98	10	enhance	72.2373	41
98	46	enhance	72.137695	42
98	97	enhance	71.998024	43
98	54	enhance	71.648636	44
98	7	enhance	71.53536	45
98	34	enhance	71.43059	46
98	6	enhance	71.268486	47
98	15	enhance	71.15472	48
98	358	enhance	70.15908	49
98	70	enhance	70.12288	50
98	52	enhance	70.091125	51
98	155	enhance	70.036026	52
98	45	enhance	69.987175	53
98	19	enhance	69.58863	54
98	28	enhance	69.05651	55
98	882	enhance	68.920296	56
98	126	enhance	68.290565	57
98	24	enhance	68.105835	58
98	30	enhance	67.91863	59
98	185	enhance	67.86186	60
98	27	enhance	67.60947	61
98	76	enhance	67.43512	62
98	37	enhance	67.28455	63
98	455	enhance	66.326675	64
98	16	enhance	66.14967	65
98	2	enhance	66.09035	66
98	73	enhance	65.73124	67
98	29	enhance	64.55156	68
98	38	enhance	63.41006	69
98	62	enhance	62.634434	70
98	42	enhance	62.418438	71
98	90	enhance	62.079647	72
98	72	enhance	61.8488	73
98	593	enhance	60.889034	74
98	66	enhance	60.87858	75
98	79	enhance	58.72595	76
98	83	enhance	58.564453	77
98	18	enhance	57.069813	78
98	100	enhance	56.87907	79
98	82	enhance	56.59591	80
98	26	enhance	55.860855	81
98	80	enhance	55.73037	82
98	901	enhance	55.17019	83
98	77	enhance	55.143085	84
98	921	enhance	53.494633	85
98	53	enhance	53.416092	86
98	81	enhance	53.081684	87
98	93	enhance	50.381832	88
98	3	enhance	47.195816	89
98	32	enhance	45.805138	90
98	78	enhance	45.357426	91
98	5	enhance	43.37622	92
98	59	enhance	43.197636	93
98	868	enhance	42.67111	94
98	44	enhance	42.6281	95
98	14	enhance	41.128227	96
98	58	enhance	40.66121	97
98	55	enhance	40.477516	98
98	8	enhance	38.185036	99
98	23	enhance	37.663433	100
98	65	enhance	37.61722	101
98	60	enhance	35.52429	102
98	184	enhance	35.49195	103
98	21	enhance	34.585125	104
98	12	enhance	33.89363	105
98	171	enhance	32.93276	106
98	57	enhance	32.89614	107
98	85	enhance	32.096813	108
98	9	enhance	31.06377	109
98	4	enhance	31.032686	110
98	91	enhance	31.010706	111
98	11	enhance	30.907024	112
98	69	enhance	30.828478	113
98	488	enhance	30.58789	114
98	35	enhance	30.367325	115
98	219	enhance	29.736673	116
98	335	enhance	29.422544	117
98	22	enhance	28.910444	118
98	64	enhance	28.460346	119
98	20	enhance	26.919664	120
98	74	enhance	26.14427	121
98	96	enhance	25.480549	122
98	41	enhance	24.767708	123
98	95	enhance	22.640377	124
98	64	soften	100	1
98	74	soften	98.61232	2
98	11	soften	97.09078	3
98	91	soften	94.97233	4
98	60	soften	93.462364	5
98	96	soften	91.84068	6
98	55	soften	89.52284	7
98	335	soften	89.193146	8
98	184	soften	88.99461	9
98	21	soften	88.05888	10
98	4	soften	88.02674	11
98	171	soften	86.98365	12
98	22	soften	86.85083	13
98	20	soften	86.8418	14
98	219	soften	86.5816	15
98	23	soften	86.21145	16
98	3	soften	86.20429	17
98	80	soften	85.74347	18
98	85	soften	85.466095	19
98	868	soften	85.334946	20
98	95	soften	85.144196	21
98	12	soften	85.04313	22
98	93	soften	84.96448	23
98	35	soften	84.93727	24
98	9	soften	84.85016	25
98	83	soften	83.90724	26
98	59	soften	83.695435	27
98	79	soften	83.25574	28
98	41	soften	82.5144	29
98	72	soften	82.45493	30
98	78	soften	82.299416	31
98	5	soften	81.848694	32
98	90	soften	81.56253	33
98	126	soften	80.94655	34
98	69	soften	80.925705	35
98	44	soften	80.29158	36
98	70	soften	79.960175	37
98	82	soften	79.10678	38
98	18	soften	78.859764	39
98	45	soften	77.66288	40
98	34	soften	76.64448	41
98	593	soften	76.44295	42
98	2	soften	76.33676	43
98	8	soften	76.214226	44
98	66	soften	75.378456	45
98	28	soften	74.934395	46
98	73	soften	73.8645	47
98	43	soften	73.594086	48
98	94	soften	73.45045	49
98	99	soften	73.15582	50
98	30	soften	73.10442	51
98	63	soften	72.19297	52
98	39	soften	72.15407	53
98	182	soften	71.926155	54
98	49	soften	71.57372	55
98	50	soften	71.1029	56
98	13	soften	70.55088	57
98	27	soften	70.18703	58
98	176	soften	69.35548	59
98	7	soften	69.23096	60
98	92	soften	69.19362	61
98	187	soften	68.622955	62
98	222	soften	68.20686	63
98	33	soften	67.65378	64
98	285	soften	67.08965	65
98	86	soften	67.0841	66
98	56	soften	66.97083	67
98	61	soften	66.5484	68
98	640	soften	66.2643	69
98	230	soften	65.97211	70
98	51	soften	65.73715	71
98	47	soften	64.80912	72
98	31	soften	64.40726	73
99	90	enhance	100	1
99	63	enhance	98.40014	2
99	70	enhance	96.94232	3
99	126	enhance	96.76635	4
99	182	enhance	96.74999	5
99	43	enhance	96.748474	6
99	13	enhance	95.62594	7
99	50	enhance	95.4167	8
99	2	enhance	95.30129	9
99	34	enhance	93.08015	10
99	230	enhance	92.96293	11
99	49	enhance	92.80905	12
99	33	enhance	91.85365	13
99	640	enhance	91.850586	14
99	93	enhance	90.44956	15
99	82	enhance	89.459785	16
99	94	enhance	89.449	17
99	3	enhance	89.24989	18
99	61	enhance	89.07558	19
99	72	enhance	88.93927	20
99	83	enhance	87.122795	21
99	39	enhance	86.442726	22
99	593	enhance	86.21849	23
99	7	enhance	84.956116	24
99	80	enhance	83.29847	25
99	31	enhance	82.01492	26
99	23	enhance	81.94127	27
99	55	enhance	81.56773	28
99	45	enhance	81.31332	29
99	187	enhance	81.29592	30
99	5	enhance	80.023895	31
99	92	enhance	79.516945	32
99	222	enhance	77.33083	33
99	98	enhance	77.24874	34
99	79	enhance	76.94587	35
99	19	enhance	74.12175	36
99	44	enhance	73.740425	37
99	78	enhance	73.43405	38
99	60	enhance	73.360176	39
99	91	enhance	73.2649	40
99	4	enhance	72.98385	41
99	11	enhance	72.97699	42
99	184	enhance	72.454575	43
99	47	enhance	71.9242	44
99	9	enhance	71.89797	45
99	18	enhance	71.32168	46
99	108	enhance	71.25111	47
99	59	enhance	71.24374	48
99	868	enhance	70.78603	49
99	64	enhance	70.5969	50
99	285	enhance	70.47588	51
99	28	enhance	70.444275	52
99	56	enhance	69.89505	53
99	74	enhance	69.706955	54
99	89	enhance	69.448006	55
99	66	enhance	69.35285	56
99	10	enhance	69.14803	57
99	96	enhance	68.77411	58
99	30	enhance	68.620285	59
99	22	enhance	68.446785	60
99	8	enhance	67.762375	61
99	219	enhance	67.415344	62
99	88	enhance	66.80589	63
99	335	enhance	66.59139	64
99	21	enhance	66.30533	65
99	176	enhance	65.82378	66
99	54	enhance	65.068565	67
99	41	enhance	64.16614	68
99	58	enhance	63.804073	69
99	27	enhance	63.001667	70
99	171	enhance	62.94078	71
99	12	enhance	62.5448	72
99	20	enhance	62.476723	73
99	73	enhance	62.20421	74
99	85	enhance	61.92632	75
99	69	enhance	61.741493	76
99	455	enhance	60.727303	77
99	35	enhance	60.669376	78
99	86	enhance	59.042736	79
99	647	enhance	58.377563	80
99	52	enhance	57.98533	81
99	51	enhance	55.241306	82
99	1	enhance	55.203545	83
99	36	enhance	53.93133	84
99	15	enhance	53.636204	85
99	67	enhance	53.33877	86
99	14	enhance	51.408577	87
99	68	enhance	51.215664	88
99	95	enhance	51.140453	89
99	84	enhance	50.597237	90
99	185	enhance	50.339508	91
99	62	enhance	50.190567	92
99	77	enhance	50.140213	93
99	100	enhance	49.888344	94
99	65	enhance	49.566032	95
99	24	enhance	48.996887	96
99	901	enhance	48.288036	97
99	40	enhance	48.15529	98
99	48	enhance	47.61321	99
99	26	enhance	47.60039	100
99	71	enhance	47.464737	101
99	37	enhance	46.93699	102
99	488	enhance	46.875557	103
99	32	enhance	46.85478	104
99	785	enhance	46.47164	105
99	921	enhance	46.055798	106
99	57	enhance	44.99081	107
99	17	enhance	42.900486	108
99	25	enhance	41.949368	109
99	38	enhance	40.707973	110
99	81	enhance	40.038734	111
99	42	enhance	39.661633	112
99	87	enhance	39.603928	113
99	6	enhance	38.944748	114
99	76	enhance	38.857323	115
99	16	enhance	38.752296	116
99	75	enhance	37.215645	117
99	53	enhance	36.282387	118
99	97	enhance	35.25251	119
99	358	enhance	34.741398	120
99	29	enhance	33.47802	121
99	46	enhance	31.21951	122
99	155	enhance	28.772999	123
99	882	enhance	28.459805	124
99	11	soften	100	1
99	60	soften	97.128456	2
99	91	soften	96.87658	3
99	184	soften	93.38339	4
99	55	soften	92.70095	5
99	96	soften	92.44659	6
99	868	soften	91.48245	7
99	335	soften	91.478935	8
99	22	soften	90.73404	9
99	4	soften	89.52038	10
99	72	soften	88.99968	11
99	83	soften	88.77217	12
99	3	soften	88.71011	13
99	93	soften	88.54987	14
99	21	soften	87.79979	15
99	219	soften	87.554634	16
99	171	soften	87.5187	17
99	80	soften	86.69706	18
99	59	soften	86.611046	19
99	78	soften	86.424446	20
99	44	soften	86.13467	21
99	20	soften	85.608696	22
99	23	soften	85.374756	23
99	70	soften	85.36327	24
99	12	soften	84.960526	25
99	9	soften	84.92322	26
99	79	soften	84.635796	27
99	85	soften	84.43477	28
99	126	soften	83.956726	29
99	90	soften	83.90793	30
99	5	soften	81.87197	31
99	45	soften	81.7476	32
99	34	soften	79.60716	33
99	30	soften	78.573555	34
99	13	soften	78.361465	35
99	2	soften	76.64295	36
99	64	soften	71.92405	37
99	74	soften	68.30205	38
99	49	soften	54.97593	39
100	77	enhance	100	1
100	62	enhance	94.85175	2
100	42	enhance	94.78734	3
100	38	enhance	94.53549	4
100	455	enhance	94.009224	5
100	65	enhance	93.08885	6
100	76	enhance	91.87811	7
100	185	enhance	90.71617	8
100	81	enhance	90.34166	9
100	52	enhance	90.15102	10
100	24	enhance	89.7356	11
100	54	enhance	89.18951	12
100	32	enhance	88.70555	13
100	921	enhance	88.459175	14
100	53	enhance	88.31918	15
100	785	enhance	88.0105	16
100	6	enhance	86.7684	17
100	16	enhance	86.675995	18
100	29	enhance	86.47524	19
100	14	enhance	86.131386	20
100	27	enhance	85.42311	21
100	58	enhance	84.88273	22
100	358	enhance	84.71166	23
100	37	enhance	84.455505	24
100	97	enhance	84.452705	25
100	66	enhance	84.21152	26
100	10	enhance	83.92801	27
100	17	enhance	81.936005	28
100	593	enhance	80.909966	29
100	647	enhance	80.73302	30
100	18	enhance	80.0464	31
100	488	enhance	80.024155	32
100	8	enhance	79.128265	33
100	15	enhance	78.80438	34
100	69	enhance	78.4756	35
100	57	enhance	78.46796	36
100	78	enhance	78.36868	37
100	59	enhance	77.59908	38
100	71	enhance	77.51577	39
100	28	enhance	76.66583	40
100	41	enhance	76.21463	41
100	12	enhance	75.86053	42
100	108	enhance	75.76038	43
100	35	enhance	75.70096	44
100	219	enhance	75.43939	45
100	7	enhance	75.43645	46
100	26	enhance	75.33129	47
100	85	enhance	74.59801	48
100	48	enhance	74.08336	49
100	19	enhance	74.060425	50
100	901	enhance	73.70669	51
100	87	enhance	73.37134	52
100	335	enhance	72.83637	53
100	21	enhance	72.21901	54
100	20	enhance	71.677826	55
100	176	enhance	71.54331	56
100	86	enhance	71.35753	57
100	44	enhance	71.22676	58
100	68	enhance	70.971436	59
100	50	enhance	70.762825	60
100	39	enhance	70.57867	61
100	5	enhance	69.71528	62
100	171	enhance	68.996956	63
100	9	enhance	68.95554	64
100	95	enhance	68.829475	65
100	868	enhance	68.72819	66
100	89	enhance	68.331024	67
100	94	enhance	68.233406	68
100	36	enhance	67.619835	69
100	84	enhance	67.41402	70
100	40	enhance	66.98058	71
100	92	enhance	66.9798	72
100	1	enhance	66.907074	73
100	46	enhance	66.26372	74
100	82	enhance	66.097565	75
100	184	enhance	65.9254	76
100	96	enhance	65.920815	77
100	25	enhance	65.73808	78
100	22	enhance	65.08387	79
100	155	enhance	64.78118	80
100	882	enhance	64.2188	81
100	23	enhance	63.503387	82
100	285	enhance	63.33848	83
100	187	enhance	63.040154	84
100	75	enhance	62.880642	85
100	4	enhance	62.714314	86
100	63	enhance	59.130863	87
100	79	enhance	59.001087	88
100	34	enhance	58.636887	89
100	88	enhance	57.90592	90
100	56	enhance	57.16575	91
100	182	enhance	55.57639	92
100	98	enhance	54.804314	93
100	31	enhance	54.58025	94
100	74	enhance	54.493126	95
100	55	enhance	54.077656	96
100	93	enhance	53.527546	97
100	91	enhance	53.518524	98
100	49	enhance	51.00397	99
100	3	enhance	50.647873	100
100	70	enhance	49.734642	101
100	60	enhance	49.662014	102
100	64	enhance	48.844536	103
100	43	enhance	47.678696	104
100	2	enhance	47.456036	105
100	99	enhance	47.11005	106
100	222	enhance	46.90221	107
100	73	enhance	46.81284	108
100	11	enhance	46.71195	109
100	72	enhance	44.275192	110
100	83	enhance	44.165928	111
100	67	enhance	41.274654	112
100	51	enhance	40.950733	113
100	47	enhance	39.934067	114
100	45	enhance	39.518585	115
100	90	enhance	38.007687	116
100	230	enhance	37.681488	117
100	30	enhance	37.677498	118
100	13	enhance	37.249203	119
100	126	enhance	36.89117	120
100	61	enhance	36.628098	121
100	640	enhance	36.137997	122
100	80	enhance	31.67495	123
100	33	enhance	24.90576	124
100	80	soften	100	1
100	90	soften	97.57916	2
100	126	soften	97.53573	3
100	11	soften	97.191154	4
100	64	soften	96.50543	5
100	72	soften	95.2376	6
100	83	soften	95.233635	7
100	60	soften	95.07977	8
100	3	soften	92.50516	9
100	33	soften	91.85211	10
100	55	soften	91.83804	11
100	70	soften	91.09664	12
100	91	soften	90.86336	13
100	45	soften	90.23027	14
100	93	soften	89.92802	15
100	13	soften	89.86731	16
100	74	soften	89.8015	17
100	79	soften	88.58861	18
100	49	soften	87.73588	19
100	30	soften	87.61266	20
100	99	soften	87.14445	21
100	43	soften	86.73903	22
100	182	soften	86.41809	23
100	2	soften	86.21682	24
100	34	soften	86.020546	25
100	61	soften	85.90409	26
100	640	soften	85.676315	27
100	73	soften	84.638504	28
100	230	soften	84.606476	29
100	23	soften	84.0769	30
100	4	soften	83.93323	31
100	184	soften	83.28105	32
100	82	soften	82.5339	33
100	222	soften	82.09113	34
100	63	soften	81.68417	35
100	96	soften	81.12709	36
100	94	soften	81.11278	37
100	868	soften	80.614426	38
100	171	soften	80.52856	39
100	5	soften	80.33922	40
100	22	soften	79.686295	41
100	9	soften	79.53678	42
100	50	soften	79.37292	43
100	47	soften	79.12337	44
100	21	soften	78.99796	45
100	335	soften	78.75123	46
100	28	soften	78.703674	47
100	98	soften	78.69738	48
100	51	soften	78.53586	49
100	31	soften	78.45708	50
100	39	soften	78.41466	51
100	78	soften	78.18234	52
100	187	soften	77.941055	53
100	59	soften	77.82436	54
100	44	soften	77.72814	55
100	219	soften	77.50018	56
100	285	soften	77.36386	57
100	20	soften	77.337395	58
100	18	soften	77.23245	59
100	593	soften	77.114525	60
100	92	soften	76.76859	61
100	56	soften	76.60407	62
100	12	soften	75.75685	63
100	35	soften	75.27427	64
100	85	soften	75.20637	65
100	66	soften	74.830315	66
100	95	soften	74.1193	67
100	7	soften	74.00482	68
100	176	soften	73.9242	69
100	67	soften	73.59031	70
100	88	soften	73.35372	71
100	41	soften	73.27471	72
100	89	soften	73.060646	73
100	8	soften	73.05402	74
100	19	soften	72.206825	75
100	69	soften	71.89703	76
100	54	soften	71.58232	77
100	27	soften	70.69449	78
100	108	soften	70.26351	79
100	86	soften	70.175674	80
100	10	soften	69.740845	81
100	1	soften	69.600006	82
100	84	soften	69.58215	83
100	647	soften	67.89636	84
100	26	soften	67.66646	85
100	58	soften	67.60016	86
100	455	soften	67.38239	87
100	52	soften	66.46056	88
100	901	soften	66.34286	89
100	488	soften	66.15678	90
100	36	soften	66.05465	91
100	24	soften	65.76274	92
100	14	soften	65.2302	93
100	40	soften	65.03558	94
100	921	soften	64.133286	95
100	785	soften	64.03997	96
100	185	soften	63.938297	97
100	25	soften	63.774204	98
100	62	soften	63.330933	99
100	87	soften	63.26958	100
100	6	soften	62.468086	101
100	65	soften	62.446735	102
100	97	soften	61.093887	103
100	77	soften	60.97445	104
108	36	enhance	100	1
108	48	enhance	99.450966	2
108	40	enhance	99.238976	3
108	1	enhance	97.58158	4
108	71	enhance	97.13656	5
108	68	enhance	97.089455	6
108	647	enhance	96.95225	7
108	89	enhance	96.5445	8
108	25	enhance	96.48723	9
108	31	enhance	95.04346	10
108	7	enhance	94.41872	11
108	52	enhance	94.3176	12
108	86	enhance	94.27562	13
108	88	enhance	94.11213	14
108	285	enhance	93.92129	15
108	87	enhance	93.91302	16
108	84	enhance	93.7877	17
108	39	enhance	93.38301	18
108	17	enhance	93.04657	19
108	785	enhance	92.5106	20
108	6	enhance	91.96308	21
108	75	enhance	91.31341	22
108	455	enhance	91.2529	23
108	16	enhance	91.18107	24
108	98	enhance	91.08729	25
108	185	enhance	90.913155	26
108	92	enhance	90.84093	27
108	97	enhance	90.42877	28
108	38	enhance	89.53733	29
108	358	enhance	89.457054	30
108	15	enhance	89.266815	31
108	176	enhance	89.15221	32
108	24	enhance	88.37638	33
108	10	enhance	88.18033	34
108	42	enhance	88.1003	35
108	76	enhance	87.95522	36
108	62	enhance	87.85874	37
108	155	enhance	87.13092	38
108	882	enhance	86.39531	39
108	94	enhance	86.0133	40
108	187	enhance	85.886505	41
108	63	enhance	85.69145	42
108	56	enhance	84.79576	43
108	46	enhance	84.64858	44
108	37	enhance	84.52538	45
108	27	enhance	83.7607	46
108	29	enhance	83.42362	47
108	54	enhance	82.72636	48
108	49	enhance	82.38321	49
108	222	enhance	82.1519	50
108	901	enhance	80.97806	51
108	100	enhance	80.07359	52
108	26	enhance	79.2214	53
108	77	enhance	78.24049	54
108	50	enhance	77.87349	55
108	19	enhance	77.40623	56
108	67	enhance	76.54321	57
108	61	enhance	76.158165	58
108	640	enhance	75.983894	59
108	593	enhance	75.94919	60
108	13	enhance	75.26976	61
108	43	enhance	75.12717	62
108	28	enhance	74.380974	63
108	230	enhance	74.35009	64
108	81	enhance	74.21051	65
108	921	enhance	74.06804	66
108	47	enhance	72.89915	67
108	182	enhance	72.62084	68
108	99	enhance	71.1137	69
108	18	enhance	70.93014	70
108	66	enhance	70.68768	71
108	34	enhance	70.00248	72
108	51	enhance	68.97669	73
108	30	enhance	68.26596	74
108	58	enhance	68.142494	75
108	78	enhance	67.8393	76
108	53	enhance	66.40167	77
108	70	enhance	65.77976	78
108	73	enhance	65.73516	79
108	45	enhance	65.55493	80
108	44	enhance	64.4364	81
108	33	enhance	63.86101	82
108	868	enhance	62.573376	83
108	65	enhance	60.151447	84
108	14	enhance	59.818108	85
108	32	enhance	59.458458	86
108	2	enhance	59.032803	87
108	79	enhance	58.17418	88
108	93	enhance	57.770435	89
108	59	enhance	56.81117	90
108	184	enhance	56.38769	91
108	8	enhance	56.343643	92
108	126	enhance	55.781975	93
108	82	enhance	55.43879	94
108	72	enhance	54.796886	95
108	90	enhance	53.29978	96
108	3	enhance	53.110176	97
108	219	enhance	52.596474	98
108	83	enhance	51.63612	99
108	5	enhance	51.55682	100
108	57	enhance	51.11881	101
108	80	enhance	50.18523	102
108	335	enhance	50.039196	103
108	22	enhance	49.702072	104
108	23	enhance	47.80486	105
108	55	enhance	47.5979	106
108	21	enhance	47.26468	107
108	171	enhance	46.80789	108
108	41	enhance	46.714108	109
108	12	enhance	46.33407	110
108	69	enhance	46.19587	111
108	20	enhance	45.953335	112
108	96	enhance	45.621655	113
108	35	enhance	45.229774	114
108	85	enhance	45.185013	115
108	4	enhance	45.016476	116
108	9	enhance	44.65452	117
108	488	enhance	44.288807	118
108	64	enhance	41.870018	119
108	91	enhance	41.61594	120
108	95	enhance	41.133694	121
108	11	enhance	40.645546	122
108	74	enhance	40.264317	123
108	60	enhance	40.054314	124
108	64	soften	100	1
108	11	soften	99.7707	2
108	60	soften	97.71022	3
108	74	soften	96.9898	4
108	91	soften	95.502365	5
108	55	soften	93.58256	6
108	80	soften	93.47843	7
108	83	soften	92.13243	8
108	3	soften	90.861534	9
108	72	soften	90.759445	10
108	90	soften	90.61461	11
108	126	soften	90.52725	12
108	96	soften	88.9672	13
108	4	soften	88.530785	14
108	93	soften	88.11728	15
108	23	soften	87.50556	16
108	171	soften	86.867424	17
108	184	soften	86.73376	18
108	70	soften	86.40849	19
108	79	soften	86.37708	20
108	21	soften	86.07131	21
108	335	soften	85.99682	22
108	20	soften	85.111336	23
108	9	soften	85.018715	24
108	22	soften	84.43814	25
108	868	soften	84.25789	26
108	219	soften	84.21876	27
108	45	soften	83.9599	28
108	82	soften	83.46363	29
108	12	soften	83.415405	30
108	35	soften	83.27066	31
108	5	soften	83.25709	32
108	85	soften	83.20424	33
108	95	soften	83.15658	34
108	59	soften	82.6959	35
108	34	soften	82.35661	36
108	2	soften	82.2109	37
108	78	soften	80.55418	38
108	41	soften	80.17451	39
108	99	soften	79.98498	40
108	13	soften	79.798355	41
108	182	soften	79.77813	42
108	43	soften	79.59284	43
108	33	soften	79.07102	44
108	69	soften	78.87301	45
108	44	soften	78.74822	46
108	30	soften	78.6663	47
108	49	soften	78.61938	48
108	18	soften	78.37774	49
108	73	soften	78.21299	50
108	593	soften	77.11743	51
108	94	soften	76.7463	52
108	28	soften	76.53698	53
108	63	soften	76.354706	54
108	8	soften	76.188194	55
108	50	soften	75.74821	56
108	66	soften	75.42263	57
108	61	soften	75.390526	58
108	640	soften	75.20588	59
108	222	soften	74.81873	60
108	230	soften	74.50029	61
108	488	soften	73.462906	62
108	39	soften	73.33241	63
108	51	soften	72.72058	64
108	92	soften	72.68999	65
108	187	soften	72.6044	66
108	47	soften	72.35249	67
108	176	soften	71.91323	68
108	285	soften	70.90611	69
108	58	soften	70.631	70
108	56	soften	70.558624	71
108	7	soften	70.474014	72
108	54	soften	70.381	73
108	31	soften	69.72504	74
108	19	soften	69.26535	75
108	27	soften	69.040115	76
108	89	soften	68.46994	77
108	98	soften	68.43822	78
108	10	soften	68.19896	79
108	455	soften	67.96775	80
108	24	soften	67.19164	81
108	67	soften	66.90377	82
108	86	soften	66.43408	83
108	1	soften	65.35239	84
108	84	soften	65.3331	85
108	52	soften	65.17063	86
126	90	enhance	100	1
126	70	enhance	99.38456	2
126	83	enhance	97.59568	3
126	80	enhance	96.359024	4
126	34	enhance	95.94346	5
126	99	enhance	95.158966	6
126	49	enhance	94.48461	7
126	72	enhance	94.38025	8
126	43	enhance	94.32773	9
126	3	enhance	92.99302	10
126	182	enhance	92.52218	11
126	45	enhance	91.50481	12
126	13	enhance	91.45962	13
126	2	enhance	90.05871	14
126	93	enhance	88.52548	15
126	63	enhance	88.11471	16
126	50	enhance	87.34336	17
126	82	enhance	86.73479	18
126	94	enhance	85.78009	19
126	61	enhance	85.37546	20
126	79	enhance	85.29847	21
126	230	enhance	84.73837	22
126	55	enhance	84.25253	23
126	33	enhance	83.62763	24
126	640	enhance	82.63441	25
126	23	enhance	78.260155	26
126	74	enhance	78.24683	27
126	30	enhance	77.341324	28
126	5	enhance	76.66128	29
126	91	enhance	76.33496	30
126	11	enhance	76.074135	31
126	593	enhance	76.017845	32
126	39	enhance	75.91294	33
126	47	enhance	75.50007	34
126	60	enhance	75.104614	35
126	73	enhance	74.63167	36
126	64	enhance	73.68082	37
126	18	enhance	73.48982	38
126	9	enhance	72.81116	39
126	4	enhance	71.62679	40
126	187	enhance	71.61777	41
126	19	enhance	71.34208	42
126	78	enhance	70.876335	43
126	184	enhance	70.79887	44
126	96	enhance	70.142586	45
126	92	enhance	69.7485	46
126	285	enhance	68.851524	47
126	31	enhance	68.774666	48
126	222	enhance	68.65801	49
126	98	enhance	68.5226	50
126	59	enhance	68.20688	51
126	56	enhance	67.83906	52
126	7	enhance	67.837494	53
126	21	enhance	67.504555	54
126	44	enhance	66.43648	55
126	868	enhance	65.51655	56
126	219	enhance	65.47443	57
126	171	enhance	65.266304	58
126	22	enhance	64.87178	59
126	28	enhance	64.817345	60
126	20	enhance	64.39572	61
126	66	enhance	63.911026	62
126	335	enhance	63.462852	63
126	85	enhance	61.810596	64
126	69	enhance	61.331657	65
126	176	enhance	61.274162	66
126	12	enhance	60.990063	67
126	89	enhance	60.661377	68
126	41	enhance	60.42036	69
126	8	enhance	60.363686	70
126	54	enhance	59.767475	71
126	35	enhance	59.72291	72
126	88	enhance	59.494045	73
126	58	enhance	59.37006	74
126	10	enhance	58.973606	75
126	27	enhance	56.0562	76
126	95	enhance	55.801876	77
126	108	enhance	54.961376	78
126	455	enhance	51.296288	79
126	51	enhance	51.28731	80
126	86	enhance	50.955006	81
126	647	enhance	48.396038	82
126	1	enhance	47.98838	83
126	52	enhance	45.934883	84
126	488	enhance	45.84103	85
126	67	enhance	45.039684	86
126	14	enhance	42.744255	87
126	36	enhance	42.55445	88
126	24	enhance	42.398445	89
126	84	enhance	42.12562	90
126	65	enhance	40.742603	91
126	62	enhance	40.736164	92
126	15	enhance	39.751408	93
126	26	enhance	39.468014	94
126	185	enhance	39.172398	95
126	77	enhance	39.092705	96
126	32	enhance	38.906166	97
126	100	enhance	38.417866	98
126	921	enhance	37.524017	99
126	68	enhance	35.324116	100
126	57	enhance	34.50943	101
126	40	enhance	33.548103	102
126	71	enhance	32.37109	103
126	785	enhance	32.099625	104
126	901	enhance	31.437805	105
126	37	enhance	31.275377	106
126	48	enhance	30.32686	107
126	17	enhance	28.469704	108
126	6	enhance	28.128239	109
126	81	enhance	26.691055	110
126	53	enhance	26.45821	111
126	38	enhance	25.002354	112
126	25	enhance	24.196394	113
126	97	enhance	24.119612	114
126	76	enhance	24.094635	115
126	42	enhance	23.94923	116
126	87	enhance	23.231049	117
126	75	enhance	22.344877	118
126	16	enhance	21.219185	119
126	358	enhance	19.110533	120
126	29	enhance	18.657246	121
126	46	enhance	17.491255	122
126	155	enhance	13.283999	123
126	882	enhance	12.856704	124
126	11	soften	100	1
126	91	soften	96.81271	2
126	184	soften	96.13795	3
126	60	soften	95.66074	4
126	55	soften	91.41241	5
126	93	soften	89.115875	6
126	3	soften	88.183655	7
126	72	soften	86.9116	8
126	83	soften	86.05157	9
126	80	soften	85.914116	10
126	90	soften	82.39251	11
126	64	soften	73.120255	12
126	74	soften	68.63627	13
155	882	enhance	100	1
155	87	enhance	99.46985	2
155	25	enhance	97.30753	3
155	46	enhance	97.09404	4
155	75	enhance	95.93583	5
155	84	enhance	94.50966	6
155	48	enhance	94.35087	7
155	68	enhance	93.66934	8
155	71	enhance	91.998665	9
155	40	enhance	91.6906	10
155	36	enhance	91.467064	11
155	358	enhance	91.33541	12
155	17	enhance	90.917915	13
155	785	enhance	89.71827	14
155	76	enhance	87.796364	15
155	1	enhance	87.376854	16
155	97	enhance	84.04617	17
155	16	enhance	83.91698	18
155	6	enhance	83.60239	19
155	67	enhance	83.14139	20
155	108	enhance	83.10747	21
155	86	enhance	82.63272	22
155	37	enhance	82.54359	23
155	38	enhance	81.70529	24
155	176	enhance	81.036255	25
155	647	enhance	80.87064	26
155	15	enhance	80.73374	27
155	42	enhance	79.351494	28
155	29	enhance	79.24304	29
155	88	enhance	79.12494	30
155	24	enhance	77.27664	31
155	185	enhance	77.204315	32
155	52	enhance	76.69764	33
155	51	enhance	76.65173	34
155	285	enhance	76.29334	35
155	10	enhance	74.15267	36
155	92	enhance	73.85806	37
155	222	enhance	73.21663	38
155	62	enhance	71.13157	39
155	31	enhance	70.80944	40
155	89	enhance	70.1187	41
155	455	enhance	69.844505	42
155	98	enhance	68.02972	43
155	901	enhance	66.89252	44
155	27	enhance	65.93962	45
155	26	enhance	65.787125	46
155	100	enhance	65.3076	47
155	81	enhance	65.0509	48
155	7	enhance	63.254707	49
155	77	enhance	62.867252	50
155	39	enhance	62.26617	51
155	56	enhance	60.22292	52
155	47	enhance	60.218697	53
155	54	enhance	59.590904	54
155	921	enhance	56.840225	55
155	187	enhance	55.970448	56
155	19	enhance	55.26835	57
155	94	enhance	54.64267	58
155	53	enhance	54.555374	59
155	640	enhance	50.339317	60
155	66	enhance	47.616585	61
155	61	enhance	46.9999	62
155	50	enhance	45.37839	63
155	28	enhance	45.31453	64
155	13	enhance	44.505276	65
155	49	enhance	43.91063	66
155	63	enhance	43.559666	67
155	230	enhance	41.928997	68
155	65	enhance	40.83096	69
155	14	enhance	40.602955	70
155	593	enhance	40.41555	71
155	58	enhance	40.33758	72
155	182	enhance	40.319714	73
155	32	enhance	38.66164	74
155	78	enhance	38.116085	75
155	44	enhance	37.86622	76
155	18	enhance	37.60822	77
155	868	enhance	36.610073	78
155	30	enhance	33.74396	79
155	57	enhance	31.922525	80
155	73	enhance	31.60136	81
155	59	enhance	30.050508	82
155	33	enhance	29.984932	83
155	43	enhance	29.642433	84
155	34	enhance	28.418516	85
155	70	enhance	28.065695	86
155	184	enhance	27.804485	87
155	99	enhance	27.391417	88
155	8	enhance	26.32394	89
155	45	enhance	24.934118	90
155	22	enhance	24.669106	91
155	335	enhance	23.690811	92
155	72	enhance	23.394331	93
155	219	enhance	22.696861	94
155	93	enhance	20.286804	95
155	41	enhance	20.189077	96
155	488	enhance	20.13653	97
155	12	enhance	19.049088	98
155	79	enhance	18.944515	99
155	82	enhance	18.654734	100
155	171	enhance	17.679068	101
155	69	enhance	17.235632	102
155	83	enhance	17.16859	103
155	5	enhance	16.776964	104
155	21	enhance	16.660788	105
155	85	enhance	16.450897	106
155	35	enhance	16.316753	107
155	2	enhance	15.375677	108
155	4	enhance	14.988461	109
155	55	enhance	14.848655	110
155	96	enhance	14.8243685	111
155	20	enhance	14.059106	112
155	3	enhance	13.757523	113
155	95	enhance	13.474296	114
155	9	enhance	13.23202	115
155	126	enhance	12.859761	116
155	60	enhance	12.097024	117
155	23	enhance	10.808396	118
155	90	enhance	10.641862	119
155	64	enhance	10.561945	120
155	91	enhance	10.336127	121
155	11	enhance	9.68102	122
155	80	enhance	6.1235223	123
155	74	enhance	4.8520603	124
155	64	soften	100	1
155	11	soften	99.93127	2
155	80	soften	99.21221	3
155	74	soften	97.86049	4
155	60	soften	96.244095	5
155	90	soften	94.61581	6
155	91	soften	94.53577	7
155	126	soften	93.935234	8
155	55	soften	92.64972	9
155	3	soften	92.426155	10
155	83	soften	91.758514	11
155	79	soften	89.06106	12
155	23	soften	89.00593	13
155	72	soften	88.906784	14
155	93	soften	88.04062	15
155	4	soften	87.543205	16
155	96	soften	86.271515	17
155	45	soften	85.96775	18
155	171	soften	85.80852	19
155	70	soften	85.62277	20
155	2	soften	85.39447	21
155	21	soften	84.852776	22
155	20	soften	84.84227	23
155	9	soften	84.38725	24
155	5	soften	84.12463	25
155	82	soften	83.76154	26
155	34	soften	83.538666	27
155	184	soften	83.10952	28
155	35	soften	82.67611	29
155	43	soften	82.573105	30
155	99	soften	82.48215	31
155	85	soften	82.153854	32
155	219	soften	82.09653	33
155	95	soften	81.870804	34
155	335	soften	81.85099	35
155	33	soften	81.64462	36
155	12	soften	81.360916	37
155	30	soften	80.34544	38
155	22	soften	79.89765	39
155	73	soften	79.82788	40
155	182	soften	78.94206	41
155	59	soften	78.79242	42
155	868	soften	78.60054	43
155	49	soften	78.48599	44
155	13	soften	78.3129	45
155	69	soften	77.872185	46
155	41	soften	77.55678	47
155	78	soften	77.259384	48
155	18	soften	76.90629	49
155	63	soften	76.602455	50
155	8	soften	76.17528	51
155	593	soften	75.55721	52
155	230	soften	75.229546	53
155	28	soften	75.19379	54
155	50	soften	74.673164	55
155	61	soften	74.65392	56
155	44	soften	74.059555	57
155	640	soften	73.26823	58
155	94	soften	72.86192	59
155	488	soften	72.64534	60
155	187	soften	71.30134	61
155	66	soften	70.765305	62
155	39	soften	69.59506	63
155	56	soften	68.43285	64
155	7	soften	67.70943	65
155	58	soften	67.69983	66
155	47	soften	66.96369	67
155	54	soften	66.69038	68
155	14	soften	66.65447	69
155	31	soften	66.451904	70
155	222	soften	66.44214	71
155	92	soften	65.824684	72
155	19	soften	65.70929	73
155	89	soften	65.354164	74
155	98	soften	65.20071	75
155	65	soften	63.987644	76
155	285	soften	63.699528	77
155	27	soften	62.888256	78
155	176	soften	62.335556	79
155	455	soften	62.332203	80
155	26	soften	62.065098	81
155	921	soften	61.78794	82
155	10	soften	61.12195	83
155	51	soften	60.23261	84
155	901	soften	60.194977	85
155	108	soften	59.771038	86
155	24	soften	59.119232	87
155	88	soften	58.902203	88
155	647	soften	58.716446	89
155	62	soften	58.698875	90
155	52	soften	58.409824	91
155	185	soften	58.059372	92
155	77	soften	57.659286	93
155	1	soften	57.574238	94
155	100	soften	57.0524	95
155	86	soften	56.709538	96
155	67	soften	55.70816	97
155	84	soften	55.051105	98
155	785	soften	54.7327	99
155	36	soften	53.025127	100
155	6	soften	52.724064	101
155	71	soften	52.072178	102
155	17	soften	52.053177	103
155	97	soften	49.989613	104
155	40	soften	49.98233	105
155	48	soften	49.61137	106
155	87	soften	49.053204	107
155	25	soften	48.00584	108
171	20	enhance	100	1
171	219	enhance	96.75092	2
171	35	enhance	94.3751	3
171	95	enhance	92.28886	4
171	8	enhance	92.16564	5
171	5	enhance	89.65464	6
171	488	enhance	89.1911	7
171	85	enhance	89.1819	8
171	82	enhance	88.69839	9
171	55	enhance	88.442024	10
171	868	enhance	88.38103	11
171	12	enhance	88.245834	12
171	21	enhance	87.843445	13
171	335	enhance	87.34502	14
171	18	enhance	86.93212	15
171	69	enhance	86.84709	16
171	28	enhance	86.72609	17
171	11	enhance	86.67091	18
171	14	enhance	86.48702	19
171	9	enhance	86.19668	20
171	96	enhance	86.192566	21
171	23	enhance	86.18173	22
171	59	enhance	85.85024	23
171	64	enhance	85.494194	24
171	78	enhance	85.25646	25
171	65	enhance	85.25593	26
171	41	enhance	85.01815	27
171	593	enhance	84.977974	28
171	58	enhance	84.11122	29
171	74	enhance	83.342	30
171	4	enhance	83.12582	31
171	184	enhance	83.01892	32
171	60	enhance	83.01075	33
171	32	enhance	80.756	34
171	34	enhance	80.27637	35
171	3	enhance	78.44924	36
171	66	enhance	77.15585	37
171	50	enhance	76.77621	38
171	79	enhance	76.62552	39
171	54	enhance	76.493645	40
171	91	enhance	75.793106	41
171	455	enhance	75.24984	42
171	921	enhance	74.64398	43
171	77	enhance	74.22694	44
171	22	enhance	73.54786	45
171	100	enhance	72.47737	46
171	83	enhance	72.41473	47
171	93	enhance	72.05921	48
171	62	enhance	71.0151	49
171	44	enhance	69.31562	50
171	63	enhance	68.53743	51
171	70	enhance	68.29649	52
171	2	enhance	68.24178	53
171	24	enhance	67.44531	54
171	185	enhance	66.900444	55
171	7	enhance	66.69778	56
171	57	enhance	66.24008	57
171	19	enhance	66.08814	58
171	53	enhance	65.98317	59
171	126	enhance	65.834076	60
171	94	enhance	65.66523	61
171	27	enhance	65.338264	62
171	81	enhance	65.26722	63
171	43	enhance	65.162506	64
171	72	enhance	64.580246	65
171	90	enhance	64.51297	66
171	10	enhance	63.731785	67
171	187	enhance	63.126575	68
171	52	enhance	62.641792	69
171	80	enhance	62.576733	70
171	182	enhance	62.451424	71
171	99	enhance	62.43371	72
171	26	enhance	62.28554	73
171	45	enhance	60.960636	74
171	39	enhance	58.552288	75
171	42	enhance	58.03984	76
171	73	enhance	57.77107	77
171	38	enhance	57.589706	78
171	92	enhance	57.50485	79
171	89	enhance	56.300045	80
171	901	enhance	55.631573	81
171	49	enhance	55.001457	82
171	176	enhance	53.754063	83
171	785	enhance	53.5986	84
171	56	enhance	53.263485	85
171	647	enhance	52.84655	86
171	76	enhance	51.044933	87
171	37	enhance	48.92783	88
171	16	enhance	48.90378	89
171	6	enhance	48.273502	90
171	30	enhance	48.171883	91
171	29	enhance	47.11733	92
171	108	enhance	46.52051	93
171	285	enhance	43.918755	94
171	86	enhance	43.685905	95
171	15	enhance	42.316124	96
171	358	enhance	41.80953	97
171	97	enhance	41.63277	98
171	13	enhance	41.473183	99
171	1	enhance	40.650345	100
171	17	enhance	40.215816	101
171	230	enhance	39.562405	102
171	47	enhance	38.638245	103
171	71	enhance	37.174347	104
171	61	enhance	36.873165	105
171	31	enhance	36.75802	106
171	84	enhance	34.6602	107
171	98	enhance	33.332123	108
171	640	enhance	32.818386	109
171	222	enhance	32.586754	110
171	36	enhance	32.214325	111
171	33	enhance	30.964848	112
171	48	enhance	29.928675	113
171	87	enhance	29.78567	114
171	68	enhance	29.588049	115
171	88	enhance	29.061207	116
171	51	enhance	23.009617	117
171	40	enhance	22.566444	118
171	46	enhance	20.75576	119
171	25	enhance	19.559952	120
171	155	enhance	18.421162	121
171	882	enhance	16.917616	122
171	67	enhance	15.87396	123
171	75	enhance	15.159449	124
171	11	soften	100	1
171	90	soften	99.09724	2
171	126	soften	98.4178	3
171	93	soften	95.99491	4
171	3	soften	94.64637	5
171	91	soften	94.27554	6
171	55	soften	92.64919	7
171	184	soften	92.442696	8
171	79	soften	92.34745	9
171	868	soften	87.878914	10
171	22	soften	87.47547	11
171	4	soften	84.75087	12
171	96	soften	84.72234	13
171	23	soften	83.646034	14
171	21	soften	80.40534	15
171	64	soften	71.78749	16
171	80	soften	71.656456	17
171	72	soften	69.3119	18
171	60	soften	67.47254	19
171	70	soften	67.23252	20
171	83	soften	67.19522	21
171	45	soften	65.745895	22
171	74	soften	64.10894	23
171	335	soften	58.81933	24
176	285	enhance	100	1
176	92	enhance	99.64464	2
176	222	enhance	96.58576	3
176	84	enhance	95.2108	4
176	1	enhance	94.56598	5
176	51	enhance	94.272545	6
176	67	enhance	93.63805	7
176	86	enhance	93.186066	8
176	94	enhance	93.1153	9
176	36	enhance	92.81037	10
176	87	enhance	92.05717	11
176	71	enhance	91.43041	12
176	10	enhance	91.235504	13
176	24	enhance	91.10054	14
176	88	enhance	91.08742	15
176	108	enhance	90.69404	16
176	785	enhance	90.02953	17
176	68	enhance	89.56354	18
176	48	enhance	88.93273	19
176	25	enhance	88.71497	20
176	47	enhance	87.25905	21
176	75	enhance	86.95112	22
176	98	enhance	86.74258	23
176	40	enhance	86.56854	24
176	155	enhance	86.42875	25
176	52	enhance	86.195274	26
176	15	enhance	85.798134	27
176	31	enhance	85.404076	28
176	455	enhance	84.840065	29
176	17	enhance	84.73339	30
176	7	enhance	83.270454	31
176	19	enhance	83.20305	32
176	647	enhance	83.19654	33
176	39	enhance	82.7469	34
176	76	enhance	82.67977	35
176	882	enhance	82.12912	36
176	185	enhance	81.692986	37
176	182	enhance	81.38466	38
176	49	enhance	81.33736	39
176	46	enhance	81.284294	40
176	38	enhance	81.159065	41
176	13	enhance	81.11666	42
176	358	enhance	80.41581	43
176	50	enhance	80.277695	44
176	89	enhance	79.39184	45
176	27	enhance	79.002205	46
176	62	enhance	78.78537	47
176	6	enhance	77.99435	48
176	640	enhance	77.90463	49
176	54	enhance	77.89136	50
176	70	enhance	77.60273	51
176	42	enhance	77.46605	52
176	97	enhance	77.26941	53
176	100	enhance	76.92417	54
176	37	enhance	76.80626	55
176	187	enhance	76.69955	56
176	63	enhance	76.61999	57
176	77	enhance	75.93162	58
176	66	enhance	75.79163	59
176	61	enhance	75.51087	60
176	16	enhance	75.29723	61
176	593	enhance	74.44471	62
176	72	enhance	73.160095	63
176	868	enhance	72.26493	64
176	28	enhance	69.79874	65
176	83	enhance	69.794174	66
176	230	enhance	69.75145	67
176	56	enhance	69.47871	68
176	34	enhance	68.87263	69
176	59	enhance	68.20653	70
176	29	enhance	68.14754	71
176	82	enhance	67.36473	72
176	18	enhance	67.342354	73
176	99	enhance	66.833015	74
176	58	enhance	66.37333	75
176	78	enhance	66.18554	76
176	44	enhance	65.610535	77
176	901	enhance	65.087456	78
176	93	enhance	63.991657	79
176	43	enhance	63.854794	80
176	45	enhance	63.68712	81
176	126	enhance	63.264534	82
176	81	enhance	62.84108	83
176	26	enhance	62.762947	84
176	921	enhance	61.397747	85
176	55	enhance	60.752377	86
176	32	enhance	60.354294	87
176	3	enhance	60.040577	88
176	5	enhance	60.03789	89
176	184	enhance	59.996628	90
176	79	enhance	59.97065	91
176	53	enhance	59.628414	92
176	14	enhance	59.52661	93
176	33	enhance	59.4066	94
176	90	enhance	59.09613	95
176	335	enhance	58.167652	96
176	65	enhance	57.650658	97
176	12	enhance	57.24386	98
176	21	enhance	56.69943	99
176	22	enhance	56.559605	100
176	219	enhance	56.47952	101
176	2	enhance	56.37514	102
176	60	enhance	56.28376	103
176	9	enhance	55.63023	104
176	4	enhance	55.605835	105
176	73	enhance	55.36507	106
176	8	enhance	55.234333	107
176	171	enhance	55.021515	108
176	91	enhance	54.890106	109
176	85	enhance	54.85157	110
176	96	enhance	54.328648	111
176	23	enhance	54.235508	112
176	69	enhance	53.495377	113
176	41	enhance	53.051125	114
176	35	enhance	52.601624	115
176	30	enhance	52.58802	116
176	11	enhance	50.957996	117
176	20	enhance	50.816566	118
176	80	enhance	50.333786	119
176	74	enhance	49.686947	120
176	64	enhance	49.117313	121
176	488	enhance	48.977093	122
176	95	enhance	47.028736	123
176	57	enhance	40.9905	124
176	11	soften	100	1
176	90	soften	93.727425	2
176	91	soften	93.56545	3
176	3	soften	93.24125	4
176	126	soften	92.88447	5
176	55	soften	92.278435	6
176	79	soften	90.52684	7
176	93	soften	90.16128	8
176	184	soften	89.143326	9
176	96	soften	88.03441	10
176	23	soften	88.02449	11
176	30	soften	87.9114	12
176	4	soften	87.75625	13
176	171	soften	85.73273	14
176	2	soften	85.427826	15
176	34	soften	85.15042	16
176	21	soften	84.79225	17
176	22	soften	84.684685	18
176	219	soften	84.58053	19
176	99	soften	84.4852	20
176	9	soften	83.2974	21
176	868	soften	82.119774	22
176	82	soften	82.09453	23
176	18	soften	81.84317	24
176	35	soften	81.687706	25
176	85	soften	81.21583	26
176	59	soften	80.929955	27
176	44	soften	80.834114	28
176	12	soften	80.63917	29
176	182	soften	80.58998	30
176	63	soften	80.22721	31
176	28	soften	80.21981	32
176	39	soften	78.450195	33
176	69	soften	77.47027	34
176	50	soften	77.38262	35
176	66	soften	76.13992	36
176	64	soften	71.483246	37
176	285	soften	70.93781	38
176	80	soften	69.350075	39
176	74	soften	67.7854	40
176	60	soften	66.07817	41
176	83	soften	63.174988	42
176	72	soften	61.97254	43
176	45	soften	61.61992	44
176	70	soften	60.67084	45
176	43	soften	60.026493	46
176	73	soften	59.864647	47
176	335	soften	59.613136	48
176	20	soften	59.274445	49
176	78	soften	58.619595	50
176	33	soften	58.477543	51
176	5	soften	58.288437	52
176	49	soften	57.612938	53
176	13	soften	56.887917	54
176	95	soften	56.865948	55
176	41	soften	55.446342	56
176	593	soften	55.353535	57
176	61	soften	54.701958	58
176	230	soften	54.70144	59
176	94	soften	54.148624	60
176	640	soften	53.994072	61
176	222	soften	50.74399	62
176	92	soften	50.009285	63
176	51	soften	46.515602	64
182	50	enhance	100	1
182	13	enhance	96.73506	2
182	99	enhance	96.47486	3
182	70	enhance	95.63959	4
182	49	enhance	95.07578	5
182	126	enhance	93.81747	6
182	90	enhance	93.725945	7
182	640	enhance	93.60147	8
182	72	enhance	93.5856	9
182	94	enhance	93.49725	10
182	83	enhance	91.50912	11
182	230	enhance	91.353226	12
182	34	enhance	91.14806	13
182	61	enhance	90.98124	14
182	82	enhance	90.58413	15
182	33	enhance	89.41846	16
182	98	enhance	88.82208	17
182	63	enhance	88.147575	18
182	92	enhance	87.52008	19
182	43	enhance	86.41449	20
182	222	enhance	86.32952	21
182	2	enhance	84.7727	22
182	47	enhance	83.826866	23
182	285	enhance	83.43307	24
182	3	enhance	83.237335	25
182	31	enhance	83.14276	26
182	593	enhance	83.12104	27
182	93	enhance	82.74834	28
182	39	enhance	81.49204	29
182	19	enhance	81.28901	30
182	187	enhance	81.27779	31
182	88	enhance	80.94512	32
182	66	enhance	80.18204	33
182	55	enhance	80.14637	34
182	176	enhance	79.92773	35
182	10	enhance	79.20161	36
182	5	enhance	79.182945	37
182	7	enhance	78.45377	38
182	79	enhance	76.64479	39
182	54	enhance	76.582115	40
182	28	enhance	76.42705	41
182	23	enhance	75.774475	42
182	45	enhance	75.17338	43
182	60	enhance	75.15192	44
182	59	enhance	74.39405	45
182	51	enhance	74.221924	46
182	80	enhance	73.24888	47
182	108	enhance	72.55426	48
182	27	enhance	72.032486	49
182	18	enhance	71.79775	50
182	4	enhance	71.419815	51
182	78	enhance	70.16091	52
182	91	enhance	69.781815	53
182	9	enhance	69.67647	54
182	56	enhance	69.60619	55
182	44	enhance	68.67397	56
182	11	enhance	68.4529	57
182	67	enhance	68.411835	58
182	868	enhance	68.15362	59
182	8	enhance	67.14546	60
182	21	enhance	66.60039	61
182	12	enhance	66.4341	62
182	184	enhance	66.307014	63
182	89	enhance	66.04053	64
182	455	enhance	65.25471	65
182	647	enhance	64.92978	66
182	52	enhance	64.54829	67
182	85	enhance	63.931458	68
182	335	enhance	63.851383	69
182	64	enhance	63.638226	70
182	86	enhance	63.4883	71
182	22	enhance	63.38734	72
182	68	enhance	62.955708	73
182	30	enhance	62.947407	74
182	71	enhance	62.914597	75
182	1	enhance	62.811836	76
182	171	enhance	62.779602	77
182	219	enhance	62.640797	78
182	35	enhance	62.209286	79
182	36	enhance	62.051266	80
182	69	enhance	61.941498	81
182	15	enhance	61.739723	82
182	74	enhance	61.526062	83
182	73	enhance	61.325314	84
182	785	enhance	60.99297	85
182	96	enhance	60.944595	86
182	84	enhance	60.892925	87
182	41	enhance	60.402855	88
182	17	enhance	59.482292	89
182	185	enhance	58.852642	90
182	100	enhance	58.68661	91
182	77	enhance	58.518326	92
182	24	enhance	58.2343	93
182	48	enhance	57.6632	94
182	40	enhance	57.601395	95
182	20	enhance	57.37861	96
182	58	enhance	57.054775	97
182	37	enhance	56.110657	98
182	14	enhance	55.969303	99
182	62	enhance	55.793453	100
182	32	enhance	54.77226	101
182	65	enhance	53.84317	102
182	921	enhance	53.27882	103
182	76	enhance	52.444744	104
182	26	enhance	51.660397	105
182	901	enhance	51.585747	106
182	75	enhance	51.488678	107
182	87	enhance	51.278957	108
182	25	enhance	51.05014	109
182	53	enhance	50.688923	110
182	488	enhance	50.59907	111
182	6	enhance	50.57965	112
182	81	enhance	50.524	113
182	38	enhance	49.879513	114
182	358	enhance	49.73162	115
182	42	enhance	49.201504	116
182	16	enhance	49.020996	117
182	97	enhance	48.42235	118
182	46	enhance	48.26671	119
182	29	enhance	47.982254	120
182	95	enhance	47.236874	121
182	57	enhance	43.624367	122
182	155	enhance	42.232937	123
182	882	enhance	41.539505	124
182	11	soften	100	1
182	91	soften	97.8537	2
182	60	soften	95.18271	3
182	184	soften	95.07833	4
182	96	soften	94.19637	5
182	335	soften	92.459366	6
182	22	soften	91.8199	7
182	55	soften	91.25929	8
182	868	soften	90.47414	9
182	93	soften	90.15827	10
182	80	soften	89.878	11
182	4	soften	89.5265	12
182	3	soften	89.39352	13
182	21	soften	89.355515	14
182	219	soften	88.352905	15
182	78	soften	87.61307	16
182	79	soften	87.49557	17
182	44	soften	87.13346	18
182	23	soften	87.13179	19
182	171	soften	86.96009	20
182	59	soften	86.64361	21
182	72	soften	86.45066	22
182	20	soften	86.38233	23
182	83	soften	86.15221	24
182	85	soften	85.51263	25
182	12	soften	85.18795	26
182	9	soften	85.157265	27
182	90	soften	85.02355	28
182	70	soften	84.84731	29
182	126	soften	84.0972	30
182	35	soften	84.080894	31
182	5	soften	82.668076	32
182	45	soften	82.59205	33
182	30	soften	80.32544	34
182	34	soften	79.37726	35
182	82	soften	79.30268	36
182	2	soften	78.728455	37
182	43	soften	78.3917	38
182	99	soften	77.61272	39
182	13	soften	77.24204	40
182	64	soften	73.3171	41
182	74	soften	70.34405	42
182	94	soften	56.370884	43
182	49	soften	54.99921	44
184	22	enhance	100	1
184	335	enhance	99.54931	2
184	78	enhance	98.914825	3
184	44	enhance	98.2525	4
184	96	enhance	97.432175	5
184	64	enhance	97.257256	6
184	91	enhance	96.32861	7
184	219	enhance	95.701935	8
184	93	enhance	95.5808	9
184	74	enhance	94.94695	10
184	4	enhance	94.745895	11
184	59	enhance	94.455894	12
184	868	enhance	93.92897	13
184	11	enhance	93.7256	14
184	41	enhance	93.37785	15
184	55	enhance	93.25146	16
184	9	enhance	93.05937	17
184	23	enhance	92.96389	18
184	3	enhance	92.31696	19
184	21	enhance	91.25	20
184	593	enhance	91.20495	21
184	60	enhance	90.7587	22
184	5	enhance	89.50206	23
184	66	enhance	86.769775	24
184	69	enhance	86.70931	25
184	85	enhance	86.624954	26
184	12	enhance	86.38657	27
184	18	enhance	84.121735	28
184	39	enhance	83.1796	29
184	35	enhance	83.14798	30
184	20	enhance	82.66814	31
184	70	enhance	82.66186	32
184	27	enhance	82.64257	33
184	94	enhance	82.53826	34
184	171	enhance	81.4216	35
184	72	enhance	81.020775	36
184	10	enhance	80.81244	37
184	58	enhance	79.34106	38
184	8	enhance	78.79375	39
184	83	enhance	78.66765	40
184	90	enhance	78.50525	41
184	82	enhance	78.38361	42
184	79	enhance	78.27097	43
184	50	enhance	77.789894	44
184	7	enhance	76.69446	45
184	455	enhance	75.65687	46
184	52	enhance	73.64716	47
184	54	enhance	72.81075	48
184	28	enhance	71.853424	49
184	34	enhance	70.54838	50
184	99	enhance	70.48803	51
184	126	enhance	70.0407	52
184	92	enhance	68.567566	53
184	77	enhance	68.351845	54
184	65	enhance	68.32216	55
184	100	enhance	67.918465	56
184	63	enhance	67.63879	57
184	86	enhance	67.52632	58
184	95	enhance	67.27078	59
184	80	enhance	66.43882	60
184	182	enhance	64.69129	61
184	19	enhance	63.825428	62
184	43	enhance	62.217743	63
184	49	enhance	60.922745	64
184	14	enhance	60.67541	65
184	2	enhance	60.60516	66
184	62	enhance	60.594536	67
184	488	enhance	60.466175	68
184	24	enhance	58.497864	69
184	176	enhance	57.4868	70
184	187	enhance	56.80355	71
184	285	enhance	55.47139	72
184	185	enhance	55.228954	73
184	108	enhance	54.963234	74
184	45	enhance	54.25208	75
184	32	enhance	53.67566	76
184	647	enhance	52.941784	77
184	921	enhance	52.85478	78
184	89	enhance	52.108894	79
184	13	enhance	51.48376	80
184	38	enhance	51.275063	81
184	26	enhance	50.301067	82
184	42	enhance	50.07382	83
184	53	enhance	49.25804	84
184	6	enhance	49.14604	85
184	56	enhance	48.643578	86
184	15	enhance	48.29659	87
184	785	enhance	48.26471	88
184	76	enhance	47.23303	89
184	222	enhance	47.04329	90
184	73	enhance	46.926487	91
184	81	enhance	46.80866	92
184	57	enhance	46.02832	93
184	97	enhance	45.9034	94
184	84	enhance	45.330536	95
184	16	enhance	44.843655	96
184	30	enhance	44.789486	97
184	901	enhance	44.492886	98
184	1	enhance	44.080357	99
184	29	enhance	43.69515	100
184	640	enhance	43.661427	101
184	68	enhance	42.6874	102
184	17	enhance	42.16246	103
184	48	enhance	42.161087	104
184	37	enhance	41.76848	105
184	358	enhance	41.409946	106
184	230	enhance	41.060356	107
184	36	enhance	40.95008	108
184	61	enhance	39.795185	109
184	31	enhance	39.575203	110
184	47	enhance	38.638092	111
184	71	enhance	37.827446	112
184	87	enhance	37.09584	113
184	88	enhance	36.62219	114
184	40	enhance	35.285606	115
184	98	enhance	35.231182	116
184	51	enhance	33.011635	117
184	33	enhance	31.76912	118
184	46	enhance	31.601917	119
184	25	enhance	31.569025	120
184	882	enhance	29.876646	121
184	75	enhance	29.258204	122
184	155	enhance	28.414175	123
184	67	enhance	25.364777	124
184	11	soften	100	1
184	60	soften	98.43223	2
184	83	soften	98.24312	3
184	72	soften	98.07624	4
184	80	soften	97.52227	5
184	90	soften	96.33476	6
184	55	soften	95.08127	7
184	3	soften	93.457184	8
184	91	soften	89.894424	9
184	93	soften	88.544655	10
184	64	soften	68.18282	11
184	74	soften	61.049034	12
185	62	enhance	100	1
185	42	enhance	98.80321	2
185	38	enhance	98.474724	3
185	785	enhance	98.169334	4
185	16	enhance	97.10955	5
185	455	enhance	96.678375	6
185	921	enhance	96.18726	7
185	6	enhance	96.10574	8
185	76	enhance	96.07385	9
185	24	enhance	95.70584	10
185	81	enhance	95.46995	11
185	358	enhance	94.44829	12
185	647	enhance	94.44036	13
185	29	enhance	94.14585	14
185	26	enhance	93.54801	15
185	17	enhance	93.1238	16
185	100	enhance	92.83552	17
185	77	enhance	92.05547	18
185	52	enhance	91.83508	19
185	97	enhance	91.69308	20
185	54	enhance	90.79079	21
185	71	enhance	90.53667	22
185	37	enhance	89.75703	23
185	89	enhance	88.77934	24
185	108	enhance	88.02561	25
185	901	enhance	87.74898	26
185	53	enhance	87.56333	27
185	14	enhance	86.49672	28
185	48	enhance	86.16519	29
185	1	enhance	85.856255	30
185	87	enhance	85.517815	31
185	65	enhance	84.8287	32
185	36	enhance	84.56789	33
185	10	enhance	84.30583	34
185	68	enhance	84.24718	35
185	27	enhance	83.16104	36
185	32	enhance	82.40656	37
185	84	enhance	81.8101	38
185	7	enhance	80.99043	39
185	40	enhance	80.79795	40
185	15	enhance	80.70149	41
185	46	enhance	80.19366	42
185	25	enhance	79.539	43
185	18	enhance	79.278656	44
185	56	enhance	79.24447	45
185	155	enhance	78.37113	46
185	882	enhance	78.07778	47
185	58	enhance	77.85978	48
185	187	enhance	77.830284	49
185	176	enhance	77.753586	50
185	28	enhance	77.10938	51
185	86	enhance	76.3506	52
185	75	enhance	76.30685	53
185	66	enhance	74.14263	54
185	593	enhance	73.96638	55
185	8	enhance	73.87536	56
185	285	enhance	73.63369	57
185	19	enhance	73.29671	58
185	92	enhance	73.278	59
185	39	enhance	73.19292	60
185	488	enhance	72.821396	61
185	50	enhance	72.62707	62
185	88	enhance	72.469894	63
185	78	enhance	72.21823	64
185	31	enhance	69.898926	65
185	57	enhance	68.979004	66
185	95	enhance	67.79507	67
185	63	enhance	67.14887	68
185	94	enhance	67.099785	69
185	98	enhance	66.91408	70
185	20	enhance	66.65382	71
185	34	enhance	66.38484	72
185	219	enhance	66.23747	73
185	171	enhance	65.17573	74
185	35	enhance	64.208466	75
185	59	enhance	62.83494	76
185	73	enhance	62.488094	77
185	12	enhance	60.115612	78
185	82	enhance	59.708935	79
185	85	enhance	59.410812	80
185	868	enhance	59.391262	81
185	49	enhance	58.777756	82
185	43	enhance	58.717377	83
185	69	enhance	58.54891	84
185	5	enhance	57.50859	85
185	335	enhance	57.219746	86
185	30	enhance	57.17271	87
185	47	enhance	57.06535	88
185	21	enhance	57.03942	89
185	182	enhance	57.035686	90
185	41	enhance	56.89966	91
185	44	enhance	56.122498	92
185	79	enhance	55.116085	93
185	184	enhance	54.86068	94
185	222	enhance	54.830326	95
185	67	enhance	54.810505	96
185	45	enhance	52.78587	97
185	96	enhance	52.173622	98
185	51	enhance	50.491627	99
185	9	enhance	50.431774	100
185	61	enhance	49.549934	101
185	23	enhance	49.468834	102
185	230	enhance	48.93313	103
185	2	enhance	48.74652	104
185	99	enhance	48.646645	105
185	4	enhance	48.223637	106
185	22	enhance	47.914127	107
185	70	enhance	46.477085	108
185	55	enhance	45.58082	109
185	640	enhance	45.263584	110
185	13	enhance	44.489918	111
185	3	enhance	44.073677	112
185	93	enhance	42.821583	113
185	74	enhance	42.331955	114
185	83	enhance	41.99263	115
185	126	enhance	38.494507	116
185	72	enhance	38.152557	117
185	64	enhance	37.545296	118
185	91	enhance	37.204582	119
185	11	enhance	36.66455	120
185	60	enhance	36.194836	121
185	80	enhance	35.734566	122
185	33	enhance	34.66339	123
185	90	enhance	32.963104	124
185	64	soften	100	1
185	80	soften	99.695045	2
185	11	soften	98.88685	3
185	60	soften	96.32035	4
185	90	soften	96.2087	5
185	126	soften	95.49494	6
185	74	soften	95.291756	7
185	91	soften	95.10194	8
185	72	soften	94.03285	9
185	83	soften	93.64992	10
185	3	soften	92.483444	11
185	55	soften	92.16907	12
185	93	soften	91.64692	13
185	70	soften	90.77954	14
185	79	soften	90.0148	15
185	45	soften	88.75516	16
185	33	soften	87.65656	17
185	13	soften	87.247086	18
185	23	soften	86.630844	19
185	184	soften	86.63004	20
185	96	soften	86.12909	21
185	2	soften	85.972275	22
185	4	soften	85.97097	23
185	49	soften	85.51071	24
185	99	soften	85.30687	25
185	43	soften	84.32504	26
185	30	soften	84.21272	27
185	34	soften	83.99124	28
185	182	soften	83.8769	29
185	22	soften	83.51683	30
185	21	soften	83.47659	31
185	868	soften	83.34251	32
185	335	soften	83.106766	33
185	61	soften	82.85359	34
185	82	soften	82.74694	35
185	640	soften	82.70351	36
185	73	soften	82.43822	37
185	171	soften	82.14743	38
185	9	soften	82.146996	39
185	5	soften	82.06787	40
185	230	soften	81.73524	41
185	94	soften	81.05219	42
185	59	soften	81.00151	43
185	63	soften	80.70993	44
185	219	soften	80.37898	45
185	222	soften	80.367096	46
185	20	soften	80.132935	47
185	44	soften	80.05739	48
185	78	soften	80.00547	49
185	12	soften	79.4211	50
185	85	soften	79.360756	51
185	18	soften	78.511536	52
185	28	soften	78.39475	53
185	39	soften	78.324135	54
185	35	soften	78.22076	55
185	593	soften	78.153946	56
185	50	soften	77.895935	57
185	95	soften	77.01161	58
185	51	soften	76.40571	59
185	41	soften	76.38407	60
185	47	soften	76.31341	61
185	31	soften	75.98661	62
185	66	soften	75.84645	63
185	285	soften	75.66579	64
185	92	soften	75.50162	65
185	98	soften	75.500565	66
185	69	soften	75.44714	67
185	187	soften	74.734535	68
185	176	soften	73.97691	69
185	56	soften	73.53309	70
185	8	soften	73.276146	71
185	7	soften	72.95477	72
185	67	soften	71.62004	73
185	27	soften	71.26384	74
185	54	soften	71.14972	75
185	89	soften	71.10979	76
185	86	soften	70.79584	77
185	88	soften	70.56694	78
185	19	soften	70.15916	79
185	10	soften	69.7253	80
185	84	soften	69.145615	81
185	58	soften	69.06041	82
185	108	soften	68.93877	83
185	488	soften	68.51542	84
185	455	soften	68.31999	85
185	1	soften	68.090576	86
185	24	soften	67.17998	87
185	52	soften	67.012215	88
185	647	soften	66.80817	89
185	14	soften	65.96998	90
185	26	soften	65.47709	91
185	36	soften	64.741066	92
185	62	soften	63.59355	93
185	785	soften	63.39306	94
187	7	enhance	100	1
187	89	enhance	98.24972	2
187	901	enhance	97.99789	3
187	56	enhance	97.05661	4
187	19	enhance	94.703186	5
187	34	enhance	92.56705	6
187	43	enhance	92.1381	7
187	26	enhance	91.39587	8
187	108	enhance	90.43924	9
187	50	enhance	90.30203	10
187	92	enhance	90.234604	11
187	63	enhance	89.54619	12
187	1	enhance	87.21118	13
187	182	enhance	85.664764	14
187	99	enhance	85.440216	15
187	31	enhance	85.22846	16
187	285	enhance	84.878716	17
187	185	enhance	84.64441	18
187	15	enhance	84.570335	19
187	647	enhance	84.350975	20
187	49	enhance	83.44322	21
187	39	enhance	83.32192	22
187	94	enhance	82.36275	23
187	10	enhance	81.08751	24
187	37	enhance	80.87288	25
187	98	enhance	80.7003	26
187	88	enhance	80.31177	27
187	71	enhance	80.19442	28
187	47	enhance	80.11884	29
187	785	enhance	79.98566	30
187	62	enhance	79.87444	31
187	455	enhance	79.47031	32
187	176	enhance	79.39225	33
187	13	enhance	79.27145	34
187	921	enhance	79.22393	35
187	36	enhance	79.12744	36
187	16	enhance	78.98884	37
187	54	enhance	78.76795	38
187	30	enhance	78.68187	39
187	8	enhance	78.67043	40
187	81	enhance	78.40119	41
187	593	enhance	78.188484	42
187	70	enhance	77.41046	43
187	83	enhance	77.40625	44
187	61	enhance	77.17791	45
187	58	enhance	76.913605	46
187	640	enhance	76.82749	47
187	82	enhance	76.77527	48
187	126	enhance	76.5401	49
187	45	enhance	76.51029	50
187	17	enhance	76.47985	51
187	222	enhance	76.33008	52
187	68	enhance	76.32878	53
187	230	enhance	76.18922	54
187	52	enhance	75.86979	55
187	48	enhance	74.97894	56
187	3	enhance	74.88083	57
187	42	enhance	73.04562	58
187	72	enhance	73.00697	59
187	38	enhance	72.959145	60
187	78	enhance	72.79702	61
187	84	enhance	72.327415	62
187	18	enhance	72.04663	63
187	33	enhance	71.89439	64
187	24	enhance	71.765236	65
187	55	enhance	71.720566	66
187	28	enhance	71.48728	67
187	86	enhance	71.457115	68
187	73	enhance	71.31621	69
187	90	enhance	71.20319	70
187	76	enhance	71.04638	71
187	2	enhance	71.00261	72
187	14	enhance	70.310234	73
187	27	enhance	70.202736	74
187	100	enhance	70.161095	75
187	40	enhance	70.079384	76
187	6	enhance	69.82896	77
187	77	enhance	69.58469	78
187	358	enhance	69.55524	79
187	87	enhance	68.89218	80
187	57	enhance	68.642204	81
187	25	enhance	67.885544	82
187	66	enhance	67.63382	83
187	65	enhance	67.21786	84
187	171	enhance	66.88347	85
187	868	enhance	66.83568	86
187	51	enhance	66.39494	87
187	93	enhance	65.812904	88
187	29	enhance	65.79919	89
187	67	enhance	65.61297	90
187	219	enhance	65.20381	91
187	5	enhance	64.9195	92
187	44	enhance	64.40492	93
187	46	enhance	63.681763	94
187	20	enhance	63.317696	95
187	4	enhance	63.246983	96
187	75	enhance	63.10428	97
187	80	enhance	62.52152	98
187	97	enhance	62.220634	99
187	882	enhance	62.173916	100
187	155	enhance	61.79068	101
187	184	enhance	61.364822	102
187	59	enhance	60.531998	103
187	23	enhance	60.517433	104
187	9	enhance	60.17864	105
187	79	enhance	59.63268	106
187	95	enhance	59.608303	107
187	32	enhance	59.077812	108
187	11	enhance	58.914867	109
187	41	enhance	58.63381	110
187	60	enhance	58.1126	111
187	35	enhance	56.796238	112
187	335	enhance	55.96747	113
187	96	enhance	55.266483	114
187	22	enhance	55.237213	115
187	488	enhance	55.00166	116
187	53	enhance	54.472496	117
187	64	enhance	53.954674	118
187	12	enhance	53.154152	119
187	69	enhance	52.868587	120
187	91	enhance	52.324093	121
187	21	enhance	51.65789	122
187	74	enhance	51.37775	123
187	85	enhance	50.797386	124
187	64	soften	100	1
187	74	soften	96.89761	2
187	11	soften	95.60448	3
187	91	soften	95.499664	4
187	60	soften	92.40112	5
187	184	soften	89.321434	6
187	96	soften	89.275505	7
187	80	soften	89.16248	8
187	93	soften	88.13046	9
187	55	soften	87.00529	10
187	22	soften	86.88648	11
187	335	soften	86.833885	12
187	72	soften	85.87135	13
187	3	soften	85.66133	14
187	21	soften	85.442375	15
187	79	soften	85.39752	16
187	868	soften	85.0006	17
187	90	soften	84.77502	18
187	83	soften	84.68367	19
187	4	soften	84.12543	20
187	70	soften	83.95152	21
187	23	soften	83.71899	22
187	126	soften	83.449776	23
187	59	soften	82.49118	24
187	44	soften	81.70568	25
187	219	soften	81.48388	26
187	85	soften	81.07873	27
187	9	soften	80.991615	28
187	78	soften	80.85779	29
187	12	soften	80.59159	30
187	171	soften	80.30496	31
187	45	soften	79.74917	32
187	20	soften	79.741394	33
187	5	soften	79.0299	34
187	35	soften	78.17884	35
187	94	soften	77.91839	36
187	41	soften	77.76501	37
187	18	soften	77.43404	38
187	2	soften	77.01783	39
187	95	soften	76.92272	40
187	13	soften	76.86602	41
187	82	soften	76.53003	42
187	49	soften	76.50937	43
187	69	soften	76.3925	44
187	39	soften	76.16807	45
187	593	soften	75.77489	46
187	66	soften	75.73488	47
187	99	soften	75.23646	48
187	222	soften	74.916214	49
187	34	soften	74.8535	50
187	28	soften	74.6407	51
187	182	soften	74.41054	52
187	73	soften	74.35793	53
187	30	soften	74.264534	54
187	63	soften	73.85673	55
187	43	soften	73.73606	56
187	176	soften	73.089035	57
187	33	soften	72.67089	58
187	640	soften	72.45804	59
187	51	soften	72.41698	60
187	285	soften	72.29029	61
187	92	soften	72.15729	62
187	61	soften	72.151535	63
187	50	soften	71.40906	64
187	230	soften	70.74172	65
187	8	soften	69.28031	66
219	335	enhance	100	1
219	20	enhance	99.05085	2
219	78	enhance	98.68278	3
219	96	enhance	98.62801	4
219	35	enhance	98.26735	5
219	41	enhance	98.07221	6
219	21	enhance	97.57392	7
219	59	enhance	97.27912	8
219	85	enhance	97.08352	9
219	23	enhance	96.716644	10
219	5	enhance	96.680336	11
219	9	enhance	96.65226	12
219	12	enhance	96.42034	13
219	184	enhance	96.28511	14
219	69	enhance	95.921295	15
219	4	enhance	95.61924	16
219	8	enhance	95.47113	17
219	171	enhance	95.46762	18
219	593	enhance	94.84052	19
219	74	enhance	94.38177	20
219	22	enhance	92.673904	21
219	18	enhance	91.6327	22
219	55	enhance	91.14212	23
219	868	enhance	90.74894	24
219	91	enhance	90.46071	25
219	64	enhance	90.10682	26
219	58	enhance	88.849495	27
219	44	enhance	88.777664	28
219	95	enhance	88.520035	29
219	11	enhance	88.17626	30
219	82	enhance	87.97518	31
219	66	enhance	87.68567	32
219	3	enhance	87.66815	33
219	65	enhance	87.51488	34
219	93	enhance	85.95383	35
219	60	enhance	85.75621	36
219	488	enhance	85.121506	37
219	14	enhance	83.80967	38
219	455	enhance	82.01539	39
219	79	enhance	80.27044	40
219	54	enhance	80.15457	41
219	77	enhance	79.54482	42
219	50	enhance	79.43641	43
219	28	enhance	79.25326	44
219	27	enhance	78.29482	45
219	100	enhance	78.19369	46
219	32	enhance	77.338844	47
219	34	enhance	76.85635	48
219	7	enhance	75.48235	49
219	10	enhance	74.99629	50
219	83	enhance	73.78868	51
219	70	enhance	73.63465	52
219	52	enhance	73.444534	53
219	94	enhance	73.31331	54
219	62	enhance	72.30772	55
219	921	enhance	72.216385	56
219	39	enhance	71.46694	57
219	72	enhance	70.79078	58
219	90	enhance	70.4911	59
219	24	enhance	68.26906	60
219	63	enhance	67.16545	61
219	185	enhance	67.088455	62
219	53	enhance	66.29492	63
219	99	enhance	65.98523	64
219	2	enhance	65.390816	65
219	19	enhance	65.21691	66
219	126	enhance	65.16799	67
219	81	enhance	64.13991	68
219	57	enhance	63.89979	69
219	43	enhance	63.25025	70
219	80	enhance	62.73394	71
219	182	enhance	61.486824	72
219	26	enhance	61.167507	73
219	42	enhance	60.88656	74
219	38	enhance	60.879974	75
219	187	enhance	60.72498	76
219	92	enhance	60.09968	77
219	86	enhance	55.980453	78
219	901	enhance	55.45496	79
219	89	enhance	55.24241	80
219	647	enhance	55.06638	81
219	785	enhance	54.93179	82
219	45	enhance	54.66531	83
219	176	enhance	54.446594	84
219	76	enhance	54.270145	85
219	49	enhance	54.17749	86
219	6	enhance	52.585957	87
219	16	enhance	52.57509	88
219	73	enhance	51.748135	89
219	108	enhance	51.580196	90
219	29	enhance	50.99709	91
219	56	enhance	50.184513	92
219	37	enhance	49.514603	93
219	97	enhance	47.00102	94
219	15	enhance	45.88048	95
219	358	enhance	45.731075	96
219	285	enhance	45.323444	97
219	30	enhance	43.770737	98
219	17	enhance	42.945404	99
219	13	enhance	40.818768	100
219	1	enhance	40.563435	101
219	84	enhance	38.415123	102
219	71	enhance	37.970978	103
219	48	enhance	36.457405	104
219	230	enhance	36.21816	105
219	31	enhance	35.535423	106
219	68	enhance	35.390873	107
219	36	enhance	34.918762	108
219	222	enhance	34.914658	109
219	87	enhance	34.347996	110
219	640	enhance	32.711422	111
219	61	enhance	32.709442	112
219	47	enhance	32.303463	113
219	98	enhance	29.698063	114
219	88	enhance	27.75511	115
219	40	enhance	27.291805	116
219	33	enhance	25.968306	117
219	46	enhance	25.782001	118
219	25	enhance	24.69587	119
219	155	enhance	23.335894	120
219	882	enhance	23.011934	121
219	51	enhance	21.981344	122
219	75	enhance	20.179344	123
219	67	enhance	14.681407	124
219	126	soften	100	1
219	90	soften	99.662186	2
219	11	soften	99.38326	3
219	3	soften	94.50323	4
219	55	soften	93.71649	5
219	93	soften	93.02872	6
219	91	soften	91.339584	7
219	79	soften	89.50443	8
219	184	soften	87.33517	9
219	868	soften	85.17155	10
219	4	soften	83.99094	11
219	22	soften	82.67479	12
219	23	soften	82.02814	13
219	96	soften	80.55617	14
219	171	soften	79.296196	15
219	21	soften	77.10034	16
219	80	soften	70.98299	17
219	72	soften	70.31068	18
219	64	soften	69.29074	19
219	83	soften	68.99579	20
219	60	soften	68.05185	21
219	70	soften	66.8272	22
219	45	soften	65.58985	23
219	74	soften	61.34042	24
219	335	soften	55.90003	25
222	51	enhance	100	1
222	67	enhance	99.90095	2
222	640	enhance	96.52484	3
222	92	enhance	96.3804	4
222	13	enhance	95.71937	5
222	176	enhance	95.20096	6
222	285	enhance	93.18677	7
222	47	enhance	92.56882	8
222	31	enhance	92.54069	9
222	88	enhance	91.46592	10
222	98	enhance	90.92342	11
222	61	enhance	89.95882	12
222	84	enhance	87.01543	13
222	182	enhance	86.642815	14
222	94	enhance	86.50918	15
222	230	enhance	85.56755	16
222	49	enhance	84.07113	17
222	36	enhance	83.960045	18
222	1	enhance	82.81704	19
222	68	enhance	82.687775	20
222	108	enhance	82.37444	21
222	86	enhance	82.04156	22
222	33	enhance	81.61756	23
222	25	enhance	81.30801	24
222	39	enhance	80.201035	25
222	75	enhance	80.06075	26
222	87	enhance	79.91007	27
222	70	enhance	79.449844	28
222	40	enhance	79.20036	29
222	48	enhance	78.43071	30
222	10	enhance	78.29935	31
222	63	enhance	77.917755	32
222	50	enhance	77.91564	33
222	99	enhance	77.39078	34
222	71	enhance	77.033134	35
222	155	enhance	76.96918	36
222	7	enhance	76.16416	37
222	72	enhance	76.13434	38
222	15	enhance	75.05799	39
222	882	enhance	74.36583	40
222	19	enhance	74.32054	41
222	46	enhance	73.85977	42
222	187	enhance	72.68397	43
222	785	enhance	69.895874	44
222	126	enhance	69.87187	45
222	89	enhance	69.5622	46
222	17	enhance	69.16093	47
222	647	enhance	69.15242	48
222	90	enhance	69.05643	49
222	43	enhance	68.51158	50
222	83	enhance	68.18578	51
222	56	enhance	66.81159	52
222	34	enhance	65.30949	53
222	37	enhance	64.72594	54
222	52	enhance	64.466545	55
222	93	enhance	63.094288	56
222	24	enhance	62.93812	57
222	27	enhance	62.766342	58
222	45	enhance	61.240395	59
222	76	enhance	61.11634	60
222	358	enhance	61.11587	61
222	593	enhance	61.06326	62
222	2	enhance	60.594063	63
222	455	enhance	59.01021	64
222	66	enhance	58.255833	65
222	82	enhance	58.21714	66
222	868	enhance	57.81558	67
222	3	enhance	57.458652	68
222	44	enhance	57.290634	69
222	185	enhance	56.782352	70
222	54	enhance	56.741467	71
222	6	enhance	54.959763	72
222	97	enhance	54.951958	73
222	38	enhance	54.643013	74
222	55	enhance	54.579613	75
222	28	enhance	54.161564	76
222	16	enhance	53.14829	77
222	30	enhance	52.877934	78
222	80	enhance	52.06039	79
222	62	enhance	51.13834	80
222	60	enhance	50.78418	81
222	42	enhance	50.711266	82
222	59	enhance	49.76153	83
222	100	enhance	49.706738	84
222	78	enhance	49.58546	85
222	901	enhance	48.865307	86
222	184	enhance	48.393227	87
222	77	enhance	48.28866	88
222	79	enhance	47.67974	89
222	29	enhance	46.457626	90
222	18	enhance	46.429844	91
222	22	enhance	46.394497	92
222	91	enhance	45.84606	93
222	5	enhance	45.739822	94
222	26	enhance	45.466038	95
222	73	enhance	45.44864	96
222	11	enhance	45.259537	97
222	23	enhance	44.18967	98
222	58	enhance	43.823395	99
222	4	enhance	43.48677	100
222	64	enhance	41.80134	101
222	9	enhance	40.894794	102
222	335	enhance	40.784115	103
222	81	enhance	39.133537	104
222	96	enhance	37.517403	105
222	21	enhance	35.889503	106
222	219	enhance	35.699017	107
222	41	enhance	35.55557	108
222	921	enhance	35.54077	109
222	74	enhance	35.10439	110
222	8	enhance	35.01719	111
222	12	enhance	34.763756	112
222	171	enhance	32.87688	113
222	14	enhance	32.378033	114
222	69	enhance	31.757858	115
222	85	enhance	31.63455	116
222	53	enhance	31.220606	117
222	32	enhance	30.35841	118
222	65	enhance	29.85816	119
222	35	enhance	28.052212	120
222	20	enhance	26.02292	121
222	57	enhance	23.488014	122
222	95	enhance	18.991484	123
222	488	enhance	18.50588	124
222	64	soften	100	1
222	11	soften	96.77224	2
222	74	soften	96.54436	3
222	91	soften	92.29057	4
222	60	soften	91.176094	5
222	80	soften	88.74285	6
222	96	soften	88.34741	7
222	55	soften	88.20308	8
222	184	soften	87.72461	9
222	3	soften	86.98827	10
222	4	soften	86.09875	11
222	335	soften	85.71848	12
222	23	soften	84.92919	13
222	21	soften	84.88384	14
222	171	soften	84.858246	15
222	93	soften	84.68734	16
222	20	soften	84.62123	17
222	79	soften	84.47219	18
222	219	soften	84.42382	19
222	22	soften	84.02639	20
222	90	soften	83.41894	21
222	83	soften	83.11557	22
222	126	soften	82.57774	23
222	9	soften	82.153046	24
222	35	soften	82.03445	25
222	85	soften	81.92965	26
222	868	soften	81.73995	27
222	95	soften	81.73639	28
222	78	soften	81.60949	29
222	12	soften	81.11283	30
222	72	soften	80.97496	31
222	5	soften	80.49253	32
222	59	soften	80.154	33
222	45	soften	79.55304	34
222	70	soften	79.34299	35
222	41	soften	79.32184	36
222	44	soften	78.66253	37
222	18	soften	78.63474	38
222	34	soften	77.64232	39
222	30	soften	77.55576	40
222	82	soften	77.25642	41
222	73	soften	77.09725	42
222	2	soften	76.9599	43
222	43	soften	76.45125	44
222	99	soften	75.08908	45
222	49	soften	73.01249	46
222	39	soften	72.72195	47
222	94	soften	72.27348	48
222	182	soften	71.88812	49
222	13	soften	70.622574	50
222	33	soften	70.02103	51
230	61	enhance	100	1
230	33	enhance	98.17455	2
230	640	enhance	97.85372	3
230	13	enhance	95.78647	4
230	31	enhance	92.50552	5
230	49	enhance	91.126205	6
230	63	enhance	89.27646	7
230	98	enhance	88.91342	8
230	99	enhance	88.89447	9
230	43	enhance	88.33057	10
230	182	enhance	87.60434	11
230	2	enhance	86.122375	12
230	47	enhance	84.61587	13
230	126	enhance	82.39858	14
230	50	enhance	81.825096	15
230	222	enhance	81.75938	16
230	88	enhance	80.73666	17
230	34	enhance	80.24622	18
230	45	enhance	79.93031	19
230	90	enhance	77.8151	20
230	70	enhance	77.17622	21
230	56	enhance	74.29488	22
230	94	enhance	74.17353	23
230	80	enhance	73.793655	24
230	39	enhance	73.62392	25
230	30	enhance	73.60191	26
230	285	enhance	71.92279	27
230	108	enhance	71.23358	28
230	92	enhance	71.06195	29
230	67	enhance	69.37935	30
230	187	enhance	69.32101	31
230	89	enhance	69.239456	32
230	73	enhance	66.87785	33
230	82	enhance	65.8998	34
230	72	enhance	65.826004	35
230	176	enhance	65.69161	36
230	36	enhance	65.565674	37
230	7	enhance	65.1994	38
230	51	enhance	64.79914	39
230	83	enhance	64.28869	40
230	84	enhance	63.208332	41
230	79	enhance	63.162754	42
230	647	enhance	62.99471	43
230	40	enhance	61.550083	44
230	1	enhance	61.4233	45
230	28	enhance	61.255596	46
230	68	enhance	60.822475	47
230	593	enhance	60.654266	48
230	93	enhance	60.398792	49
230	19	enhance	60.18973	50
230	3	enhance	58.08831	51
230	10	enhance	57.51615	52
230	18	enhance	56.002186	53
230	54	enhance	55.51487	54
230	86	enhance	54.97478	55
230	48	enhance	54.602974	56
230	25	enhance	54.15676	57
230	71	enhance	54.07126	58
230	75	enhance	53.054546	59
230	27	enhance	51.96857	60
230	37	enhance	49.790417	61
230	87	enhance	49.77516	62
230	5	enhance	49.505894	63
230	17	enhance	49.341938	64
230	455	enhance	49.21994	65
230	15	enhance	49.051666	66
230	785	enhance	49.01745	67
230	23	enhance	48.761955	68
230	66	enhance	48.48207	69
230	185	enhance	48.41991	70
230	24	enhance	48.32906	71
230	55	enhance	48.232567	72
230	52	enhance	47.339508	73
230	46	enhance	46.319637	74
230	78	enhance	45.61374	75
230	62	enhance	44.72248	76
230	26	enhance	44.179848	77
230	6	enhance	43.278465	78
230	155	enhance	42.116283	79
230	76	enhance	42.101864	80
230	44	enhance	42.024574	81
230	97	enhance	41.73953	82
230	882	enhance	41.621155	83
230	59	enhance	41.553116	84
230	358	enhance	41.431313	85
230	868	enhance	41.347607	86
230	58	enhance	40.818054	87
230	184	enhance	40.358784	88
230	60	enhance	39.967705	89
230	8	enhance	39.874676	90
230	11	enhance	39.56278	91
230	921	enhance	39.445393	92
230	38	enhance	38.177124	93
230	100	enhance	38.157375	94
230	171	enhance	38.138233	95
230	74	enhance	38.033012	96
230	91	enhance	37.80473	97
230	77	enhance	37.626144	98
230	64	enhance	37.608433	99
230	16	enhance	37.574413	100
230	21	enhance	37.327015	101
230	9	enhance	37.154915	102
230	29	enhance	37.11197	103
230	42	enhance	36.941288	104
230	14	enhance	36.873165	105
230	901	enhance	36.83704	106
230	32	enhance	36.062332	107
230	20	enhance	35.69637	108
230	4	enhance	35.469723	109
230	81	enhance	35.396873	110
230	219	enhance	35.3837	111
230	96	enhance	35.345173	112
230	85	enhance	33.468246	113
230	53	enhance	33.31547	114
230	22	enhance	33.179688	115
230	12	enhance	33.02573	116
230	335	enhance	32.648796	117
230	35	enhance	32.164864	118
230	69	enhance	32.13711	119
230	95	enhance	31.134697	120
230	57	enhance	30.630062	121
230	65	enhance	30.56289	122
230	488	enhance	30.520212	123
230	41	enhance	28.88823	124
230	64	soften	100	1
230	11	soften	96.79771	2
230	74	soften	96.59103	3
230	91	soften	94.46702	4
230	60	soften	93.3234	5
230	96	soften	91.38689	6
230	184	soften	90.55506	7
230	335	soften	90.04464	8
230	55	soften	89.22682	9
230	868	soften	88.25453	10
230	22	soften	88.22388	11
230	4	soften	87.72858	12
230	21	soften	87.01312	13
230	219	soften	86.677475	14
230	171	soften	86.508705	15
230	20	soften	85.67693	16
230	3	soften	84.76468	17
230	59	soften	84.50652	18
230	12	soften	84.46982	19
230	93	soften	84.26968	20
230	85	soften	84.23029	21
230	95	soften	83.988464	22
230	78	soften	83.91915	23
230	35	soften	83.83527	24
230	9	soften	83.76862	25
230	23	soften	83.720436	26
230	83	soften	83.403984	27
230	44	soften	82.76651	28
230	41	soften	82.551865	29
230	72	soften	82.511086	30
230	80	soften	81.125885	31
230	79	soften	81.0185	32
230	5	soften	80.27744	33
230	69	soften	79.779465	34
230	70	soften	79.64237	35
230	18	soften	79.15054	36
230	90	soften	78.20893	37
230	126	soften	77.97326	38
230	66	soften	77.56578	39
230	82	soften	77.160995	40
230	593	soften	77.05946	41
230	45	soften	76.50154	42
230	94	soften	76.0539	43
230	28	soften	75.89227	44
230	34	soften	75.367874	45
230	39	soften	74.76922	46
230	73	soften	73.18798	47
230	2	soften	72.56206	48
230	30	soften	72.56177	49
230	285	soften	72.03374	50
230	63	soften	72.0249	51
230	49	soften	71.950516	52
230	43	soften	71.87448	53
230	182	soften	71.664474	54
230	222	soften	71.45223	55
230	99	soften	71.3341	56
230	13	soften	70.43307	57
230	640	soften	65.93416	58
230	61	soften	65.70631	59
230	33	soften	65.013405	60
285	88	enhance	100	1
285	176	enhance	98.792725	2
285	92	enhance	97.883835	3
285	1	enhance	97.186066	4
285	36	enhance	95.805016	5
285	94	enhance	95.16355	6
285	98	enhance	94.762596	7
285	108	enhance	94.3921	8
285	222	enhance	93.40088	9
285	86	enhance	93.36999	10
285	84	enhance	92.59249	11
285	40	enhance	91.916466	12
285	68	enhance	91.79473	13
285	71	enhance	91.43152	14
285	49	enhance	91.23951	15
285	48	enhance	90.4696	16
285	47	enhance	90.038284	17
285	31	enhance	89.25857	18
285	39	enhance	89.177795	19
285	10	enhance	88.700294	20
285	67	enhance	88.570435	21
285	51	enhance	88.16312	22
285	75	enhance	88.048546	23
285	25	enhance	87.882324	24
285	13	enhance	86.612465	25
285	647	enhance	85.95617	26
285	15	enhance	85.59227	27
285	87	enhance	85.449844	28
285	17	enhance	85.041664	29
285	89	enhance	85.00161	30
285	52	enhance	83.93182	31
285	182	enhance	83.92825	32
285	19	enhance	83.78006	33
285	640	enhance	82.93739	34
285	61	enhance	82.6701	35
285	7	enhance	82.595436	36
285	785	enhance	82.556725	37
285	187	enhance	81.009964	38
285	70	enhance	80.39682	39
285	155	enhance	80.38787	40
285	46	enhance	79.88309	41
285	27	enhance	79.76731	42
285	24	enhance	79.4919	43
285	455	enhance	79.428566	44
285	56	enhance	79.30853	45
285	882	enhance	79.21305	46
285	63	enhance	79.06258	47
285	50	enhance	78.99595	48
285	6	enhance	78.86893	49
285	97	enhance	78.47773	50
285	54	enhance	76.53671	51
285	185	enhance	76.43035	52
285	358	enhance	75.7455	53
285	72	enhance	75.65653	54
285	230	enhance	75.44575	55
285	76	enhance	74.46397	56
285	83	enhance	73.230156	57
285	62	enhance	73.14236	58
285	38	enhance	72.912674	59
285	16	enhance	72.831055	60
285	45	enhance	72.4587	61
285	34	enhance	72.16243	62
285	43	enhance	71.5831	63
285	66	enhance	71.13962	64
285	99	enhance	70.692566	65
285	42	enhance	70.365234	66
285	126	enhance	70.2298	67
285	37	enhance	70.15829	68
285	30	enhance	68.34881	69
285	593	enhance	68.095795	70
285	33	enhance	67.32108	71
285	100	enhance	67.28006	72
285	29	enhance	66.8469	73
285	28	enhance	66.82135	74
285	73	enhance	66.39444	75
285	18	enhance	65.52191	76
285	77	enhance	65.503456	77
285	26	enhance	64.49623	78
285	868	enhance	64.04438	79
285	93	enhance	64.02533	80
285	78	enhance	63.6753	81
285	90	enhance	63.58519	82
285	901	enhance	63.525246	83
285	44	enhance	63.467285	84
285	79	enhance	61.945885	85
285	3	enhance	61.683132	86
285	80	enhance	58.968887	87
285	82	enhance	58.74602	88
285	58	enhance	58.283478	89
285	59	enhance	57.890396	90
285	55	enhance	57.615265	91
285	184	enhance	57.194294	92
285	921	enhance	55.98998	93
285	81	enhance	55.892033	94
285	2	enhance	55.202885	95
285	60	enhance	52.019707	96
285	22	enhance	51.3891	97
285	53	enhance	50.718235	98
285	5	enhance	50.692238	99
285	91	enhance	50.384796	100
285	11	enhance	48.96202	101
285	335	enhance	48.67125	102
285	4	enhance	48.28692	103
285	64	enhance	47.57734	104
285	9	enhance	47.31326	105
285	21	enhance	46.59715	106
285	219	enhance	46.448116	107
285	23	enhance	45.90582	108
285	96	enhance	45.762768	109
285	74	enhance	45.31564	110
285	65	enhance	44.56292	111
285	32	enhance	44.432755	112
285	171	enhance	44.411575	113
285	12	enhance	44.296806	114
285	8	enhance	44.142597	115
285	14	enhance	44.058342	116
285	41	enhance	42.73987	117
285	69	enhance	42.470474	118
285	85	enhance	42.26013	119
285	35	enhance	39.159073	120
285	20	enhance	38.757324	121
285	95	enhance	33.70252	122
285	57	enhance	33.545517	123
285	488	enhance	32.863037	124
285	11	soften	100	1
285	91	soften	95.587944	2
285	55	soften	92.49738	3
285	3	soften	91.25429	4
285	96	soften	91.198654	5
285	90	soften	89.69402	6
285	184	soften	89.2954	7
285	4	soften	89.18012	8
285	126	soften	88.95031	9
285	23	soften	88.80708	10
285	93	soften	88.561226	11
285	79	soften	87.94289	12
285	171	soften	87.686554	13
285	21	soften	87.54948	14
285	219	soften	86.44023	15
285	22	soften	86.151184	16
285	9	soften	85.33144	17
285	35	soften	84.53649	18
285	85	soften	84.47718	19
285	868	soften	83.98209	20
285	12	soften	83.971245	21
285	59	soften	82.96873	22
285	2	soften	82.91059	23
285	82	soften	82.31552	24
285	34	soften	82.25633	25
285	30	soften	81.09677	26
285	18	soften	80.612434	27
285	44	soften	80.34453	28
285	69	soften	80.146454	29
285	99	soften	80.033455	30
285	28	soften	77.69504	31
285	182	soften	77.26157	32
285	63	soften	76.7622	33
285	66	soften	75.55963	34
285	39	soften	74.72236	35
285	64	soften	71.478516	36
285	74	soften	69.599594	37
285	60	soften	66.90534	38
285	80	soften	66.26834	39
285	83	soften	62.03371	40
285	335	soften	61.5378	41
285	20	soften	60.951557	42
285	72	soften	60.85972	43
285	95	soften	59.256767	44
285	70	soften	59.08704	45
285	45	soften	58.71238	46
285	5	soften	58.609413	47
285	78	soften	58.13486	48
285	41	soften	57.150818	49
285	43	soften	56.64178	50
285	73	soften	56.14196	51
285	593	soften	54.67313	52
285	33	soften	54.190754	53
285	49	soften	54.17809	54
285	13	soften	53.923298	55
285	94	soften	52.5612	56
285	61	soften	51.4188	57
285	640	soften	50.939426	58
285	222	soften	49.59496	59
335	59	enhance	100	1
335	96	enhance	99.78774	2
335	184	enhance	99.502716	3
335	219	enhance	99.3478	4
335	22	enhance	99.226654	5
335	41	enhance	98.32311	6
335	4	enhance	97.782196	7
335	78	enhance	97.42671	8
335	21	enhance	97.42216	9
335	23	enhance	96.794014	10
335	9	enhance	96.792625	11
335	91	enhance	96.00361	12
335	12	enhance	95.94373	13
335	85	enhance	95.37512	14
335	44	enhance	95.31729	15
335	5	enhance	95.022446	16
335	69	enhance	94.147285	17
335	74	enhance	93.986176	18
335	593	enhance	93.60251	19
335	868	enhance	93.106544	20
335	35	enhance	92.57677	21
335	64	enhance	91.878204	22
335	55	enhance	91.27826	23
335	93	enhance	91.00923	24
335	66	enhance	90.67791	25
335	60	enhance	89.676704	26
335	11	enhance	89.059715	27
335	20	enhance	88.73391	28
335	3	enhance	87.635124	29
335	8	enhance	87.112885	30
335	171	enhance	85.62436	31
335	18	enhance	84.280426	32
335	82	enhance	84.267456	33
335	58	enhance	81.36329	34
335	27	enhance	80.499054	35
335	10	enhance	78.7478	36
335	65	enhance	78.61954	37
335	455	enhance	77.372925	38
335	94	enhance	77.09935	39
335	50	enhance	76.80227	40
335	70	enhance	76.46089	41
335	77	enhance	75.987366	42
335	72	enhance	75.97841	43
335	79	enhance	75.903755	44
335	95	enhance	75.527725	45
335	54	enhance	75.03907	46
335	100	enhance	75.00325	47
335	488	enhance	73.92597	48
335	39	enhance	73.91902	49
335	83	enhance	73.845314	50
335	52	enhance	72.94485	51
335	7	enhance	72.55805	52
335	90	enhance	72.52551	53
335	14	enhance	72.33797	54
335	28	enhance	72.2508	55
335	32	enhance	67.55774	56
335	34	enhance	66.89895	57
335	99	enhance	64.75366	58
335	62	enhance	63.253914	59
335	126	enhance	62.753876	60
335	92	enhance	62.69146	61
335	182	enhance	62.266342	62
335	24	enhance	62.113007	63
335	63	enhance	61.244743	64
335	19	enhance	60.65872	65
335	2	enhance	59.696495	66
335	86	enhance	59.616066	67
335	53	enhance	59.49286	68
335	921	enhance	58.352413	69
335	185	enhance	57.576897	70
335	80	enhance	56.55157	71
335	38	enhance	55.987766	72
335	176	enhance	55.708252	73
335	42	enhance	55.13218	74
335	43	enhance	53.82961	75
335	81	enhance	53.302456	76
335	57	enhance	52.97852	77
335	49	enhance	51.979267	78
335	187	enhance	51.78314	79
335	785	enhance	50.680023	80
335	76	enhance	50.35055	81
335	647	enhance	48.947697	82
335	108	enhance	48.752285	83
335	6	enhance	48.676693	84
335	26	enhance	47.599632	85
335	285	enhance	47.183	86
335	16	enhance	46.676796	87
335	29	enhance	46.46691	88
335	97	enhance	45.5787	89
335	901	enhance	45.173367	90
335	15	enhance	44.91221	91
335	45	enhance	44.32084	92
335	89	enhance	43.793095	93
335	358	enhance	42.737206	94
335	37	enhance	42.418056	95
335	13	enhance	42.326145	96
335	17	enhance	41.4822	97
335	222	enhance	39.62788	98
335	56	enhance	37.987274	99
335	73	enhance	37.898216	100
335	84	enhance	37.619804	101
335	48	enhance	37.447742	102
335	68	enhance	36.821877	103
335	71	enhance	36.32176	104
335	1	enhance	35.937534	105
335	640	enhance	34.720436	106
335	87	enhance	34.396328	107
335	230	enhance	33.200798	108
335	36	enhance	33.046722	109
335	31	enhance	31.768234	110
335	30	enhance	31.142918	111
335	61	enhance	30.290821	112
335	47	enhance	29.271692	113
335	98	enhance	29.192701	114
335	88	enhance	28.543941	115
335	40	enhance	28.259401	116
335	51	enhance	27.360346	117
335	46	enhance	26.853798	118
335	25	enhance	25.942509	119
335	882	enhance	24.356571	120
335	33	enhance	24.284546	121
335	155	enhance	24.198965	122
335	75	enhance	23.439714	123
335	67	enhance	18.512705	124
335	80	soften	100	1
335	126	soften	99.66966	2
335	72	soften	98.84389	3
335	90	soften	98.64306	4
335	83	soften	98.32875	5
335	11	soften	98.0772	6
335	60	soften	95.909134	7
335	64	soften	95.86126	8
335	3	soften	93.72367	9
335	55	soften	93.31965	10
335	70	soften	92.90139	11
335	93	soften	89.48486	12
335	91	soften	87.32464	13
335	79	soften	86.77092	14
335	74	soften	83.793655	15
335	184	soften	83.323265	16
335	4	soften	82.70504	17
335	96	soften	76.703476	18
358	17	enhance	100	1
358	76	enhance	99.92902	2
358	785	enhance	99.63507	3
358	29	enhance	99.30401	4
358	16	enhance	98.893196	5
358	6	enhance	98.78127	6
358	97	enhance	98.05756	7
358	42	enhance	96.57342	8
358	38	enhance	96.52444	9
358	71	enhance	95.692535	10
358	87	enhance	95.339615	11
358	46	enhance	94.794	12
358	185	enhance	94.33558	13
358	48	enhance	93.93034	14
358	882	enhance	93.18817	15
358	155	enhance	92.60515	16
358	68	enhance	92.41142	17
358	647	enhance	91.55018	18
358	37	enhance	90.821175	19
358	25	enhance	90.36931	20
358	52	enhance	90.24599	21
358	62	enhance	89.98812	22
358	40	enhance	89.82007	23
358	75	enhance	89.5546	24
358	24	enhance	89.463326	25
358	81	enhance	88.82041	26
358	84	enhance	88.57623	27
358	455	enhance	87.81642	28
358	36	enhance	87.6512	29
358	100	enhance	86.58727	30
358	108	enhance	86.51239	31
358	53	enhance	84.693245	32
358	77	enhance	84.68255	33
358	54	enhance	83.94699	34
358	921	enhance	83.67787	35
358	10	enhance	83.09194	36
358	27	enhance	83.05748	37
358	1	enhance	82.93764	38
358	26	enhance	82.73972	39
358	15	enhance	80.44359	40
358	901	enhance	80.41805	41
358	86	enhance	79.317566	42
358	88	enhance	77.06588	43
358	176	enhance	76.44666	44
358	89	enhance	75.86814	45
358	285	enhance	72.88681	46
358	7	enhance	69.72845	47
358	92	enhance	69.622574	48
358	65	enhance	69.38781	49
358	98	enhance	69.09665	50
358	66	enhance	69.08228	51
358	14	enhance	68.514046	52
358	31	enhance	67.92688	53
358	32	enhance	67.84971	54
358	28	enhance	67.4338	55
358	39	enhance	67.38077	56
358	56	enhance	67.366035	57
358	67	enhance	64.4813	58
358	187	enhance	63.879517	59
358	18	enhance	62.022057	60
358	19	enhance	60.786045	61
358	50	enhance	60.117603	62
358	51	enhance	59.323875	63
358	593	enhance	59.234207	64
358	94	enhance	58.974384	65
358	222	enhance	58.944447	66
358	78	enhance	57.16285	67
358	58	enhance	56.375732	68
358	57	enhance	54.575478	69
358	8	enhance	53.970802	70
358	47	enhance	51.77071	71
358	488	enhance	51.529	72
358	59	enhance	50.08108	73
358	63	enhance	49.68226	74
358	182	enhance	48.138744	75
358	49	enhance	48.071693	76
358	44	enhance	47.44581	77
358	219	enhance	45.09712	78
358	868	enhance	45.06256	79
358	73	enhance	44.997795	80
358	12	enhance	44.559914	81
358	35	enhance	44.269814	82
358	61	enhance	43.623257	83
358	640	enhance	43.183865	84
358	34	enhance	43.067657	85
358	85	enhance	42.5624	86
358	335	enhance	42.42142	87
358	230	enhance	41.820496	88
358	69	enhance	41.71528	89
358	184	enhance	41.084732	90
358	30	enhance	40.79191	91
358	171	enhance	40.68306	92
358	21	enhance	40.442688	93
358	41	enhance	39.806667	94
358	20	enhance	39.53272	95
358	5	enhance	39.080772	96
358	95	enhance	38.67182	97
358	79	enhance	38.548946	98
358	43	enhance	38.20538	99
358	13	enhance	38.205173	100
358	82	enhance	37.898514	101
358	22	enhance	36.55075	102
358	99	enhance	33.533012	103
358	4	enhance	31.898275	104
358	96	enhance	31.770964	105
358	9	enhance	31.530817	106
358	70	enhance	31.424755	107
358	23	enhance	30.385052	108
358	45	enhance	30.37354	109
358	93	enhance	28.208237	110
358	2	enhance	27.801352	111
358	33	enhance	27.550123	112
358	55	enhance	26.136784	113
358	72	enhance	25.714705	114
358	3	enhance	24.36695	115
358	83	enhance	23.259619	116
358	60	enhance	22.442085	117
358	91	enhance	22.10741	118
358	64	enhance	21.240639	119
358	74	enhance	20.303637	120
358	11	enhance	19.547497	121
358	126	enhance	18.75741	122
358	90	enhance	16.643583	123
358	80	enhance	13.174706	124
358	11	soften	100	1
358	64	soften	99.93234	2
358	80	soften	99.75168	3
358	60	soften	97.64591	4
358	74	soften	96.82778	5
358	90	soften	96.14319	6
358	126	soften	95.714935	7
358	91	soften	95.607216	8
358	83	soften	94.25857	9
358	55	soften	93.30985	10
358	72	soften	93.05553	11
358	3	soften	92.80222	12
358	93	soften	89.96031	13
358	79	soften	89.38895	14
358	70	soften	89.08762	15
358	23	soften	88.02265	16
358	45	soften	87.69138	17
358	4	soften	87.17092	18
358	96	soften	86.01112	19
358	2	soften	85.85629	20
358	33	soften	85.29117	21
358	171	soften	84.35386	22
358	21	soften	84.28238	23
358	82	soften	84.09018	24
358	34	soften	84.07765	25
358	184	soften	83.99491	26
358	99	soften	83.950134	27
358	9	soften	83.81442	28
358	13	soften	83.684944	29
358	5	soften	83.46515	30
358	43	soften	83.28515	31
358	20	soften	82.51336	32
358	49	soften	82.41225	33
358	182	soften	82.21526	34
358	335	soften	82.12178	35
358	868	soften	81.47797	36
358	30	soften	81.21023	37
358	22	soften	81.181435	38
358	85	soften	81.03497	39
358	219	soften	80.872375	40
358	12	soften	80.83958	41
358	35	soften	80.715965	42
358	73	soften	80.43948	43
358	59	soften	80.038605	44
358	95	soften	79.6495	45
358	61	soften	79.32761	46
358	230	soften	78.82935	47
358	63	soften	78.631096	48
358	640	soften	78.62755	49
358	78	soften	77.62551	50
358	94	soften	77.38313	51
358	18	soften	76.904045	52
358	41	soften	76.85138	53
358	69	soften	76.83195	54
358	593	soften	76.66709	55
358	50	soften	76.45596	56
358	28	soften	76.37063	57
358	44	soften	76.36774	58
358	8	soften	74.53303	59
358	222	soften	74.4398	60
358	39	soften	73.00144	61
358	66	soften	72.96049	62
358	187	soften	72.88395	63
358	47	soften	72.80905	64
358	92	soften	71.35385	65
358	31	soften	71.28855	66
358	488	soften	70.80011	67
358	98	soften	70.64914	68
358	56	soften	70.207756	69
358	285	soften	70.179535	70
358	7	soften	70.012	71
358	51	soften	69.88736	72
358	176	soften	69.22675	73
358	19	soften	68.516136	74
358	58	soften	68.25718	75
358	54	soften	68.21304	76
358	89	soften	67.66262	77
358	14	soften	66.23589	78
358	27	soften	65.91685	79
358	10	soften	65.1623	80
358	88	soften	64.886406	81
358	67	soften	64.86665	82
358	455	soften	64.75292	83
358	108	soften	63.82107	84
358	86	soften	63.397392	85
358	65	soften	63.34801	86
358	24	soften	63.166676	87
358	1	soften	62.869778	88
358	26	soften	62.684795	89
358	32	soften	62.550575	90
358	52	soften	61.97241	91
358	647	soften	61.96204	92
358	84	soften	61.76643	93
358	921	soften	61.693558	94
358	901	soften	61.216118	95
358	62	soften	60.573826	96
358	185	soften	60.27057	97
358	77	soften	59.588326	98
358	100	soften	59.154465	99
358	785	soften	58.772644	100
358	36	soften	58.706524	101
358	53	soften	58.384586	102
358	71	soften	57.099224	103
358	17	soften	56.46464	104
358	6	soften	56.275875	105
358	40	soften	56.215977	106
358	68	soften	56.06092	107
358	87	soften	55.677773	108
358	48	soften	55.27565	109
358	25	soften	54.99256	110
358	97	soften	54.29824	111
358	155	soften	52.21863	112
358	882	soften	51.85297	113
455	52	enhance	100	1
455	62	enhance	98.675804	2
455	24	enhance	97.993515	3
455	185	enhance	97.34182	4
455	100	enhance	96.86569	5
455	54	enhance	96.439644	6
455	77	enhance	96.29217	7
455	38	enhance	95.80285	8
455	42	enhance	95.38414	9
455	27	enhance	94.17444	10
455	6	enhance	94.0782	11
455	785	enhance	92.26477	12
455	10	enhance	91.46873	13
455	16	enhance	91.44644	14
455	76	enhance	91.39639	15
455	97	enhance	91.3223	16
455	18	enhance	91.08181	17
455	647	enhance	90.923225	18
455	921	enhance	90.29998	19
455	593	enhance	89.521515	20
455	29	enhance	89.007866	21
455	108	enhance	88.960884	22
455	66	enhance	88.93059	23
455	358	enhance	88.52468	24
455	78	enhance	88.16593	25
455	53	enhance	88.15586	26
455	65	enhance	87.61903	27
455	7	enhance	87.02754	28
455	81	enhance	86.70807	29
455	17	enhance	86.47966	30
455	86	enhance	85.63825	31
455	14	enhance	85.45879	32
455	58	enhance	85.38105	33
455	28	enhance	85.30297	34
455	39	enhance	85.259575	35
455	32	enhance	84.926094	36
455	71	enhance	84.05141	37
455	89	enhance	83.66825	38
455	48	enhance	83.03471	39
455	26	enhance	82.76468	40
455	59	enhance	82.16121	41
455	94	enhance	81.91957	42
455	219	enhance	81.53074	43
455	176	enhance	81.30303	44
455	8	enhance	81.23067	45
455	87	enhance	80.68514	46
455	37	enhance	80.663895	47
455	36	enhance	80.45809	48
455	1	enhance	80.416824	49
455	68	enhance	79.59617	50
455	84	enhance	79.49776	51
455	50	enhance	79.14313	52
455	35	enhance	78.641594	53
455	901	enhance	78.25996	54
455	40	enhance	78.083755	55
455	12	enhance	78.03797	56
455	85	enhance	77.94696	57
455	21	enhance	77.7892	58
455	488	enhance	77.65004	59
455	20	enhance	77.48176	60
455	92	enhance	77.44449	61
455	335	enhance	77.42064	62
455	285	enhance	77.04732	63
455	15	enhance	76.94611	64
455	69	enhance	76.71396	65
455	44	enhance	76.48644	66
455	868	enhance	76.10875	67
455	184	enhance	75.6681	68
455	5	enhance	75.07683	69
455	25	enhance	75.06175	70
455	41	enhance	74.26605	71
455	171	enhance	73.81296	72
455	63	enhance	73.674904	73
455	19	enhance	73.59369	74
455	187	enhance	73.574165	75
455	79	enhance	73.00252	76
455	95	enhance	72.803215	77
455	96	enhance	72.65212	78
455	56	enhance	71.70503	79
455	155	enhance	71.38663	80
455	46	enhance	71.350784	81
455	34	enhance	71.090965	82
455	75	enhance	70.778786	83
455	882	enhance	70.45924	84
455	82	enhance	70.14109	85
455	22	enhance	69.90142	86
455	23	enhance	69.834435	87
455	9	enhance	69.76643	88
455	88	enhance	69.23813	89
455	31	enhance	67.98891	90
455	4	enhance	67.97071	91
455	49	enhance	67.45705	92
455	98	enhance	65.84913	93
455	74	enhance	65.62428	94
455	93	enhance	65.31561	95
455	57	enhance	65.27167	96
455	73	enhance	64.55942	97
455	182	enhance	63.674072	98
455	43	enhance	63.550503	99
455	70	enhance	62.99871	100
455	3	enhance	62.6787	101
455	55	enhance	62.020786	102
455	91	enhance	61.983215	103
455	64	enhance	59.397755	104
455	99	enhance	59.087826	105
455	45	enhance	58.174316	106
455	222	enhance	57.372623	107
455	2	enhance	56.63043	108
455	30	enhance	56.288708	109
455	11	enhance	56.105373	110
455	60	enhance	55.531673	111
455	83	enhance	55.33321	112
455	72	enhance	54.441814	113
455	47	enhance	52.35528	114
455	126	enhance	50.754513	115
455	13	enhance	50.728184	116
455	61	enhance	50.237885	117
455	230	enhance	50.08298	118
455	90	enhance	49.905487	119
455	80	enhance	49.694324	120
455	67	enhance	49.296097	121
455	640	enhance	47.538216	122
455	51	enhance	47.286053	123
455	33	enhance	34.97535	124
455	80	soften	100	1
455	11	soften	99.65141	2
455	126	soften	97.902306	3
455	60	soften	97.82441	4
455	90	soften	97.719734	5
455	83	soften	96.812096	6
455	72	soften	96.41716	7
455	55	soften	94.36796	8
455	3	soften	93.849945	9
455	91	soften	92.940285	10
455	70	soften	91.55034	11
455	33	soften	90.76346	12
455	93	soften	90.56145	13
455	45	soften	90.167336	14
455	13	soften	89.32445	15
455	79	soften	88.801094	16
455	30	soften	87.15368	17
455	34	soften	86.94856	18
455	99	soften	86.81419	19
455	182	soften	86.61875	20
455	43	soften	86.55538	21
455	2	soften	86.55123	22
455	4	soften	86.44646	23
455	23	soften	85.919395	24
455	184	soften	84.97753	25
455	640	soften	84.94399	26
455	73	soften	84.4221	27
455	82	soften	84.30448	28
455	96	soften	83.8432	29
455	230	soften	83.65374	30
455	171	soften	83.579605	31
455	868	soften	82.65604	32
455	5	soften	81.95189	33
455	9	soften	81.862526	34
455	22	soften	81.63698	35
455	63	soften	81.440765	36
455	335	soften	81.3648	37
455	21	soften	81.288956	38
455	20	soften	80.267914	39
455	219	soften	80.16597	40
455	59	soften	79.9069	41
455	50	soften	79.84554	42
455	78	soften	79.66671	43
455	28	soften	79.16087	44
455	44	soften	78.67651	45
455	12	soften	78.42235	46
455	187	soften	78.36571	47
455	18	soften	78.3081	48
455	35	soften	78.126236	49
455	39	soften	77.95563	50
455	593	soften	77.89585	51
455	85	soften	77.71815	52
455	98	soften	77.4106	53
455	285	soften	77.03479	54
455	66	soften	75.853226	55
455	41	soften	75.74016	56
455	8	soften	75.057755	57
455	176	soften	74.86283	58
455	7	soften	74.154305	59
455	69	soften	74.05155	60
455	89	soften	72.96783	61
455	54	soften	72.09003	62
455	27	soften	70.90145	63
455	10	soften	70.279274	64
455	86	soften	69.90774	65
455	64	soften	68.98469	66
455	74	soften	64.54825	67
455	49	soften	60.823708	68
455	61	soften	59.542072	69
455	222	soften	57.667492	70
455	94	soften	56.705383	71
455	51	soften	55.728394	72
455	47	soften	55.594437	73
455	31	soften	54.34934	74
455	95	soften	54.21143	75
455	92	soften	54.07468	76
455	56	soften	53.679607	77
488	32	enhance	100	1
488	14	enhance	98.698	2
488	95	enhance	96.82434	3
488	65	enhance	96.79461	4
488	20	enhance	95.54584	5
488	35	enhance	94.541046	6
488	8	enhance	93.29563	7
488	85	enhance	90.23458	8
488	171	enhance	88.81478	9
488	12	enhance	88.56295	10
488	69	enhance	87.791504	11
488	18	enhance	86.976204	12
488	921	enhance	86.3972	13
488	53	enhance	86.20585	14
488	219	enhance	85.901764	15
488	77	enhance	85.70207	16
488	21	enhance	85.356674	17
488	100	enhance	83.706154	18
488	5	enhance	83.54089	19
488	58	enhance	82.917145	20
488	82	enhance	82.599594	21
488	54	enhance	81.01029	22
488	62	enhance	80.32527	23
488	59	enhance	80.314575	24
488	593	enhance	79.29912	25
488	57	enhance	79.10759	26
488	455	enhance	78.82763	27
488	81	enhance	78.65547	28
488	41	enhance	78.17239	29
488	28	enhance	77.53359	30
488	24	enhance	76.93396	31
488	23	enhance	76.36484	32
488	9	enhance	76.15172	33
488	96	enhance	75.49685	34
488	66	enhance	75.12294	35
488	335	enhance	75.09336	36
488	78	enhance	74.753525	37
488	185	enhance	74.43305	38
488	79	enhance	72.20453	39
488	42	enhance	71.17434	40
488	38	enhance	69.69891	41
488	74	enhance	69.15154	42
488	34	enhance	68.89408	43
488	4	enhance	68.40346	44
488	50	enhance	67.67158	45
488	2	enhance	63.758118	46
488	27	enhance	63.367844	47
488	52	enhance	63.28618	48
488	76	enhance	63.28131	49
488	26	enhance	62.92019	50
488	184	enhance	61.392273	51
488	868	enhance	61.334705	52
488	29	enhance	60.829094	53
488	785	enhance	60.788784	54
488	55	enhance	59.510242	55
488	6	enhance	58.378044	56
488	16	enhance	58.090576	57
488	91	enhance	57.419346	58
488	22	enhance	57.329666	59
488	37	enhance	57.160744	60
488	3	enhance	56.383904	61
488	10	enhance	56.281452	62
488	901	enhance	55.957066	63
488	19	enhance	55.951244	64
488	647	enhance	55.821327	65
488	63	enhance	55.315468	66
488	73	enhance	55.190197	67
488	7	enhance	54.831528	68
488	44	enhance	53.45322	69
488	97	enhance	53.25189	70
488	358	enhance	52.73235	71
488	43	enhance	52.531094	72
488	64	enhance	52.25052	73
488	60	enhance	51.980484	74
488	187	enhance	51.69315	75
488	93	enhance	51.490578	76
488	11	enhance	51.190678	77
488	94	enhance	50.974308	78
488	89	enhance	50.32429	79
488	182	enhance	50.122196	80
488	45	enhance	49.2231	81
488	83	enhance	49.20215	82
488	176	enhance	47.646996	83
488	70	enhance	47.540634	84
488	80	enhance	46.883377	85
488	99	enhance	46.30173	86
488	17	enhance	46.273724	87
488	126	enhance	46.044716	88
488	56	enhance	45.45093	89
488	39	enhance	45.047386	90
488	108	enhance	43.83118	91
488	90	enhance	42.849426	92
488	49	enhance	42.791775	93
488	71	enhance	40.310707	94
488	72	enhance	40.190975	95
488	15	enhance	39.16313	96
488	30	enhance	38.383183	97
488	92	enhance	37.67679	98
488	86	enhance	34.651314	99
488	1	enhance	33.749992	100
488	87	enhance	33.40328	101
488	84	enhance	32.745724	102
488	285	enhance	32.361248	103
488	31	enhance	31.928514	104
488	230	enhance	31.526329	105
488	98	enhance	30.828194	106
488	48	enhance	30.330729	107
488	36	enhance	29.928041	108
488	68	enhance	28.284311	109
488	61	enhance	26.766003	110
488	47	enhance	25.49633	111
488	13	enhance	24.859318	112
488	88	enhance	24.769182	113
488	40	enhance	24.256975	114
488	46	enhance	23.419924	115
488	155	enhance	20.89325	116
488	25	enhance	20.698853	117
488	33	enhance	20.096176	118
488	640	enhance	19.07815	119
488	882	enhance	18.50303	120
488	222	enhance	18.265182	121
488	75	enhance	16.454245	122
488	51	enhance	10.375147	123
488	67	enhance	7.0658884	124
488	90	soften	100	1
488	126	soften	99.77554	2
488	11	soften	96.7554	3
488	30	soften	95.95197	4
488	93	soften	94.33352	5
488	3	soften	93.48642	6
488	182	soften	92.34053	7
488	99	soften	91.82254	8
488	285	soften	91.720146	9
488	55	soften	91.0954	10
488	79	soften	90.89942	11
488	39	soften	90.55787	12
488	91	soften	90.24348	13
488	184	soften	88.31477	14
488	63	soften	87.662384	15
488	34	soften	87.65435	16
488	2	soften	86.550934	17
488	44	soften	85.37034	18
488	868	soften	85.124535	19
488	176	soften	84.90797	20
488	28	soften	84.25677	21
488	50	soften	83.8526	22
488	22	soften	83.49985	23
488	27	soften	82.063774	24
488	4	soften	81.90375	25
488	7	soften	81.79926	26
488	66	soften	81.27763	27
488	23	soften	80.866554	28
488	18	soften	80.607574	29
488	82	soften	80.31251	30
488	10	soften	79.88772	31
488	96	soften	79.39635	32
488	59	soften	79.221	33
488	54	soften	78.658516	34
488	52	soften	78.04851	35
488	21	soften	76.2233	36
488	171	soften	76.19787	37
488	9	soften	76.04251	38
488	219	soften	75.71927	39
488	455	soften	75.3649	40
488	12	soften	71.96262	41
488	80	soften	71.05089	42
488	85	soften	70.703285	43
488	8	soften	70.48631	44
488	72	soften	70.06711	45
488	13	soften	69.74845	46
488	35	soften	69.543	47
488	33	soften	69.44903	48
488	58	soften	69.30279	49
488	64	soften	68.375084	50
488	49	soften	68.02941	51
488	69	soften	67.99542	52
488	83	soften	67.97645	53
488	70	soften	67.68478	54
488	640	soften	67.165794	55
488	222	soften	66.90094	56
488	61	soften	66.67044	57
488	45	soften	66.48623	58
488	60	soften	66.00014	59
488	51	soften	65.117584	60
488	230	soften	64.63619	61
488	98	soften	64.08398	62
488	94	soften	63.763897	63
488	43	soften	63.65057	64
488	73	soften	63.527626	65
488	31	soften	62.97242	66
488	67	soften	61.952435	67
488	47	soften	61.807327	68
488	92	soften	61.296886	69
488	86	soften	60.53567	70
488	74	soften	60.02238	71
488	84	soften	59.557068	72
488	56	soften	59.49094	73
488	187	soften	58.93259	74
488	78	soften	58.08519	75
488	1	soften	57.807453	76
488	89	soften	57.548683	77
488	593	soften	56.562263	78
488	335	soften	55.523792	79
488	5	soften	54.575928	80
488	19	soften	54.526497	81
488	24	soften	51.80385	82
488	20	soften	50.211723	83
488	41	soften	49.877003	84
488	95	soften	47.157486	85
593	59	enhance	100	1
593	5	enhance	99.989815	2
593	23	enhance	99.10976	3
593	78	enhance	98.32441	4
593	66	enhance	97.74318	5
593	21	enhance	97.04947	6
593	219	enhance	96.54552	7
593	12	enhance	96.391685	8
593	335	enhance	95.91078	9
593	85	enhance	95.65655	10
593	50	enhance	95.16768	11
593	4	enhance	94.6072	12
593	35	enhance	94.56876	13
593	18	enhance	94.39381	14
593	9	enhance	94.222534	15
593	82	enhance	94.15376	16
593	69	enhance	94.08034	17
593	8	enhance	94.06339	18
593	93	enhance	94.01054	19
593	184	enhance	93.41036	20
593	44	enhance	93.40736	21
593	41	enhance	93.19786	22
593	94	enhance	92.248505	23
593	96	enhance	92.14477	24
593	455	enhance	91.672615	25
593	22	enhance	91.353546	26
593	54	enhance	91.334885	27
593	3	enhance	91.05953	28
593	7	enhance	91.04227	29
593	91	enhance	90.7962	30
593	868	enhance	90.22744	31
593	27	enhance	89.96286	32
593	55	enhance	89.27011	33
593	28	enhance	89.26446	34
593	20	enhance	89.21205	35
593	74	enhance	88.80994	36
593	39	enhance	88.72411	37
593	79	enhance	88.37225	38
593	10	enhance	88.28504	39
593	52	enhance	88.24669	40
593	70	enhance	87.1896	41
593	58	enhance	85.96597	42
593	99	enhance	85.90662	43
593	77	enhance	85.81529	44
593	34	enhance	85.759926	45
593	100	enhance	85.37166	46
593	171	enhance	85.35826	47
593	65	enhance	85.279526	48
593	63	enhance	85.236046	49
593	60	enhance	84.70789	50
593	64	enhance	84.55687	51
593	90	enhance	84.0593	52
593	11	enhance	83.23732	53
593	182	enhance	83.05656	54
593	14	enhance	82.17481	55
593	72	enhance	81.498924	56
593	32	enhance	81.361244	57
593	488	enhance	79.99149	58
593	83	enhance	79.671585	59
593	62	enhance	79.08879	60
593	24	enhance	78.92017	61
593	2	enhance	78.647804	62
593	92	enhance	78.5346	63
593	43	enhance	77.87861	64
593	49	enhance	77.21833	65
593	126	enhance	77.02229	66
593	95	enhance	76.33744	67
593	185	enhance	76.26349	68
593	108	enhance	75.820694	69
593	921	enhance	74.99461	70
593	19	enhance	74.69715	71
593	53	enhance	74.49032	72
593	187	enhance	74.12683	73
593	86	enhance	73.939095	74
593	176	enhance	73.055305	75
593	38	enhance	72.294525	76
593	42	enhance	71.89312	77
593	647	enhance	70.5902	78
593	785	enhance	69.46391	79
593	81	enhance	68.84851	80
593	80	enhance	68.844666	81
593	89	enhance	68.68151	82
593	285	enhance	67.64151	83
593	76	enhance	67.04611	84
593	13	enhance	66.97123	85
593	16	enhance	66.726814	86
593	6	enhance	66.70678	87
593	31	enhance	64.89773	88
593	45	enhance	64.29678	89
593	29	enhance	63.595272	90
593	97	enhance	63.52806	91
593	901	enhance	63.404274	92
593	230	enhance	63.200806	93
593	26	enhance	62.961506	94
593	57	enhance	62.459602	95
593	98	enhance	61.9032	96
593	37	enhance	61.70589	97
593	15	enhance	61.35552	98
593	358	enhance	61.146755	99
593	640	enhance	61.120064	100
593	17	enhance	61.00051	101
593	222	enhance	60.79526	102
593	56	enhance	60.575237	103
593	71	enhance	59.858906	104
593	48	enhance	59.69704	105
593	61	enhance	59.082024	106
593	73	enhance	58.93323	107
593	68	enhance	58.14674	108
593	1	enhance	57.411633	109
593	36	enhance	57.242607	110
593	84	enhance	57.084488	111
593	88	enhance	56.18288	112
593	87	enhance	54.550495	113
593	40	enhance	53.657963	114
593	33	enhance	53.436695	115
593	30	enhance	52.158043	116
593	47	enhance	50.20827	117
593	25	enhance	49.339737	118
593	75	enhance	44.247593	119
593	46	enhance	43.247505	120
593	51	enhance	42.540443	121
593	155	enhance	42.30048	122
593	882	enhance	40.741375	123
593	67	enhance	38.85311	124
593	11	soften	100	1
593	64	soften	99.87275	2
593	60	soften	97.900055	3
593	80	soften	96.04614	4
593	72	soften	95.91166	5
593	83	soften	95.5984	6
593	126	soften	94.553185	7
593	55	soften	94.40698	8
593	90	soften	94.13639	9
593	91	soften	93.31533	10
593	3	soften	92.9185	11
593	74	soften	91.92009	12
593	70	soften	91.12154	13
593	93	soften	90.66227	14
593	45	soften	89.09216	15
593	13	soften	88.78356	16
593	184	soften	88.73668	17
593	30	soften	87.6747	18
593	79	soften	87.62636	19
593	33	soften	87.60834	20
593	4	soften	87.22397	21
593	49	soften	86.99775	22
593	868	soften	86.70598	23
593	182	soften	85.98851	24
593	34	soften	85.96098	25
593	222	soften	85.63652	26
593	96	soften	85.58874	27
593	43	soften	85.25286	28
593	22	soften	85.17743	29
593	99	soften	85.00862	30
593	73	soften	84.789734	31
593	23	soften	84.68587	32
593	335	soften	84.45393	33
593	171	soften	84.42475	34
593	94	soften	83.73262	35
593	2	soften	83.44683	36
593	78	soften	83.281395	37
593	44	soften	82.857475	38
593	82	soften	82.72569	39
593	219	soften	82.311775	40
593	59	soften	82.204666	41
593	21	soften	82.069016	42
593	9	soften	81.9362	43
593	39	soften	81.802734	44
593	5	soften	81.303375	45
593	28	soften	81.10891	46
593	20	soften	80.80197	47
593	18	soften	80.42518	48
593	12	soften	79.352295	49
593	35	soften	78.592834	50
593	85	soften	78.34775	51
593	95	soften	78.02461	52
593	41	soften	77.59879	53
640	13	enhance	100	1
640	61	enhance	99.32161	2
640	230	enhance	98.73609	3
640	33	enhance	97.48318	4
640	222	enhance	93.06067	5
640	31	enhance	93.01418	6
640	98	enhance	90.79138	7
640	182	enhance	90.56972	8
640	49	enhance	89.92934	9
640	47	enhance	88.83277	10
640	99	enhance	88.622795	11
640	63	enhance	85.75161	12
640	88	enhance	85.55219	13
640	43	enhance	81.974625	14
640	92	enhance	81.81863	15
640	67	enhance	81.544	16
640	50	enhance	81.32401	17
640	70	enhance	81.07955	18
640	126	enhance	81.07728	19
640	285	enhance	79.77756	20
640	94	enhance	79.61914	21
640	90	enhance	79.35284	22
640	51	enhance	79.27887	23
640	2	enhance	77.94101	24
640	39	enhance	77.12739	25
640	34	enhance	74.4279	26
640	176	enhance	74.031845	27
640	72	enhance	73.89618	28
640	108	enhance	73.45535	29
640	45	enhance	71.83242	30
640	187	enhance	70.53207	31
640	36	enhance	70.02717	32
640	56	enhance	69.80314	33
640	7	enhance	69.07866	34
640	83	enhance	68.44024	35
640	84	enhance	68.351006	36
640	68	enhance	67.82797	37
640	1	enhance	66.580215	38
640	80	enhance	66.25031	39
640	89	enhance	66.249435	40
640	40	enhance	66.199104	41
640	19	enhance	65.17762	42
640	30	enhance	64.541534	43
640	10	enhance	64.4678	44
640	93	enhance	64.11116	45
640	82	enhance	63.0098	46
640	86	enhance	62.793682	47
640	25	enhance	61.702774	48
640	75	enhance	61.49793	49
640	647	enhance	61.405987	50
640	48	enhance	61.34194	51
640	3	enhance	59.854618	52
640	71	enhance	59.656246	53
640	593	enhance	59.186295	54
640	15	enhance	57.598186	55
640	87	enhance	56.747066	56
640	73	enhance	54.654774	57
640	79	enhance	54.56783	58
640	28	enhance	54.46839	59
640	46	enhance	53.82926	60
640	27	enhance	53.424103	61
640	17	enhance	53.272625	62
640	55	enhance	52.34255	63
640	785	enhance	51.570637	64
640	54	enhance	51.29806	65
640	155	enhance	51.020123	66
640	37	enhance	50.905056	67
640	882	enhance	50.48663	68
640	66	enhance	50.20945	69
640	52	enhance	49.31672	70
640	44	enhance	48.94423	71
640	18	enhance	47.58868	72
640	455	enhance	47.1403	73
640	868	enhance	47.120453	74
640	23	enhance	46.831417	75
640	5	enhance	46.61539	76
640	60	enhance	46.267593	77
640	24	enhance	45.820953	78
640	185	enhance	45.19273	79
640	78	enhance	44.994286	80
640	184	enhance	43.302395	81
640	358	enhance	43.167778	82
640	76	enhance	43.121834	83
640	11	enhance	43.119427	84
640	59	enhance	42.690136	85
640	91	enhance	41.898884	86
640	6	enhance	41.74035	87
640	97	enhance	41.04095	88
640	62	enhance	40.16506	89
640	64	enhance	39.991367	90
640	26	enhance	39.748356	91
640	22	enhance	39.05629	92
640	4	enhance	38.672962	93
640	38	enhance	37.933113	94
640	16	enhance	37.796825	95
640	9	enhance	37.692745	96
640	58	enhance	37.60698	97
640	901	enhance	37.60267	98
640	100	enhance	36.924374	99
640	77	enhance	35.96862	100
640	42	enhance	35.644512	101
640	74	enhance	35.434586	102
640	29	enhance	34.989323	103
640	96	enhance	34.769554	104
640	335	enhance	34.45105	105
640	8	enhance	34.289433	106
640	21	enhance	33.597683	107
640	219	enhance	32.245934	108
640	171	enhance	31.922272	109
640	921	enhance	30.803694	110
640	81	enhance	30.652634	111
640	12	enhance	30.292	112
640	41	enhance	29.783085	113
640	85	enhance	28.8356	114
640	14	enhance	28.511053	115
640	69	enhance	28.494741	116
640	20	enhance	26.735012	117
640	32	enhance	26.473526	118
640	35	enhance	25.872757	119
640	53	enhance	25.04892	120
640	65	enhance	24.095797	121
640	57	enhance	23.788916	122
640	95	enhance	20.00768	123
640	488	enhance	18.63584	124
640	64	soften	100	1
640	74	soften	97.0573	2
640	11	soften	96.40229	3
640	91	soften	93.76724	4
640	60	soften	92.0192	5
640	96	soften	90.96349	6
640	184	soften	89.76223	7
640	335	soften	89.13474	8
640	55	soften	88.271194	9
640	4	soften	87.162186	10
640	22	soften	87.07786	11
640	21	soften	86.72789	12
640	219	soften	86.33499	13
640	868	soften	86.14017	14
640	171	soften	86.123	15
640	20	soften	85.77848	16
640	3	soften	84.60015	17
640	85	soften	83.972	18
640	23	soften	83.93875	19
640	95	soften	83.80573	20
640	12	soften	83.767685	21
640	35	soften	83.68252	22
640	93	soften	83.63643	23
640	9	soften	83.313835	24
640	59	soften	83.1755	25
640	78	soften	83.15575	26
640	80	soften	82.11305	27
640	41	soften	81.898865	28
640	83	soften	81.88999	29
640	79	soften	81.40274	30
640	44	soften	81.28813	31
640	72	soften	80.45651	32
640	5	soften	80.10931	33
640	18	soften	78.773766	34
640	70	soften	78.20039	35
640	90	soften	78.178764	36
640	126	soften	77.68958	37
640	82	soften	76.47962	38
640	593	soften	76.169395	39
640	45	soften	76.11463	40
640	28	soften	75.07603	41
640	34	soften	74.95948	42
640	94	soften	73.78022	43
640	73	soften	73.2735	44
640	39	soften	73.23648	45
640	2	soften	72.83525	46
640	30	soften	72.67639	47
640	43	soften	71.95749	48
640	63	soften	71.25964	49
640	99	soften	71.02727	50
640	49	soften	70.59254	51
640	182	soften	70.08456	52
640	13	soften	68.45474	53
640	222	soften	67.62079	54
640	33	soften	64.24335	55
647	6	enhance	100	1
647	185	enhance	99.15679	2
647	108	enhance	98.560974	3
647	17	enhance	98.224045	4
647	785	enhance	97.8795	5
647	89	enhance	97.04318	6
647	97	enhance	96.998505	7
647	62	enhance	96.56197	8
647	36	enhance	96.343765	9
647	358	enhance	96.237114	10
647	71	enhance	95.66733	11
647	76	enhance	95.33986	12
647	1	enhance	95.17485	13
647	48	enhance	94.97312	14
647	16	enhance	94.82858	15
647	455	enhance	94.81337	16
647	38	enhance	94.769844	17
647	40	enhance	94.7075	18
647	68	enhance	94.593285	19
647	42	enhance	94.45331	20
647	84	enhance	94.31747	21
647	29	enhance	93.962074	22
647	24	enhance	93.401505	23
647	52	enhance	92.90359	24
647	87	enhance	92.4097	25
647	26	enhance	92.31568	26
647	56	enhance	91.14332	27
647	86	enhance	91.12866	28
647	37	enhance	91.01729	29
647	25	enhance	90.62667	30
647	54	enhance	90.0064	31
647	46	enhance	89.33845	32
647	88	enhance	89.2999	33
647	921	enhance	88.153824	34
647	882	enhance	87.72055	35
647	10	enhance	87.6118	36
647	27	enhance	87.54648	37
647	75	enhance	87.54323	38
647	39	enhance	87.38042	39
647	285	enhance	86.9466	40
647	31	enhance	86.82195	41
647	81	enhance	86.80382	42
647	100	enhance	86.74521	43
647	155	enhance	86.192665	44
647	77	enhance	85.159645	45
647	15	enhance	84.83484	46
647	7	enhance	84.129196	47
647	98	enhance	83.68534	48
647	176	enhance	83.13918	49
647	901	enhance	81.97635	50
647	187	enhance	81.43391	51
647	92	enhance	80.568214	52
647	18	enhance	79.39333	53
647	53	enhance	79.077934	54
647	63	enhance	77.92884	55
647	28	enhance	76.54138	56
647	50	enhance	76.04049	57
647	94	enhance	75.849945	58
647	19	enhance	75.352646	59
647	49	enhance	75.042015	60
647	14	enhance	74.97644	61
647	30	enhance	74.03922	62
647	73	enhance	73.60667	63
647	58	enhance	72.34194	64
647	66	enhance	71.90185	65
647	593	enhance	71.883125	66
647	34	enhance	71.673775	67
647	65	enhance	71.44835	68
647	78	enhance	71.446655	69
647	47	enhance	70.777756	70
647	43	enhance	70.650375	71
647	222	enhance	70.10995	72
647	61	enhance	69.19408	73
647	32	enhance	68.28312	74
647	67	enhance	68.25648	75
647	230	enhance	66.84177	76
647	182	enhance	66.06775	77
647	45	enhance	65.8503	78
647	640	enhance	64.57374	79
647	13	enhance	62.795532	80
647	51	enhance	61.879253	81
647	8	enhance	61.03985	82
647	57	enhance	59.92818	83
647	79	enhance	59.563847	84
647	99	enhance	59.231773	85
647	44	enhance	58.183434	86
647	2	enhance	57.50551	87
647	488	enhance	57.34006	88
647	219	enhance	57.083065	89
647	59	enhance	56.598038	90
647	70	enhance	56.267128	91
647	868	enhance	56.10099	92
647	82	enhance	55.4822	93
647	95	enhance	55.26925	94
647	184	enhance	55.21509	95
647	20	enhance	54.701187	96
647	171	enhance	54.055313	97
647	33	enhance	53.88944	98
647	335	enhance	51.0734	99
647	35	enhance	50.234203	100
647	126	enhance	49.933643	101
647	5	enhance	49.85576	102
647	21	enhance	49.197834	103
647	80	enhance	48.884827	104
647	69	enhance	48.51504	105
647	12	enhance	48.48201	106
647	85	enhance	48.275536	107
647	93	enhance	48.25842	108
647	96	enhance	47.898582	109
647	41	enhance	47.738693	110
647	3	enhance	46.828423	111
647	83	enhance	46.630177	112
647	22	enhance	46.076057	113
647	72	enhance	45.120533	114
647	23	enhance	44.154064	115
647	55	enhance	42.93987	116
647	9	enhance	42.930443	117
647	90	enhance	42.628872	118
647	4	enhance	40.700127	119
647	74	enhance	40.080112	120
647	64	enhance	37.044617	121
647	91	enhance	34.866745	122
647	11	enhance	34.6571	123
647	60	enhance	32.59726	124
647	11	soften	100	1
647	60	soften	97.99509	2
647	91	soften	96.073906	3
647	80	soften	95.64658	4
647	55	soften	93.39151	5
647	83	soften	93.08566	6
647	90	soften	92.739555	7
647	126	soften	92.46028	8
647	72	soften	92.427635	9
647	3	soften	91.54583	10
647	93	soften	89.48641	11
647	70	soften	88.23781	12
647	4	soften	88.00267	13
647	96	soften	87.80194	14
647	79	soften	87.64237	15
647	23	soften	87.36429	16
647	184	soften	86.37417	17
647	45	soften	85.77133	18
647	171	soften	85.40605	19
647	21	soften	85.36709	20
647	335	soften	84.83374	21
647	868	soften	84.57349	22
647	9	soften	84.33713	23
647	22	soften	83.845375	24
647	20	soften	83.403465	25
647	82	soften	83.30276	26
647	2	soften	83.21806	27
647	5	soften	83.13857	28
647	34	soften	82.75658	29
647	219	soften	82.745	30
647	13	soften	82.501335	31
647	12	soften	82.3153	32
647	85	soften	82.22004	33
647	59	soften	82.15379	34
647	33	soften	81.924904	35
647	99	soften	81.76554	36
647	35	soften	81.74753	37
647	182	soften	81.23565	38
647	43	soften	81.19911	39
647	78	soften	79.841	40
647	30	soften	79.721924	41
647	73	soften	79.130684	42
647	44	soften	79.02314	43
647	41	soften	78.74986	44
647	18	soften	77.973976	45
647	63	soften	77.93034	46
647	69	soften	77.858055	47
647	640	soften	77.68214	48
647	593	soften	77.51577	49
647	28	soften	77.05412	50
647	230	soften	76.82133	51
647	50	soften	76.30831	52
647	66	soften	75.320786	53
647	8	soften	75.162544	54
647	39	soften	74.69732	55
647	187	soften	73.3914	56
647	176	soften	73.0083	57
647	285	soften	72.88024	58
647	488	soften	71.77788	59
647	7	soften	71.55109	60
647	98	soften	70.93056	61
647	64	soften	70.24106	62
647	54	soften	70.204834	63
647	58	soften	70.11906	64
647	19	soften	69.69063	65
647	89	soften	69.266304	66
647	27	soften	69.18349	67
647	10	soften	68.45947	68
647	455	soften	68.03013	69
647	86	soften	67.94983	70
647	74	soften	67.77302	71
647	24	soften	67.229164	72
647	108	soften	66.06011	73
647	52	soften	65.8192	74
647	49	soften	56.8752	75
647	95	soften	56.635365	76
647	94	soften	55.08137	77
647	61	soften	54.541813	78
647	222	soften	53.697914	79
647	92	soften	51.810078	80
647	51	soften	51.671314	81
647	47	soften	51.603065	82
647	31	soften	50.281544	83
647	56	soften	49.62359	84
647	67	soften	47.93341	85
647	88	soften	46.624176	86
647	1	soften	46.500458	87
647	84	soften	46.314312	88
785	76	enhance	100	1
785	358	enhance	99.98146	2
785	17	enhance	99.78445	3
785	38	enhance	98.76016	4
785	185	enhance	98.39306	5
785	42	enhance	98.14628	6
785	71	enhance	98.11871	7
785	16	enhance	98.003136	8
785	6	enhance	96.495476	9
785	87	enhance	95.923874	10
785	29	enhance	95.54846	11
785	97	enhance	94.20876	12
785	48	enhance	94.09213	13
785	62	enhance	94.05106	14
785	24	enhance	94.04107	15
785	647	enhance	93.43628	16
785	37	enhance	92.966675	17
785	68	enhance	92.93317	18
785	46	enhance	91.97775	19
785	455	enhance	91.84477	20
785	52	enhance	91.412155	21
785	155	enhance	91.28177	22
785	81	enhance	90.97911	23
785	882	enhance	90.67984	24
785	25	enhance	90.27384	25
785	100	enhance	90.2719	26
785	36	enhance	89.93577	27
785	84	enhance	89.84112	28
785	108	enhance	89.77646	29
785	1	enhance	89.02341	30
785	77	enhance	88.893105	31
785	40	enhance	88.55336	32
785	75	enhance	88.263824	33
785	10	enhance	87.72372	34
785	921	enhance	86.90793	35
785	15	enhance	86.30601	36
785	54	enhance	86.25331	37
785	26	enhance	85.96108	38
785	176	enhance	85.883415	39
785	901	enhance	84.67338	40
785	53	enhance	83.53608	41
785	27	enhance	82.6402	42
785	89	enhance	82.35869	43
785	86	enhance	81.33815	44
785	88	enhance	80.313324	45
785	92	enhance	79.947334	46
785	285	enhance	79.717155	47
785	7	enhance	78.242195	48
785	14	enhance	76.81708	49
785	65	enhance	75.530174	50
785	32	enhance	73.97502	51
785	187	enhance	73.714195	52
785	31	enhance	73.64319	53
785	98	enhance	73.46016	54
785	66	enhance	73.02626	55
785	19	enhance	72.28151	56
785	56	enhance	72.21474	57
785	39	enhance	72.16933	58
785	28	enhance	70.96968	59
785	67	enhance	70.85533	60
785	50	enhance	69.905464	61
785	94	enhance	68.00808	62
785	222	enhance	67.64686	63
785	593	enhance	67.525154	64
785	51	enhance	67.38281	65
785	18	enhance	67.110245	66
785	58	enhance	66.687584	67
785	78	enhance	63.372902	68
785	8	enhance	62.60609	69
785	47	enhance	61.52006	70
785	63	enhance	60.884346	71
785	57	enhance	59.949223	72
785	488	enhance	59.608097	73
785	182	enhance	59.244648	74
785	59	enhance	58.103344	75
785	49	enhance	56.19922	76
785	868	enhance	56.10013	77
785	34	enhance	55.44086	78
785	219	enhance	54.35861	79
785	44	enhance	53.61725	80
785	82	enhance	52.5843	81
785	35	enhance	52.54929	82
785	171	enhance	52.335815	83
785	12	enhance	52.257725	84
785	640	enhance	51.769207	85
785	61	enhance	51.58807	86
785	95	enhance	50.748856	87
785	20	enhance	50.627224	88
785	335	enhance	50.480434	89
785	85	enhance	49.756416	90
785	230	enhance	49.649895	91
785	5	enhance	49.00589	92
785	69	enhance	48.74944	93
785	13	enhance	48.740486	94
785	41	enhance	48.505463	95
785	73	enhance	48.48455	96
785	43	enhance	48.382763	97
785	184	enhance	48.052135	98
785	21	enhance	47.561054	99
785	30	enhance	45.07526	100
785	99	enhance	45.0112	101
785	70	enhance	44.03149	102
785	79	enhance	43.59764	103
785	22	enhance	43.55631	104
785	96	enhance	41.931164	105
785	9	enhance	41.734623	106
785	4	enhance	41.569904	107
785	45	enhance	40.921844	108
785	23	enhance	40.37632	109
785	2	enhance	40.02262	110
785	55	enhance	39.136955	111
785	72	enhance	38.38039	112
785	93	enhance	37.996334	113
785	83	enhance	37.459126	114
785	33	enhance	36.897953	115
785	3	enhance	35.624657	116
785	60	enhance	33.155033	117
785	126	enhance	31.61602	118
785	91	enhance	31.233696	119
785	11	enhance	29.6466	120
785	74	enhance	29.581696	121
785	64	enhance	29.54297	122
785	90	enhance	28.418425	123
785	80	enhance	22.469175	124
785	64	soften	100	1
785	80	soften	99.49884	2
785	11	soften	98.71252	3
785	74	soften	96.05531	4
785	60	soften	95.32973	5
785	90	soften	95.15023	6
785	91	soften	94.55751	7
785	126	soften	94.342705	8
785	3	soften	92.076385	9
785	83	soften	91.955826	10
785	55	soften	91.49506	11
785	72	soften	91.41696	12
785	93	soften	90.37164	13
785	79	soften	89.839615	14
785	70	soften	88.61074	15
785	45	soften	87.73177	16
785	23	soften	87.04387	17
785	96	soften	86.030464	18
785	4	soften	86.01094	19
785	184	soften	85.72334	20
785	2	soften	85.46985	21
785	33	soften	85.290016	22
785	99	soften	84.14812	23
785	13	soften	83.905495	24
785	43	soften	83.78159	25
785	21	soften	83.71978	26
785	34	soften	83.4056	27
785	30	soften	83.34054	28
785	49	soften	83.17112	29
785	171	soften	82.78547	30
785	335	soften	82.5931	31
785	9	soften	82.391846	32
785	22	soften	82.38857	33
785	5	soften	82.34969	34
785	82	soften	82.24591	35
785	73	soften	81.93053	36
785	868	soften	81.641495	37
785	182	soften	81.62876	38
785	20	soften	81.29881	39
785	219	soften	80.78418	40
785	85	soften	79.992195	41
785	59	soften	79.98042	42
785	61	soften	79.94783	43
785	12	soften	79.593666	44
785	63	soften	79.430695	45
785	230	soften	79.42947	46
785	78	soften	79.322495	47
785	640	soften	79.301186	48
785	35	soften	79.224174	49
785	44	soften	78.38957	50
785	94	soften	78.32881	51
785	18	soften	78.185394	52
785	95	soften	78.05758	53
785	28	soften	77.49384	54
785	593	soften	77.323166	55
785	41	soften	76.52015	56
785	50	soften	76.4954	57
785	69	soften	76.00943	58
785	39	soften	75.9954	59
785	222	soften	75.33125	60
785	66	soften	74.12836	61
785	8	soften	73.9965	62
785	187	soften	73.50247	63
785	31	soften	72.98145	64
785	47	soften	72.64993	65
785	98	soften	72.110565	66
785	92	soften	72.090294	67
785	56	soften	72.03613	68
785	285	soften	71.703575	69
785	7	soften	71.495	70
785	51	soften	70.201996	71
785	54	soften	69.81595	72
785	176	soften	69.77572	73
785	89	soften	69.5286	74
785	488	soften	69.46907	75
785	27	soften	69.007484	76
785	58	soften	68.69274	77
785	19	soften	68.34931	78
785	10	soften	66.96925	79
785	88	soften	66.83989	80
785	86	soften	66.7239	81
785	455	soften	66.690704	82
785	108	soften	66.40474	83
785	67	soften	65.903	84
785	14	soften	65.856	85
785	84	soften	64.79778	86
785	1	soften	64.78226	87
785	52	soften	64.73971	88
785	24	soften	64.6537	89
785	26	soften	64.50801	90
785	647	soften	64.47849	91
785	62	soften	62.221657	92
785	36	soften	61.268253	93
868	184	enhance	100	1
868	64	enhance	99.7594	2
868	11	enhance	99.52772	3
868	335	enhance	99.17082	4
868	55	enhance	98.9357	5
868	60	enhance	98.58305	6
868	219	enhance	96.02925	7
868	44	enhance	95.80515	8
868	22	enhance	95.357506	9
868	59	enhance	94.75319	10
868	96	enhance	94.23156	11
868	593	enhance	93.79127	12
868	4	enhance	93.60345	13
868	91	enhance	92.8399	14
868	78	enhance	92.81237	15
868	93	enhance	92.65162	16
868	171	enhance	92.28306	17
868	41	enhance	92.07186	18
868	9	enhance	91.79467	19
868	23	enhance	90.995995	20
868	5	enhance	89.21415	21
868	3	enhance	88.561615	22
868	94	enhance	88.44507	23
868	21	enhance	88.15195	24
868	74	enhance	88.09055	25
868	12	enhance	87.13731	26
868	66	enhance	86.33489	27
868	7	enhance	86.16938	28
868	85	enhance	85.31899	29
868	69	enhance	85.1814	30
868	92	enhance	85.03029	31
868	70	enhance	84.94937	32
868	10	enhance	84.90135	33
868	20	enhance	84.65511	34
868	35	enhance	84.34181	35
868	82	enhance	84.26752	36
868	58	enhance	84.124916	37
868	72	enhance	83.558304	38
868	39	enhance	82.59656	39
868	455	enhance	81.01595	40
868	8	enhance	80.91427	41
868	28	enhance	80.74278	42
868	50	enhance	80.17448	43
868	83	enhance	80.15116	44
868	52	enhance	78.62577	45
868	18	enhance	78.08651	46
868	27	enhance	78.04577	47
868	90	enhance	76.775185	48
868	63	enhance	76.152405	49
868	77	enhance	75.94005	50
868	100	enhance	75.38246	51
868	176	enhance	73.717285	52
868	86	enhance	73.43892	53
868	19	enhance	73.3938	54
868	99	enhance	73.315796	55
868	54	enhance	71.99355	56
868	65	enhance	71.89831	57
868	34	enhance	71.479645	58
868	182	enhance	70.79061	59
868	79	enhance	70.28406	60
868	95	enhance	69.41831	61
868	24	enhance	69.08022	62
868	126	enhance	69.00422	63
868	14	enhance	67.41676	64
868	62	enhance	67.25803	65
868	285	enhance	66.12988	66
868	187	enhance	65.86653	67
868	108	enhance	64.93487	68
868	488	enhance	64.313995	69
868	185	enhance	63.654427	70
868	49	enhance	63.596878	71
868	38	enhance	63.02248	72
868	32	enhance	62.64167	73
868	2	enhance	62.61499	74
868	15	enhance	62.370663	75
868	43	enhance	62.258224	76
868	42	enhance	60.61096	77
868	785	enhance	59.990334	78
868	222	enhance	59.835423	79
868	80	enhance	58.69593	80
868	13	enhance	58.607147	81
868	89	enhance	58.428005	82
868	647	enhance	57.267963	83
868	1	enhance	56.75168	84
868	76	enhance	55.480156	85
868	921	enhance	55.42279	86
868	901	enhance	54.741016	87
868	48	enhance	53.946545	88
868	16	enhance	53.61376	89
868	45	enhance	53.14238	90
868	6	enhance	52.98697	91
868	71	enhance	52.42075	92
868	81	enhance	52.228035	93
868	68	enhance	52.141636	94
868	84	enhance	51.709675	95
868	36	enhance	51.67135	96
868	53	enhance	51.087986	97
868	17	enhance	50.723705	98
868	640	enhance	50.581985	99
868	26	enhance	50.51115	100
868	87	enhance	50.05303	101
868	57	enhance	49.74095	102
868	97	enhance	49.727516	103
868	37	enhance	49.49372	104
868	31	enhance	49.32889	105
868	358	enhance	48.3549	106
868	51	enhance	47.200573	107
868	56	enhance	46.77776	108
868	47	enhance	46.187458	109
868	88	enhance	45.982365	110
868	29	enhance	45.893673	111
868	98	enhance	45.09534	112
868	25	enhance	44.998554	113
868	40	enhance	44.920967	114
868	230	enhance	44.785294	115
868	61	enhance	44.28658	116
868	67	enhance	40.692383	117
868	75	enhance	40.67881	118
868	155	enhance	39.831	119
868	73	enhance	39.396023	120
868	882	enhance	37.989765	121
868	33	enhance	37.62734	122
868	46	enhance	37.145714	123
868	30	enhance	36.60644	124
868	80	soften	100	1
868	11	soften	98.83283	2
868	126	soften	97.07002	3
868	90	soften	96.918755	4
868	60	soften	95.18232	5
868	83	soften	95.01305	6
868	72	soften	94.85761	7
868	3	soften	93.57906	8
868	55	soften	92.84447	9
868	70	soften	90.550095	10
868	93	soften	90.06591	11
868	91	soften	89.59368	12
868	79	soften	88.37115	13
868	184	soften	86.358246	14
868	4	soften	84.35629	15
868	96	soften	81.525246	16
868	22	soften	81.454865	17
868	335	soften	80.05912	18
868	64	soften	69.01014	19
868	74	soften	62.18454	20
882	155	enhance	100	1
882	46	enhance	98.849945	2
882	87	enhance	98.04018	3
882	25	enhance	96.21201	4
882	75	enhance	95.74289	5
882	68	enhance	94.41744	6
882	48	enhance	94.14366	7
882	84	enhance	94.02841	8
882	17	enhance	92.32824	9
882	358	enhance	91.91043	10
882	40	enhance	91.659294	11
882	71	enhance	91.35277	12
882	36	enhance	90.82455	13
882	785	enhance	89.12665	14
882	76	enhance	87.76067	15
882	1	enhance	86.59029	16
882	97	enhance	84.97638	17
882	6	enhance	84.77457	18
882	16	enhance	84.116554	19
882	37	enhance	83.31888	20
882	108	enhance	82.40583	21
882	647	enhance	82.3042	22
882	86	enhance	81.41487	23
882	29	enhance	81.30998	24
882	15	enhance	80.87568	25
882	38	enhance	80.85206	26
882	67	enhance	80.59423	27
882	88	enhance	79.240105	28
882	42	enhance	78.909355	29
882	176	enhance	77.00489	30
882	185	enhance	76.91533	31
882	52	enhance	75.90808	32
882	285	enhance	75.178375	33
882	10	enhance	75.06916	34
882	51	enhance	74.32048	35
882	24	enhance	74.00127	36
882	92	enhance	72.23776	37
882	62	enhance	70.86644	38
882	222	enhance	70.74021	39
882	89	enhance	70.68192	40
882	31	enhance	69.439606	41
882	26	enhance	68.99498	42
882	455	enhance	68.93716	43
882	27	enhance	67.79585	44
882	901	enhance	67.501976	45
882	98	enhance	66.94595	46
882	81	enhance	66.113914	47
882	100	enhance	64.740654	48
882	39	enhance	64.21919	49
882	56	enhance	63.09283	50
882	7	enhance	62.591995	51
882	77	enhance	62.142925	52
882	54	enhance	59.97891	53
882	47	enhance	59.19506	54
882	921	enhance	57.500713	55
882	187	enhance	56.317585	56
882	19	enhance	55.157845	57
882	53	enhance	54.02288	58
882	94	enhance	53.058475	59
882	640	enhance	49.812943	60
882	66	enhance	47.4594	61
882	61	enhance	46.421505	62
882	50	enhance	45.417866	63
882	28	enhance	43.729122	64
882	13	enhance	43.101463	65
882	49	enhance	42.899014	66
882	63	enhance	42.579853	67
882	230	enhance	41.436073	68
882	65	enhance	40.45236	69
882	58	enhance	39.94491	70
882	78	enhance	39.733467	71
882	182	enhance	39.657696	72
882	14	enhance	39.471073	73
882	44	enhance	38.93375	74
882	593	enhance	38.925915	75
882	18	enhance	37.915276	76
882	30	enhance	36.24896	77
882	32	enhance	35.363777	78
882	868	enhance	34.917732	79
882	57	enhance	33.1248	80
882	73	enhance	31.940304	81
882	33	enhance	29.832617	82
882	43	enhance	29.798971	83
882	184	enhance	29.235577	84
882	59	enhance	28.71132	85
882	34	enhance	28.190481	86
882	99	enhance	27.093262	87
882	70	enhance	27.010374	88
882	22	enhance	25.63079	89
882	8	enhance	25.466082	90
882	45	enhance	24.221825	91
882	335	enhance	23.845106	92
882	72	enhance	22.504269	93
882	219	enhance	22.381773	94
882	93	enhance	20.05437	95
882	41	enhance	19.925234	96
882	488	enhance	17.83288	97
882	79	enhance	17.489014	98
882	82	enhance	16.947212	99
882	12	enhance	16.639765	100
882	83	enhance	16.374174	101
882	171	enhance	16.236094	102
882	69	enhance	15.35084	103
882	96	enhance	14.980191	104
882	5	enhance	14.956189	105
882	2	enhance	14.944669	106
882	21	enhance	14.807607	107
882	55	enhance	14.2123575	108
882	85	enhance	14.171142	109
882	4	enhance	14.035957	110
882	35	enhance	13.848945	111
882	3	enhance	13.619931	112
882	20	enhance	12.62296	113
882	126	enhance	12.446112	114
882	95	enhance	12.155548	115
882	9	enhance	11.956457	116
882	60	enhance	10.884282	117
882	64	enhance	10.580124	118
882	90	enhance	10.310364	119
882	23	enhance	9.351629	120
882	91	enhance	9.207368	121
882	11	enhance	9.162708	122
882	80	enhance	5.892653	123
882	74	enhance	3.9585516	124
882	11	soften	100	1
882	64	soften	99.801994	2
882	80	soften	98.19369	3
882	74	soften	98.11264	4
882	60	soften	96.893585	5
882	91	soften	95.106606	6
882	90	soften	93.934875	7
882	126	soften	93.38045	8
882	55	soften	92.798454	9
882	83	soften	91.93976	10
882	3	soften	91.92324	11
882	72	soften	89.23573	12
882	23	soften	88.81445	13
882	79	soften	88.20919	14
882	4	soften	87.68033	15
882	93	soften	87.63262	16
882	96	soften	86.35503	17
882	171	soften	85.88005	18
882	70	soften	85.48662	19
882	45	soften	85.14782	20
882	21	soften	85.02646	21
882	20	soften	84.76705	22
882	9	soften	84.60497	23
882	2	soften	84.53254	24
882	5	soften	83.98666	25
882	82	soften	83.73137	26
882	35	soften	82.83165	27
882	34	soften	82.75214	28
882	184	soften	82.51109	29
882	85	soften	82.45473	30
882	95	soften	81.99628	31
882	335	soften	81.8583	32
882	219	soften	81.83896	33
882	12	soften	81.774956	34
882	99	soften	81.42138	35
882	43	soften	81.33423	36
882	33	soften	80.55593	37
882	22	soften	79.66338	38
882	868	soften	79.16244	39
882	59	soften	78.94532	40
882	182	soften	78.468636	41
882	30	soften	78.24751	42
882	73	soften	78.1742	43
882	69	soften	77.98842	44
882	13	soften	77.866066	45
882	49	soften	77.73229	46
882	41	soften	77.51198	47
882	78	soften	76.36513	48
882	18	soften	75.93689	49
882	63	soften	75.76938	50
882	8	soften	75.6743	51
882	593	soften	75.06523	52
882	28	soften	74.30306	53
882	230	soften	74.22317	54
882	50	soften	73.96551	55
882	61	soften	73.875275	56
882	44	soften	73.53625	57
882	94	soften	72.70155	58
882	488	soften	72.69917	59
882	640	soften	72.602486	60
882	187	soften	70.406075	61
882	66	soften	70.28491	62
882	39	soften	68.41824	63
882	58	soften	67.45334	64
882	7	soften	67.03259	65
882	56	soften	66.939	66
882	47	soften	66.92227	67
882	222	soften	66.635506	68
882	14	soften	66.3547	69
882	92	soften	65.92226	70
882	54	soften	65.716194	71
882	31	soften	65.66505	72
882	19	soften	65.43475	73
882	98	soften	64.43057	74
882	89	soften	64.32397	75
882	285	soften	63.55918	76
882	65	soften	63.530094	77
882	176	soften	63.005642	78
882	455	soften	61.844547	79
882	27	soften	61.815613	80
882	51	soften	60.939884	81
882	921	soften	60.76517	82
882	26	soften	60.700397	83
882	10	soften	60.689995	84
882	24	soften	59.23365	85
882	901	soften	59.203915	86
882	108	soften	58.9142	87
882	88	soften	58.23528	88
882	62	soften	58.10211	89
882	52	soften	57.81635	90
882	647	soften	57.68264	91
882	185	soften	57.465683	92
882	77	soften	57.397552	93
882	1	soften	57.261	94
882	100	soften	56.74063	95
882	86	soften	56.44519	96
882	67	soften	56.144783	97
882	84	soften	54.6225	98
882	785	soften	54.33855	99
882	36	soften	52.530437	100
882	6	soften	51.699184	101
882	71	soften	51.62856	102
882	17	soften	51.220043	103
882	40	soften	49.208603	104
882	48	soften	49.04032	105
882	97	soften	48.98102	106
882	87	soften	48.81131	107
882	25	soften	47.576504	108
882	155	soften	44.29108	109
901	26	enhance	100	1
901	16	enhance	98.55713	2
901	187	enhance	97.868706	3
901	81	enhance	96.80305	4
901	185	enhance	95.30569	5
901	921	enhance	92.489685	6
901	785	enhance	91.75612	7
901	42	enhance	91.41577	8
901	37	enhance	91.17874	9
901	7	enhance	90.91893	10
901	38	enhance	90.08301	11
901	62	enhance	89.77231	12
901	89	enhance	89.594025	13
901	17	enhance	87.65341	14
901	358	enhance	87.4478	15
901	76	enhance	87.42308	16
901	71	enhance	86.939156	17
901	15	enhance	86.17663	18
901	29	enhance	85.75234	19
901	108	enhance	85.158195	20
901	647	enhance	84.800896	21
901	455	enhance	84.42018	22
901	6	enhance	83.47774	23
901	52	enhance	82.27303	24
901	56	enhance	81.94904	25
901	100	enhance	81.92436	26
901	1	enhance	81.830055	27
901	48	enhance	81.01715	28
901	77	enhance	80.95698	29
901	19	enhance	80.19942	30
901	14	enhance	79.30649	31
901	54	enhance	79.20876	32
901	8	enhance	78.61683	33
901	65	enhance	78.50945	34
901	68	enhance	78.40408	35
901	87	enhance	78.14496	36
901	24	enhance	78.08512	37
901	10	enhance	77.50601	38
901	57	enhance	76.4563	39
901	97	enhance	76.262314	40
901	36	enhance	75.78277	41
901	46	enhance	74.43293	42
901	882	enhance	74.4231	43
901	155	enhance	73.75115	44
901	92	enhance	73.6775	45
901	58	enhance	73.19316	46
901	25	enhance	73.15999	47
901	53	enhance	71.85707	48
901	40	enhance	70.76071	49
901	27	enhance	69.93209	50
901	84	enhance	69.194374	51
901	32	enhance	68.76851	52
901	50	enhance	68.713005	53
901	75	enhance	67.97967	54
901	176	enhance	67.28368	55
901	593	enhance	66.790245	56
901	285	enhance	66.471245	57
901	86	enhance	66.21374	58
901	39	enhance	65.24754	59
901	28	enhance	64.8099	60
901	78	enhance	64.38584	61
901	88	enhance	64.00502	62
901	66	enhance	63.639004	63
901	31	enhance	63.612713	64
901	34	enhance	63.33482	65
901	18	enhance	62.016605	66
901	63	enhance	61.063087	67
901	219	enhance	59.4666	68
901	488	enhance	59.459995	69
901	98	enhance	59.084415	70
901	43	enhance	58.93612	71
901	171	enhance	58.864708	72
901	94	enhance	58.151234	73
901	20	enhance	56.835594	74
901	95	enhance	55.536114	75
901	868	enhance	55.473244	76
901	35	enhance	54.65618	77
901	182	enhance	54.298416	78
901	82	enhance	53.86776	79
901	41	enhance	53.790707	80
901	44	enhance	53.33184	81
901	59	enhance	52.106686	82
901	30	enhance	51.40649	83
901	222	enhance	51.248928	84
901	5	enhance	50.691418	85
901	99	enhance	50.68276	86
901	4	enhance	50.505188	87
901	67	enhance	50.191082	88
901	47	enhance	50.18438	89
901	12	enhance	49.172665	90
901	73	enhance	48.99535	91
901	335	enhance	48.75923	92
901	51	enhance	48.690804	93
901	49	enhance	48.491924	94
901	55	enhance	48.391968	95
901	184	enhance	48.002262	96
901	69	enhance	48.0009	97
901	9	enhance	46.481922	98
901	85	enhance	45.86477	99
901	3	enhance	45.72453	100
901	22	enhance	44.17121	101
901	23	enhance	43.051685	102
901	21	enhance	42.521812	103
901	83	enhance	41.889065	104
901	96	enhance	41.568474	105
901	640	enhance	40.90494	106
901	230	enhance	40.433422	107
901	70	enhance	40.404408	108
901	45	enhance	40.322624	109
901	61	enhance	40.176735	110
901	13	enhance	39.637894	111
901	72	enhance	38.048622	112
901	60	enhance	37.748894	113
901	11	enhance	37.706673	114
901	93	enhance	37.580887	115
901	2	enhance	37.099754	116
901	79	enhance	35.699333	117
901	64	enhance	34.24328	118
901	126	enhance	33.554253	119
901	33	enhance	32.282074	120
901	91	enhance	32.166206	121
901	90	enhance	31.365353	122
901	74	enhance	30.525528	123
901	80	enhance	21.961256	124
901	91	soften	100	1
901	11	soften	99.848206	2
901	90	soften	93.9325	3
901	93	soften	93.772606	4
901	126	soften	92.40301	5
901	79	soften	91.498	6
901	55	soften	91.25322	7
901	3	soften	91.10477	8
901	96	soften	90.931625	9
901	184	soften	90.522804	10
901	22	soften	88.15594	11
901	23	soften	88.07685	12
901	21	soften	87.93887	13
901	4	soften	86.66836	14
901	868	soften	86.34142	15
901	59	soften	84.51319	16
901	2	soften	84.191216	17
901	9	soften	83.94581	18
901	85	soften	83.05932	19
901	44	soften	83.0008	20
901	12	soften	82.453156	21
901	99	soften	82.09268	22
901	219	soften	82.014366	23
901	171	soften	81.75057	24
901	82	soften	81.59324	25
901	182	soften	80.98632	26
901	34	soften	79.848656	27
901	35	soften	79.51813	28
901	18	soften	79.277466	29
901	30	soften	78.83779	30
901	63	soften	78.808105	31
901	39	soften	78.77783	32
901	69	soften	78.26659	33
901	66	soften	77.402824	34
901	28	soften	77.322044	35
901	50	soften	75.92463	36
901	176	soften	75.653854	37
901	285	soften	75.446365	38
901	27	soften	73.03173	39
901	64	soften	72.44838	40
901	10	soften	70.92798	41
901	74	soften	70.45639	42
901	7	soften	70.42391	43
901	54	soften	70.404816	44
901	8	soften	70.335754	45
901	58	soften	69.41727	46
901	455	soften	69.28545	47
901	80	soften	68.91776	48
901	488	soften	68.819496	49
901	52	soften	68.20354	50
901	60	soften	68.15621	51
901	647	soften	65.56692	52
901	72	soften	65.2575	53
901	14	soften	64.88362	54
901	83	soften	64.15184	55
901	70	soften	63.6274	56
901	6	soften	62.375904	57
901	335	soften	61.282185	58
901	45	soften	60.417606	59
901	13	soften	59.43148	60
901	49	soften	58.27586	61
901	5	soften	58.033253	62
901	94	soften	57.55423	63
901	33	soften	57.53134	64
901	78	soften	57.03666	65
901	20	soften	56.612007	66
901	640	soften	56.07134	67
901	222	soften	56.044292	68
901	61	soften	55.924026	69
901	43	soften	55.62419	70
901	73	soften	55.13713	71
901	230	soften	55.017242	72
901	41	soften	54.99982	73
901	593	soften	54.94637	74
901	95	soften	54.315228	75
901	51	soften	53.706295	76
901	92	soften	52.538128	77
901	47	soften	52.32681	78
901	86	soften	51.42354	79
901	31	soften	51.213013	80
901	98	soften	50.810955	81
901	67	soften	50.435932	82
901	84	soften	49.349197	83
901	24	soften	48.39111	84
901	88	soften	48.2878	85
901	56	soften	48.173	86
901	187	soften	48.020336	87
901	89	soften	47.503635	88
901	108	soften	47.227398	89
901	19	soften	47.157734	90
901	1	soften	47.108208	91
901	36	soften	45.32679	92
901	87	soften	44.641747	93
901	62	soften	44.382515	94
901	785	soften	44.05321	95
901	65	soften	44.042515	96
901	185	soften	43.60331	97
901	26	soften	42.91007	98
921	81	enhance	100	1
921	185	enhance	96.96217	2
921	62	enhance	96.884796	3
921	14	enhance	94.49281	4
921	65	enhance	94.33239	5
921	26	enhance	94.27141	6
921	42	enhance	92.87422	7
921	53	enhance	92.80531	8
921	54	enhance	91.881	9
921	77	enhance	91.26233	10
921	100	enhance	91.25509	11
921	38	enhance	90.4572	12
921	455	enhance	90.40705	13
921	32	enhance	90.37367	14
921	29	enhance	90.16291	15
921	16	enhance	89.93554	16
921	76	enhance	88.64974	17
921	785	enhance	87.408875	18
921	6	enhance	87.040794	19
921	24	enhance	86.55925	20
921	37	enhance	86.558266	21
921	901	enhance	85.842285	22
921	488	enhance	85.20745	23
921	647	enhance	84.63716	24
921	358	enhance	84.45278	25
921	8	enhance	84.23709	26
921	18	enhance	83.325615	27
921	57	enhance	82.00719	28
921	52	enhance	81.7824	29
921	97	enhance	80.9161	30
921	17	enhance	80.65957	31
921	28	enhance	79.79274	32
921	58	enhance	79.6607	33
921	89	enhance	79.39251	34
921	95	enhance	77.4583	35
921	27	enhance	77.151306	36
921	20	enhance	76.313896	37
921	56	enhance	74.86626	38
921	35	enhance	74.383644	39
921	71	enhance	74.01112	40
921	66	enhance	73.46717	41
921	187	enhance	73.43304	42
921	593	enhance	73.3217	43
921	171	enhance	73.30549	44
921	78	enhance	72.9076	45
921	108	enhance	72.29328	46
921	219	enhance	71.87476	47
921	10	enhance	71.82403	48
921	7	enhance	71.136246	49
921	50	enhance	70.783745	50
921	19	enhance	69.98229	51
921	34	enhance	69.26017	52
921	15	enhance	68.107376	53
921	69	enhance	67.521965	54
921	85	enhance	66.918465	55
921	12	enhance	66.84758	56
921	1	enhance	66.22349	57
921	48	enhance	66.05695	58
921	87	enhance	65.88367	59
921	73	enhance	64.67378	60
921	68	enhance	64.055145	61
921	59	enhance	63.99159	62
921	82	enhance	63.911438	63
921	5	enhance	63.817616	64
921	36	enhance	63.31201	65
921	46	enhance	63.086098	66
921	41	enhance	63.045574	67
921	21	enhance	62.627926	68
921	84	enhance	62.444244	69
921	39	enhance	60.3641	70
921	40	enhance	59.82822	71
921	63	enhance	59.61137	72
921	79	enhance	59.18275	73
921	176	enhance	58.90781	74
921	882	enhance	58.839985	75
921	335	enhance	58.457638	76
921	155	enhance	58.164112	77
921	43	enhance	57.6537	78
921	25	enhance	56.959476	79
921	9	enhance	56.775894	80
921	86	enhance	56.69184	81
921	30	enhance	56.281334	82
921	31	enhance	55.4739	83
921	92	enhance	54.9293	84
921	23	enhance	54.784893	85
921	285	enhance	54.375816	86
921	94	enhance	54.13225	87
921	88	enhance	53.92349	88
921	96	enhance	53.76634	89
921	98	enhance	53.17245	90
921	184	enhance	52.92531	91
921	75	enhance	52.78399	92
921	4	enhance	52.176426	93
921	868	enhance	52.127525	94
921	182	enhance	52.049923	95
921	44	enhance	51.26601	96
921	49	enhance	49.93791	97
921	2	enhance	49.76326	98
921	45	enhance	49.532394	99
921	55	enhance	47.002197	100
921	22	enhance	46.26087	101
921	74	enhance	45.6995	102
921	3	enhance	45.304596	103
921	99	enhance	44.86555	104
921	47	enhance	41.68865	105
921	230	enhance	40.184635	106
921	83	enhance	40.073902	107
921	70	enhance	39.114983	108
921	93	enhance	38.800365	109
921	64	enhance	38.283688	110
921	61	enhance	38.122448	111
921	11	enhance	38.06276	112
921	91	enhance	37.316517	113
921	126	enhance	37.171726	114
921	60	enhance	36.73666	115
921	80	enhance	36.072685	116
921	222	enhance	34.595455	117
921	72	enhance	32.19014	118
921	90	enhance	31.526579	119
921	13	enhance	31.467821	120
921	640	enhance	31.10054	121
921	67	enhance	30.954273	122
921	51	enhance	29.596386	123
921	33	enhance	27.292719	124
921	64	soften	100	1
921	80	soften	98.81453	2
921	11	soften	98.06308	3
921	60	soften	96.27332	4
921	91	soften	96.182625	5
921	90	soften	95.72673	6
921	72	soften	95.42091	7
921	74	soften	94.94346	8
921	126	soften	94.75594	9
921	83	soften	93.331825	10
921	93	soften	92.87829	11
921	70	soften	92.297485	12
921	3	soften	91.31694	13
921	55	soften	90.94346	14
921	79	soften	89.985085	15
921	13	soften	89.54491	16
921	45	soften	88.563774	17
921	33	soften	87.96832	18
921	184	soften	87.62276	19
921	49	soften	87.18806	20
921	96	soften	86.03212	21
921	868	soften	85.44694	22
921	23	soften	85.38474	23
921	640	soften	85.03439	24
921	99	soften	84.91423	25
921	4	soften	84.84502	26
921	22	soften	84.83368	27
921	2	soften	84.817375	28
921	222	soften	84.75007	29
921	61	soften	84.69889	30
921	182	soften	84.39501	31
921	94	soften	84.176674	32
921	335	soften	83.50818	33
921	21	soften	83.3281	34
921	43	soften	83.026825	35
921	230	soften	82.82707	36
921	30	soften	82.692665	37
921	34	soften	82.09273	38
921	44	soften	81.99979	39
921	59	soften	81.828606	40
921	51	soften	81.61324	41
921	82	soften	81.35757	42
921	73	soften	81.15815	43
921	63	soften	81.15345	44
921	9	soften	81.07643	45
921	5	soften	80.91961	46
921	39	soften	80.66557	47
921	78	soften	79.93032	48
921	285	soften	79.717	49
921	171	soften	79.691635	50
921	47	soften	78.94259	51
921	219	soften	78.93777	52
921	12	soften	78.74734	53
921	85	soften	78.634705	54
921	92	soften	78.62526	55
921	593	soften	78.42915	56
921	28	soften	78.35365	57
921	176	soften	78.31494	58
921	31	soften	78.1793	59
921	98	soften	78.16077	60
921	18	soften	78.00723	61
921	50	soften	77.80874	62
921	20	soften	77.45861	63
921	66	soften	77.106064	64
921	67	soften	77.053986	65
921	35	soften	76.054855	66
921	86	soften	75.99139	67
921	41	soften	75.37896	68
921	69	soften	74.48793	69
921	88	soften	74.10409	70
921	95	soften	74.09107	71
921	187	soften	73.74973	72
921	7	soften	73.7275	73
921	27	soften	73.55803	74
921	84	soften	73.54771	75
921	56	soften	72.861404	76
921	10	soften	72.356834	77
921	89	soften	71.56634	78
921	54	soften	71.410095	79
921	108	soften	71.37584	80
921	1	soften	71.23696	81
921	8	soften	70.497505	82
921	19	soften	70.38156	83
921	455	soften	69.925026	84
921	24	soften	69.84915	85
921	52	soften	69.77323	86
921	58	soften	68.73477	87
921	36	soften	68.64258	88
921	647	soften	68.24859	89
921	40	soften	68.21141	90
921	25	soften	67.66095	91
921	87	soften	67.17925	92
921	488	soften	66.16074	93
921	785	soften	65.38842	94
921	6	soften	64.52365	95
921	62	soften	64.36783	96
921	14	soften	64.20938	97
921	185	soften	64.11275	98
921	26	soften	64.07385	99
921	901	soften	62.5072	100
921	65	soften	61.910957	101
\.


--
-- PostgreSQL database dump complete
--


